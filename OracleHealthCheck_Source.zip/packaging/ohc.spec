# -*- mode: python ; coding: utf-8 -*-
# Build from the project root:
#     python -m PyInstaller --noconfirm --clean packaging\ohc.spec
# Result: dist\OracleHealthCheck\  (OracleHealthCheck.exe + _internal\)
from pathlib import Path

ROOT = Path(SPECPATH).parent

a = Analysis(
    [str(ROOT / "ohc" / "__main__.py")],
    pathex=[str(ROOT)],
    binaries=[],
    datas=[],  # intentionally empty: the SQL is inside the generated Python module, not loose files
    hiddenimports=[],
    hookspath=[],
    runtime_hooks=[],
    excludes=["tkinter"],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="OracleHealthCheck",
    console=False,  # windowed GUI application
    upx=False,      # UPX packing raises antivirus false positives
    icon=str(ROOT / "packaging" / "ohc.ico"),  # the Oracle health-check icon (EXE file icon)
    contents_directory="bin",
)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name="OracleHealthCheck")