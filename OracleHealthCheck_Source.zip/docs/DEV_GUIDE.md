# Oracle Health Check (Python) - Development Guide

**Status:** development scaffold. Only the application shell, the bundled SQL scripts and the
packaging pipeline exist. The Oracle health checks, credential protection, configuration files
and other features are **not implemented yet** (see section 12 and `docs\STATUS.md`).

All commands are PowerShell, run from the project root. They call the virtual environment's
Python directly, so no activation and no execution-policy change is needed:

```powershell
$proj = 'D:\tool_exe\OracleHC_PY'; $py = "$proj\.venv\Scripts\python.exe"; Set-Location $proj
```

## 1. Project structure

| Path | Responsibility |
|---|---|
| `ohc\` | The application package (this is what gets packaged into the EXE) |
| `ohc\__init__.py` | `__version__` (bump it for a release) |
| `ohc\__main__.py` | Entry point for `python -m ohc` and for PyInstaller |
| `ohc\app.py` | Starts the GUI; command-line switches `--selftest` and `--verify-sql` (`--out FILE`) |
| `ohc\paths.py` | `is_frozen()` and `app_root()` (the install root, found from the EXE location) |
| `ohc\security\identity.py` | `current_identity()`: the Windows account SID (authoritative), name and domain from the process token (`ctypes`) |
| `ohc\userstore.py` | Finds or creates `user\<label>\` (found by SID; the folder name is only a label) and validates `owner.json` |
| `ohc\security\dpapi.py` | Windows DPAPI (CurrentUser) through `ctypes`: `protect()`, `unprotect()`, `wipe()`; no PowerShell |
| `ohc\security\credstore.py` | Encrypted per-database credential files `credentials\<database-id>.dat`: save, load, delete, quarantine of unreadable files |
| `tools\cred_probe.py` | Developer helper for the credential store, run as `python -m tools.cred_probe` (hidden password prompt, prints only lengths) |
| `ohc\config\thresholds.py` | Shared `config\thresholds.json`: 22 validated keys, immutable run snapshot with SHA-256, atomic save |
| `ohc\config\environment.py` | Shared `config\environment.json`: default Oracle Home (blank by default), NLS_LANG, report date format |
| `ohc\config\oracle_home.py` | Oracle Home syntax check, sqlplus/dgmgrl inspection, priority resolution, read-only detection |
| `ohc\config\databases.py` | Per-user `databases.json` store (no secrets) |
| `ohc\config\settings.py` | Per-user `settings.json` store (theme, default database) |
| `ohc\config\dbadmin.py` | Add, update and delete databases together with their encrypted credentials |
| `ohc\config\jsonio.py` | Shared JSON helpers: duplicate-key detection, atomic writes |
| `ohc\gui\theme.py` | Light and dark palettes, the stylesheet, sun/moon icons and `ThemeManager` |
| `ohc\gui\settings_page.py` | Settings page: Oracle Home, databases, retention, theme |
| `ohc\gui\database_dialog.py` | Add / Edit database dialog (including the encrypted login) |
| `ohc\gui\context.py` | Shared config paths and the current user's stores |
| `ohc\gui\main_window.py` | Main window, left navigation, theme toggle header, the `PAGES` list |
| `ohc\resources\sql_bundle.py` | **Generated** SQL bundle. Never edit by hand |
| `ohc\resources\sql_access.py` | `get_sql()`, `list_sql()`, `verify()`, `bundle_sha256()` |
| `sql_src\` | The 51 original SQL scripts (development only, never shipped) |
| `tools\gen_sql_bundle.py` | Generates / checks the SQL bundle |
| `tools\sql_baseline.py` | Compares `sql_src` with the original baseline plus approved changes |
| `tools\original_sql.sha256` | The ORIGINAL baseline from the supplied ZIP. **Never edit** |
| `tools\sql_changes.txt` | Approved, deliberate SQL changes |
| `tools\snapshot.py` | Git-free backup and change tracking |
| `tests\` | `unittest` tests |
| `packaging\ohc.spec` | PyInstaller recipe (one-folder, windowed, UPX off) |
| `docs\` | This guide and `STATUS.md` |
| `dev_home\` | Stand-in install root for development (not shipped, not backed up) |
| `requirements.txt`, `requirements-dev.txt` | Pinned dependencies (runtime / runtime + build) |
| `.venv\`, `build\`, `dist\` | Generated; excluded from snapshots |

Backups live next to the project in `D:\tool_exe\OracleHC_PY_backups`.

## 2. Development environment

- Windows 11 Pro 25H2, Python 3.14.7 64-bit (normal build, not free-threaded).
- Pinned: `PySide6-Essentials==6.12.0`, `shiboken6==6.12.0`, `pyinstaller==6.22.3`
  (full list in `requirements-dev.txt`). The runtime needs only PySide6; DPAPI will use `ctypes`.
- Create the environment from scratch (does not overwrite an existing `.venv`):

```powershell
python -m venv .venv
& $py -m pip install --only-binary=:all: -r requirements-dev.txt
& $py -m pip check
```

- VS Code uses the interpreter set in `.vscode\settings.json`.
- Upgrading a dependency: change its pin in the requirements file, reinstall, run all tests
  and checks, rebuild and repeat the packaged tests (section 8). Do not change Python or a pin
  silently when an install fails; investigate the error first.

## 3. Running the application and the tests

```powershell
& $py -m ohc                 # start the GUI in development mode
& $py -m ohc --selftest      # version, Qt, SQL bundle; "RESULT: OK" and exit code 0
& $py -m ohc --verify-sql    # SQL bundle integrity only
& $py -m unittest discover -s tests -t . -v
& $py tools\gen_sql_bundle.py --check
& $py tools\sql_baseline.py
```

Run the last three before every build and after every SQL or code change. All must pass.
Always run from the project root (the tests import `ohc` and `tools` from there).

## 4. The embedded SQL bundle

- The SQL is not shipped as `.sql` files. `tools\gen_sql_bundle.py` reads `sql_src\*.sql` as raw
  bytes and generates `ohc\resources\sql_bundle.py` (bytes + per-file SHA-256 + a bundle SHA-256).
  PyInstaller compiles that module into the application.
- Development and the packaged EXE use the same call: `sql_access.get_sql("v_tbs.sql")`. It
  re-hashes the script before returning it. `verify()` checks every script and the bundle hash.
- The bundle SHA-256 is the hash of the sorted `<sha256>  <name>` list. For the unmodified
  originals it equals the original baseline hash
  `9fd617ca86797d557d249b32ae61a72198e56f2ed1a7dfc0cb689620f779ac62`. After an approved SQL change the
  bundle hash differs from this value; that is expected.
- All 51 original scripts use LF line endings and no BOM. The generator rejects a BOM and warns on CR bytes.
- **Limits:** this prevents casual or accidental modification and detects corruption. It does
  not stop a determined user with administrator rights from extracting the SQL or replacing the
  application. Code signing and folder permissions are separate controls.

```powershell
& $py tools\gen_sql_bundle.py            # regenerate the bundle
& $py tools\gen_sql_bundle.py --check    # verify it is current (writes nothing)
& $py -m ohc.resources.sql_access        # verify the bundled content
```

## 5. Editing and adding SQL

Never edit `tools\original_sql.sha256` or `ohc\resources\sql_bundle.py`.

**Change an existing query**

1. Edit `sql_src\<name>.sql` in VS Code (LF line endings, UTF-8 without BOM).
2. `& $py tools\sql_baseline.py --suggest` prints a ready-to-paste line.
3. Paste it into `tools\sql_changes.txt` and replace the `REASON:` text with a real reason
   (at least 10 characters: what, why, date). Format: `ACTION | filename | sha256 | reason`.
4. `& $py tools\gen_sql_bundle.py`
5. `& $py -m unittest discover -s tests -t . -v` must say `OK`.
6. `& $py tools\snapshot.py -m "changed <name>.sql: <why>"`
7. Rebuild the package at the next milestone (section 7).

**Edit the same file again:** run `--suggest` again, update the hash on the existing line and
append to its reason. One line per file, never two.

**Add a query:** create `sql_src\<new_name>.sql` (letters, digits, `_`, `-`, `.`, ending in `.sql`);
the suggested action is `ADDED`. Using it in a check is a separate code change.

**Remove an original query:** delete it from `sql_src`; record `REMOVED | name.sql | - | reason`.

The tests fail on purpose when the bundle is stale, when a change is unrecorded, when a recorded
file changes again, or when a record is stale or has no real reason.

## 6. Configuration and data locations

**Exists today:** `ohc\paths.py` finds the install root: the folder of the EXE when packaged
(the `OHC_DEV_HOME` override is ignored there), otherwise `dev_home\` (or the folder named by
`OHC_DEV_HOME`).

`ohc\security\identity.py` reads the account SID from the process token. `ohc\userstore.py` finds the
folder whose `owner.json` carries that SID (so a renamed account keeps its folder), or creates
`user\<label>\` with `owner.json`, `credentials\` and `files\work\`. A folder owned by a different SID is
refused (`OwnershipError`); a corrupt `owner.json` is reported (`CorruptOwnerFileError`) and never
modified or deleted. `--selftest` only reads this state and creates nothing. Nothing else is read
from or written to the root yet.

`ohc\security\dpapi.py` wraps Windows DPAPI (CurrentUser scope). `ohc\security\credstore.py` stores each database's
username and password together in `credentials\<database-id>.dat`, bound to the database id. An unreadable file is
never deleted: a re-save keeps it as `.corrupt-<time>`. The Settings page uses them; `--selftest` runs a DPAPI
round trip on dummy data. Use `python -m tools.cred_probe` for manual checks.

Shared configuration (next to the EXE, edited with any editor or the Settings page): `config\thresholds.json`
(22 keys, including `RETENTION_DAYS`) and `config\environment.json` (default Oracle Home, NLS_LANG, report date
format). Create them with `python -m ohc.config.thresholds --write-default PATH` and
`python -m ohc.config.environment --write-default PATH`; list every problem in a file with `--check PATH`. Neither
is created or defaulted silently. Copy the project's `config` folder next to the EXE when deploying; `--selftest`
reports both files. Per user: `settings.json` (theme: the default is dark, saved when you click the sun/moon
toggle or change the Settings page) and `databases.json`. Oracle Home priority: the database's override, then the
shared default. Logs and reports use the fixed folders `logs` and `reports` under the install root.

**Agreed design, NOT implemented yet:**

- Shared, next to the EXE: `config\thresholds.json` and `config\environment.json` exist (see above); `logs\`,
  `reports\<date>\` and `history\` are NOT implemented yet.
- Per Windows user: the folder, `owner.json`, `settings.json`, `databases.json`, `credentials\` and the credential
  library exist and are used by the Settings page. NOT implemented yet: the per-run folders `files\work\<run-id>\`.
- The per-database Oracle Home override lives in the user's `databases.json`.
- The install root must always be derived from the EXE location, never hardcoded to `D:\`.

## 7. Building the one-folder package

Close any running instance first (an open window locks `dist\`). Build at milestones, not after
every small edit.

```powershell
& $py -m unittest discover -s tests -t .
& $py tools\gen_sql_bundle.py --check
& $py tools\sql_baseline.py
& $py -m PyInstaller --noconfirm --clean packaging\ohc.spec 2>&1 | Tee-Object -FilePath 'D:\tool_exe\ohc_build_log.txt'
```

Result: `dist\OracleHealthCheck\` containing `OracleHealthCheck.exe` and `_internal\`.
Step 0.5 result on this machine: about 44.6 s, about 94.5 MB, 160 files, EXE about 2.1 MB.
`--clean` empties `build\`, so keep the build log outside the project (as above).

## 8. Testing the packaged application

```powershell
$dist = "$proj\dist\OracleHealthCheck"
"loose .sql / sql_bundle files: {0}" -f (Get-ChildItem $dist -Recurse -Force -File | Where-Object { $_.Extension -ieq '.sql' -or $_.Name -like 'sql_bundle*' } | Measure-Object).Count
$out = "$proj\build\selftest_packaged.txt"
$p = Start-Process -FilePath "$dist\OracleHealthCheck.exe" -ArgumentList '--selftest','--out',$out -Wait -PassThru
"exit code: $($p.ExitCode)"; Get-Content $out
Start-Process "$dist\OracleHealthCheck.exe"      # visual check, then close the window
```

Expected: `loose ... files: 0`, `exit code: 0`, `frozen: True`, the Qt line with
`platform plugin: windows`, `SQL bundle OK: 51 scripts, sha256 ...` and `RESULT: OK`.
The windowed EXE has no console, which is why `--out FILE` exists.

Relocation test: copy `dist\OracleHealthCheck` to another folder, run `--selftest` there
and confirm `app root:` shows the new folder. A test on a second Windows machine or VM without
Python is the real check for "no Python needed" and for endpoint-security behaviour.

## 9. Distributing to another Windows machine

- Copy the **whole** `dist\OracleHealthCheck\` folder (`OracleHealthCheck.exe` plus `_internal\`).
  The EXE alone does not work.
- Do not copy `.venv`, `sql_src`, `tools`, `tests`, `build`, backups or `dev_home`.
- No Python installation is needed on the target machine.
- The Oracle checks will later need `sqlplus.exe` (and `dgmgrl.exe` for Data Guard checks) from an
  Oracle client or server installation; they are not used yet.
- Only Windows 11 Pro 25H2 has been tested so far. Antivirus/EDR behaviour on other machines is untested.

## 10. Backups and change tracking (no Git)

```powershell
& $py tools\snapshot.py -m "what I just did"   # new zip + manifest in D:\tool_exe\OracleHC_PY_backups
& $py tools\snapshot.py --diff                 # changes since the latest snapshot
& $py tools\snapshot.py --list
```

Snapshots are never overwritten. They exclude `.venv`, `build`, `dist`, `__pycache__`, `dev_home`,
`.git`, `*.pyc` and `*.dat`. The backup folder is on the same disk: copy it to another drive or a
network share regularly. Take a snapshot before and after each milestone.

## 11. Troubleshooting

| Symptom | Cause and fix |
|---|---|
| `No module named 'ohc'` or `'tools'` | Run from the project root; run tests with `-s tests -t .` |
| `elseif` / `else` "is not recognized" when pasting | Keep `} elseif` and `} else {` on the same line as the closing brace and paste the whole block |
| `SKIP (exists)` from `Write-NewFile` | Safety feature: it never overwrites. Delete the file first only if you really want to replace it |
| Test says `sql_bundle.py is out of date` | Run `tools\gen_sql_bundle.py` |
| `sql_baseline` reports `UNAPPROVED CHANGED` | Record the change in `tools\sql_changes.txt` (section 5) |
| Generator error about a BOM | Re-save the file as UTF-8 without BOM |
| Generator warning about CR bytes | Switch the file to LF (VS Code status bar, `CRLF` -> `LF`) |
| pip: no matching distribution with `--only-binary` | No wheel for this Python/package. Do not silently downgrade; investigate |
| PyInstaller `PermissionError` on `dist\` | Close the running EXE and any Explorer window on it; wait for antivirus scanning; retry |
| EXE starts and exits, or no window | Run `--selftest --out FILE` and read the file; check the exit code |
| `Could not find the Qt platform plugin "windows"` | The EXE was moved without `_internal\`, or the build is stale: rebuild with `--clean` |
| Antivirus quarantines the build | Note the product and detection name; do not disable protection without approval; request an exclusion by file hash; code signing will help later |
| `FileExistsError` from `snapshot.py` | Two snapshots in the same second; wait and retry |
| GUI changes not visible in the EXE | The EXE only changes after a rebuild (section 7) |
| `OwnershipError` ... SID mismatch | The user folder belongs to another Windows account (recreated account or same name on another domain). It is never used; an administrator renames or removes it |
| `CorruptOwnerFileError` | `owner.json` is unreadable. The file is kept unchanged; fix it or move the folder aside after checking whose it is |
| `IndentationError` after a manual edit | VS Code can re-indent multi-line pastes. Check with `& $py -m py_compile <file>`; prefer the scripted patches; restore from a snapshot if needed |
| `CredentialUnreadableError` (decrypt) | The credentials belong to another Windows account, or the profile was reset. The file is left unchanged; re-enter the credentials (a re-save keeps the old file as `.corrupt-<time>`) |
| `CredentialUnreadableError` (format) | The credential file is damaged. Loading never modifies it; re-enter the credentials |
| Settings: "Oracle Home is not configured" | A blank default is intentional. Use Browse or Detect, or set an Oracle Home per database |
| Settings: thresholds.json or environment.json invalid or not found | Fix the named key, or copy the project's `config` folder next to the EXE. `python -m ohc.config.thresholds --check PATH` lists every problem |

## 12. Not yet production-ready

The current application is a shell. The following must still be implemented, tested against the
original BAT tool and verified on Windows before it is production-ready:

- The 21 health checks (IDs 0-20), the three execution modes, skip rules, statuses and exit codes.
- SQL*Plus and DGMGRL execution, Data Guard parsing and the server-specification check.
- HTML reports, logs, run history and retention cleanup, with the BAT's naming and formats.
- AWR, ASH and ADDM reports.
- Using the validated configuration in runs: recording the thresholds snapshot in history and the retention cleanup (the files, validation and Settings page exist).
- Connection testing, run cancellation and headless execution.
- Release hardening: code signing, version information, and antivirus/EDR and clean-machine testing.