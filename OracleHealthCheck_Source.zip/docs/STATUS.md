# Oracle Health Check (Python) - Project Status

Living log. Update it at every checkpoint with ACTUAL results (never with expected ones).
Environment: Windows 11 Pro 25H2, Python 3.14.7 64-bit, PySide6 6.12.0 / Qt 6.12.0, PyInstaller 6.22.3.
Project: `D:\tool_exe\OracleHC_PY`. The C# application is untouched and remains the fallback.

## Checkpoints

| Step | Result (as reported from the Windows machine) |
|---|---|
| 0.1 Environment | Python 3.14.7 AMD64, GIL enabled; PySide6 6.12.0, Qt 6.12.0, PyInstaller 6.22.3 installed; `pip check` clean; venv about 240 MB |
| 0.2 Skeleton | Pinned requirements, folder skeleton, `.gitignore`, `.vscode\settings.json`; `import ohc` works |
| 0.3 SQL baseline | 51 scripts copied from the original ZIP; 0 mismatches; baseline file SHA-256 `9fd617ca86797d557d249b32ae61a72198e56f2ed1a7dfc0cb689620f779ac62`; the ZIP hash matched the one inspected; all 51 scripts are LF-only |
| 0.4 SQL bundle | Bundle generated; bundle SHA-256 equals the baseline hash; 23 tests passed; snapshot `OracleHC_PY_20261011_120358` (68 files, 41 KB) |
| 0.5 GUI shell and package | 33 tests passed; PyInstaller build about 44.6 s; `dist\OracleHealthCheck` about 94.5 MB, 160 files, EXE about 2.1 MB; no loose `.sql` or `sql_bundle*` files; packaged `--selftest`: exit 0, `frozen: True`, 51 scripts verified, `RESULT: OK`; packaged GUI launched; relocated copy with restricted `PATH`: exit 0, correct app root; snapshot `OracleHC_PY_20261011_153513` (75 files, 47 KB) |
| 0.6 Documentation | `docs\DEV_GUIDE.md`, `docs\STATUS.md`, `tests\test_docs.py` created; 40 tests passed (7 new doc tests); `gen_sql_bundle.py --check` and `sql_baseline.py` OK; snapshot `OracleHC_PY_20261011_154511` (78 files, 56 KB) |
| 3.1 Identity and user folder | 71 tests passed (2 non-Windows skips); the token-based SID matched `whoami /user` on an Azure AD account (SID prefix `S-1-12-1`); `dev_home\user\<account>\` created then reused; SID mismatch refused (exit 1); corrupt `owner.json` reported and left unchanged (exit 1); snapshot `OracleHC_PY_20261011_213018` (83 files, 64 KB). A manual edit of `ohc\app.py` lost its indentation and was repaired with a script |
| 4.1 DPAPI wrapper | `ohc\security\dpapi.py` and `tests\test_dpapi.py`: 14 tests passed with only the non-Windows test skipped, so all 8 real-DPAPI tests ran; full suite 85 tests OK (3 skips) |
| 4.2 Credential store | `ohc\security\credstore.py`, `tools\cred_probe.py`, `tests\test_credstore.py`: 24 tests passed with none skipped (3 real-DPAPI store tests ran); full suite 109 tests OK (3 skips). The optional real-file check with `cred_probe` was not run |
| 4.3 Packaged verification | `--selftest` gained a DPAPI round-trip block (dummy in-memory data); 111 tests OK (4 skips); build 103 s (Step 0.5 took 44.6 s); package 94.5 MB and 160 files (unchanged); no loose `.sql`, `sql_bundle*` or `cred_probe*` files; packaged `--selftest`: exit 0, `frozen: True`, SID shown, DPAPI round trip OK (318-byte blob), 51 scripts verified, `RESULT: OK`; the self-test created no `user` folder. Snapshot result not reported at the time of writing |
| 5.1 Thresholds file | `ohc\config\thresholds.py` and `tests\test_thresholds.py`: 27 tests passed; full suite 138 tests OK (4 skips); the default file's sha256 starts with 4e0de7eb; three deliberately invalid copies were rejected with exit code 1 |
| 5.2-5.4 Configuration, Settings page, themes | Delivered as one bundle: `environment.json`, Oracle Home logic, per-user `settings.json` and `databases.json`, database manager with encrypted logins, Settings page, light/dark theme with sun/moon toggle. **Windows results not reported yet.** Update this row when they are |

## Modified files in the latest step (Phase 5)

Created: `ohc\config\jsonio.py`, `ohc\config\oracle_home.py`, `ohc\config\environment.py`, `ohc\config\databases.py`,
`ohc\config\settings.py`, `ohc\config\dbadmin.py`, `ohc\gui\theme.py`, `ohc\gui\context.py`, `ohc\gui\database_dialog.py`,
`ohc\gui\settings_page.py`, `tests\test_config_files.py`, `tests\test_gui_phase5.py`.
Modified: `ohc\gui\main_window.py` (replaced), `ohc\app.py` (config check in `--selftest`, per-user context in the GUI start),
`docs\DEV_GUIDE.md`, `docs\STATUS.md`. No EXE rebuild yet (planned at the end of Phase 5).

## Known issues and open items

- The application is a GUI shell with placeholder pages; none of the real features exist yet (see the last section of `docs\DEV_GUIDE.md`).
- Not reported yet: antivirus/EDR behaviour of the build or EXE, a test on a second Windows machine without Python, and a visual comparison with the C# application.
- The restricted-`PATH` test shows the app and self-test start under that environment. It does not prove that Oracle client utilities work.
- The windowed EXE has no console. Before headless mode (Phase 10) decide between file-only output and a second console EXE sharing `_internal\`.
- Retention (Phase 7): decide whether history files follow `RETENTION_DAYS`, and confirm that reparse points are skipped during cleanup (a deliberate difference from the BAT).
- The Settings page, database dialog and theme toggle have not been checked visually on Windows yet.
- The Test Connection button is disabled until the SQL*Plus runner exists (Phase 6).
- `config\environment.json` is not created automatically; the Settings page creates it on Save, or use `python -m ohc.config.environment --write-default PATH`.
- Cross-account decryption (another Windows account opening a copied `.dat`) is covered by fake-backend tests only. `tools\cred_probe.py` cannot run under another account because the venv's Python lives in the first account's profile.
- Python `str` copies of passwords (from `getpass` or a GUI field) cannot be wiped; the credential store wipes everything it creates itself.
- Identity was verified on one Azure AD account only. A classic local or domain account and a second Windows account were not tested. The identity code was verified inside the packaged EXE (Phase 4 build).

## Next task (proposed)

Phase 6: SQL*Plus and DGMGRL runner (original `@file` approach, credentials through stdin), connection test and check 1.
Needs an Oracle test server. The plan is proposed; implementation waits for approval.
