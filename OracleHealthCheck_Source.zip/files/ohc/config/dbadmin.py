"""Add, update and delete databases together with their encrypted credentials (no GUI code)."""
from __future__ import annotations

from dataclasses import replace

from ohc.config.databases import DatabaseEntry, DatabaseStore, DatabasesError, validate_entries
from ohc.security import credstore, dpapi


class DatabaseValidationError(DatabasesError):
    pass


def _need_credentials_dir(credentials_dir):
    if credentials_dir is None:
        raise DatabaseValidationError("Credential storage is not available (no per-user folder)")


def _check_login(username, password) -> None:
    for what, value in (("Username", username), ("Password", password)):
        if not isinstance(value, str) or not 1 <= len(value.encode("utf-8")) <= credstore.MAX_FIELD:
            raise DatabaseValidationError(f"{what} is required (1 to {credstore.MAX_FIELD} bytes)")


def add_database(store: DatabaseStore, credentials_dir, *, name, username, password, sid="", dg_service="",
                 oracle_home="", notes="", backend=dpapi) -> DatabaseEntry:
    """Credentials are saved first; if the list cannot be saved they are removed again."""
    _need_credentials_dir(credentials_dir)
    _check_login(username, password)
    entry = DatabaseEntry(credstore.new_database_id(), name.strip(), sid.strip(), dg_service.strip(), oracle_home.strip(), notes.strip())
    problems = validate_entries(store.entries() + [entry])
    if problems:
        raise DatabaseValidationError("; ".join(problems), problems)
    credstore.save_credentials(credentials_dir, entry.id, username, password, backend=backend)
    try:
        store.add(entry)
    except Exception:
        credstore.delete_credentials(credentials_dir, entry.id)
        raise
    return entry


def update_database(store: DatabaseStore, credentials_dir, db_id: str, *, username=None, password=None,
                    backend=dpapi, **fields) -> DatabaseEntry:
    """Blank username and password keep the stored credentials; otherwise both are required."""
    _need_credentials_dir(credentials_dir)
    old = store.get(db_id)
    if old is None:
        raise DatabaseValidationError("The database no longer exists")
    new_login = bool(username) or bool(password)
    if new_login:
        _check_login(username, password)
    new = replace(old, **{k: v.strip() for k, v in fields.items()})
    store.update(new)
    if new_login:
        try:
            credstore.save_credentials(credentials_dir, db_id, username, password, backend=backend)
        except Exception:
            store.update(old)
            raise
    return new


def delete_database(store: DatabaseStore, credentials_dir, db_id: str) -> DatabaseEntry:
    """Removes the encrypted credentials first, then the list entry."""
    _need_credentials_dir(credentials_dir)
    entry = store.get(db_id)
    if entry is None:
        raise DatabaseValidationError("The database no longer exists")
    credstore.delete_credentials(credentials_dir, db_id)
    store.delete(db_id)
    return entry
