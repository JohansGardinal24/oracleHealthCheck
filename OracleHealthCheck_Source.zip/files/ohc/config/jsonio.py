"""JSON helpers shared by the config modules: duplicate-key detection, one retry, atomic writes."""
from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

_sleep = time.sleep  # replaced in tests


class ConfigFileError(RuntimeError):
    def __init__(self, message: str, problems=()):
        super().__init__(message)
        self.problems = list(problems)


def _no_duplicates(pairs):
    seen = {}
    for k, v in pairs:
        if k in seen:
            raise ValueError(f"duplicate key '{k}'")
        seen[k] = v
    return seen


def parse_object(raw: bytes) -> dict:
    try:
        doc = json.loads(raw.decode("utf-8-sig"), object_pairs_hook=_no_duplicates)
    except (UnicodeDecodeError, RecursionError):
        raise ValueError("not valid UTF-8 JSON") from None
    except ValueError as exc:
        text = str(exc)
        raise ValueError(text if text.startswith("duplicate key") else f"not valid JSON ({text})") from None
    if not isinstance(doc, dict):
        raise ValueError("the top level must be a JSON object")
    return doc


def read_object(path, *, retry: bool = True):
    """Return (doc, raw), or (None, None) if the file does not exist. Never writes."""
    path = Path(path)
    for attempt in (1, 2):
        try:
            raw = path.read_bytes()
        except FileNotFoundError:
            return None, None
        except OSError as exc:
            raise ConfigFileError(f"Cannot read {path.name}: {exc.strerror or type(exc).__name__}") from None
        try:
            return parse_object(raw), raw
        except ValueError as exc:
            if retry and attempt == 1 and str(exc).startswith("not valid"):  # an editor may still be writing
                _sleep(0.25)
                continue
            raise ConfigFileError(f"{path.name} is invalid: {exc}. The file was left unchanged.") from None


def write_atomic(path, doc: dict) -> str:
    """Temp file + replace. Returns the SHA-256 of the written bytes."""
    path = Path(path)
    data = (json.dumps(doc, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
    tmp = path.with_name(f"{path.name}.tmp{os.getpid()}")
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(tmp, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except OSError as exc:
        raise ConfigFileError(f"Cannot write {path.name}: {exc.strerror or type(exc).__name__}") from None
    finally:
        tmp.unlink(missing_ok=True)
    return hashlib.sha256(data).hexdigest()
