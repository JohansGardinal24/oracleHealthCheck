r"""Per-user database list: user\<account>\databases.json (no secrets; credentials live in credentials\<id>.dat).

A missing file means 'no databases yet'. An invalid file raises an error and is never overwritten.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, replace
from pathlib import Path

from ohc.config import jsonio
from ohc.config.jsonio import ConfigFileError
from ohc.config.oracle_home import check_home_syntax
from ohc.security.credstore import ID_RE

SCHEMA_VERSION = 1
MAX_DATABASES = 200
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,29}$")  # becomes part of log and report file names
SID_RE = re.compile(r"^[A-Za-z0-9_$#]{1,30}$")
SERVICE_RE = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")
NOTES_RE = re.compile(r"^[^\x00-\x1f\x7f]{0,200}$")
FIELDS = ("id", "name", "sid", "dg_service", "oracle_home", "notes")


class DatabasesError(ConfigFileError):
    pass


@dataclass(frozen=True)
class DatabaseEntry:
    id: str
    name: str
    sid: str = ""          # blank = same as the name (the BAT's default; SID_<name> was an override)
    dg_service: str = ""   # optional; appended as @service for DGMGRL
    oracle_home: str = ""  # optional override of the shared default
    notes: str = ""

    @property
    def effective_sid(self) -> str:
        return self.sid or self.name


def validate_entry(e: DatabaseEntry) -> list:
    problems = []
    if not isinstance(e.id, str) or not ID_RE.match(e.id):
        problems.append("id: invalid")
    for field in ("name", "sid", "dg_service", "oracle_home", "notes"):
        if not isinstance(getattr(e, field), str):
            problems.append(f"{field}: must be text")
    if problems:
        return problems
    if not NAME_RE.match(e.name):
        problems.append("Name: 1 to 30 letters, digits, _ or - (it is used in log and report file names)")
    if e.sid and not SID_RE.match(e.sid):
        problems.append("SID: letters, digits, _ $ # only (up to 30)")
    if e.dg_service and not SERVICE_RE.match(e.dg_service):
        problems.append("Data Guard service: letters, digits, _ . - only (up to 64)")
    if e.oracle_home and (msg := check_home_syntax(e.oracle_home)):
        problems.append(f"Oracle Home override: {msg}")
    if not NOTES_RE.match(e.notes):
        problems.append("Notes: up to 200 characters, no control characters")
    return problems


def validate_entries(entries) -> list:
    problems = []
    if len(entries) > MAX_DATABASES:
        problems.append(f"more than {MAX_DATABASES} databases")
    seen_ids, seen_names = set(), set()
    for e in entries:
        problems += [f"{getattr(e, 'name', '?')}: {p}" for p in validate_entry(e)]
        if e.id in seen_ids:
            problems.append(f"{e.name}: duplicate id")
        if str(e.name).lower() in seen_names:
            problems.append(f"{e.name}: a database with this name already exists")
        seen_ids.add(e.id)
        seen_names.add(str(e.name).lower())
    return problems


class DatabaseStore:
    """path=None keeps everything in memory (used when no per-user folder is available)."""

    def __init__(self, path=None):
        self.path = Path(path) if path is not None else None
        self._entries = []
        if self.path is not None:
            self._entries = self._load()

    def _load(self) -> list:
        doc, _raw = jsonio.read_object(self.path)
        if doc is None:
            return []
        problems = [f"unknown top-level key '{k}'" for k in sorted(set(doc) - {"schema_version", "databases"})]
        if doc.get("schema_version") != SCHEMA_VERSION or isinstance(doc.get("schema_version"), bool):
            problems.append(f"schema_version: must be {SCHEMA_VERSION}")
        items = doc.get("databases")
        entries = []
        if not isinstance(items, list):
            problems.append("'databases' is missing or is not a list")
        else:
            for n, item in enumerate(items, 1):
                if not isinstance(item, dict) or set(item) - set(FIELDS) or "id" not in item or "name" not in item:
                    problems.append(f"entry {n}: must be an object with id, name and optional sid, dg_service, oracle_home, notes")
                else:
                    entries.append(DatabaseEntry(**item))
            problems += validate_entries(entries)
        if problems:
            raise DatabasesError(f"{self.path.name} is invalid ({len(problems)} problem(s)):\n  - " + "\n  - ".join(problems), problems)
        return entries

    def entries(self) -> list:
        return list(self._entries)

    def get(self, db_id: str):
        return next((e for e in self._entries if e.id == db_id), None)

    def find_by_name(self, name: str):
        return next((e for e in self._entries if e.name.lower() == str(name).lower()), None)

    def _commit(self, new_entries: list) -> None:
        problems = validate_entries(new_entries)
        if problems:
            raise DatabasesError("Not saved: " + "; ".join(problems), problems)
        if self.path is not None:
            jsonio.write_atomic(self.path, {"schema_version": SCHEMA_VERSION,
                                            "databases": [{f: getattr(e, f) for f in FIELDS} for e in new_entries]})
        self._entries = new_entries

    def add(self, entry: DatabaseEntry) -> None:
        self._commit(self._entries + [entry])

    def update(self, entry: DatabaseEntry) -> None:
        if self.get(entry.id) is None:
            raise DatabasesError("The database no longer exists")
        self._commit([entry if e.id == entry.id else e for e in self._entries])

    def delete(self, db_id: str) -> None:
        if self.get(db_id) is None:
            raise DatabasesError("The database no longer exists")
        self._commit([e for e in self._entries if e.id != db_id])
