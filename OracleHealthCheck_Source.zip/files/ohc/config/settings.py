r"""Per-user settings: user\<account>\settings.json (theme, default database).

A missing file means defaults. An invalid file raises SettingsError and is never overwritten.
"""
from __future__ import annotations

from pathlib import Path

from ohc.config import jsonio
from ohc.config.jsonio import ConfigFileError
from ohc.security.credstore import ID_RE

SCHEMA_VERSION = 1
THEMES = ("dark", "light")
DEFAULTS = {"theme": "dark", "default_db": ""}  # first-time users get the dark theme, as before


class SettingsError(ConfigFileError):
    pass


def validate(values: dict) -> list:
    problems = [f"{k}: unknown setting" for k in sorted(set(values) - set(DEFAULTS))]
    if values.get("theme") not in THEMES:
        problems.append(f"theme: must be one of {', '.join(THEMES)}")
    db = values.get("default_db")
    if not isinstance(db, str) or (db and not ID_RE.match(db)):
        problems.append("default_db: must be empty or a database id")
    return problems


class SettingsStore:
    """path=None keeps the settings in memory only."""

    def __init__(self, path=None):
        self.path = Path(path) if path is not None else None
        self._values = dict(DEFAULTS)
        if self.path is not None:
            self._values = self._load()

    def _load(self) -> dict:
        doc, _raw = jsonio.read_object(self.path)
        if doc is None:
            return dict(DEFAULTS)
        stored = doc.get("settings")
        problems = [f"unknown top-level key '{k}'" for k in sorted(set(doc) - {"schema_version", "settings"})]
        if doc.get("schema_version") != SCHEMA_VERSION or isinstance(doc.get("schema_version"), bool):
            problems.append(f"schema_version: must be {SCHEMA_VERSION}")
        if not isinstance(stored, dict):
            problems.append("'settings' is missing or is not an object")
            values = dict(DEFAULTS)
        else:
            values = {**DEFAULTS, **stored}
            problems += validate(values)
        if problems:
            raise SettingsError(f"{self.path.name} is invalid ({len(problems)} problem(s)):\n  - " + "\n  - ".join(problems), problems)
        return values

    def values(self) -> dict:
        return dict(self._values)

    def get(self, key: str):
        return self._values[key]

    def set(self, key: str, value) -> None:
        new = {**self._values, key: value}
        problems = validate(new)
        if problems:
            raise SettingsError("Not saved: " + "; ".join(problems), problems)
        if self.path is not None:
            try:
                jsonio.write_atomic(self.path, {"schema_version": SCHEMA_VERSION, "settings": new})
            except ConfigFileError as exc:
                raise SettingsError(str(exc)) from None
        self._values = new
