r"""Shared environment settings: <install root>\config\environment.json.

ORACLE_HOME is the shared default (blank = not configured). A database can override it.
Strict like thresholds.json: a missing or invalid file is an error; saving is an explicit action.

    python -m ohc.config.environment --write-default PATH
    python -m ohc.config.environment --check [PATH]
"""
from __future__ import annotations

import hashlib
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType

from ohc import paths
from ohc.config import jsonio
from ohc.config.jsonio import ConfigFileError
from ohc.config.oracle_home import check_home_syntax, normalize_home

SCHEMA_VERSION = 1
TOP_LEVEL_KEYS = {"schema_version", "environment", "descriptions"}
KEYS = ("ORACLE_HOME", "NLS_LANG", "REPORT_DATE_FORMAT")
DEFAULTS = MappingProxyType({"ORACLE_HOME": "", "NLS_LANG": "AMERICAN_AMERICA.WE8MSWIN1252", "REPORT_DATE_FORMAT": "yyyy-MM-dd"})
DESCRIPTIONS = {
    "ORACLE_HOME": "Default Oracle Home for all databases (blank = not configured); a database can override it",
    "NLS_LANG": "NLS_LANG for SQL*Plus, for example AMERICAN_AMERICA.WE8MSWIN1252",
    "REPORT_DATE_FORMAT": "Report folder date format using y, M and d, for example yyyy-MM-dd",
}
_NLS = re.compile(r"^[A-Za-z0-9_]{1,40}\.[A-Za-z0-9]{1,30}$")
_DATE = re.compile(r"^(?=.*y)(?=.*M)(?=.*d)[yMd._ -]{3,20}$")


class EnvConfigMissingError(ConfigFileError):
    pass


class EnvConfigInvalidError(ConfigFileError):
    pass


@dataclass(frozen=True, eq=False)
class EnvSnapshot:
    values: dict
    sha256: str
    source: str

    def __getitem__(self, key):
        return self.values[key]


def default_path() -> Path:
    return paths.app_root() / "config" / "environment.json"


def validate_values(values) -> list:
    problems = [f"{k}: unknown key (check the spelling)" for k in sorted(set(values) - set(KEYS))]
    for key in KEYS:
        if key not in values:
            problems.append(f"{key}: missing")
        elif not isinstance(values[key], str):
            problems.append(f"{key}: must be text")
    if problems:
        return problems
    home = values["ORACLE_HOME"]
    if home and (msg := check_home_syntax(home)):
        problems.append(f"ORACLE_HOME: {msg}")
    if not _NLS.match(values["NLS_LANG"]):
        problems.append("NLS_LANG: must look like AMERICAN_AMERICA.WE8MSWIN1252")
    if not _DATE.match(values["REPORT_DATE_FORMAT"]):
        problems.append("REPORT_DATE_FORMAT: use only y, M, d and the separators - _ . space (for example yyyy-MM-dd)")
    return problems


def load_environment(path=None) -> EnvSnapshot:
    path = Path(path) if path is not None else default_path()
    try:
        doc, raw = jsonio.read_object(path)
    except ConfigFileError as exc:
        raise EnvConfigInvalidError(str(exc)) from None
    if doc is None:
        raise EnvConfigMissingError(f"The environment file was not found: {path}")
    problems = [f"unknown top-level key '{k}'" for k in sorted(set(doc) - TOP_LEVEL_KEYS)]
    version = doc.get("schema_version")
    if isinstance(version, bool) or not isinstance(version, int) or version != SCHEMA_VERSION:
        problems.append(f"schema_version: must be {SCHEMA_VERSION}")
    values = doc.get("environment")
    if not isinstance(values, dict):
        problems.append("'environment' is missing or is not an object")
    else:
        problems += validate_values(values)
    if problems:
        raise EnvConfigInvalidError(
            f"{path.name} is invalid ({len(problems)} problem(s)):\n  - " + "\n  - ".join(problems), problems)
    return EnvSnapshot({k: values[k] for k in KEYS}, hashlib.sha256(raw).hexdigest(), str(path))


def save_environment(path, values) -> str:
    values = dict(values)
    if values.get("ORACLE_HOME"):
        values["ORACLE_HOME"] = normalize_home(values["ORACLE_HOME"])
    problems = validate_values(values)
    if problems:
        raise EnvConfigInvalidError("Not saved: " + "; ".join(problems), problems)
    return jsonio.write_atomic(path, {"schema_version": SCHEMA_VERSION, "environment": {k: values[k] for k in KEYS},
                                      "descriptions": DESCRIPTIONS})


def write_default(path) -> str:
    if Path(path).exists():
        raise ConfigFileError(f"{path} already exists and was not overwritten")
    return save_environment(path, DEFAULTS)


def main(argv: list) -> int:
    try:
        if len(argv) == 2 and argv[0] == "--write-default":
            print(f"written: {argv[1]}  sha256 {write_default(argv[1])}")
            return 0
        if argv[:1] == ["--check"] and len(argv) <= 2:
            snap = load_environment(argv[1] if len(argv) == 2 else None)
            print(f"OK: {len(snap.values)} keys, sha256 {snap.sha256}")
            return 0
    except ConfigFileError as exc:
        print(f"FAILED: {exc}")
        return 1
    print("usage: python -m ohc.config.environment --write-default PATH | --check [PATH]")
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
