"""Light and dark themes: one palette per theme, one stylesheet template, programmatic sun/moon icons."""
from __future__ import annotations

import math
from string import Template

from PySide6.QtCore import QObject, QPointF, Qt, Signal
from PySide6.QtGui import QColor, QIcon, QPainter, QPainterPath, QPen, QPixmap
from PySide6.QtWidgets import QApplication

from ohc.config.jsonio import ConfigFileError
from ohc.config.settings import THEMES

PALETTES = {
    "dark": dict(bg="#0A1220", sidebar="#0B1426", sidebar_text="#E8EEF9", sidebar_hover="#16233D", card="#0F1A30",
                 input_bg="#0D1729", border="#1E2B47", text="#E8EEF9", muted="#8EA0BF", accent="#2563EB",
                 accent_hover="#1D4ED8", button_bg="#111D35", button_hover="#18284A", ok="#4ADE80", bad="#F87171",
                 warn="#FBBF24", toggle_hover="#16233D", icon="#F6C453"),
    "light": dict(bg="#F3F6FB", sidebar="#0E2A5E", sidebar_text="#FFFFFF", sidebar_hover="#1A3A78", card="#FFFFFF",
                  input_bg="#FFFFFF", border="#D5DEEB", text="#0F1B33", muted="#5B6B85", accent="#1F6FFF",
                  accent_hover="#1A5FE0", button_bg="#EEF2F8", button_hover="#E2E8F2", ok="#15803D", bad="#DC2626",
                  warn="#B45309", toggle_hover="#E4EAF4", icon="#0F1B33"),
}

_QSS = Template("""
QWidget { color: $text; font-size: 14px; }
QMainWindow, QDialog, QMessageBox, QWidget#content, QWidget#header, QWidget#page { background: $bg; }
QWidget#nav { background: $sidebar; }
QLabel#brand { color: $sidebar_text; font-size: 20px; font-weight: 600; padding: 18px 12px; }
QListWidget#navList { background: transparent; border: none; outline: none; color: $sidebar_text; }
QListWidget#navList::item { padding: 14px 16px; border-radius: 8px; margin: 2px 0; color: $sidebar_text; }
QListWidget#navList::item:selected { background: $accent; color: #FFFFFF; }
QListWidget#navList::item:hover:!selected { background: $sidebar_hover; }
QLabel { background: transparent; }
QLabel#title { font-size: 28px; font-weight: 600; }
QLabel#section { font-size: 20px; font-weight: 600; }
QLabel#muted { color: $muted; }
QLabel#ok { color: $ok; }
QLabel#bad { color: $bad; }
QLabel#warn { color: $warn; }
QFrame#card { background: $card; border: 1px solid $border; border-radius: 10px; }
QFrame#separator { background: $border; max-height: 1px; min-height: 1px; border: none; }
QLineEdit, QSpinBox, QComboBox, QPlainTextEdit { background: $input_bg; border: 1px solid $border; border-radius: 6px;
    padding: 8px 10px; selection-background-color: $accent; selection-color: #FFFFFF; }
QLineEdit:focus, QSpinBox:focus, QComboBox:focus { border: 1px solid $accent; }
QLineEdit:disabled, QSpinBox:disabled, QComboBox:disabled { color: $muted; }
QComboBox QAbstractItemView { background: $input_bg; color: $text; border: 1px solid $border;
    selection-background-color: $accent; selection-color: #FFFFFF; }
QPushButton { background: $button_bg; border: 1px solid $border; border-radius: 6px; padding: 9px 18px; }
QPushButton:hover { background: $button_hover; }
QPushButton:disabled { color: $muted; }
QPushButton#primary { background: $accent; border: 1px solid $accent; color: #FFFFFF; }
QPushButton#primary:hover { background: $accent_hover; }
QToolButton#themeToggle { background: transparent; border: 1px solid transparent; border-radius: 18px; padding: 4px; }
QToolButton#themeToggle:hover { background: $toggle_hover; border: 1px solid $border; }
QToolTip { background: $card; color: $text; border: 1px solid $border; padding: 4px 6px; }
""")


def stylesheet(theme: str) -> str:
    return _QSS.substitute(PALETTES[theme])


def make_icon(kind: str, color: str) -> QIcon:
    """'sun' or 'moon', drawn with QPainter (no image files)."""
    size, scale = 24, 2
    pixmap = QPixmap(size * scale, size * scale)
    pixmap.fill(Qt.GlobalColor.transparent)
    pixmap.setDevicePixelRatio(scale)
    p = QPainter(pixmap)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    c = QColor(color)
    if kind == "sun":
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(c)
        p.drawEllipse(QPointF(12, 12), 4.5, 4.5)
        pen = QPen(c, 2)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        p.setPen(pen)
        for i in range(8):
            a = i * math.pi / 4
            p.drawLine(QPointF(12 + 7.5 * math.cos(a), 12 + 7.5 * math.sin(a)),
                       QPointF(12 + 10 * math.cos(a), 12 + 10 * math.sin(a)))
    else:
        disc, cut = QPainterPath(), QPainterPath()
        disc.addEllipse(QPointF(12, 12), 8, 8)
        cut.addEllipse(QPointF(16, 9.5), 7, 7)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(c)
        p.drawPath(disc.subtracted(cut))
    p.end()
    return QIcon(pixmap)


class ThemeManager(QObject):
    """Holds the current theme, applies it to the whole application and saves it in the user's settings."""
    changed = Signal(str)

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self._settings = settings
        self.last_error = ""
        name = settings.get("theme")
        self._theme = name if name in THEMES else "dark"

    @property
    def theme(self) -> str:
        return self._theme

    def palette(self) -> dict:
        return PALETTES[self._theme]

    def apply(self) -> None:
        app = QApplication.instance()
        if app is not None:
            app.setStyleSheet(stylesheet(self._theme))

    def set_theme(self, name: str) -> None:
        if name not in THEMES:
            raise ValueError(f"unknown theme: {name!r}")
        if name == self._theme:
            return
        self._theme = name
        try:
            self._settings.set("theme", name)
            self.last_error = ""
        except ConfigFileError as exc:  # keep working; the choice just could not be saved
            self.last_error = str(exc)
        self.apply()
        self.changed.emit(name)

    def toggle(self) -> None:
        self.set_theme("light" if self._theme == "dark" else "dark")
