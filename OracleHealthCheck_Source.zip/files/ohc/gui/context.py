"""What the GUI needs: shared config paths and the current user's stores."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from ohc import paths, userstore
from ohc.config.databases import DatabaseStore
from ohc.config.jsonio import ConfigFileError
from ohc.config.settings import SettingsStore
from ohc.security import dpapi


@dataclass
class AppContext:
    root: Path
    settings: SettingsStore
    databases: DatabaseStore
    credentials_dir: Path | None
    environment_path: Path
    thresholds_path: Path
    databases_error: str = ""
    problems: list = field(default_factory=list)  # shown once at start-up
    backend: object = dpapi

    @classmethod
    def ephemeral(cls) -> "AppContext":
        """No per-user folder: nothing is read from or written to disk (used when no context is given)."""
        root = paths.app_root()
        return cls(root, SettingsStore(), DatabaseStore(), None, root / "config" / "environment.json",
                   root / "config" / "thresholds.json", databases_error="No per-user folder is available")

    @classmethod
    def for_current_user(cls, root: Path | None = None) -> "AppContext":
        """Raises IdentityError / UserStoreError when the per-user folder cannot be used."""
        root = Path(root) if root is not None else paths.app_root()
        user = userstore.ensure_user_dir(root)
        problems, databases_error = [], ""
        try:
            settings = SettingsStore(user.folder / "settings.json")
        except ConfigFileError as exc:  # keep the file untouched and work in memory
            settings = SettingsStore()
            problems.append(f"{exc}\nSettings are not saved until this is fixed.")
        try:
            databases = DatabaseStore(user.folder / "databases.json")
        except ConfigFileError as exc:
            databases, databases_error = DatabaseStore(), str(exc)
        return cls(root, settings, databases, user.credentials, root / "config" / "environment.json",
                   root / "config" / "thresholds.json", databases_error, problems)
