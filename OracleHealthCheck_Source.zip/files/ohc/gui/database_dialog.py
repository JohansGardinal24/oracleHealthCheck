"""Add / Edit database dialog (including the encrypted login)."""
from __future__ import annotations

from PySide6.QtWidgets import (QDialog, QDialogButtonBox, QFileDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit,
                               QPushButton, QVBoxLayout)

from ohc.config import dbadmin
from ohc.config.databases import DatabaseEntry
from ohc.config.jsonio import ConfigFileError
from ohc.security.credstore import CredentialError


class DatabaseDialog(QDialog):
    def __init__(self, ctx, entry: DatabaseEntry | None = None, parent=None):
        super().__init__(parent)
        self.ctx, self.entry, self.result_entry = ctx, entry, None
        self.setWindowTitle("Edit Database" if entry else "Add Database")
        self.setMinimumWidth(520)
        self.name = QLineEdit(entry.name if entry else "")
        self.sid = QLineEdit(entry.sid if entry else "")
        self.sid.setPlaceholderText("same as the name")
        self.dg_service = QLineEdit(entry.dg_service if entry else "")
        self.dg_service.setPlaceholderText("optional (Data Guard service for DGMGRL)")
        self.home = QLineEdit(entry.oracle_home if entry else "")
        self.home.setPlaceholderText("blank = use the default Oracle Home")
        browse = QPushButton("Browse")
        browse.clicked.connect(self._browse)
        self.notes = QLineEdit(entry.notes if entry else "")
        self.username = QLineEdit()
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.EchoMode.Password)
        keep = "leave blank to keep the stored login" if entry else "required"
        self.username.setPlaceholderText(keep)
        self.password.setPlaceholderText(keep)
        home_row = QHBoxLayout()
        home_row.addWidget(self.home, 1)
        home_row.addWidget(browse)
        form = QFormLayout()
        form.addRow("Name", self.name)
        form.addRow("SID", self.sid)
        form.addRow("Data Guard service", self.dg_service)
        form.addRow("Oracle Home override", home_row)
        form.addRow("Notes", self.notes)
        form.addRow("Username", self.username)
        form.addRow("Password", self.password)
        self.error = QLabel("")
        self.error.setObjectName("bad")
        self.error.setWordWrap(True)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout = QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(self.error)
        layout.addWidget(buttons)

    def _browse(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Select the Oracle Home for this database")
        if folder:
            self.home.setText(folder.replace("/", "\\"))

    def apply(self) -> DatabaseEntry:
        """Validate and save. Raises on any problem (nothing is half-saved)."""
        fields = dict(name=self.name.text(), sid=self.sid.text(), dg_service=self.dg_service.text(),
                      oracle_home=self.home.text(), notes=self.notes.text())
        user, pw = self.username.text(), self.password.text()
        backend = self.ctx.backend
        if self.entry is None:
            return dbadmin.add_database(self.ctx.databases, self.ctx.credentials_dir, username=user, password=pw,
                                        backend=backend, **fields)
        return dbadmin.update_database(self.ctx.databases, self.ctx.credentials_dir, self.entry.id,
                                       username=user or None, password=pw or None, backend=backend, **fields)

    def accept(self) -> None:
        try:
            self.result_entry = self.apply()
        except (ConfigFileError, CredentialError, ValueError) as exc:
            self.error.setText(str(exc))
            return
        finally:
            self.password.clear()
        super().accept()
