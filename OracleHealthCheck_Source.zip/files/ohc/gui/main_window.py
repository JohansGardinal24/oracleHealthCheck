"""Main window: left navigation, theme toggle in the header, and the pages."""
from __future__ import annotations

from PySide6.QtCore import QSize, Qt
from PySide6.QtWidgets import (QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QMainWindow, QStackedWidget,
                               QToolButton, QVBoxLayout, QWidget)

from ohc import __version__, paths
from ohc.gui.context import AppContext
from ohc.gui.settings_page import SettingsPage
from ohc.gui.theme import PALETTES, ThemeManager, make_icon
from ohc.resources import sql_access

PAGES = [
    ("Dashboard", ""),
    ("1. Oracle Health Check", "SQL checks run here (later phase)."),
    ("2. Sync Check", "Data Guard / sync checks run here (later phase)."),
    ("3. All Checks", "All 21 checks run here (later phase)."),
    ("4. Database Reports", "AWR / ASH / ADDM reports (later phase)."),
    ("Reports & Logs", "Browse reports and logs (later phase)."),
    ("Settings", ""),
]


class MainWindow(QMainWindow):
    def __init__(self, context: AppContext | None = None) -> None:
        super().__init__()
        self.ctx = context or AppContext.ephemeral()
        self.theme = ThemeManager(self.ctx.settings, self)
        self.setWindowTitle("Oracle Health Check")
        self.resize(1200, 760)
        self.setMinimumSize(900, 560)

        root = QWidget()
        root.setObjectName("content")
        self.setCentralWidget(root)
        layout = QHBoxLayout(root)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        nav_box = QWidget()
        nav_box.setObjectName("nav")
        nav_box.setFixedWidth(300)
        nav_layout = QVBoxLayout(nav_box)
        nav_layout.setContentsMargins(8, 0, 8, 12)
        brand = QLabel("Oracle Health Check")
        brand.setObjectName("brand")
        self.nav = QListWidget()
        self.nav.setObjectName("navList")
        nav_layout.addWidget(brand)
        nav_layout.addWidget(self.nav)

        self.pages = QStackedWidget()
        for title, note in PAGES:
            self.nav.addItem(QListWidgetItem(title))
            if title == "Dashboard":
                page = self._dashboard_page()
            elif title == "Settings":
                page = SettingsPage(self.ctx, self.theme)
                self.settings_page = page
            else:
                page = self._simple_page(title, note)
            self.pages.addWidget(page)
        self.nav.currentRowChanged.connect(self.pages.setCurrentIndex)
        self.nav.setCurrentRow(0)

        header = QWidget()
        header.setObjectName("header")
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(40, 12, 24, 0)
        header_layout.addStretch(1)
        self.toggle = QToolButton()
        self.toggle.setObjectName("themeToggle")
        self.toggle.setFixedSize(36, 36)
        self.toggle.setIconSize(QSize(22, 22))
        self.toggle.setCursor(Qt.CursorShape.PointingHandCursor)
        self.toggle.clicked.connect(self.theme.toggle)
        header_layout.addWidget(self.toggle)

        right = QWidget()
        right.setObjectName("content")
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(0)
        right_layout.addWidget(header)
        right_layout.addWidget(self.pages, 1)
        layout.addWidget(nav_box)
        layout.addWidget(right, 1)

        self.theme.changed.connect(lambda _name: self._update_toggle())
        self.theme.apply()
        self._update_toggle()

    def _update_toggle(self) -> None:
        """The icon shows the theme a click switches TO: sun while dark, moon while light."""
        current = self.theme.theme
        kind = "sun" if current == "dark" else "moon"
        self.toggle.setIcon(make_icon(kind, PALETTES[current]["icon"]))
        self.toggle.setToolTip(f"Switch to {'Light' if current == 'dark' else 'Dark'} mode")
        self.toggle.setProperty("icon_kind", kind)

    @staticmethod
    def _page_shell(title: str) -> tuple:
        page = QWidget()
        page.setObjectName("page")
        box = QVBoxLayout(page)
        box.setContentsMargins(40, 8, 40, 36)
        box.setSpacing(10)
        heading = QLabel(title)
        heading.setObjectName("title")
        box.addWidget(heading)
        return page, box

    def _simple_page(self, title: str, note: str) -> QWidget:
        page, box = self._page_shell(title)
        label = QLabel(note)
        label.setObjectName("muted")
        box.addWidget(label)
        box.addStretch(1)
        return page

    def _dashboard_page(self) -> QWidget:
        page, box = self._page_shell("Dashboard")
        problems = sql_access.verify()
        if problems:
            sql_text, sql_style = "SQL bundle: INTEGRITY FAILURE - " + "; ".join(problems), "bad"
        else:
            sql_text = f"SQL bundle: OK ({len(sql_access.list_sql())} scripts, sha256 {sql_access.bundle_sha256()})"
            sql_style = "ok"
        rows = [
            (f"Version {__version__}", "muted"),
            (f"Mode: {'packaged EXE' if paths.is_frozen() else 'development'}", "muted"),
            (f"Application root: {paths.app_root()}", "muted"),
            (sql_text, sql_style),
        ]
        for text, style in rows:
            label = QLabel(text)
            label.setObjectName(style)
            label.setWordWrap(True)
            box.addWidget(label)
        box.addStretch(1)
        return page
