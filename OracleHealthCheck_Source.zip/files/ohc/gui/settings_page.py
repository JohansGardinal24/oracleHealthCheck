"""Settings page: Oracle Home, databases, retention and theme."""
from __future__ import annotations

from PySide6.QtWidgets import (QComboBox, QFileDialog, QFrame, QHBoxLayout, QInputDialog, QLabel, QLineEdit, QMessageBox,
                               QPushButton, QSpinBox, QVBoxLayout, QWidget)

from ohc.config import dbadmin, environment, thresholds
from ohc.config import oracle_home as oh
from ohc.config.jsonio import ConfigFileError
from ohc.gui.database_dialog import DatabaseDialog
from ohc.security import credstore


def _label(text="", name="muted", wrap=True) -> QLabel:
    label = QLabel(text)
    label.setObjectName(name)
    label.setWordWrap(wrap)
    return label


class SettingsPage(QWidget):
    def __init__(self, ctx, theme, parent=None):
        super().__init__(parent)
        self.setObjectName("page")
        self.ctx, self.theme = ctx, theme
        self.env_values, self.env_ok = dict(environment.DEFAULTS), True
        self.th_values, self.th_state = dict(thresholds.DEFAULTS), "ok"  # ok | missing | invalid

        title = _label("Settings", "title", False)
        # --- Oracle Home
        self.home_edit = QLineEdit()
        self.browse_btn, self.detect_btn = QPushButton("Browse"), QPushButton("Detect")
        self.home_status = _label()
        home_row = QHBoxLayout()
        for w, s in ((self.home_edit, 1), (self.browse_btn, 0), (self.detect_btn, 0)):
            home_row.addWidget(w, s)
        # --- Databases
        self.db_combo = QComboBox()
        self.add_btn, self.edit_btn, self.delete_btn = QPushButton("Add Database"), QPushButton("Edit"), QPushButton("Delete")
        self.add_btn.setObjectName("primary")
        self.db_details = _label()
        card = QFrame()
        card.setObjectName("card")
        QVBoxLayout(card).addWidget(self.db_details)
        db_row = QHBoxLayout()
        db_row.addWidget(self.db_combo, 1)
        for b in (self.add_btn, self.edit_btn, self.delete_btn):
            db_row.addWidget(b)
        self.test_btn = QPushButton("Test Connection")
        self.test_btn.setEnabled(False)
        self.test_btn.setToolTip("Connection testing arrives with the SQL*Plus runner.")
        # --- Retention, theme
        self.retention = QSpinBox()
        self.retention.setRange(1, 3650)
        self.retention.setFixedWidth(120)
        self.theme_combo = QComboBox()
        self.theme_combo.addItem("Dark", "dark")
        self.theme_combo.addItem("Light", "light")
        self.theme_combo.setFixedWidth(160)
        self.validate_btn, self.save_btn = QPushButton("Validate"), QPushButton("Save")
        self.save_btn.setObjectName("primary")
        self.shared_note = _label()
        self.status = _label()
        buttons = QHBoxLayout()
        buttons.addWidget(self.validate_btn)
        buttons.addWidget(self.save_btn)
        buttons.addStretch(1)
        separator = QFrame()
        separator.setObjectName("separator")

        box = QVBoxLayout(self)
        box.setContentsMargins(40, 8, 40, 30)
        box.setSpacing(8)
        for w in (title, _label("Oracle Home (default for all databases)"), ):
            box.addWidget(w)
        box.addLayout(home_row)
        box.addWidget(self.home_status)
        box.addWidget(_label("Databases", "section", False))
        box.addLayout(db_row)
        box.addWidget(card)
        box.addWidget(self.test_btn)
        box.addWidget(separator)
        box.addWidget(_label("Report/log retention (days)"))
        box.addWidget(self.retention)
        box.addWidget(_label("Theme"))
        box.addWidget(self.theme_combo)
        box.addLayout(buttons)
        box.addWidget(self.shared_note)
        box.addWidget(self.status)
        box.addStretch(1)

        self.browse_btn.clicked.connect(self.browse)
        self.detect_btn.clicked.connect(self.detect)
        self.home_edit.editingFinished.connect(self._update_home_status)
        self.add_btn.clicked.connect(self.add_database)
        self.edit_btn.clicked.connect(self.edit_database)
        self.delete_btn.clicked.connect(self.delete_database)
        self.db_combo.currentIndexChanged.connect(lambda _i: self._update_db_details())
        self.validate_btn.clicked.connect(self.run_validate)
        self.save_btn.clicked.connect(self.save)
        self._sync_theme_combo(theme.theme)
        self.theme_combo.currentIndexChanged.connect(lambda _i: self.theme.set_theme(self.theme_combo.currentData()))
        theme.changed.connect(self._sync_theme_combo)
        self.load_shared()
        self.refresh_databases()

    # ---------------------------------------------------------------- helpers
    @staticmethod
    def _set(label: QLabel, kind: str, text: str) -> None:
        label.setObjectName(kind)
        label.setText(text)
        label.style().unpolish(label)
        label.style().polish(label)

    def _sync_theme_combo(self, name: str) -> None:
        self.theme_combo.blockSignals(True)
        self.theme_combo.setCurrentIndex(self.theme_combo.findData(name))
        self.theme_combo.blockSignals(False)

    def _confirm(self, text: str) -> bool:
        return QMessageBox.question(self, "Oracle Health Check", text) == QMessageBox.StandardButton.Yes

    def _ask_create_thresholds(self) -> bool:
        return self._confirm("thresholds.json was not found. Create it with the default values and this retention?")

    # ---------------------------------------------------------------- shared configuration
    def load_shared(self) -> None:
        notes = []
        try:
            self.env_values, self.env_ok = dict(environment.load_environment(self.ctx.environment_path).values), True
        except environment.EnvConfigMissingError:
            self.env_values, self.env_ok = dict(environment.DEFAULTS), True
            notes.append("environment.json was not found; saving will create it.")
        except ConfigFileError as exc:
            self.env_ok = False
            notes.append(str(exc))
        try:
            self.th_values, self.th_state = thresholds.load_thresholds(self.ctx.thresholds_path).as_dict(), "ok"
        except thresholds.ThresholdsMissingError:
            self.th_values, self.th_state = dict(thresholds.DEFAULTS), "missing"
            notes.append("thresholds.json was not found; saving will offer to create it.")
        except thresholds.ThresholdsError as exc:
            self.th_state = "invalid"
            notes.append(str(exc))
        self.home_edit.setText(self.env_values["ORACLE_HOME"] if self.env_ok else "")
        self.retention.setValue(self.th_values["RETENTION_DAYS"])
        for w in (self.home_edit, self.browse_btn, self.detect_btn):
            w.setEnabled(self.env_ok)
        self.retention.setEnabled(self.th_state != "invalid")
        self.save_btn.setEnabled(self.env_ok and self.th_state != "invalid")
        self._set(self.shared_note, "warn" if notes else "muted", "\n".join(notes))
        self._update_home_status()

    def _update_home_status(self) -> None:
        text = self.home_edit.text().strip()
        if not text:
            self._set(self.home_status, "warn", "Oracle Home is not configured. Use Browse or Detect, or set an Oracle Home per database.")
            return
        errors, warnings = oh.findings(oh.inspect_home(text), "all")
        if errors:
            self._set(self.home_status, "bad", "; ".join(errors))
        elif warnings:
            self._set(self.home_status, "warn", "sqlplus.exe found. " + " ".join(warnings))
        else:
            self._set(self.home_status, "ok", "sqlplus.exe and dgmgrl.exe found")

    def browse(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Select the Oracle Home")
        if folder:
            self.home_edit.setText(folder.replace("/", "\\"))
            self._update_home_status()

    def _choose_home(self, found: list) -> str:
        items = [f"{c.path}  ({c.source}{'' if c.sqlplus else ', no sqlplus.exe'})" for c in found]
        item, ok = QInputDialog.getItem(self, "Detect Oracle Home", "Oracle Homes found:", items, 0, False)
        return found[items.index(item)].path if ok else ""

    def detect(self) -> None:
        found = oh.detect_oracle_homes()
        if not found:
            self._set(self.status, "warn", "No Oracle client was found in the registry, the ORACLE_HOME variable or PATH.")
            return
        chosen = found[0].path if len(found) == 1 else self._choose_home(found)
        if chosen:
            self.home_edit.setText(chosen)
            self._update_home_status()

    def validate(self) -> tuple:
        errors, warnings = [], []
        text = self.home_edit.text().strip()
        if not text:
            warnings.append("Oracle Home (default) is not configured")
        elif msg := oh.check_home_syntax(text):
            errors.append(msg)
        else:
            e, w = oh.findings(oh.inspect_home(text), "all")
            warnings += e + w
        return errors, warnings

    def run_validate(self) -> tuple:
        errors, warnings = self.validate()
        if errors:
            self._set(self.status, "bad", "Invalid: " + "; ".join(errors))
        elif warnings:
            self._set(self.status, "warn", "Valid, with warnings: " + "; ".join(warnings))
        else:
            self._set(self.status, "ok", "Settings are valid.")
        return errors, warnings

    def save(self) -> bool:
        errors, _warnings = self.validate()
        if errors:
            self._set(self.status, "bad", "Not saved: " + "; ".join(errors))
            return False
        saved = []
        try:
            if self.env_ok:
                environment.save_environment(self.ctx.environment_path, {**self.env_values, "ORACLE_HOME": self.home_edit.text().strip()})
                saved.append("environment.json")
            days = self.retention.value()
            if self.th_state == "missing":
                if self._ask_create_thresholds():
                    thresholds.save_thresholds(self.ctx.thresholds_path, {**thresholds.DEFAULTS, "RETENTION_DAYS": days})
                    saved.append("thresholds.json (created)")
            elif self.th_state == "ok" and days != self.th_values["RETENTION_DAYS"]:
                current = thresholds.load_thresholds(self.ctx.thresholds_path).as_dict()  # re-read: keep other people's edits
                thresholds.save_thresholds(self.ctx.thresholds_path, {**current, "RETENTION_DAYS": days})
                saved.append("thresholds.json")
        except (ConfigFileError, thresholds.ThresholdsError) as exc:
            self._set(self.status, "bad", f"Not saved: {exc}")
            return False
        self.load_shared()
        if self.th_state == "missing":
            self.retention.setValue(days)  # keep what the user typed when thresholds.json was not created
        self._set(self.status, "ok", "Saved: " + ", ".join(saved) if saved else "Nothing to save.")
        return True

    # ---------------------------------------------------------------- databases
    def _db_enabled(self) -> bool:
        return not self.ctx.databases_error and self.ctx.credentials_dir is not None

    def current_entry(self):
        return self.ctx.databases.get(self.db_combo.currentData()) if self._db_enabled() else None

    def refresh_databases(self, select_id=None) -> None:
        self.db_combo.blockSignals(True)
        self.db_combo.clear()
        for e in self.ctx.databases.entries():
            self.db_combo.addItem(e.name, e.id)
        if select_id is not None:
            self.db_combo.setCurrentIndex(max(0, self.db_combo.findData(select_id)))
        self.db_combo.blockSignals(False)
        self._update_db_details()

    def _update_db_details(self) -> None:
        enabled, entry = self._db_enabled(), self.current_entry()
        self.add_btn.setEnabled(enabled)
        self.edit_btn.setEnabled(entry is not None)
        self.delete_btn.setEnabled(entry is not None)
        if not enabled:
            self._set(self.db_details, "bad", self.ctx.databases_error or "Databases cannot be edited (no per-user folder).")
        elif entry is None:
            self._set(self.db_details, "muted", "No databases configured. Click Add Database.")
        else:
            login = "stored (encrypted)" if credstore.has_credentials(self.ctx.credentials_dir, entry.id) else "NOT stored: edit the database to enter it"
            self._set(self.db_details, "muted", f"SID: {entry.effective_sid}\nData Guard service: {entry.dg_service or '-'}\n"
                      f"Oracle Home: {entry.oracle_home or 'default (shared)'}\nLogin: {login}")

    def add_database(self) -> None:
        dialog = DatabaseDialog(self.ctx, parent=self)
        if dialog.exec():
            self.refresh_databases(dialog.result_entry.id)

    def edit_database(self) -> None:
        entry = self.current_entry()
        if entry is None:
            return
        dialog = DatabaseDialog(self.ctx, entry, parent=self)
        if dialog.exec():
            self.refresh_databases(entry.id)

    def delete_database(self) -> None:
        entry = self.current_entry()
        if entry is None or not self._confirm(f"Delete database '{entry.name}' and its stored login?"):
            return
        try:
            dbadmin.delete_database(self.ctx.databases, self.ctx.credentials_dir, entry.id)
            if self.ctx.settings.get("default_db") == entry.id:
                self.ctx.settings.set("default_db", "")
        except (ConfigFileError, OSError) as exc:
            self._set(self.status, "bad", f"Not deleted: {exc}")
        self.refresh_databases()
