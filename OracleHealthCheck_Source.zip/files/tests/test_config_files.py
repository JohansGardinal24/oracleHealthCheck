"""Tests for environment.json, Oracle Home logic, databases.json, settings.json and credential-coupled DB operations."""
import contextlib
import io
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from ohc.config import dbadmin, databases, environment, jsonio, oracle_home, settings
from ohc.config.databases import DatabaseEntry, DatabaseStore, DatabasesError
from ohc.config.jsonio import ConfigFileError
from ohc.config.settings import SettingsError, SettingsStore
from ohc.security import credstore
from tests.test_credstore import FakeBackend

ID1, ID2 = "1" * 16, "2" * 16


class Tmp(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self._tmp.name)
        self.addCleanup(self._tmp.cleanup)

    def make_home(self, name="home", sqlplus=True, dgmgrl=True) -> Path:
        home = self.dir / name
        (home / "bin").mkdir(parents=True)
        if sqlplus:
            (home / "bin" / f"sqlplus{oracle_home.EXE}").write_text("x")
        if dgmgrl:
            (home / "bin" / f"dgmgrl{oracle_home.EXE}").write_text("x")
        return home


class JsonIo(Tmp):
    def test_read_missing_invalid_duplicate_and_bom(self):
        p = self.dir / "a.json"
        self.assertEqual(jsonio.read_object(p), (None, None))
        p.write_bytes(b"\xef\xbb\xbf" + b'{"a": 1}')
        self.assertEqual(jsonio.read_object(p)[0], {"a": 1})
        for raw in (b'{"a": 1, "a": 2}', b"[1]", b"{ nope", b"\xff\xfe"):
            p.write_bytes(raw)
            with mock.patch.object(jsonio, "_sleep", lambda s: None), self.assertRaises(ConfigFileError):
                jsonio.read_object(p)
            self.assertEqual(p.read_bytes(), raw, "an invalid file must never be modified")

    def test_atomic_write_and_failure_cleanup(self):
        p = self.dir / "sub" / "a.json"
        sha = jsonio.write_atomic(p, {"a": 1})
        self.assertEqual(len(sha), 64)
        with mock.patch("os.replace", side_effect=PermissionError(13, "Access is denied")), self.assertRaises(ConfigFileError):
            jsonio.write_atomic(p, {"a": 2})
        self.assertEqual(json.loads(p.read_text()), {"a": 1})
        self.assertEqual([x.name for x in p.parent.iterdir()], ["a.json"])


class OracleHome(Tmp):
    def test_syntax_rules(self):
        for ok in ("D:\\ims_ecs\\oracle\\WINDOWS.X64_193000_db_home", "C:/oracle/db_1", "E:\\Program Files (x86)\\ora"):
            self.assertIsNone(oracle_home.check_home_syntax(ok), ok)
        for bad in ("", " D:\\x", "D:\\x ", "\\\\server\\share\\ora", "relative\\path", "D:\\a\\..\\b", 'D:\\a"b', "D:\\a;b", "D:\\a&b",
                    "D:\\a|b", "D:\\a%b", "D:\\a:b", "D:\\a\nb", "x" * 241, None, 5):
            self.assertIsNotNone(oracle_home.check_home_syntax(bad), repr(bad))

    def test_normalize_and_resolve_priority(self):
        self.assertEqual(oracle_home.normalize_home("D:\\ora\\"), "D:\\ora")
        self.assertEqual(oracle_home.normalize_home("D:\\"), "D:\\")
        self.assertEqual(oracle_home.resolve_oracle_home("D:\\db", "D:\\default"), ("D:\\db", "database"))
        self.assertEqual(oracle_home.resolve_oracle_home("  ", "D:\\default"), ("D:\\default", "default"))
        self.assertEqual(oracle_home.resolve_oracle_home("", ""), ("", "none"))

    def test_inspect_and_findings_per_mode(self):
        full = oracle_home.inspect_home(str(self.make_home("full")))
        self.assertEqual((full.sqlplus, full.dgmgrl, full.problems), (True, True, ()))
        self.assertEqual(oracle_home.findings(full, "all"), ([], []))
        no_dg = oracle_home.inspect_home(str(self.make_home("nodg", dgmgrl=False)))
        self.assertEqual(oracle_home.findings(no_dg, "sql"), ([], []), "DGMGRL must not be required for SQL checks")
        self.assertEqual(oracle_home.findings(no_dg, "reports"), ([], []))
        for mode in ("sync", "all"):
            errors, warnings = oracle_home.findings(no_dg, mode)
            self.assertEqual((errors, len(warnings)), ([], 1))
        no_sql = oracle_home.inspect_home(str(self.make_home("nosql", sqlplus=False)))
        self.assertTrue(oracle_home.findings(no_sql, "sql")[0])
        self.assertTrue(oracle_home.inspect_home(str(self.dir / "missing")).problems)
        self.assertTrue(oracle_home.inspect_home("relative").problems)

    def test_detect_is_read_only_deduplicated_and_ordered(self):
        a, b = self.make_home("a"), self.make_home("b", sqlplus=False)
        env = {"ORACLE_HOME": str(a), "PATH": os.pathsep.join([str(a / "bin"), str(self.dir), "", str(self.dir / "nope")])}
        found = oracle_home.detect_oracle_homes(lambda: [str(b), str(a) + os.sep, "not absolute"], env)
        self.assertEqual([c.path for c in found], [str(a), str(b)])
        self.assertEqual([c.sqlplus for c in found], [True, False])
        self.assertEqual(found[0].source, "registry")
        before = sorted(p.name for p in self.dir.rglob("*"))
        oracle_home.detect_oracle_homes(lambda: [], {"PATH": ""})
        self.assertEqual(sorted(p.name for p in self.dir.rglob("*")), before)


class Environment(Tmp):
    def test_defaults_roundtrip_and_blank_oracle_home(self):
        p = self.dir / "config" / "environment.json"
        sha = environment.write_default(p)
        snap = environment.load_environment(p)
        self.assertEqual((snap.sha256, snap["ORACLE_HOME"], snap["NLS_LANG"], snap["REPORT_DATE_FORMAT"]),
                         (sha, "", "AMERICAN_AMERICA.WE8MSWIN1252", "yyyy-MM-dd"))
        with self.assertRaises(ConfigFileError):
            environment.write_default(p)

    def test_missing_invalid_and_validation(self):
        p = self.dir / "environment.json"
        with self.assertRaises(environment.EnvConfigMissingError):
            environment.load_environment(p)
        base = dict(environment.DEFAULTS)
        for key, bad in (("ORACLE_HOME", "\\\\srv\\x"), ("ORACLE_HOME", "D:\\a;b"), ("NLS_LANG", "x y"), ("NLS_LANG", "AMERICAN"),
                         ("REPORT_DATE_FORMAT", "yyyy/MM/dd"), ("REPORT_DATE_FORMAT", "yyyy:MM"), ("REPORT_DATE_FORMAT", "abc"), ("NLS_LANG", 5)):
            self.assertTrue(environment.validate_values({**base, key: bad}), (key, bad))
        self.assertEqual(environment.validate_values({**base, "ORACLE_HOME": "D:\\ora"}), [])
        p.write_text(json.dumps({"schema_version": 1, "environment": {**base, "EXTRA": 1}}))
        with self.assertRaises(environment.EnvConfigInvalidError) as cm:
            environment.load_environment(p)
        self.assertIn("EXTRA", str(cm.exception))

    def test_save_normalizes_and_validates_before_writing(self):
        p = self.dir / "environment.json"
        environment.save_environment(p, {**environment.DEFAULTS, "ORACLE_HOME": "D:\\ora\\"})
        self.assertEqual(environment.load_environment(p)["ORACLE_HOME"], "D:\\ora")
        before = p.read_bytes()
        with self.assertRaises(environment.EnvConfigInvalidError):
            environment.save_environment(p, {**environment.DEFAULTS, "ORACLE_HOME": "bad"})
        self.assertEqual(p.read_bytes(), before)

    def test_cli(self):
        p = self.dir / "e.json"
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            codes = [environment.main(["--write-default", str(p)]), environment.main(["--write-default", str(p)]),
                     environment.main(["--check", str(p)]), environment.main(["--bogus"])]
        self.assertEqual(codes, [0, 1, 0, 2])


def entry(n=1, **kw):
    base = dict(id=str(n) * 16, name=f"DB{n}")
    base.update(kw)
    return DatabaseEntry(**base)


class Databases(Tmp):
    def test_missing_file_means_empty_and_crud_persists(self):
        p = self.dir / "databases.json"
        store = DatabaseStore(p)
        self.assertEqual(store.entries(), [])
        store.add(entry(1, sid="ORCL", dg_service="DG_IMS", oracle_home="D:\\ora", notes="prod"))
        store.add(entry(2))
        again = DatabaseStore(p)
        self.assertEqual([e.name for e in again.entries()], ["DB1", "DB2"])
        e = again.get(ID1)
        self.assertEqual((e.effective_sid, e.dg_service, e.oracle_home), ("ORCL", "DG_IMS", "D:\\ora"))
        self.assertEqual(again.get(ID2).effective_sid, "DB2")
        again.update(entry(1, name="RENAMED"))
        again.delete(ID2)
        self.assertEqual([x.name for x in DatabaseStore(p).entries()], ["RENAMED"])
        self.assertEqual(DatabaseStore(p).find_by_name("renamed").id, ID1)

    def test_validation_rules(self):
        store = DatabaseStore()
        for bad in (entry(1, name=""), entry(1, name="a b"), entry(1, name="x" * 31), entry(1, name="../x"), entry(1, name="-x"),
                    entry(1, sid="a b"), entry(1, dg_service="a b"), entry(1, dg_service="a;b"), entry(1, oracle_home="bad"),
                    entry(1, oracle_home="D:\\a;b"), entry(1, notes="x" * 201), entry(1, notes="a\nb"), entry(1, id="XYZ")):
            with self.assertRaises(DatabasesError, msg=repr(bad)):
                store.add(bad)
        self.assertEqual(store.entries(), [])
        store.add(entry(1, name="IMS"))
        with self.assertRaises(DatabasesError):
            store.add(entry(2, name="ims"))  # names are case-insensitive (file names on Windows)
        with self.assertRaises(DatabasesError):
            store.add(entry(1, name="OTHER"))  # duplicate id

    def test_invalid_file_raises_and_is_never_modified(self):
        p = self.dir / "databases.json"
        good = {"schema_version": 1, "databases": [{"id": ID1, "name": "A"}]}
        for doc in ('{ broken', json.dumps({**good, "x": 1}), json.dumps({"schema_version": 2, "databases": []}),
                    json.dumps({"schema_version": 1, "databases": {}}), json.dumps({"schema_version": 1, "databases": [{"id": ID1}]}),
                    json.dumps({"schema_version": 1, "databases": [{"id": ID1, "name": "A", "evil": 1}]}),
                    json.dumps({"schema_version": 1, "databases": [{"id": ID1, "name": "A"}, {"id": ID2, "name": "a"}]})):
            p.write_text(doc, encoding="utf-8")
            with mock.patch.object(jsonio, "_sleep", lambda s: None), self.assertRaises(ConfigFileError):
                DatabaseStore(p)
            self.assertEqual(p.read_text(encoding="utf-8"), doc)

    def test_failed_save_keeps_memory_and_file_consistent(self):
        p = self.dir / "databases.json"
        store = DatabaseStore(p)
        store.add(entry(1))
        with mock.patch("os.replace", side_effect=PermissionError(13, "denied")), self.assertRaises(ConfigFileError):
            store.add(entry(2))
        self.assertEqual([e.name for e in store.entries()], ["DB1"])
        self.assertEqual([e.name for e in DatabaseStore(p).entries()], ["DB1"])


class SettingsTests(Tmp):
    def test_defaults_persist_and_validate(self):
        p = self.dir / "settings.json"
        s = SettingsStore(p)
        self.assertEqual(s.values(), {"theme": "dark", "default_db": ""})
        self.assertFalse(p.exists(), "reading must not create the file")
        s.set("theme", "light")
        self.assertEqual(SettingsStore(p).get("theme"), "light")
        s.set("default_db", ID1)
        for key, bad in (("theme", "blue"), ("default_db", "xx"), ("nokey", 1)):
            with self.assertRaises(SettingsError):
                s.set(key, bad)
        self.assertEqual(SettingsStore(p).values(), {"theme": "light", "default_db": ID1})

    def test_invalid_file_is_kept_and_memory_store_works(self):
        p = self.dir / "settings.json"
        p.write_text('{"schema_version": 1, "settings": {"theme": "pink"}}')
        with self.assertRaises(SettingsError):
            SettingsStore(p)
        self.assertIn("pink", p.read_text())
        mem = SettingsStore()
        mem.set("theme", "light")
        self.assertEqual(mem.get("theme"), "light")

    def test_failed_write_keeps_old_value(self):
        s = SettingsStore(self.dir / "settings.json")
        s.set("theme", "light")
        with mock.patch("os.replace", side_effect=PermissionError(13, "denied")), self.assertRaises(SettingsError):
            s.set("theme", "dark")
        self.assertEqual(s.get("theme"), "light")


class DbAdmin(Tmp):
    def setUp(self):
        super().setUp()
        self.store = DatabaseStore(self.dir / "databases.json")
        self.cred = self.dir / "credentials"
        self.fake = FakeBackend()

    def add(self, name="IMS", **kw):
        kw.setdefault("username", "scott")
        kw.setdefault("password", "tiger-pw")
        return dbadmin.add_database(self.store, self.cred, name=name, backend=self.fake, **kw)

    def creds(self, db_id):
        return credstore.load_credentials(self.cred, db_id, backend=self.fake)

    def test_add_stores_entry_and_encrypted_credentials(self):
        e = self.add(sid="IMSPRD", dg_service="DG1")
        self.assertEqual((self.store.get(e.id).name, self.store.get(e.id).effective_sid), ("IMS", "IMSPRD"))
        with self.creds(e.id) as c:
            self.assertEqual((bytes(c.username), bytes(c.password)), (b"scott", b"tiger-pw"))
        self.assertNotIn(b"tiger-pw", (self.dir / "databases.json").read_bytes())
        self.assertNotIn(b"scott", (self.dir / "databases.json").read_bytes())

    def test_add_validation_failures_leave_nothing_behind(self):
        for kw in ({"name": "bad name"}, {"username": ""}, {"password": ""}, {"oracle_home": "bad"}):
            with self.assertRaises(DatabasesError):
                self.add(**kw)
        self.add("IMS")
        with self.assertRaises(DatabasesError):
            self.add("ims")
        self.assertEqual([e.name for e in self.store.entries()], ["IMS"])
        self.assertEqual(len(list(self.cred.iterdir())), 1)

    def test_failed_list_save_removes_the_new_credentials(self):
        with mock.patch("os.replace", side_effect=[None, PermissionError(13, "denied")]), self.assertRaises(ConfigFileError):
            self.add("IMS")
        self.assertEqual(self.store.entries(), [])
        self.assertEqual([p for p in self.cred.iterdir()], [])

    def test_update_keeps_credentials_unless_new_ones_are_given(self):
        e = self.add()
        dbadmin.update_database(self.store, self.cred, e.id, name="IMS2", notes="n", backend=self.fake)
        self.assertEqual(self.store.get(e.id).name, "IMS2")
        with self.creds(e.id) as c:
            self.assertEqual(bytes(c.password), b"tiger-pw")
        dbadmin.update_database(self.store, self.cred, e.id, username="u2", password="p2", backend=self.fake)
        with self.creds(e.id) as c:
            self.assertEqual((bytes(c.username), bytes(c.password)), (b"u2", b"p2"))
        with self.assertRaises(DatabasesError):
            dbadmin.update_database(self.store, self.cred, e.id, username="only-user", backend=self.fake)

    def test_failed_credential_update_reverts_the_entry(self):
        e = self.add()
        self.fake.fail_protect = True
        with self.assertRaises(credstore.CredentialError):
            dbadmin.update_database(self.store, self.cred, e.id, name="CHANGED", username="u", password="p", backend=self.fake)
        self.assertEqual(self.store.get(e.id).name, "IMS")

    def test_delete_removes_credentials_and_entry(self):
        e = self.add()
        dbadmin.delete_database(self.store, self.cred, e.id)
        self.assertEqual((self.store.entries(), list(self.cred.iterdir())), ([], []))
        with self.assertRaises(DatabasesError):
            dbadmin.delete_database(self.store, self.cred, e.id)

    def test_no_credential_folder_means_no_changes(self):
        with self.assertRaises(DatabasesError):
            dbadmin.add_database(self.store, None, name="X", username="u", password="p")


if __name__ == "__main__":
    unittest.main()
