"""Themes, theme toggle, Settings page and database manager (Qt offscreen; no dialogs are shown)."""
import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from PySide6.QtWidgets import QApplication

from ohc.config import environment, oracle_home, thresholds
from ohc.config.databases import DatabaseStore
from ohc.config.settings import SettingsStore
from ohc.gui import theme as theme_mod
from ohc.gui.context import AppContext
from ohc.gui.database_dialog import DatabaseDialog
from ohc.gui.main_window import MainWindow
from ohc.gui.settings_page import SettingsPage
from ohc.gui.theme import PALETTES, ThemeManager, make_icon
from ohc.security import credstore
from tests.test_credstore import FakeBackend


def make_ctx(root: Path) -> AppContext:
    user = root / "user" / "me"
    return AppContext(root, SettingsStore(user / "settings.json"), DatabaseStore(user / "databases.json"), user / "credentials",
                      root / "config" / "environment.json", root / "config" / "thresholds.json", backend=FakeBackend())


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)
        self.addCleanup(self._tmp.cleanup)
        self.ctx = make_ctx(self.root)


class Palettes(unittest.TestCase):
    def test_both_themes_define_the_same_keys_and_differ(self):
        self.assertEqual(set(PALETTES["dark"]), set(PALETTES["light"]))
        self.assertNotEqual(PALETTES["dark"]["bg"], PALETTES["light"]["bg"])
        light = PALETTES["light"]
        self.assertEqual((light["sidebar_text"], light["card"], light["accent"]), ("#FFFFFF", "#FFFFFF", "#1F6FFF"))
        self.assertTrue(light["sidebar"].startswith("#0") and PALETTES["dark"]["sidebar"].startswith("#0"))
        for name in ("dark", "light"):
            self.assertIn(PALETTES[name]["accent"], theme_mod.stylesheet(name))
            self.assertNotIn("$", theme_mod.stylesheet(name))


class Manager(Base):
    def test_default_dark_toggle_persists_and_reloads(self):
        m = ThemeManager(self.ctx.settings)
        self.assertEqual(m.theme, "dark")
        seen = []
        m.changed.connect(seen.append)
        m.toggle()
        self.assertEqual((m.theme, seen), ("light", ["light"]))
        self.assertEqual(self.app.styleSheet(), theme_mod.stylesheet("light"))
        self.assertEqual(ThemeManager(SettingsStore(self.ctx.settings.path)).theme, "light")
        m.set_theme("light")
        self.assertEqual(seen, ["light"], "no signal when nothing changes")
        with self.assertRaises(ValueError):
            m.set_theme("blue")

    def test_unsaveable_choice_still_switches_and_reports(self):
        m = ThemeManager(self.ctx.settings)
        with mock.patch("os.replace", side_effect=PermissionError(13, "denied")):
            m.toggle()
        self.assertEqual(m.theme, "light")
        self.assertIn("Cannot write", m.last_error)

    def test_icons_exist_and_differ(self):
        sun, moon = make_icon("sun", "#F6C453"), make_icon("moon", "#0F1B33")
        self.assertFalse(sun.isNull() or moon.isNull())
        self.assertNotEqual(sun.pixmap(24, 24).toImage(), moon.pixmap(24, 24).toImage())


class Window(Base):
    def test_default_context_is_in_memory_and_keeps_seven_pages(self):
        w = MainWindow()
        self.assertEqual(w.pages.count(), 7)
        self.assertEqual(w.theme.theme, "dark")

    def test_toggle_icon_tooltip_style_and_persistence(self):
        w = MainWindow(self.ctx)
        self.assertEqual((w.toggle.property("icon_kind"), w.toggle.toolTip()), ("sun", "Switch to Light mode"))
        self.assertEqual(self.app.styleSheet(), theme_mod.stylesheet("dark"))
        w.toggle.click()
        self.assertEqual((w.toggle.property("icon_kind"), w.toggle.toolTip()), ("moon", "Switch to Dark mode"))
        self.assertEqual(self.app.styleSheet(), theme_mod.stylesheet("light"))
        self.assertEqual(json.loads(self.ctx.settings.path.read_text())["settings"]["theme"], "light")
        w2 = MainWindow(make_ctx(self.root))  # a new start reads the saved choice
        self.assertEqual((w2.theme.theme, w2.toggle.property("icon_kind")), ("light", "moon"))
        w2.toggle.click()
        self.assertEqual(w2.toggle.property("icon_kind"), "sun")

    def test_settings_combo_and_header_toggle_stay_in_sync(self):
        w = MainWindow(self.ctx)
        page = w.settings_page
        self.assertEqual(page.theme_combo.currentData(), "dark")
        w.toggle.click()
        self.assertEqual(page.theme_combo.currentData(), "light")
        page.theme_combo.setCurrentIndex(page.theme_combo.findData("dark"))
        self.assertEqual((w.theme.theme, w.toggle.property("icon_kind")), ("dark", "sun"))

    def test_header_toggle_is_a_small_icon_button(self):
        w = MainWindow(self.ctx)
        self.assertEqual((w.toggle.width(), w.toggle.height(), w.toggle.text()), (36, 36, ""))


class Settings(Base):
    def page(self):
        return SettingsPage(self.ctx, ThemeManager(self.ctx.settings))

    def make_home(self, dgmgrl=True) -> Path:
        home = self.root / "ora"
        (home / "bin").mkdir(parents=True, exist_ok=True)
        (home / "bin" / f"sqlplus{oracle_home.EXE}").write_text("x")
        if dgmgrl:
            (home / "bin" / f"dgmgrl{oracle_home.EXE}").write_text("x")
        return home

    def seed_thresholds(self):
        thresholds.write_default(self.ctx.thresholds_path)

    def test_blank_oracle_home_warns_and_missing_files_are_noted(self):
        p = self.page()
        self.assertEqual(p.home_edit.text(), "")
        self.assertEqual(p.home_status.objectName(), "warn")
        self.assertIn("not configured", p.home_status.text())
        self.assertIn("environment.json was not found", p.shared_note.text())
        self.assertTrue(p.save_btn.isEnabled())

    def test_validate_errors_and_warnings(self):
        p = self.page()
        p.home_edit.setText("\\\\server\\share")
        self.assertTrue(p.run_validate()[0])
        self.assertEqual(p.status.objectName(), "bad")
        p.home_edit.setText(str(self.make_home(dgmgrl=False)))
        errors, warnings = p.run_validate()
        self.assertEqual((errors, len(warnings)), ([], 1))
        p.home_edit.setText(str(self.make_home()))
        self.assertEqual(p.run_validate(), ([], []))
        self.assertEqual(p.status.objectName(), "ok")

    def test_save_writes_environment_and_changes_only_retention(self):
        self.seed_thresholds()
        before = thresholds.load_thresholds(self.ctx.thresholds_path).as_dict()
        p = self.page()
        p.home_edit.setText(str(self.make_home()))
        p.retention.setValue(90)
        self.assertTrue(p.save())
        self.assertEqual(environment.load_environment(self.ctx.environment_path)["ORACLE_HOME"], str(self.root / "ora"))
        after = thresholds.load_thresholds(self.ctx.thresholds_path).as_dict()
        self.assertEqual({k: v for k, v in after.items() if k != "RETENTION_DAYS"}, {k: v for k, v in before.items() if k != "RETENTION_DAYS"})
        self.assertEqual(after["RETENTION_DAYS"], 90)

    def test_invalid_input_is_not_saved(self):
        p = self.page()
        p.home_edit.setText("D:\\a;b")
        self.assertFalse(p.save())
        self.assertFalse(self.ctx.environment_path.exists())

    def test_missing_thresholds_are_created_only_if_the_user_agrees(self):
        p = self.page()
        p.retention.setValue(120)
        with mock.patch.object(SettingsPage, "_ask_create_thresholds", return_value=False):
            self.assertTrue(p.save())
        self.assertFalse(self.ctx.thresholds_path.exists())
        with mock.patch.object(SettingsPage, "_ask_create_thresholds", return_value=True):
            self.assertTrue(p.save())
        self.assertEqual(thresholds.load_thresholds(self.ctx.thresholds_path)["RETENTION_DAYS"], 120)

    def test_invalid_shared_files_disable_saving_and_are_not_touched(self):
        self.ctx.thresholds_path.parent.mkdir(parents=True)
        self.ctx.thresholds_path.write_text('{"schema_version": 1, "thresholds": {}}')
        self.ctx.environment_path.write_text("{ broken")
        with mock.patch("ohc.config.jsonio._sleep", lambda s: None):
            p = self.page()
        self.assertFalse(p.save_btn.isEnabled())
        self.assertFalse(p.home_edit.isEnabled())
        self.assertEqual(self.ctx.environment_path.read_text(), "{ broken")

    def test_save_failure_is_reported_not_raised(self):
        self.seed_thresholds()
        p = self.page()
        p.home_edit.setText(str(self.make_home()))
        with mock.patch("os.replace", side_effect=PermissionError(13, "denied")):
            self.assertFalse(p.save())
        self.assertIn("Not saved", p.status.text())

    def test_detect_fills_the_field_or_reports_nothing_found(self):
        p = self.page()
        with mock.patch("ohc.gui.settings_page.oh.detect_oracle_homes", return_value=[]):
            p.detect()
        self.assertEqual((p.home_edit.text(), p.status.objectName()), ("", "warn"))
        cand = oracle_home.Candidate(str(self.make_home()), "registry", True)
        with mock.patch("ohc.gui.settings_page.oh.detect_oracle_homes", return_value=[cand]):
            p.detect()
        self.assertEqual(p.home_edit.text(), cand.path)
        two = [cand, oracle_home.Candidate("D:\\other", "PATH", False)]
        with mock.patch("ohc.gui.settings_page.oh.detect_oracle_homes", return_value=two), \
                mock.patch.object(SettingsPage, "_choose_home", return_value="D:\\other"):
            p.detect()
        self.assertEqual(p.home_edit.text(), "D:\\other")

    def test_database_add_edit_delete_with_encrypted_login(self):
        p = self.page()
        self.assertFalse(p.edit_btn.isEnabled())
        self.assertIn("No databases", p.db_details.text())
        d = DatabaseDialog(self.ctx)
        d.name.setText("IMS")
        d.sid.setText("IMSPRD")
        d.username.setText("scott")
        d.password.setText("tiger-pw")
        d.accept()
        self.assertEqual(d.password.text(), "", "the password field is cleared")
        p.refresh_databases(d.result_entry.id)
        self.assertEqual(p.db_combo.currentText(), "IMS")
        self.assertIn("stored (encrypted)", p.db_details.text())
        self.assertIn("IMSPRD", p.db_details.text())
        self.assertNotIn(b"tiger-pw", self.ctx.databases.path.read_bytes())
        e = DatabaseDialog(self.ctx, d.result_entry)
        e.notes.setText("production")
        e.accept()
        with credstore.load_credentials(self.ctx.credentials_dir, d.result_entry.id, backend=self.ctx.backend) as c:
            self.assertEqual(bytes(c.password), b"tiger-pw")
        self.ctx.settings.set("default_db", d.result_entry.id)
        with mock.patch.object(SettingsPage, "_confirm", return_value=False):
            p.delete_database()
        self.assertEqual(len(self.ctx.databases.entries()), 1)
        with mock.patch.object(SettingsPage, "_confirm", return_value=True):
            p.delete_database()
        self.assertEqual((self.ctx.databases.entries(), list(self.ctx.credentials_dir.iterdir()), self.ctx.settings.get("default_db")),
                         ([], [], ""))

    def test_dialog_shows_validation_errors_and_saves_nothing(self):
        d = DatabaseDialog(self.ctx)
        d.name.setText("bad name")
        d.username.setText("u")
        d.password.setText("p")
        d.accept()
        self.assertIn("Name", d.error.text())
        self.assertEqual((self.ctx.databases.entries(), d.result_entry), ([], None))
        d.name.setText("OK")
        d.username.setText("")
        d.accept()
        self.assertIn("Username", d.error.text())

    def test_database_controls_are_disabled_without_a_usable_user_folder(self):
        for ctx in (AppContext.ephemeral(), AppContext(self.root, SettingsStore(), DatabaseStore(), self.ctx.credentials_dir,
                                                       self.ctx.environment_path, self.ctx.thresholds_path, databases_error="databases.json is invalid")):
            p = SettingsPage(ctx, ThemeManager(ctx.settings))
            self.assertFalse(p.add_btn.isEnabled())
            self.assertFalse(p.edit_btn.isEnabled())
        self.assertIn("invalid", p.db_details.text())

    def test_test_connection_is_disabled_until_the_runner_exists(self):
        self.assertFalse(self.page().test_btn.isEnabled())


class UserContext(unittest.TestCase):
    def test_for_current_user_survives_a_corrupt_settings_file(self):
        from ohc.security.identity import WinIdentity

        with tempfile.TemporaryDirectory() as d:
            who = WinIdentity("S-1-5-21-1-2-3-1001", "me", "PC")
            with mock.patch("ohc.userstore.current_identity", return_value=who):
                ctx = AppContext.for_current_user(Path(d))
                (Path(d) / "user" / "me" / "settings.json").write_text("{ broken")
                with mock.patch("ohc.config.jsonio._sleep", lambda s: None):
                    ctx2 = AppContext.for_current_user(Path(d))
            self.assertEqual((ctx.problems, ctx.credentials_dir.name), ([], "credentials"))
            self.assertEqual(len(ctx2.problems), 1)
            self.assertEqual(ctx2.settings.get("theme"), "dark")
            self.assertEqual((Path(d) / "user" / "me" / "settings.json").read_text(), "{ broken")


if __name__ == "__main__":
    unittest.main()
