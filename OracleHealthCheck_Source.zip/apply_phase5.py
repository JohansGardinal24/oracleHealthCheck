r"""Phase 5 apply script. Run from the project root (the folder that contains ohc\ and tools\):

    python apply_phase5.py            dry run: checks everything and writes nothing
    python apply_phase5.py --apply    writes the changes (backups of changed files: build\phase5_backup\)

New files are never overwritten. main_window.py is replaced only if it is still the Step 0.5 version.
app.py and the two docs are patched with exact-match checks. If anything does not match, nothing is written.
"""
import hashlib
import re
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path.cwd()
FILES = HERE / "files"
MAIN_WINDOW = "ohc/gui/main_window.py"
MAIN_WINDOW_ORIGINAL_SHA = "88e1ffc8b312bdfb2a80837669828e0014f26d2337a2a32348d66e6acfd3df8f"
apply_changes = "--apply" in sys.argv
problems, plan, notes = [], {}, []


def norm(text):
    return "\n".join(l.rstrip() for l in text.replace("\r\n", "\n").split("\n")).rstrip("\n") + "\n"


def read(rel):
    with open(ROOT / rel, encoding="utf-8", newline="") as f:
        return f.read()


def edit(text, old, new, label):
    nl = "\r\n" if "\r\n" in text else "\n"
    old, new = old.replace("\n", nl), new.replace("\n", nl)
    if text.count(old) != 1:
        problems.append(f"{label}: expected exactly 1 match, found {text.count(old)} for {old[:60]!r}")
        return text
    return text.replace(old, new)


def replace_section(text, heading, body, label):
    nl = "\r\n" if "\r\n" in text else "\n"
    pat = re.compile(r"^" + heading + r".*?(?=^## |\Z)", re.S | re.M)
    if len(pat.findall(text)) != 1:
        problems.append(f"{label}: section '{heading}' not found exactly once")
        return text
    return pat.sub(lambda _: body.replace("\n", nl), text)


if not (ROOT / "ohc" / "app.py").is_file():
    sys.exit("Run this from the project root (the folder that contains ohc\\app.py).")

# 1. new files and the main_window replacement
for src in sorted(FILES.rglob("*")):
    if not src.is_file():
        continue
    rel = src.relative_to(FILES).as_posix()
    data = src.read_bytes()
    dest = ROOT / rel
    if rel == MAIN_WINDOW:
        current = norm(read(rel))
        if current == norm(data.decode("utf-8")):
            notes.append(f"already applied: {rel}")
        elif hashlib.sha256(current.encode()).hexdigest() == MAIN_WINDOW_ORIGINAL_SHA:
            plan[rel] = data
        else:
            problems.append(f"{rel} is not the expected Step 0.5 version (it was edited); it was not replaced")
    elif dest.exists():
        if dest.read_bytes() == data:
            notes.append(f"already present: {rel}")
        else:
            problems.append(f"{rel} already exists with different content; it was not overwritten")
    else:
        plan[rel] = data

# 2. app.py
app = read("ohc/app.py")
if "_config_status" in app:
    notes.append("already applied: ohc/app.py")
else:
    app = edit(app, "def selftest(check_qt: bool = True, sql_only: bool = False):", '''def _config_status():
    from ohc.config import environment, thresholds
    from ohc.config.jsonio import ConfigFileError

    config = paths.app_root() / "config"
    lines, ok = [], True
    for name, load, missing in (("thresholds.json", thresholds.load_thresholds, thresholds.ThresholdsMissingError),
                                ("environment.json", environment.load_environment, environment.EnvConfigMissingError)):
        try:
            lines.append(f"Config {name}: OK (sha256 {load(config / name).sha256[:12]})")
        except missing:
            lines.append(f"Config {name}: not found (copy the config folder next to the EXE)")
        except (thresholds.ThresholdsError, ConfigFileError) as exc:
            ok = False
            lines.append(f"Config {name}: INVALID - {str(exc).splitlines()[0]}")
    return ok, lines


def selftest(check_qt: bool = True, sql_only: bool = False):''', "app.py (_config_status)")
    app = edit(app, "[_identity_status, _dpapi_status, _sql_status]", "[_identity_status, _dpapi_status, _config_status, _sql_status]", "app.py (checks list)")
    pat = re.compile(r"^def run_gui\(.*?(?=^def |\Z)", re.S | re.M)
    if len(pat.findall(app)) != 1:
        problems.append("app.py: run_gui not found exactly once")
    else:
        nl = "\r\n" if "\r\n" in app else "\n"
        app = pat.sub(lambda _: '''def run_gui() -> int:
    from PySide6.QtWidgets import QApplication, QMessageBox

    from ohc.gui.context import AppContext
    from ohc.gui.main_window import MainWindow

    qapp = QApplication(sys.argv[:1])
    qapp.setApplicationName("Oracle Health Check")
    try:
        context = AppContext.for_current_user()
    except Exception as exc:  # identity or per-user folder problem: explain and stop
        QMessageBox.critical(None, "Oracle Health Check", f"The per-user data folder cannot be used:\\n\\n{exc}")
        return 1
    window = MainWindow(context)
    window.show()
    for problem in context.problems:
        QMessageBox.warning(window, "Oracle Health Check", problem)
    return qapp.exec()


'''.replace("\n", nl), app)
    plan["ohc/app.py"] = app.encode("utf-8")

# 3. docs
guide, status = read("docs/DEV_GUIDE.md"), read("docs/STATUS.md")
if "ohc\\config\\environment.py" in guide:
    notes.append("already applied: docs")
else:
    G = "DEV_GUIDE.md"
    guide = edit(guide,
        "| `tools\\cred_probe.py` | Developer helper for the credential store, run as `python -m tools.cred_probe` (hidden password prompt, prints only lengths) |\n",
        "| `tools\\cred_probe.py` | Developer helper for the credential store, run as `python -m tools.cred_probe` (hidden password prompt, prints only lengths) |\n"
        "| `ohc\\config\\thresholds.py` | Shared `config\\thresholds.json`: 22 validated keys, immutable run snapshot with SHA-256, atomic save |\n"
        "| `ohc\\config\\environment.py` | Shared `config\\environment.json`: default Oracle Home (blank by default), NLS_LANG, report date format |\n"
        "| `ohc\\config\\oracle_home.py` | Oracle Home syntax check, sqlplus/dgmgrl inspection, priority resolution, read-only detection |\n"
        "| `ohc\\config\\databases.py` | Per-user `databases.json` store (no secrets) |\n"
        "| `ohc\\config\\settings.py` | Per-user `settings.json` store (theme, default database) |\n"
        "| `ohc\\config\\dbadmin.py` | Add, update and delete databases together with their encrypted credentials |\n"
        "| `ohc\\config\\jsonio.py` | Shared JSON helpers: duplicate-key detection, atomic writes |\n"
        "| `ohc\\gui\\theme.py` | Light and dark palettes, the stylesheet, sun/moon icons and `ThemeManager` |\n"
        "| `ohc\\gui\\settings_page.py` | Settings page: Oracle Home, databases, retention, theme |\n"
        "| `ohc\\gui\\database_dialog.py` | Add / Edit database dialog (including the encrypted login) |\n"
        "| `ohc\\gui\\context.py` | Shared config paths and the current user's stores |\n", G)
    guide = edit(guide, "| `ohc\\gui\\main_window.py` | Main window, left navigation, the `PAGES` list, dark stylesheet |\n",
                 "| `ohc\\gui\\main_window.py` | Main window, left navigation, theme toggle header, the `PAGES` list |\n", G)
    guide = edit(guide, "never deleted: a re-save keeps it as `.corrupt-<time>`. Neither is used by the GUI yet; `--selftest` runs a DPAPI\n",
                 "never deleted: a re-save keeps it as `.corrupt-<time>`. The Settings page uses them; `--selftest` runs a DPAPI\n", G)
    guide = edit(guide, "round trip on dummy data. Use `python -m tools.cred_probe` for manual checks.\n",
        "round trip on dummy data. Use `python -m tools.cred_probe` for manual checks.\n\n"
        "Shared configuration (next to the EXE, edited with any editor or the Settings page): `config\\thresholds.json`\n"
        "(22 keys, including `RETENTION_DAYS`) and `config\\environment.json` (default Oracle Home, NLS_LANG, report date\n"
        "format). Create them with `python -m ohc.config.thresholds --write-default PATH` and\n"
        "`python -m ohc.config.environment --write-default PATH`; list every problem in a file with `--check PATH`. Neither\n"
        "is created or defaulted silently. Copy the project's `config` folder next to the EXE when deploying; `--selftest`\n"
        "reports both files. Per user: `settings.json` (theme: the default is dark, saved when you click the sun/moon\n"
        "toggle or change the Settings page) and `databases.json`. Oracle Home priority: the database's override, then the\n"
        "shared default. Logs and reports use the fixed folders `logs` and `reports` under the install root.\n", G)
    guide = edit(guide,
        "- Shared, next to the EXE: `config\\thresholds.json` (thresholds and retention), `config\\environment.json`\n"
        "  (default Oracle Home, NLS_LANG, report date format), plus `logs\\`, `reports\\<date>\\` and `history\\`.\n",
        "- Shared, next to the EXE: `config\\thresholds.json` and `config\\environment.json` exist (see above); `logs\\`,\n"
        "  `reports\\<date>\\` and `history\\` are NOT implemented yet.\n", G)
    guide = edit(guide,
        "- Per Windows user: the folder, `owner.json`, `credentials\\` and `files\\work\\` exist, and so does the credential\n"
        "  library (see above). NOT implemented yet: `settings.json`, `databases.json`, any GUI use of credentials and\n"
        "  the per-run folders `files\\work\\<run-id>\\`.\n",
        "- Per Windows user: the folder, `owner.json`, `settings.json`, `databases.json`, `credentials\\` and the credential\n"
        "  library exist and are used by the Settings page. NOT implemented yet: the per-run folders `files\\work\\<run-id>\\`.\n", G)
    guide = edit(guide, "- `config\\thresholds.json` and `config\\environment.json` loading, validation and run snapshots.\n",
                 "- Using the validated configuration in runs: recording the thresholds snapshot in history and the retention cleanup (the files, validation and Settings page exist).\n", G)
    guide = edit(guide, "- Oracle Home detection and validation, connection testing, run cancellation and headless execution.\n",
                 "- Connection testing, run cancellation and headless execution.\n", G)
    guide = edit(guide, "- The Light/Dark theme toggle (planned together with the Settings page).\n", "", G)
    guide = edit(guide, "- Database management and the credential dialogs in the GUI (the per-user folder, the DPAPI wrapper and the encrypted credential files exist; see section 6).\n", "", G)
    guide = edit(guide,
        "| `CredentialUnreadableError` (format) | The credential file is damaged. Loading never modifies it; re-enter the credentials |\n",
        "| `CredentialUnreadableError` (format) | The credential file is damaged. Loading never modifies it; re-enter the credentials |\n"
        "| Settings: \"Oracle Home is not configured\" | A blank default is intentional. Use Browse or Detect, or set an Oracle Home per database |\n"
        "| Settings: thresholds.json or environment.json invalid or not found | Fix the named key, or copy the project's `config` folder next to the EXE. `python -m ohc.config.thresholds --check PATH` lists every problem |\n", G)

    S = "STATUS.md"
    nl = "\r\n" if "\r\n" in status else "\n"
    rows = [
        "| 5.1 Thresholds file | `ohc\\config\\thresholds.py` and `tests\\test_thresholds.py`: 27 tests passed; full suite 138 tests OK (4 skips); the default file's sha256 starts with 4e0de7eb; three deliberately invalid copies were rejected with exit code 1 |",
        "| 5.2-5.4 Configuration, Settings page, themes | Delivered as one bundle: `environment.json`, Oracle Home logic, per-user `settings.json` and `databases.json`, database manager with encrypted logins, Settings page, light/dark theme with sun/moon toggle. **Windows results not reported yet.** Update this row when they are |",
    ]
    anchor = nl + nl + "## Modified files in the latest step"
    if status.count(anchor) != 1:
        problems.append("STATUS.md: table end not found")
    else:
        i = status.index(anchor)
        status = status[:i] + nl + nl.join(rows) + status[i:]
    status = replace_section(status, r"## Modified files in the latest step", (
        "## Modified files in the latest step (Phase 5)\n\n"
        "Created: `ohc\\config\\jsonio.py`, `ohc\\config\\oracle_home.py`, `ohc\\config\\environment.py`, `ohc\\config\\databases.py`,\n"
        "`ohc\\config\\settings.py`, `ohc\\config\\dbadmin.py`, `ohc\\gui\\theme.py`, `ohc\\gui\\context.py`, `ohc\\gui\\database_dialog.py`,\n"
        "`ohc\\gui\\settings_page.py`, `tests\\test_config_files.py`, `tests\\test_gui_phase5.py`.\n"
        "Modified: `ohc\\gui\\main_window.py` (replaced), `ohc\\app.py` (config check in `--selftest`, per-user context in the GUI start),\n"
        "`docs\\DEV_GUIDE.md`, `docs\\STATUS.md`. No EXE rebuild yet (planned at the end of Phase 5).\n\n"), S)
    status = edit(status, "- Planned feature: global Light/Dark (sun/moon) theme toggle, to be built together with the Settings page.\n",
        "- The Settings page, database dialog and theme toggle have not been checked visually on Windows yet.\n"
        "- The Test Connection button is disabled until the SQL*Plus runner exists (Phase 6).\n"
        "- `config\\environment.json` is not created automatically; the Settings page creates it on Save, or use `python -m ohc.config.environment --write-default PATH`.\n", S)
    status = replace_section(status, r"## Next task \(proposed\)", (
        "## Next task (proposed)\n\n"
        "Phase 6: SQL*Plus and DGMGRL runner (original `@file` approach, credentials through stdin), connection test and check 1.\n"
        "Needs an Oracle test server. The plan is proposed; implementation waits for approval.\n"), S)
    plan["docs/DEV_GUIDE.md"] = guide.encode("utf-8")
    plan["docs/STATUS.md"] = status.encode("utf-8")

print("Plan:")
for rel in sorted(plan):
    print(f"  {'REPLACE' if (ROOT / rel).exists() else 'CREATE '} {rel}")
for n in notes:
    print("  note:", n)
if problems:
    print("\nNOT APPLIED - nothing was written. Problems:")
    for p in problems:
        print("  -", p)
    sys.exit(1)
if not apply_changes:
    print("\nDry run OK. Run again with --apply to write these changes.")
    sys.exit(0)
backup = ROOT / "build" / "phase5_backup"
for rel, data in plan.items():
    dest = ROOT / rel
    if dest.exists():
        (backup / rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(dest, backup / rel)
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
print(f"\nApplied {len(plan)} file(s). Backups of replaced files: {backup}")
