"""ASH tab of Database Reports (Qt offscreen, fake Oracle session only): tabs, parameters, validation, generation, history,
cancellation and layout in both themes. Real Oracle and real Windows rendering are NOT covered."""
import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if sys.platform == "win32":
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

import threading
import time
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest import mock

from PySide6.QtCore import QRect, Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QScrollArea, QWidget

from ohc import ash, ash_service, awr, awr_service
from tests.test_awr_page import Base
from tests.test_gui_run import wait_idle


class AshBase(Base):
    def setUp(self):
        super().setUp()
        self.page.tabs.setCurrentIndex(1)
        self.settle()
        self.ash = self.page.ash

    def generate(self):
        self.ash.generate_btn.click()
        self.assertTrue(wait_idle(self.win.gate))

    def folder(self):
        return awr_service.report_folder(self.ctx)

    def hist_names(self):
        h = self.ash.hist
        return [h.item(r, 5).text() for r in range(h.rowCount())]


class Tabs(AshBase):
    def test_ash_tab_is_live_and_switches_the_content(self):
        p = self.page
        self.assertEqual([p.tabs.tabText(i) for i in range(3)], ["AWR Report", "ASH Report", "ADDM Report"])
        self.assertEqual([p.tabs.isTabEnabled(i) for i in range(3)], [True, True, True])
        self.assertEqual(p.tabs.currentIndex(), 1)
        self.assertTrue(self.ash.isVisible() and not p.load_btn.isVisible())
        self.assertTrue(self.ash.isVisible())
        p.tabs.setCurrentIndex(0)
        self.assertTrue(p.load_btn.isVisible() and not self.ash.isVisible())
        p.tabs.setCurrentIndex(2)                                        # ADDM replaces ASH, and ASH comes back
        self.assertTrue(p.addm.isVisible() and not self.ash.isVisible())
        p.tabs.setCurrentIndex(1)
        self.assertTrue(self.ash.isVisible() and not p.addm.isVisible())

    def test_opening_the_page_or_the_tab_runs_nothing(self):
        with mock.patch.object(ash_service, "generate_report") as gen, mock.patch.object(awr_service, "load_snapshots") as load:
            self.page.tabs.setCurrentIndex(0)
            self.page.tabs.setCurrentIndex(1)
            self.settle()
            gen.assert_not_called()
            load.assert_not_called()


class SwitchLayout(AshBase):
    """Regression: ASH -> AWR used to show both contents for an instant, the window grew to the sum of their minimum heights
    (~1190 px) and stayed there: the AWR snapshot table ballooned and Generated AWR Reports was clipped until the window was resized."""

    def snapshot(self):
        p = self.page
        params, hist = p._awr_cards
        return {"win": (self.win.width(), self.win.height()), "page": (p.width(), p.height()), "win_min_h": self.win.minimumSizeHint().height(),
                "params": params.geometry().getRect(), "hist": hist.geometry().getRect(), "snap_rows": p.table.viewport().height() // 24}

    def check(self, w, h):
        p = self.page
        self.win.resize(w, h)
        p.tabs.setCurrentIndex(0)
        self.load()
        self.report("2026-10-16/AWR_Report_1_2_20261016_010101.html")
        p.refresh_btn.click()
        self.settle()
        self.settle()
        base = self.snapshot()
        self.assertEqual(base["win"], (w, h))
        for _ in range(3):
            p.tabs.setCurrentIndex(1)
            self.settle()
            self.assertEqual(self.win.height(), h, "switching to ASH must not resize the window")
            p.tabs.setCurrentIndex(0)
            self.settle()
            self.settle()
            now = self.snapshot()
            self.assertEqual(now, base, (w, h))                          # same window, page, card geometry and snapshot rows as before
            self.assertLessEqual(now["win_min_h"], h)                    # the window minimum never exceeds the window
            self.assertTrue(p.isAncestorOf(p.hist) and p.hist.isVisible() and p.table.isVisible())
            hist_card = p._awr_cards[1]
            self.assertLessEqual(hist_card.geometry().bottom(), p.height())          # Generated AWR Reports fully inside the page
            self.assertFalse(p.ash.isVisible())
        self.assertGreaterEqual(p.hist.viewport().height() // 30, 3)

    def test_round_trip_keeps_the_layout_at_1200x760(self):
        self.check(1200, 760)

    def test_round_trip_keeps_the_layout_at_1360x860(self):
        self.check(1360, 860)

    def test_round_trip_keeps_the_layout_when_large(self):
        self.check(1700, 1000)

    def test_ash_is_unchanged_by_the_round_trip(self):
        self.win.resize(1200, 760)
        self.settle()
        a = self.ash
        first = (a.geometry().getRect(), a.hist.viewport().height())
        self.page.tabs.setCurrentIndex(0)
        self.page.tabs.setCurrentIndex(1)
        self.settle()
        self.settle()
        self.assertEqual((a.geometry().getRect(), a.hist.viewport().height()), first)
        self.assertEqual((self.win.width(), self.win.height()), (1200, 760))


class Parameters(AshBase):
    def test_initial_state(self):
        a = self.ash
        self.assertTrue(a.rel_radio.isChecked() and not a.abs_radio.isChecked())
        self.assertEqual((a.rel_spin.value(), a.unit_combo.currentData(), a.duration.value()), (-15, "minutes", 15))
        self.assertEqual([a.unit_combo.itemData(i) for i in range(a.unit_combo.count())], ["minutes", "hours", "days"])
        self.assertEqual([(a.type_combo.itemText(i), a.type_combo.itemData(i)) for i in range(2)], [("HTML (Default)", "html"), ("Text", "text")])
        self.assertEqual(a.type_combo.currentData(), "html")
        self.assertEqual(a.name_edit.text(), "ASH_Report_<yyyymmdd_HHMMSS>")
        self.assertFalse(a.rac_check.isChecked() or a.open_check.isChecked())
        self.assertTrue(all(w.isEnabled() for w in (a.type_combo, a.name_edit, a.rac_check, a.open_check, a.duration, a.generate_btn)))
        self.assertTrue(a.rel_spin.isEnabled() and a.unit_combo.isEnabled())
        self.assertFalse(any(w.isEnabled() for w in (a.month, a.day, a.year, a.time_edit)))
        self.assertFalse(a.cancel_btn.isEnabled())
        self.assertIn("last 15 mins", a.summary.text())
        self.assertEqual([a.hist.horizontalHeaderItem(i).text() for i in range(8)],
                         ["Date & Time", "DB", "Begin Time", "End Time", "Duration", "File Name", "Size", "Actions"])
        self.assertEqual(a.date_combo.itemText(0), "All dates")
        self.assertIn("does not exist yet", a.hist_note.text())            # nothing generated yet

    def test_mode_switch_enables_the_matching_controls_and_selects_the_window(self):
        a = self.ash
        a.abs_radio.setChecked(True)
        self.assertTrue(a.month.isEnabled() and a.day.isEnabled() and a.year.isEnabled() and a.time_edit.isEnabled())
        self.assertFalse(a.rel_spin.isEnabled() or a.unit_combo.isEnabled())
        win, err = a.window()
        self.assertEqual((win.mode, err), ("absolute", ""))
        self.assertEqual(win.duration, 15)
        self.assertEqual(win.span()[1] - win.span()[0], timedelta(minutes=15))
        a.rel_radio.setChecked(True)
        self.assertEqual(a.window()[0].mode, "relative")
        self.assertTrue(a.rel_spin.isEnabled() and not a.month.isEnabled())

    def test_relative_units_and_limits(self):
        a = self.ash
        a.unit_combo.setCurrentIndex(1)
        a.rel_spin.setValue(-2)
        self.assertEqual(a.window()[0].minutes_back, 120)
        a.unit_combo.setCurrentIndex(2)
        a.rel_spin.setValue(-7)
        self.assertEqual(a.window()[0].minutes_back, 10080)
        a.rel_spin.setValue(-30)                                         # beyond 7 days is clamped by the control
        self.assertEqual(a.rel_spin.value(), -7)
        a.unit_combo.setCurrentIndex(0)
        self.assertEqual((a.rel_spin.minimum(), a.rel_spin.maximum()), (-10080, -1))
        a.rel_spin.setValue(-1)
        self.assertEqual(a.window()[0].minutes_back, 1)

    def test_specific_time_is_validated_and_the_interval_shown_matches_the_one_used(self):
        a = self.ash
        a.abs_radio.setChecked(True)
        year = datetime.now().year
        a.year.setCurrentText(str(year))
        a.month.setCurrentText("2")
        a.day.setCurrentText("30")
        win, err = a.window()
        self.assertIsNone(win)
        self.assertIn("not a valid date", err)
        self.assertFalse(a.generate_btn.isEnabled())
        self.assertIn("not a valid date", a.status.toPlainText())
        self.assertIn("not a valid date", a.summary.text())
        a.month.setCurrentText("12")
        a.day.setCurrentText("31")
        a.time_edit.setTime(a.time_edit.time().fromString("23:59:59", "HH:mm:ss"))
        self.assertIn("future", a.window()[1])
        self.assertFalse(a.generate_btn.isEnabled())
        a.year.setCurrentText(str(year - 1))
        a.month.setCurrentText("1")
        a.day.setCurrentText("1")
        self.assertIn("30 days", a.window()[1])
        a.abs_radio.setChecked(False)
        a.abs_radio.setChecked(True)
        a._abs_touched = False
        a._set_abs_to_default()
        a.duration.setValue(1440)                                        # default begin is 15 minutes ago: begin + 24 h ends in the future
        self.assertIn("ends in the future", a.window()[1])
        self.assertFalse(a.generate_btn.isEnabled())
        a.duration.setValue(10)
        win, err = a.window()
        self.assertEqual(err, "")
        b, e = win.span()
        self.assertEqual(e - b, timedelta(minutes=10))
        self.assertIn(b.strftime("%d-%b-%Y %H:%M:%S").upper(), a.summary.text())
        self.assertIn(e.strftime("%d-%b-%Y %H:%M:%S").upper(), a.summary.text())
        self.assertTrue(a.generate_btn.isEnabled())

    def test_report_type_name_and_rac(self):
        a = self.ash
        QTest.keyClick(a.type_combo, Qt.Key.Key_Down)
        self.assertEqual((a.type_combo.currentData(), a.name_label.text()), ("text", "Report Name (.txt)"))
        a.type_combo.setCurrentIndex(0)
        self.assertEqual(a.name_label.text(), "Report Name (.html)")
        QTest.mouseClick(a.rac_check, Qt.MouseButton.LeftButton, pos=a.rac_check.rect().center())
        self.assertTrue(a.rac_check.isChecked())
        for bad in ("", "../x", "a/b", "C:evil", "a.b", "x.html", "my report", "CON", "a" * 101):
            a.name_edit.setText(bad)
            self.assertFalse(a.generate_btn.isEnabled(), repr(bad))
            self.assertEqual(a.name_edit.property("invalid"), "true", repr(bad))
        a.name_edit.setText("peak_1")
        self.assertTrue(a.generate_btn.isEnabled())
        self.folder().mkdir(parents=True, exist_ok=True)
        (self.folder() / "taken.html").write_text("precious")
        a.name_edit.setText("taken")
        self.assertFalse(a.generate_btn.isEnabled())
        self.assertIn("already exists", a.status.toPlainText())
        a.type_combo.setCurrentIndex(1)
        self.assertTrue(a.generate_btn.isEnabled())


class Generation(AshBase):
    def test_options_reach_the_service(self):
        a = self.ash
        ok = ash_service.AshResult("ash", False, message="stub")
        with mock.patch.object(ash_service, "generate_report", return_value=ok) as gen:
            self.generate()
            ctx, db, win, token, fmt, name, rac = gen.call_args.args
            self.assertEqual((db, win.mode, win.minutes_back, fmt, name, rac), ("ims", "relative", 15, "html", "ASH_Report_<yyyymmdd_HHMMSS>", False))
            a.abs_radio.setChecked(True)
            a.duration.setValue(5)
            a.type_combo.setCurrentIndex(1)
            a.name_edit.setText("peak")
            a.rac_check.setChecked(True)
            self.generate()
            ctx, db, win, token, fmt, name, rac = gen.call_args.args
            self.assertEqual((win.mode, win.duration, fmt, name, rac), ("absolute", 5, "text", "peak", True))
        self.assertEqual(a.status.toPlainText(), "stub")

    def test_relative_html_report_end_to_end(self):
        a = self.ash
        with mock.patch("ohc.gui.ash_page.QDesktopServices.openUrl") as opener:
            self.generate()
            opener.assert_not_called()                                   # "open after generation" is off by default
        self.assertEqual(a._level, "ok", a.status.toPlainText())
        self.assertIn("SIMULATED DATA", a.status.toPlainText())
        files = list(self.folder().glob("ASH_Report_*.html"))
        self.assertEqual(len(files), 1)
        h = a.hist
        self.assertEqual(h.rowCount(), 1)
        self.assertEqual((h.item(0, 1).text(), h.item(0, 4).text(), h.item(0, 5).text()), ("ims [SIM]", "15 mins", files[0].name))
        b, e = h.item(0, 2).data(Qt.ItemDataRole.UserRole), h.item(0, 3).data(Qt.ItemDataRole.UserRole)
        self.assertEqual(e - b, timedelta(minutes=15))
        self.assertTrue(abs((e - datetime.now()).total_seconds()) < 60)
        self.assertRegex(h.item(0, 0).text(), r"^\d{4}-\d\d-\d\d \d\d:\d\d$")
        self.assertTrue(h.item(0, 6).text().endswith("B"))

    def test_specific_text_rac_report_keeps_the_chosen_window(self):
        a = self.ash
        a.abs_radio.setChecked(True)
        a.duration.setValue(5)
        a.type_combo.setCurrentIndex(1)
        a.rac_check.setChecked(True)
        a.name_edit.setText("peak_txt")
        want = a.window()[0].span()
        self.generate()
        f = self.folder() / "peak_txt.txt"
        self.assertTrue(f.is_file(), a.status.toPlainText())
        self.assertIn("RAC (all instances", f.read_text(encoding="utf-8"))
        h = a.hist
        self.assertEqual((h.item(0, 2).data(Qt.ItemDataRole.UserRole), h.item(0, 3).data(Qt.ItemDataRole.UserRole), h.item(0, 4).text()),
                         (want[0], want[1], "5 mins"))

    def test_open_after_generation_and_per_row_open(self):
        a = self.ash
        a.open_check.setChecked(True)
        with mock.patch("ohc.gui.ash_page.QDesktopServices.openUrl") as opener:
            self.generate()
            opener.assert_called_once()
            first = Path(opener.call_args.args[0].toLocalFile())
        a.open_check.setChecked(False)
        time.sleep(1.05)
        a.name_edit.setText("second")
        self.generate()
        self.assertEqual(a.hist.rowCount(), 2)
        with mock.patch("ohc.gui.ash_page.QDesktopServices.openUrl") as opener:
            for row in range(2):
                expected = Path(a.hist.item(row, 5).data(Qt.ItemDataRole.UserRole))
                holder = a.hist.cellWidget(row, 7)
                opener.reset_mock()
                holder.open_btn.click()
                self.assertEqual(Path(opener.call_args.args[0].toLocalFile()), expected)
                opener.reset_mock()
                holder.menu_btn.menu().actions()[0].trigger()
                self.assertEqual(Path(opener.call_args.args[0].toLocalFile()), expected)
        self.assertIn(first, {a.hist.cellWidget(r, 7).path for r in range(2)})

    def test_failures_empty_output_and_unsupported_rac(self):
        a = self.ash
        for mode, text in (("empty", "empty ASH report"), ("badreport", "ORA-20019"), ("fail", "ORA-13616")):
            with mock.patch.dict(os.environ, {"OHC_FAKE_ASH": mode}):
                a.name_edit.setText("f_" + mode)
                self.generate()
            self.assertEqual(a._level, "bad", mode)
            self.assertIn(text, a.status.toPlainText(), mode)
            self.assertEqual(a.hist.rowCount(), 0, mode)
            self.assertTrue(a.generate_btn.isEnabled() and a.cancel_btn.isEnabled() is False, mode)
        with mock.patch.dict(os.environ, {"OHC_FAKE_ASH": "norac"}):
            a.rac_check.setChecked(True)
            a.name_edit.setText("nr")
            self.generate()
            self.assertIn("ASH_GLOBAL_REPORT_HTML", a.status.toPlainText())
        self.assertEqual(list(self.folder().glob("*")), [])

    def test_no_duplicate_submission_and_responsive_gui_while_running(self):
        a = self.ash
        release, calls = threading.Event(), []

        def slow(ctx, db, win, token=None, *rest):
            calls.append(1)
            release.wait(10)
            return ash_service.AshResult("ash", False, True, "cancelled", db=db)
        with mock.patch.object(ash_service, "generate_report", slow):
            a.generate_btn.click()
            self.settle()
            self.assertTrue(self.win.gate.busy)
            self.assertFalse(a.generate_btn.isEnabled() or a.type_combo.isEnabled() or a.name_edit.isEnabled() or a.rel_spin.isEnabled())
            self.assertTrue(a.cancel_btn.isEnabled())
            a.generate()                                                  # a second submission is ignored
            a.generate_btn.click()
            self.settle()
            self.assertFalse(self.page.db_combo.isEnabled())
            start = time.time()
            for _ in range(20):
                self.app.processEvents()                                  # the GUI thread keeps spinning
            self.assertLess(time.time() - start, 2)
            release.set()
            self.assertTrue(wait_idle(self.win.gate))
        self.assertEqual(len(calls), 1)
        self.assertTrue(a.generate_btn.isEnabled() and not a.cancel_btn.isEnabled())

    def test_cancel_removes_the_partial_file(self):
        a = self.ash
        os.environ["OHC_FAKE_DELAY"] = "1"
        a.generate_btn.click()
        end = time.time() + 5
        while time.time() < end and not list(self.folder().glob("ASH_Report_*")):
            self.app.processEvents()
            time.sleep(0.01)
        self.assertTrue(a.cancel_btn.isEnabled())
        a.cancel_btn.click()
        self.assertFalse(a.cancel_btn.isEnabled())
        self.assertTrue(wait_idle(self.win.gate))
        self.assertEqual(list(self.folder().glob("ASH_Report_*")), [])
        self.assertIn("cancelled", a.status.toPlainText())
        self.assertEqual(a.hist.rowCount(), 0)
        self.assertTrue(a.generate_btn.isEnabled())

    def test_awr_tab_is_blocked_while_ash_runs_and_works_afterwards(self):
        release = threading.Event()

        def slow(ctx, db, win, token=None, *rest):
            release.wait(10)
            return ash_service.AshResult("ash", False, True, "cancelled", db=db)
        with mock.patch.object(ash_service, "generate_report", slow):
            self.ash.generate_btn.click()
            self.settle()
            self.page.tabs.setCurrentIndex(0)
            self.assertFalse(self.page.load_btn.isEnabled())              # one shared job gate
            release.set()
            self.assertTrue(wait_idle(self.win.gate))
        self.assertTrue(self.page.load_btn.isEnabled())
        self.page.load_btn.click()
        self.assertTrue(wait_idle(self.win.gate))
        self.assertEqual(self.page.table.rowCount(), 31)                  # AWR still loads snapshots


class History(AshBase):
    def make(self):
        self.files = {
            "a": self.report("2026-10-16/ASH_Report_20261016_014500.html", 100),
            "b": self.report("2026-10-15/ASH_Report_20261015_230000.html", 3 * 1024 * 1024),
            "c": self.report("2026-10-15/ASH_Report_20261015_214500.txt", 5000),
        }
        self.report("2026-10-16/AWR_Report_9235_9236_20261016_012216.html")
        self.report("2026-10-16/ADDM_Report_20261016_012216.html")
        self.report("2026-10-16/ims_health_20261016_010000.html")
        self.ash.refresh_btn.click()

    def test_discovery_filter_search_and_refresh_without_restart(self):
        self.make()
        a = self.ash
        self.assertEqual(self.hist_names(), [self.files[k].name for k in "abc"])          # AWR/ADDM/health files are not listed
        self.assertEqual(a.hist.item(0, 4).text(), "-")                                    # legacy file: window unknown
        self.assertEqual(a.hist.item(1, 6).text(), "3.0 MB")
        self.assertEqual(a.date_combo.count(), 3)
        a.date_combo.setCurrentIndex(a.date_combo.findData("2026-10-15"))
        self.assertEqual(a.hist.rowCount(), 2)
        a.date_combo.setCurrentIndex(0)
        a.search.setText("214500")
        self.assertEqual(self.hist_names(), [self.files["c"].name])
        a.search.setText("nothing")
        self.assertEqual(a.hist.rowCount(), 0)
        self.assertIn("No reports match", a.hist_note.text())
        a.search.setText("")
        new = self.report("2026-10-17/ASH_Report_20261017_010000.html")
        a.refresh_btn.click()                                                              # a new file shows up on Refresh
        self.assertEqual(a.hist.item(0, 5).text(), new.name)

    def test_row_buttons_open_their_own_file_and_missing_files_are_handled(self):
        self.make()
        a = self.ash
        with mock.patch("ohc.gui.ash_page.QDesktopServices.openUrl") as opener:
            for row in range(3):
                opener.reset_mock()
                a.hist.cellWidget(row, 7).open_btn.click()
                self.assertEqual(Path(opener.call_args.args[0].toLocalFile()), Path(a.hist.item(row, 5).data(Qt.ItemDataRole.UserRole)))
            self.files["a"].unlink()
            opener.reset_mock()
            a.hist.cellWidget(0, 7).open_btn.click()
            opener.assert_not_called()
        self.assertIn("no longer exists", a.status.toPlainText())
        self.assertEqual(a.hist.rowCount(), 2)

    def test_awr_history_does_not_show_ash_reports(self):
        self.make()
        self.page.tabs.setCurrentIndex(0)
        self.page.refresh_btn.click()
        self.assertEqual([self.page.hist.item(r, 3).text() for r in range(self.page.hist.rowCount())], ["AWR_Report_9235_9236_20261016_012216.html"])

    def test_missing_reports_folder_is_not_an_error(self):
        self.assertFalse((self.tmp / "reports").exists())
        self.assertIn("does not exist yet", self.ash.hist_note.text())
        self.assertEqual(self.ash.hist.rowCount(), 0)


class Layout(AshBase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        from PySide6.QtGui import QFont, QFontDatabase           # Segoe UI has Arial-like widths; see test_awr_page.Layout
        cls._old_font = cls.app.font()
        for family in ("Segoe UI", "Arial", "Liberation Sans"):
            if family in QFontDatabase.families():
                cls.app.setFont(QFont(family, 9))
                break

    @classmethod
    def tearDownClass(cls):
        cls.app.setFont(cls._old_font)

    def check(self, w, h, theme, rows):
        self.win.theme.set_theme(theme)
        self.win.resize(w, h)
        self.settle()
        for i, d in enumerate(("2026-10-16", "2026-10-15", "2026-10-14", "2026-10-13", "2026-10-12", "2026-10-11")):
            self.report(f"{d}/ASH_Report_{d.replace('-', '')}_01{i}500.html", 2 * 1024 * 1024)
        self.ash.refresh_btn.click()
        self.settle()
        self.settle()
        p, a, tag = self.page, self.ash, (w, h, theme)
        self.assertEqual((self.win.width(), self.win.height()), (w, h), tag)
        self.assertLessEqual(p.minimumSizeHint().width() + 300, 1200, tag)
        self.assertLessEqual(p.minimumSizeHint().height() + 60, 760, tag)
        self.assertLessEqual(p.minimumSizeHint().height(), p.height(), tag)
        self.assertEqual(p.findChildren(QScrollArea), [], tag)
        for wdg in p.findChildren(QWidget):
            if wdg.isVisibleTo(p) and wdg.width() and wdg.height() and not wdg.visibleRegion().isEmpty():
                vis = wdg.visibleRegion().boundingRect()
                r = wdg.mapTo(p, vis.topLeft())
                self.assertTrue(0 <= r.x() and r.x() + vis.width() <= p.width() + 1 and 0 <= r.y() and r.y() + vis.height() <= p.height() + 1, (tag, wdg))
        self.assertFalse(a.hist.horizontalScrollBar().isVisible(), tag)
        self.assertGreaterEqual(a.hist.viewport().height() // 30, rows, tag)
        self.assertEqual(a.hist.rowCount(), 6, tag)
        fm = a.hist.fontMetrics()
        for row in range(a.hist.rowCount()):                              # Begin/End/Duration texts and the action cell are never clipped
            for col in (0, 2, 3, 4, 6):
                self.assertLessEqual(fm.horizontalAdvance(a.hist.item(row, col).text()) + 8, a.hist.columnWidth(col), (tag, row, col, a.hist.item(row, col).text()))
            holder = a.hist.cellWidget(row, 7)
            self.assertLessEqual(holder.open_btn.sizeHint().width() + holder.menu_btn.width() + 8, a.hist.columnWidth(7), (tag, row))
        for wdg in (a.month, a.day, a.year, a.time_edit, a.unit_combo, a.duration, a.type_combo, a.name_edit):
            self.assertGreaterEqual(wdg.width(), wdg.minimumSizeHint().width(), (tag, wdg))
            self.assertGreaterEqual(wdg.height(), 22, (tag, wdg))
        self.assertGreaterEqual(a.name_edit.width(), 180, tag)
        self.assertGreaterEqual(a.rel_spin.width(), a.rel_spin.fontMetrics().horizontalAdvance("-10080") + 34, tag)    # value + spin buttons
        def box(x):
            return QRect(x.mapTo(p, x.rect().topLeft()), x.size())
        for left, right in ((a.rel_spin, a.unit_combo), (a.month, a.day), (a.day, a.year), (a.year, a.time_edit), (a.generate_btn, a.cancel_btn)):
            self.assertFalse(box(left).intersects(box(right)), (tag, left, right))
        self.assertLessEqual(box(a.generate_btn).bottom(), box(a.status).top() + 1, tag)
        self.assertLess(box(a.generate_btn).top(), box(a.hist).top(), tag)

    def test_1360x860_dark(self):
        self.check(1360, 860, "dark", 5)

    def test_1360x860_light(self):
        self.check(1360, 860, "light", 5)

    def test_1200x760_dark(self):
        self.check(1200, 760, "dark", 3)

    def test_1200x760_light(self):
        self.check(1200, 760, "light", 3)

    def test_status_and_summary_colours_follow_the_theme(self):
        a = self.ash
        a._set_status("bad", "x")
        dark = a.status.styleSheet()
        self.win.theme.set_theme("light")
        self.settle()
        self.assertNotEqual(a.status.styleSheet(), dark)
        self.win.theme.set_theme("dark")
        self.settle()
        self.assertEqual(a.status.styleSheet(), dark)


if __name__ == "__main__":
    unittest.main()
