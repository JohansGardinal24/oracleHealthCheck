"""Dashboard page: plan, progress events, results table, check details (Qt offscreen; the engine is real, the session is fake)."""
import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import tempfile
import unittest
from pathlib import Path
from unittest import mock

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication

from ohc.checks import engine, launcher
from ohc.gui.main_window import MainWindow
from ohc.gui.run_page import STATUS_ROLE
from ohc.resources import sql_access
from ohc.security import credstore
from tests.test_gui_run import make_ctx, wait_idle


class PlanTests(unittest.TestCase):
    def test_plan_sizes_and_order(self):
        self.assertEqual((len(engine.plan("SQL")), len(engine.plan("DG")), len(engine.plan("ALL"))), (17, 4, 21))
        self.assertEqual(engine.plan("DG"), [1, 4, 5, 8])
        self.assertEqual(engine.plan("ALL"), list(range(21)))

    def test_plan_matches_what_the_engine_records(self):
        from tests.test_fake_oracle import TH
        from ohc.checks import fake
        for mode in ("SQL", "DG", "ALL"):
            for scenario in ("healthy", "down"):
                with tempfile.TemporaryDirectory() as tmp:
                    events = []
                    r = engine.run_checks(mode, "ims", "ims", fake.FakeOracleSession(scenario, "ims"), TH, log_dir=Path(tmp) / "l",
                                          report_base=Path(tmp) / "r", emit=lambda x: None, on_event=events.append)
                self.assertEqual(sorted(x.idx for x in r.results), engine.plan(mode), (mode, scenario))
                self.assertEqual(events[0][0], "plan")
                self.assertEqual([e[0] for e in events].count("done"), len(r.results))
                self.assertTrue(all(x.seconds >= 0 for x in r.results))
                self.assertTrue(all(x.output for x in r.results))

    def test_sql_files_exist_in_the_bundle(self):
        bundle = set(sql_access.list_sql())
        for idx in range(21):
            self.assertTrue(set(engine.sql_files(idx)) <= bundle, idx)
        self.assertEqual(engine.sql_files(1), [])


class DashboardTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        env = mock.patch.dict(os.environ, {"OHC_FAKE_ORACLE": "warning"})
        env.start()
        self.addCleanup(env.stop)
        self.ctx = make_ctx(Path(tmp.name))
        credstore.save_credentials(self.ctx.credentials_dir, self.ctx.databases.entries()[0].id, "sys", "pw", backend=self.ctx.backend)
        (Path(tmp.name) / "config").mkdir()
        for name in ("environment.json", "thresholds.json"):  # the project's own default files
            (Path(tmp.name) / "config" / name).write_bytes((Path(__file__).parent.parent / "config" / name).read_bytes())
        self.win = MainWindow(self.ctx)
        self.addCleanup(self.win.deleteLater)

    def test_idle_layout(self):
        sizes = [self.win.pages.widget(r).table.rowCount() for r in (1, 2, 3)]
        self.assertEqual(sizes, [17, 4, 21])
        page = self.win.pages.widget(3)
        self.assertEqual(page.count_label.text(), "0 of 21 checks completed")
        self.assertEqual(page.state_label.text(), "Not Started")
        self.assertFalse(page.cancel_btn.isEnabled())
        self.assertFalse(page.open_file_btn.isEnabled() or page.view_log_btn.isEnabled())
        self.assertTrue(all(page.table.item(r, 2).data(STATUS_ROLE) == "PENDING" for r in range(21)))

    def test_full_fake_run_fills_the_dashboard(self):
        page = self.win.pages.widget(3)
        page.run_btn.click()
        self.assertTrue(wait_idle(self.win.gate))
        self.assertEqual(page.state_label.text(), "Completed")
        self.assertEqual(page.status.text(), "SIMULATED DATA - OVERALL: WARNING (exit code 1)")
        self.assertEqual((page.progress.value(), page.percent_label.text()), (21, "100%"))
        self.assertEqual(page.count_label.text(), "21 of 21 checks completed")
        states = [page.table.item(r, 2).data(STATUS_ROLE) for r in range(21)]
        self.assertNotIn("PENDING", states)
        self.assertIn("WARNING", states)
        self.assertTrue(page.table.item(0, 3).text().startswith("[FAKE]"))
        self.assertTrue(page.open_file_btn.isEnabled() and page.open_dir_btn.isEnabled() and page.view_log_btn.isEnabled())
        self.assertNotEqual(page.start_val.text(), "-")
        self.assertNotEqual(page.end_val.text(), "-")
        page.table.selectRow(3)  # check 4: tablespace
        self.assertEqual(page.det["id"].text(), "4")
        self.assertEqual(page.det["name"].text(), "TABLESPACE / DATAFILE")
        self.assertIn("v_tbs.sql", page.det["sql"].toolTip())  # the label shows the first script and "+N more"; the tooltip and SQL tab list all
        self.assertIn("-- ===== v_tbs.sql =====", page.sql_view.toPlainText())
        self.assertIn("Tablespace usage", page.out_view.toPlainText())
        self.assertNotIn("file", page.det)  # the Output File row is gone; the report itself is still produced
        self.assertTrue(str(page._result.report_file).endswith(".html"))
        page.table.selectRow(1)  # check 2: Data Guard has no SQL
        self.assertIn("DGMGRL", page.sql_view.toPlainText())
        self.assertIn("[FAKE / SIMULATED]", page.out_view.toPlainText())

    def test_option_1_runs_17_and_option_2_runs_4(self):
        for row, count in ((1, 17), (2, 4)):
            page = self.win.pages.widget(row)
            page.run_btn.click()
            self.assertTrue(wait_idle(self.win.gate))
            self.assertEqual(page.count_label.text(), f"{count} of {count} checks completed")

    def test_buttons_open_files_and_log_viewer(self):
        page = self.win.pages.widget(2)
        page.run_btn.click()
        self.assertTrue(wait_idle(self.win.gate))
        with mock.patch("ohc.gui.run_page.QDesktopServices.openUrl") as opener:
            page.open_file_btn.click()
            page.open_dir_btn.click()
        self.assertTrue(opener.call_args_list[0].args[0].toLocalFile().endswith(".html"))
        self.assertEqual(
            Path(opener.call_args_list[1].args[0].toLocalFile()),
            Path(page._result.report_file).parent,
        )
        with mock.patch("ohc.gui.run_page.LogDialog.exec") as dialog:
            page.view_log_btn.click()
        dialog.assert_called_once()

    def test_new_run_resets_the_table(self):
        page = self.win.pages.widget(2)
        page.run_btn.click()
        self.assertTrue(wait_idle(self.win.gate))
        with mock.patch("ohc.checks.launcher.run_option", side_effect=RuntimeError("boom")):
            page.run_btn.click()
            self.assertTrue(wait_idle(self.win.gate))
        self.assertEqual(page.state_label.text(), "Failed")
        self.assertTrue(all(page.table.item(r, 2).data(STATUS_ROLE) == "PENDING" for r in range(4)))

    def test_themes_render(self):
        for theme in ("light", "dark"):
            self.win.theme.set_theme(theme)
            self.win.pages.widget(3).grab()  # no exception while painting delegates and styles
        self.assertEqual(self.win.theme.theme, "dark")

    def test_one_banner_only(self):
        self.assertFalse(self.win.fake_banner.isHidden())
        self.assertFalse(any(hasattr(self.win.pages.widget(r), "fake_label") for r in (1, 2, 3)))


if __name__ == "__main__":
    unittest.main()
