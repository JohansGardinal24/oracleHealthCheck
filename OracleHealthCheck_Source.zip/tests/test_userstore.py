"""Tests for the per-user folder logic (fake identities; run on any OS)."""
import json
import tempfile
import unittest
from pathlib import Path

from ohc import userstore
from ohc.security.identity import WinIdentity
from ohc.userstore import CorruptOwnerFileError, OwnershipError, UserStoreError

SID_A = "S-1-5-21-111-222-333-1001"
SID_B = "S-1-5-21-111-222-333-1002"


def ident(account="imsadmin", sid=SID_A, domain="PC"):
    return WinIdentity(sid=sid, account=account, domain=domain)


class FolderLabel(unittest.TestCase):
    def test_plain_name_is_kept(self):
        self.assertEqual(userstore.folder_label("imsadmin", SID_A), "imsadmin")

    def test_invalid_characters_are_replaced(self):
        self.assertEqual(userstore.folder_label('a/b\\c:d*e?"f<g>h|i', SID_A), "a_b_c_d_e__f_g_h_i")

    def test_unicode_letters_are_kept(self):
        self.assertEqual(userstore.folder_label("José", SID_A), "José")

    def test_reserved_device_names_get_a_prefix(self):
        for name in ("CON", "nul", "COM1", "lpt9", "com1.txt"):
            self.assertTrue(userstore.folder_label(name, SID_A).startswith("_"), name)

    def test_dots_and_spaces_are_trimmed_and_empty_falls_back_to_sid(self):
        self.assertEqual(userstore.folder_label("  bob. ", SID_A), "bob")
        for name in ("", "..", " . ", "..."):
            self.assertEqual(userstore.folder_label(name, SID_A), SID_A)

    def test_length_is_limited_and_path_traversal_is_impossible(self):
        self.assertLessEqual(len(userstore.folder_label("x" * 200, SID_A)), 64)
        label = userstore.folder_label("..\\..\\evil", SID_A)
        self.assertNotIn("\\", label)
        self.assertNotIn("/", label)


class EnsureUserDir(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name) / "install"  # does not exist yet
        self.addCleanup(self._tmp.cleanup)

    def test_first_run_creates_folder_owner_file_and_subfolders(self):
        u = userstore.ensure_user_dir(self.root, ident())
        self.assertTrue(u.created)
        self.assertEqual(u.folder, self.root / "user" / "imsadmin")
        for p in (u.credentials, u.files, u.work):
            self.assertTrue(p.is_dir(), p)
        doc = json.loads(u.owner_file.read_text(encoding="utf-8"))
        self.assertEqual((doc["sid"], doc["account"], doc["schema_version"]), (SID_A, "imsadmin", 1))
        self.assertEqual(list(u.folder.glob("owner.json.tmp*")), [])

    def test_second_run_reuses_the_folder_without_changing_owner_json(self):
        first = userstore.ensure_user_dir(self.root, ident())
        before = first.owner_file.read_bytes()
        second = userstore.ensure_user_dir(self.root, ident())
        self.assertFalse(second.created)
        self.assertEqual(second.folder, first.folder)
        self.assertEqual(second.owner_file.read_bytes(), before)

    def test_two_accounts_get_separate_folders(self):
        a = userstore.ensure_user_dir(self.root, ident("imsadmin", SID_A))
        b = userstore.ensure_user_dir(self.root, ident("monitor", SID_B))
        self.assertNotEqual(a.folder, b.folder)
        self.assertEqual(sorted(p.name for p in (self.root / "user").iterdir()), ["imsadmin", "monitor"])

    def test_same_label_different_sid_is_refused_and_nothing_changes(self):
        userstore.ensure_user_dir(self.root, ident("bob", SID_A, "CORP"))
        owner = self.root / "user" / "bob" / "owner.json"
        before = owner.read_bytes()
        with self.assertRaises(OwnershipError):
            userstore.ensure_user_dir(self.root, ident("bob", SID_B, "PC"))
        self.assertEqual(owner.read_bytes(), before)
        self.assertEqual([p.name for p in (self.root / "user").iterdir()], ["bob"])

    def test_renamed_account_keeps_its_folder_because_the_sid_decides(self):
        old = userstore.ensure_user_dir(self.root, ident("oldname", SID_A))
        new = userstore.ensure_user_dir(self.root, ident("newname", SID_A))
        self.assertEqual(new.folder, old.folder)
        self.assertFalse(new.created)
        self.assertEqual([p.name for p in (self.root / "user").iterdir()], ["oldname"])

    def test_sid_comparison_ignores_case(self):
        userstore.ensure_user_dir(self.root, ident(sid=SID_A))
        again = userstore.ensure_user_dir(self.root, ident(sid=SID_A.lower()))
        self.assertFalse(again.created)

    def test_locate_is_read_only(self):
        folder, exists = userstore.locate_user_dir(self.root, ident())
        self.assertFalse(exists)
        self.assertEqual(folder, self.root / "user" / "imsadmin")
        self.assertFalse(self.root.exists())

    def test_invalid_sid_is_rejected(self):
        for bad in ("", "not-a-sid", "S-1-", "S-2-5-21"):
            with self.assertRaises(UserStoreError):
                userstore.ensure_user_dir(self.root, ident(sid=bad))

    def test_two_folders_claiming_one_sid_is_an_error(self):
        userstore.ensure_user_dir(self.root, ident("one", SID_A))
        dup = self.root / "user" / "two"
        dup.mkdir()
        (dup / "owner.json").write_bytes((self.root / "user" / "one" / "owner.json").read_bytes())
        with self.assertRaises(UserStoreError) as cm:
            userstore.ensure_user_dir(self.root, ident("one", SID_A))
        self.assertIn("more than one", str(cm.exception))

    def test_unrelated_corrupt_owner_files_are_ignored_during_the_scan(self):
        other = self.root / "user" / "someone"
        other.mkdir(parents=True)
        (other / "owner.json").write_text("{ broken", encoding="utf-8")
        u = userstore.ensure_user_dir(self.root, ident())
        self.assertTrue(u.created)
        self.assertEqual((other / "owner.json").read_text(encoding="utf-8"), "{ broken")

    def test_empty_unowned_folder_is_claimed_but_a_non_empty_one_is_not(self):
        (self.root / "user" / "imsadmin").mkdir(parents=True)
        self.assertTrue(userstore.ensure_user_dir(self.root, ident()).created)
        (self.root / "user" / "monitor").mkdir()
        (self.root / "user" / "monitor" / "stray.txt").write_text("x", encoding="utf-8")
        with self.assertRaises(UserStoreError):
            userstore.ensure_user_dir(self.root, ident("monitor", SID_B))

    def test_label_that_is_a_file_is_an_error(self):
        (self.root / "user").mkdir(parents=True)
        (self.root / "user" / "imsadmin").write_text("x", encoding="utf-8")
        with self.assertRaises(UserStoreError):
            userstore.ensure_user_dir(self.root, ident())


class CorruptOwnerFile(unittest.TestCase):
    MARKER = "SECRET-MARKER-12345"

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)
        self.addCleanup(self._tmp.cleanup)
        self.folder = self.root / "user" / "imsadmin"
        self.folder.mkdir(parents=True)

    def _check_refused_and_untouched(self, content: bytes):
        owner = self.folder / "owner.json"
        owner.write_bytes(content)
        with self.assertRaises(CorruptOwnerFileError) as cm:
            userstore.ensure_user_dir(self.root, ident())
        self.assertEqual(owner.read_bytes(), content, "the corrupt file must not be modified")
        self.assertNotIn(self.MARKER, str(cm.exception), "error text must not echo file content")

    def test_invalid_json(self):
        self._check_refused_and_untouched(("{ " + self.MARKER).encode())

    def test_empty_file(self):
        self._check_refused_and_untouched(b"")

    def test_binary_garbage(self):
        self._check_refused_and_untouched(b"\xff\xfe\x00" + self.MARKER.encode())

    def test_wrong_types_and_missing_fields(self):
        for doc in ([1, 2], {"sid": SID_A}, {"schema_version": 1}, {"schema_version": True, "sid": SID_A},
                    {"schema_version": 1, "sid": self.MARKER}, {"schema_version": "1", "sid": SID_A}):
            self._check_refused_and_untouched(json.dumps(doc).encode())

    def test_newer_schema_is_refused_without_modification(self):
        content = json.dumps({"schema_version": 99, "sid": SID_A}).encode()
        (self.folder / "owner.json").write_bytes(content)
        with self.assertRaises(UserStoreError) as cm:
            userstore.ensure_user_dir(self.root, ident())
        self.assertIn("newer version", str(cm.exception))
        self.assertEqual((self.folder / "owner.json").read_bytes(), content)

    def test_bom_is_tolerated(self):
        doc = {"schema_version": 1, "sid": SID_A}
        (self.folder / "owner.json").write_bytes(b"\xef\xbb\xbf" + json.dumps(doc).encode())
        self.assertFalse(userstore.ensure_user_dir(self.root, ident()).created)


if __name__ == "__main__":
    unittest.main()