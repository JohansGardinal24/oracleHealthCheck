"""Window sizing (nothing clipped, no scrollbars), sequential row numbers, hamburger in the sidebar (Qt offscreen)."""
import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if sys.platform == "win32":  # the offscreen plugin finds no fonts on Windows, which makes every text measurement meaningless
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

import tempfile
import unittest
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication, QLabel, QPushButton, QScrollArea, QWidget

from ohc.checks import engine
from ohc.gui.main_window import COLLAPSED_WIDTH, PAGES, REPORTS_ROW, SIDEBAR_WIDTH, MainWindow
from ohc.gui.widgets import WrapLabel
from tests.test_gui_run import make_ctx

LONG = "C:\\" + "\\".join(["very_long_directory_name"] * 8) + "\\19.0.0"


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def make_window(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        win = MainWindow(make_ctx(Path(tmp.name)))
        self.addCleanup(win.deleteLater)
        win.show()
        return win

    def settle(self):
        self.app.processEvents()
        self.app.processEvents()


class SizingTests(Base):
    def test_window_fits_at_1200x760_on_every_page_in_both_themes(self):
        win = self.make_window()
        win.pages.widget(1).home_label.setText(LONG)
        for theme in ("dark", "light"):
            win.theme.set_theme(theme)
            win.resize(1200, 760)
            self.settle()
            for row in range(len(PAGES)):  # name the page that is too wide, if any
                self.assertLessEqual(win.pages.widget(row).minimumSizeHint().width() + SIDEBAR_WIDTH, 1200, (theme, PAGES[row][0]))
                self.assertLessEqual(win.pages.widget(row).minimumSizeHint().height() + 60, 760, (theme, PAGES[row][0]))
            self.assertLessEqual(win.minimumSizeHint().width(), 1200, theme)   # the content needs no more than this ...
            self.assertLessEqual(win.minimumSizeHint().height(), 760, theme)
            self.assertEqual((win.width(), win.height()), (1200, 760), theme)  # ... so the window really is that size
            for row in range(len(PAGES)):
                win.nav.setCurrentRow(row)
                self.settle()
                page = win.pages.widget(row)
                self.assertLessEqual(page.minimumSizeHint().width(), page.width(), (theme, row))
                self.assertLessEqual(page.minimumSizeHint().height(), page.height(), (theme, row))

    def test_no_page_scrollbars_and_nothing_extends_outside_the_page(self):
        win = self.make_window()
        win.resize(1200, 760)
        for row in range(len(PAGES)):
            win.nav.setCurrentRow(row)
            self.settle()
            page = win.pages.widget(row)
            self.assertEqual(page.findChildren(QScrollArea), [], row)
            for w in page.findChildren(QWidget):
                if w.isVisibleTo(page) and w.width() and w.height():
                    r = w.mapTo(page, w.rect().topLeft())
                    self.assertGreaterEqual(r.x(), 0, (row, w))
                    self.assertGreaterEqual(r.y(), 0, (row, w))
                    self.assertLessEqual(r.x() + w.width(), page.width() + 1, (row, w))
                    self.assertLessEqual(r.y() + w.height(), page.height() + 1, (row, w))

    def test_window_stops_shrinking_instead_of_clipping(self):
        win = self.make_window()
        win.nav.setCurrentRow(1)
        win.resize(500, 300)
        self.settle()
        self.assertGreaterEqual(win.width(), win.minimumSizeHint().width())
        self.assertGreaterEqual(win.height(), win.minimumSizeHint().height())
        page = win.pages.widget(1)
        self.assertGreaterEqual(page.width(), page.minimumSizeHint().width())

    def test_long_text_wraps_instead_of_widening(self):
        win = self.make_window()
        before = win.minimumSizeHint().width()
        win.pages.widget(1).home_label.setText(LONG)
        self.settle()
        self.assertEqual(win.minimumSizeHint().width(), before)
        label = WrapLabel(LONG)
        self.assertEqual(label.text(), LONG)
        self.assertGreater(label.heightForWidth(150), label.heightForWidth(600))

    def test_collapsing_the_sidebar_lowers_the_minimum_width(self):
        win = self.make_window()
        expanded = win.minimumSizeHint().width()
        win.nav_toggle.click()
        self.settle()
        self.assertEqual(expanded - win.minimumSizeHint().width(), SIDEBAR_WIDTH - COLLAPSED_WIDTH)


class RunPageLayoutTests(Base):
    def test_log_and_output_file_row_are_gone(self):
        win = self.make_window()
        for row in (1, 2, 3):
            page = win.pages.widget(row)
            self.assertFalse(hasattr(page, "output"))
            texts = [w.text() for w in page.findChildren(QLabel)]
            self.assertNotIn("Execution Log", texts)
            self.assertNotIn("Output File", texts)
            self.assertNotIn("file", page.det)
            self.assertIn("Open Output File", [b.text() for b in page.findChildren(QPushButton)])  # the button stays

    def test_result_output_and_sql_get_real_vertical_space_at_1200x760(self):
        win = self.make_window()
        win.resize(1200, 760)
        for row in (1, 2, 3):
            win.nav.setCurrentRow(row)
            self.settle()
            page = win.pages.widget(row)
            self.assertGreaterEqual(page.tabs.height(), 200, row)
            self.assertGreaterEqual(page.out_view.height(), 150, row)
            self.assertLessEqual(page.state_icon.parentWidget().height(), 120, row)  # compact status card
            self.assertGreaterEqual(page.table.height(), 200, row)

    def test_table_size_hint_does_not_depend_on_its_columns(self):
        win = self.make_window()
        table = win.pages.widget(2).table
        before = (table.sizeHint(), table.minimumSizeHint())
        table.setColumnWidth(1, 900)
        self.assertEqual((table.sizeHint(), table.minimumSizeHint()), before)

    def test_sync_check_does_not_keep_resizing(self):
        """4 rows sit near the point where the table scrollbar appears; the layout must still settle."""
        win = self.make_window()
        win.nav.setCurrentRow(2)
        for height in range(640, 900, 13):
            win.resize(1250, height)
            self.settle()
            page = win.pages.widget(2)
            seen = []
            for _ in range(6):
                self.app.processEvents()
                seen.append((page.table.size().toTuple(), page.table.viewport().width(), page.tabs.size().toTuple()))
            self.assertEqual(len(set(seen)), 1, (height, seen))


class RowNumberingTests(Base):
    def test_first_column_is_sequential_but_check_ids_are_unchanged(self):
        win = self.make_window()
        for row, mode, count in ((1, "SQL", 17), (2, "DG", 4), (3, "ALL", 21)):
            page = win.pages.widget(row)
            plan = engine.plan(mode)
            self.assertEqual(page.table.rowCount(), count)
            self.assertEqual([page.table.item(r, 0).text() for r in range(count)], [str(n) for n in range(1, count + 1)])
            self.assertEqual([page.table.item(r, 0).data(Qt.ItemDataRole.UserRole + 1) for r in range(count)], plan)
            self.assertEqual([page.table.item(r, 1).text() for r in range(count)], [engine.NAMES[i] for i in plan])
            page.table.selectRow(count - 1)
            self.assertEqual(page.det["id"].text(), str(plan[-1] + 1))  # Check Details keeps the real ID
        sync = win.pages.widget(2)
        self.assertEqual((sync.table.item(0, 0).text(), sync.table.item(0, 0).toolTip()), ("1", "Check ID 2"))
        self.assertEqual(engine.plan("DG"), [1, 4, 5, 8])

    def test_numbers_do_not_change_during_updates(self):
        win = self.make_window()
        page = win.pages.widget(1)
        page._set_row(6, "OK", "x", 0.1, "out")
        page._on_event(("done", engine.CheckResult(9, "n", "INFO", "m", 0.0, "")))
        self.assertEqual([page.table.item(r, 0).text() for r in range(17)], [str(n) for n in range(1, 18)])


class HamburgerTests(Base):
    def test_hamburger_is_inside_the_sidebar_beside_the_branding(self):
        win = self.make_window()
        self.assertTrue(win.nav_box.isAncestorOf(win.nav_toggle))
        self.assertFalse(win.findChild(QWidget, "header").isAncestorOf(win.nav_toggle))
        head = win.sidebar.layout().itemAt(0).layout()      # the sidebar's top row (formerly `win.brand_row`): hamburger first, branding second
        self.assertIs(head.itemAt(0).widget(), win.nav_toggle)
        self.assertIs(head.itemAt(1).widget(), win.brand)
        self.assertFalse(win.nav_toggle.icon().isNull())

    def test_click_collapses_and_restores_in_both_themes(self):
        win = self.make_window()
        for theme in ("dark", "light"):
            win.theme.set_theme(theme)
            win.resize(1300, 800)
            self.settle()
            win.nav_toggle.click()
            self.settle()
            self.assertEqual(win.nav_box.width(), COLLAPSED_WIDTH)
            self.assertTrue(win.brand.isHidden())
            self.assertFalse(win.nav_toggle.isHidden())
            self.assertEqual(win.sidebar.items[(1, None)].toolTip(), "1. Oracle Health Check")
            win.nav.setCurrentRow(2)
            self.assertEqual(win.pages.currentIndex(), 2)
            win.nav_toggle.click()
            self.settle()
            self.assertEqual(win.nav_box.width(), SIDEBAR_WIDTH)
            buttons = [win.sidebar.group_btn if row == REPORTS_ROW else win.sidebar.items[(row, None)] for row in range(len(PAGES))]
            # every page has its sidebar entry again, in order; the Database Reports group is titled without its number (as designed)
            expected = [title if row != REPORTS_ROW else "Database Reports" for row, (title, _note) in enumerate(PAGES)]
            self.assertEqual([b.text().replace("&&", "&") for b in buttons], expected)      # "&&" is how a button shows a literal "&"


if __name__ == "__main__":
    unittest.main()
