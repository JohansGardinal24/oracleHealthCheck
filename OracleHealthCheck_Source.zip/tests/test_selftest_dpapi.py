"""The DPAPI block of --selftest: dummy in-memory round trip, nothing written to disk."""
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from ohc import app


class SelfTestDpapiBlock(unittest.TestCase):
    @unittest.skipIf(sys.platform == "win32", "non-Windows behaviour")
    def test_non_windows_reports_not_applicable(self):
        ok, lines = app.selftest(check_qt=False)
        self.assertTrue(ok)
        self.assertIn("DPAPI: n/a (not Windows)", lines)

    @unittest.skipUnless(sys.platform == "win32", "needs Windows DPAPI")
    def test_windows_round_trip_line_and_nothing_written(self):
        with tempfile.TemporaryDirectory() as d, mock.patch.dict(os.environ, {"OHC_DEV_HOME": d}):
            ok, lines = app.selftest(check_qt=False)
            text = "\n".join(lines)
            self.assertTrue(ok, text)
            self.assertIn("DPAPI: CurrentUser round trip OK", text)
            self.assertEqual(list(Path(d).iterdir()), [], "the self-test must not create files")


if __name__ == "__main__":
    unittest.main()