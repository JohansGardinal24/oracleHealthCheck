"""The shared wave of options 1, 2 and 3 (ohc.gui.run_skin.PageBackdrop): shape, position, both themes (Qt offscreen)."""
import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
import unittest

from PySide6.QtGui import QColor
from PySide6.QtWidgets import QApplication, QFrame, QWidget

from ohc.gui import run_skin

BG = {"light": "#F6F7FA", "dark": "#0F1014"}


def render(theme, width=1313):
    page = QWidget()
    page.resize(width, 600)
    page.setStyleSheet(f"background:{BG[theme]};")
    cards = []
    for x, w in ((26, 300), (340, 380), (656, 386)):
        card = QFrame(page)
        card.setGeometry(x, 97, w, 98)
        cards.append(card)
    run_skin.PageBackdrop(page, cards, lambda: theme, lambda: cards[0].y())
    page.show()
    QApplication.processEvents()
    return page.grab().toImage()


class SharedWaveTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_one_shared_wave_with_two_layers(self):
        self.assertEqual(len(run_skin.PageBackdrop._WAVE_LAYERS), 2)
        for layer in run_skin.PageBackdrop._WAVE_LAYERS:
            self.assertEqual(len(layer), 4)            # no per-page variant: start, segments, alpha top, alpha bottom

    def test_wave_sits_in_the_upper_right_and_fades_down_in_both_themes(self):
        for theme in ("light", "dark"):
            img = render(theme)
            bg = QColor(BG[theme])
            tint = lambda x, y: abs(QColor(img.pixel(x, y)).red() - bg.red()) + abs(QColor(img.pixel(x, y)).green() - bg.green())
            self.assertEqual(tint(150, 20), 0, theme)               # far left of the strip stays the plain page colour
            self.assertEqual(tint(500, 40), 0, theme)               # ... and so does the middle: the wave starts at ~57 % of the width
            self.assertGreater(tint(1250, 25), 8, theme)            # crest area: visibly tinted
            self.assertGreater(tint(1250, 25), tint(1250, 85), theme)   # fades towards the cards
            self.assertGreater(tint(1100, 25), 4, theme)            # the first crest is there too

    def test_wave_scales_with_the_page_width(self):
        wide, narrow = render("light", 1600), render("light", 1000)
        self.assertGreater(abs(QColor(wide.pixel(1500, 25)).green() - 247), 4)
        self.assertGreater(abs(QColor(narrow.pixel(950, 25)).green() - 247), 4)


if __name__ == "__main__":
    unittest.main()
