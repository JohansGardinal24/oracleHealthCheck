"""Dashboard redesign, look only: heading above the toolbar, the shared wave + card shadows, status pills with icons, the percentages in the
Check Status Summary (computed from the real counts), the warning icon. Qt offscreen. Run/Cancel, database selection, navigation, report opening
and the data itself are covered by test_dashboard_page / test_dashboard and are not touched."""
import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if sys.platform == "win32":
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

import shutil
import tempfile
import unittest
from pathlib import Path

from PySide6.QtCore import QPoint, QRect, Qt
from PySide6.QtGui import QColor, QImage, QPainter, QRegion
from PySide6.QtWidgets import QApplication, QStyleOptionViewItem, QWidget

from ohc import dashboard_data as dd
from ohc.gui import run_skin
from ohc.gui.dashboard_page import StatIcon, StatusBadgeDelegate
from ohc.gui.reports_page import STATUS_STYLE
from ohc.gui.run_page import STATUS_ROLE

ROW = 0                    # the Dashboard page


def summary(ok: int, warn: int, crit: int, other: int = 0):
    rows = [("OK", ok), ("WARNING", warn), ("CRITICAL", crit), ("SKIPPED", other)]
    return dd.RunSummary(db="x", rows=[dd.CheckRow(f"CHK_{i:02d}", "n", status, "") for i, status in enumerate(s for s, n in rows for _ in range(n))])


class SkinChecks:
    """The assertions. A subclass provides self.page (DashboardPage), self.set_theme(name) and self.settle()."""

    @staticmethod
    def painted(widget):
        img = QImage(widget.size(), QImage.Format.Format_ARGB32_Premultiplied)     # only what the backdrop paints; grab() adds an opaque background
        img.fill(QColor(0, 0, 0, 0))
        widget.render(img, QPoint(0, 0), QRegion(), QWidget.RenderFlag.DrawChildren)
        return img

    @staticmethod
    def close(a, b, tol=28):
        return all(abs(x - y) <= tol for x, y in ((a.red(), b.red()), (a.green(), b.green()), (a.blue(), b.blue())))

    def pos(self, widget):
        return widget.mapTo(self.page, QPoint(0, 0))

    def test_heading_is_above_the_toolbar_which_holds_last_updated_and_refresh(self):
        p = self.page
        title = next(w for w in p.findChildren(QWidget) if w.objectName() == "pageTitle")
        self.assertLess(self.pos(title).y(), self.pos(p.run_btn).y())                                  # heading first, toolbar below it
        row = [p.db_combo, p.dot, p.conn_label, p.run_btn, p.cancel_btn, p.updated, p.refresh_btn]
        centers = [self.pos(w).y() + w.height() // 2 for w in row]
        self.assertLessEqual(max(centers) - min(centers), 8, centers)                                  # one toolbar row
        xs = [self.pos(w).x() for w in row]
        self.assertEqual(xs, sorted(xs))                                                               # database, status, Run, Cancel ... Last Updated, Refresh
        self.assertTrue(p.updated.text().startswith("Last Updated: "))
        self.assertLess(self.pos(p.refresh_btn).y(), self.pos(p._stat_frames[0]).y())                  # and the KPI cards follow the toolbar

    def test_existing_controls_are_unchanged(self):
        p = self.page
        self.assertEqual((p.run_btn.text(), p.cancel_btn.text(), p.refresh_btn.text()), ("\u25B6  Run", "\u25A0  Cancel", "\u27F3  Refresh"))
        self.assertEqual(p.run_btn.objectName(), "primary")
        self.assertEqual(sorted(p.quick), ["addm", "ash", "awr", "health", "sync"])
        self.assertEqual(len(p._stat_frames), 4)
        self.assertTrue(p.footer.text().startswith("Version "))
        self.assertIn("SQL bundle", p.footer.text())

    def test_the_page_uses_the_shared_wave_backdrop_in_the_corner_only(self):
        p = self.page
        self.assertIs(type(p._backdrop), run_skin.PageBackdrop)
        self.assertIs(p._backdrop._WAVE_LAYERS, run_skin.PageBackdrop._WAVE_LAYERS)                    # the approved wave itself, not a copy
        self.assertEqual(p._backdrop.geometry(), p.rect())
        for theme in ("light", "dark"):
            self.set_theme(theme)
            img = self.painted(p._backdrop)
            y = max(3, p._stat_frames[0].y() - 10)
            self.assertGreater(img.pixelColor(int(img.width() * 0.93), y).alpha(), 0, theme)
            self.assertEqual(img.pixelColor(int(img.width() * 0.20), y).alpha(), 0, theme)

    def pill(self, row, status):
        table = self.page.results
        table.item(row, 2).setData(STATUS_ROLE, status)                                               # display only: the status code is what the pill paints from
        img = QImage(90, 28, QImage.Format.Format_ARGB32)
        img.fill(QColor("#FFFFFF"))
        option = QStyleOptionViewItem()
        option.rect, option.font = QRect(0, 0, 90, 28), table.font()
        painter = QPainter(img)
        table.itemDelegateForColumn(2).paint(painter, option, table.model().index(row, 2))
        painter.end()
        return img

    def test_status_pills_are_capsules_with_icons_in_the_approved_tints(self):
        p = self.page
        self.assertIsInstance(p.results.itemDelegateForColumn(2), StatusBadgeDelegate)
        for theme in ("light", "dark"):
            self.set_theme(theme)
            seen = []
            for row, status in enumerate(("OK", "WARNING", "CRITICAL")):
                fill, _ink, icon, _mark = STATUS_STYLE[theme][status]
                img = self.pill(row, status)
                self.assertEqual(img.pixelColor(80, 14).name(), QColor(fill).name(), (theme, status))                  # capsule tint
                icon_px = sum(1 for x in range(13, 27) for y in range(7, 21) if self.close(img.pixelColor(x, y), QColor(icon)))
                self.assertGreaterEqual(icon_px, 6, (theme, status))                                                       # the icon, in its colour
                self.assertEqual(img.pixelColor(7, 5).name(), "#ffffff", (theme, status))                                  # rounded corner
                seen.append(img)
            plain = self.pill(3, "PENDING")                                                                                # "Not Run": quiet capsule, no icon
            self.assertNotEqual(plain, seen[0])
            self.assertEqual(self.page.results.item(3, 2).data(STATUS_ROLE), "PENDING")
            self.assertEqual(StatusBadgeDelegate.LABELS, {"OK": "Passed", "WARNING": "Warning", "CRITICAL": "Critical"})

    def test_summary_percentages_are_computed_from_the_real_counts(self):
        p = self.page
        cases = ((7, 2, 1, 0, ["70%", "20%", "10%"]), (1, 1, 1, 0, ["33%", "33%", "33%"]), (3, 0, 0, 0, ["100%", "0%", "0%"]), (0, 0, 0, 0, ["0%", "0%", "0%"]))
        for ok, warn, crit, other, want in cases:
            p.summary = summary(ok, warn, crit, other)
            p._paint_chart()
            self.assertEqual([p.legend[k][1].text() for k in ("healthy", "warnings", "critical")], [str(ok), str(warn), str(crit)])
            self.assertEqual([p.legend_pct[k].text() for k in ("healthy", "warnings", "critical")], want, (ok, warn, crit))
        p.summary = summary(1, 0, 0, 1)                                                                # "Other" only shows when there is something in it
        p._paint_chart()
        self.assertFalse(p.legend_pct["other"].isHidden())
        p.summary = summary(1, 0, 0, 0)
        p._paint_chart()
        self.assertTrue(p.legend_pct["other"].isHidden())

    def test_nothing_run_yet_shows_a_grey_donut_zero_counts_and_zero_percent(self):
        p = self.page
        p.summary = summary(0, 0, 0)
        p._paint_chart()
        self.assertEqual(p.donut.values, (0, 0, 0, 0))                                                 # the existing grey empty-state ring
        for key in ("healthy", "warnings", "critical"):
            self.assertEqual(p.legend[key][1].text(), "0", key)
            self.assertEqual(p.legend_pct[key].text(), "0%", key)
            self.assertFalse(p.legend_pct[key].isHidden(), key)                                          # shown, not blank

    def test_donut_segments_follow_the_actual_counts(self):
        p = self.page
        for ok, warn, crit in ((7, 2, 1), (1, 0, 4), (0, 3, 0)):
            p.summary = summary(ok, warn, crit)
            p._paint_chart()
            self.assertEqual(p.donut.values[:3], (ok, warn, crit))                                        # green / amber / red = Passed / Warnings / Failed

    def test_legend_rows_are_packed_with_separators_and_percentages_at_the_right_edge(self):
        p = self.page
        p.summary = summary(5, 2, 1)
        p._paint_chart()
        self.settle()
        card = p.donut.parentWidget()
        card_right = card.mapTo(p, card.rect().topRight()).x()
        ys = [self.pos(p.legend[k][1]).y() for k in ("healthy", "warnings", "critical")]
        self.assertTrue(30 <= ys[1] - ys[0] <= 48 and 30 <= ys[2] - ys[1] <= 48, ys)                      # about 40 px apart, as in the reference
        for key in ("healthy", "warnings", "critical"):
            value, pct = p.legend[key][1], p.legend_pct[key]
            self.assertLess(self.pos(value).x(), self.pos(pct).x(), key)                                  # count, then percentage
            self.assertGreaterEqual(self.pos(pct).x() + pct.width(), card_right - 24, key)                # the percentages reach the card's right edge
            self.assertEqual(pct.alignment() & Qt.AlignmentFlag.AlignRight, Qt.AlignmentFlag.AlignRight)
        self.assertEqual([sep.isHidden() for sep in p.legend_seps], [False, False, True])                 # lines between the three rows, none under the last
        sy = [self.pos(sep).y() for sep in p.legend_seps[:2]]
        self.assertTrue(ys[0] < sy[0] < ys[1] and ys[1] < sy[1] < ys[2], (ys, sy))
        p.summary = summary(5, 2, 1, other=1)                                                             # "Other" row appears: the line under "Failed" with it
        p._paint_chart()
        self.assertEqual([sep.isHidden() for sep in p.legend_seps], [False, False, False])

    def test_warning_kpi_icon_is_a_triangle(self):
        img = QImage(40, 40, QImage.Format.Format_ARGB32)
        img.fill(QColor(0, 0, 0, 0))
        StatIcon("!", "#F59E0B").render(img, QPoint(0, 0), QRegion(), QWidget.RenderFlag.DrawChildren)
        self.assertGreater(img.pixelColor(14, 28).red(), 200)                                           # white base of the triangle (the old "!" had amber here)
        self.assertGreater(img.pixelColor(14, 28).green(), 200)


class DashboardSkinTests(SkinChecks, unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def settle(self):
        self.app.processEvents()
        self.app.processEvents()

    def setUp(self):
        from ohc.gui.main_window import MainWindow
        from tests.test_gui_run import make_ctx
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.win = MainWindow(make_ctx(self.tmp))
        self.addCleanup(self.win.deleteLater)
        self.win.resize(1360, 860)
        self.win.show()
        self.win.nav.setCurrentRow(ROW)
        self.page = self.win.pages.widget(ROW)
        self.settle()

    def set_theme(self, name):
        self.win.theme.set_theme(name)
        self.settle()


if __name__ == "__main__":
    unittest.main()
