"""Credential store tests. A fake DPAPI backend (per-account, per-entropy, tamper-evident) runs everywhere;
the real DPAPI integration tests run only on Windows."""
import contextlib
import hashlib
import io
import pickle
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from ohc.security import credstore, dpapi
from ohc.security.credstore import (CredentialError, CredentialNotFoundError, CredentialUnreadableError)
from ohc.security.dpapi import DpapiError
from tools import cred_probe

USER, PASSWORD = "scott-user-77", "Tiger-P@ss-4242"
ID_A, ID_B = "a" * 16, "b" * 16


class FakeBackend:
    """Mimics DPAPI: blob only opens for the same account and entropy, and any change is detected."""

    def __init__(self, account="alice"):
        self.account, self.fail_protect, self.fail_unprotect = account, False, False

    def _tag(self, entropy, cipher):
        return hashlib.sha256(self.account.encode() + b"|" + entropy + b"|" + cipher).digest()[:8]

    def _stream(self, entropy, n):
        return (hashlib.sha256(self.account.encode() + b"#" + entropy).digest() * (n // 32 + 1))[:n]

    def protect(self, data, entropy=b""):
        if self.fail_protect:
            raise DpapiError("protect", 5)
        cipher = bytes(a ^ b for a, b in zip(data, self._stream(entropy, len(data))))
        return b"FK" + self._tag(entropy, cipher) + cipher

    def unprotect(self, blob, entropy=b""):
        blob = bytes(blob)
        if self.fail_unprotect or len(blob) < 11 or blob[:2] != b"FK" or blob[2:10] != self._tag(entropy, blob[10:]):
            raise DpapiError("unprotect", 13)
        cipher = blob[10:]
        return bytearray(a ^ b for a, b in zip(cipher, self._stream(entropy, len(cipher))))


class StoreCase(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self._tmp.name) / "credentials"
        self.fake = FakeBackend()
        self.addCleanup(self._tmp.cleanup)

    def save(self, db_id=ID_A, user=USER, password=PASSWORD):
        credstore.save_credentials(self.dir, db_id, user, password, backend=self.fake)

    def load(self, db_id=ID_A):
        return credstore.load_credentials(self.dir, db_id, backend=self.fake)

    def file(self, db_id=ID_A):
        return self.dir / f"{db_id}.dat"

    def names(self):
        return sorted(p.name for p in self.dir.iterdir()) if self.dir.exists() else []


class RoundTripAndFormat(StoreCase):
    def test_round_trip_returns_bytearrays_that_can_be_wiped(self):
        self.save()
        c = self.load()
        self.assertEqual((bytes(c.username), bytes(c.password)), (USER.encode(), PASSWORD.encode()))
        self.assertIsInstance(c.password, bytearray)
        c.wipe()
        self.assertEqual(bytes(c.password), bytes(len(PASSWORD)))

    def test_context_manager_wipes(self):
        self.save()
        with self.load() as c:
            keep = c.password
        self.assertEqual(bytes(keep), bytes(len(PASSWORD)))

    def test_file_has_header_and_no_plaintext_and_no_leftovers(self):
        self.save()
        data = self.file().read_bytes()
        self.assertTrue(data.startswith(b"OHCC\x01"))
        self.assertNotIn(USER.encode(), data)
        self.assertNotIn(PASSWORD.encode(), data)
        self.assertEqual(self.names(), [f"{ID_A}.dat"])

    def test_utf8_bytes_and_bytearray_inputs(self):
        self.save(user="Jos\u00e9", password="p\u00e4ss-\u20ac")
        with self.load() as c:
            self.assertEqual((bytes(c.username), bytes(c.password)), ("Jos\u00e9".encode(), "p\u00e4ss-\u20ac".encode()))
        self.save(user=b"bytes-user", password=bytearray(b"ba-pass"))
        with self.load() as c:
            self.assertEqual((bytes(c.username), bytes(c.password)), (b"bytes-user", b"ba-pass"))

    def test_length_limits(self):
        self.save(user="u", password="p" * credstore.MAX_FIELD)
        for user, pw in (("", "x"), ("x", ""), ("x" * 1025, "x"), ("x", "x" * 1025)):
            with self.assertRaises(ValueError):
                self.save(user=user, password=pw)
        for bad in (123, None):
            with self.assertRaises(TypeError):
                self.save(user=bad)

    def test_overwrite_replaces_without_quarantine(self):
        self.save()
        self.save(password="new-pass-1")
        with self.load() as c:
            self.assertEqual(bytes(c.password), b"new-pass-1")
        self.assertEqual(self.names(), [f"{ID_A}.dat"])

    def test_has_and_delete(self):
        self.assertFalse(credstore.has_credentials(self.dir, ID_A))
        self.assertFalse(credstore.delete_credentials(self.dir, ID_A))
        self.save()
        self.assertTrue(credstore.has_credentials(self.dir, ID_A))
        self.assertTrue(credstore.delete_credentials(self.dir, ID_A))
        self.assertFalse(self.file().exists())


class IdsAndPaths(StoreCase):
    def test_generated_ids_are_valid_and_unique(self):
        ids = {credstore.new_database_id() for _ in range(50)}
        self.assertEqual(len(ids), 50)
        for i in ids:
            self.assertRegex(i, r"^[0-9a-f]{16}$")

    def test_invalid_ids_are_rejected_everywhere(self):
        for bad in ("", "../x", "..\\x", "A" * 16, "a" * 15, "a" * 33, "g" * 16, "a" * 16 + ".dat", None, 5):
            for call in (lambda i: self.save(db_id=i), lambda i: self.load(i),
                         lambda i: credstore.has_credentials(self.dir, i), lambda i: credstore.delete_credentials(self.dir, i)):
                with self.assertRaises(ValueError):
                    call(bad)
        self.assertFalse(self.dir.exists())


class FailureHandling(StoreCase):
    def test_missing_file(self):
        with self.assertRaises(CredentialNotFoundError) as cm:
            self.load()
        self.assertEqual(cm.exception.category, "missing")

    def test_copy_to_another_database_id_cannot_be_decrypted(self):
        self.save(ID_A)
        self.file(ID_B).write_bytes(self.file(ID_A).read_bytes())
        with self.assertRaises(CredentialUnreadableError) as cm:
            self.load(ID_B)
        self.assertEqual(cm.exception.category, "decrypt")

    def test_another_windows_account_cannot_decrypt_and_file_is_unchanged(self):
        self.save()
        before = self.file().read_bytes()
        other = FakeBackend("bob")
        with self.assertRaises(CredentialUnreadableError) as cm:
            credstore.load_credentials(self.dir, ID_A, backend=other)
        self.assertEqual(cm.exception.category, "decrypt")
        self.assertEqual(self.file().read_bytes(), before)

    def test_damaged_files_are_reported_and_never_modified(self):
        self.save()
        good = self.file().read_bytes()
        for bad in (b"", b"OHC", b"OHCC\x01", b"XXXX\x01" + good[5:], b"OHCC\x02" + good[5:], b"\x00" * 50,
                    good[:-1], good[:-1] + bytes([good[-1] ^ 0xFF]), b"OHCC\x01" + b"x" * (credstore.MAX_FILE + 1)):
            self.file().write_bytes(bad)
            with self.assertRaises(CredentialUnreadableError):
                self.load()
            self.assertEqual(self.file().read_bytes(), bad)
        self.assertEqual(self.names(), [f"{ID_A}.dat"])

    def test_messages_and_repr_never_contain_credentials(self):
        self.save()
        with self.load() as c:
            for text in (repr(c), str(c)):
                self.assertNotIn(USER, text)
                self.assertNotIn(PASSWORD, text)
            with self.assertRaises(TypeError):
                pickle.dumps(c)
        self.file().write_bytes(b"OHCC\x01garbage")
        for call in (lambda: self.load(), lambda: credstore.load_credentials(self.dir, ID_A, backend=FakeBackend("bob"))):
            with self.assertRaises(CredentialError) as cm:
                call()
            self.assertNotIn(USER, str(cm.exception))
            self.assertNotIn(PASSWORD, str(cm.exception))

    def test_resave_over_unreadable_file_quarantines_the_old_one(self):
        self.save()
        old = self.file().read_bytes()
        self.file().write_bytes(old[:-1])  # damaged
        damaged = self.file().read_bytes()
        self.save(password="fresh-pass-2")
        quarantined = [p for p in self.dir.iterdir() if ".corrupt-" in p.name]
        self.assertEqual(len(quarantined), 1)
        self.assertEqual(quarantined[0].read_bytes(), damaged)
        with self.load() as c:
            self.assertEqual(bytes(c.password), b"fresh-pass-2")

    def test_resave_over_another_accounts_blob_keeps_it_as_quarantine(self):
        credstore.save_credentials(self.dir, ID_A, "bob-user", "bob-pass", backend=FakeBackend("bob"))
        bobs = self.file().read_bytes()
        self.save()
        quarantined = [p for p in self.dir.iterdir() if ".corrupt-" in p.name]
        self.assertEqual([p.read_bytes() for p in quarantined], [bobs])

    def test_failed_encryption_saves_nothing(self):
        self.fake.fail_protect = True
        with self.assertRaises(CredentialError) as cm:
            self.save()
        self.assertEqual(cm.exception.category, "encrypt")
        self.assertEqual(self.names(), [])

    def test_failed_verification_keeps_the_existing_file_and_leaves_no_temp_file(self):
        self.save()
        before = self.file().read_bytes()
        self.fake.fail_unprotect = True
        with self.assertRaises(CredentialError) as cm:
            self.save(password="never-saved")
        self.assertEqual(cm.exception.category, "verify")
        self.assertEqual(self.file().read_bytes(), before)
        self.assertEqual(self.names(), [f"{ID_A}.dat"])

    def test_no_plaintext_anywhere_in_the_folder_after_all_operations(self):
        self.save()
        self.save(ID_B)
        self.file(ID_A).write_bytes(self.file(ID_A).read_bytes()[:-1])
        self.save()
        for p in self.dir.iterdir():
            data = p.read_bytes()
            self.assertNotIn(USER.encode(), data, p.name)
            self.assertNotIn(PASSWORD.encode(), data, p.name)


class CredProbeTool(StoreCase):
    def run_tool(self, *argv):
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            code = cred_probe.main(list(argv), backend=self.fake)
        return code, out.getvalue()

    def test_save_check_delete_print_only_ids_and_lengths(self):
        with mock.patch("builtins.input", return_value=USER), mock.patch("getpass.getpass", return_value=PASSWORD):
            code, out = self.run_tool("save", "--id", ID_A, "--folder", str(self.dir))
        self.assertEqual(code, 0)
        code2, out2 = self.run_tool("check", "--id", ID_A, "--folder", str(self.dir))
        self.assertEqual((code2, out2.strip()), (0, f"OK: username {len(USER)} bytes, password {len(PASSWORD)} bytes"))
        code3, out3 = self.run_tool("delete", "--id", ID_A, "--folder", str(self.dir))
        self.assertEqual((code3, out3.strip()), (0, "deleted"))
        for text in (out, out2, out3):
            self.assertNotIn(USER, text)
            self.assertNotIn(PASSWORD, text)

    def test_failures_return_1_with_a_category(self):
        code, out = self.run_tool("check", "--id", ID_A, "--folder", str(self.dir))
        self.assertEqual(code, 1)
        self.assertIn("FAILED (missing)", out)
        code, out = self.run_tool("check", "--id", "../x", "--folder", str(self.dir))
        self.assertEqual(code, 1)


@unittest.skipUnless(sys.platform == "win32", "needs Windows DPAPI")
class RealDpapiStore(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self._tmp.name)
        self.addCleanup(self._tmp.cleanup)

    def test_round_trip_and_no_plaintext_on_disk(self):
        credstore.save_credentials(self.dir, ID_A, USER, PASSWORD)
        data = (self.dir / f"{ID_A}.dat").read_bytes()
        self.assertNotIn(USER.encode(), data)
        self.assertNotIn(PASSWORD.encode(), data)
        self.assertNotIn(USER.encode("utf-16-le"), data)
        self.assertNotIn(PASSWORD.encode("utf-16-le"), data)
        with credstore.load_credentials(self.dir, ID_A) as c:
            self.assertEqual((bytes(c.username), bytes(c.password)), (USER.encode(), PASSWORD.encode()))

    def test_copy_to_another_id_and_flipped_byte_fail_with_decrypt_category(self):
        credstore.save_credentials(self.dir, ID_A, USER, PASSWORD)
        good = (self.dir / f"{ID_A}.dat").read_bytes()
        (self.dir / f"{ID_B}.dat").write_bytes(good)
        with self.assertRaises(CredentialUnreadableError) as cm:
            credstore.load_credentials(self.dir, ID_B)
        self.assertEqual(cm.exception.category, "decrypt")
        (self.dir / f"{ID_A}.dat").write_bytes(good[:-1] + bytes([good[-1] ^ 0xFF]))
        with self.assertRaises(CredentialUnreadableError):
            credstore.load_credentials(self.dir, ID_A)

    def test_resave_over_damaged_real_file_quarantines_it(self):
        credstore.save_credentials(self.dir, ID_A, USER, PASSWORD)
        good = (self.dir / f"{ID_A}.dat").read_bytes()
        (self.dir / f"{ID_A}.dat").write_bytes(good[:-3])
        credstore.save_credentials(self.dir, ID_A, USER, "second-pass")
        self.assertEqual(len([p for p in self.dir.iterdir() if ".corrupt-" in p.name]), 1)
        with credstore.load_credentials(self.dir, ID_A) as c:
            self.assertEqual(bytes(c.password), b"second-pass")


if __name__ == "__main__":
    unittest.main()