"""Reports & Logs: theme-aware popup menus and the narrower search fields (Qt offscreen)."""
import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if sys.platform == "win32":
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

import shutil
import tempfile
import unittest
from pathlib import Path

from PySide6.QtGui import QColor
from PySide6.QtWidgets import QApplication, QMenu

from ohc.gui.main_window import MainWindow
from ohc.gui.theme import PALETTES
from tests.test_gui_run import make_ctx


def luminance(c: QColor) -> float:
    def f(v):
        v /= 255
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(c.red()) + 0.7152 * f(c.green()) + 0.0722 * f(c.blue())


def contrast(a: str, b: str) -> float:
    la, lb = sorted((luminance(QColor(a)), luminance(QColor(b))), reverse=True)
    return (la + 0.05) / (lb + 0.05)


class MenuAndSearchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.win = MainWindow(make_ctx(self.tmp))
        self.addCleanup(self.win.deleteLater)
        self.win.show()

    def test_menu_colours_follow_the_theme_and_stay_readable(self):
        for theme in ("light", "dark"):
            self.win.theme.set_theme(theme)
            self.app.processEvents()
            p = PALETTES[theme]
            self.assertGreaterEqual(contrast(p["text"], p["card"]), 4.5, theme)          # normal item
            self.assertGreaterEqual(contrast(p["text"], p["button_hover"]), 4.5, theme)  # hovered / selected item
            self.assertGreaterEqual(contrast(p["muted"], p["card"]), 3.0, theme)          # disabled item
            menu = QMenu(self.win)
            menu.addAction("Open in default app")
            menu.addAction("Copy path")
            menu.show()
            self.app.processEvents()
            image = menu.grab().toImage()
            bg = image.pixelColor(image.width() // 2, 2 + 1)  # inside the 4 px padding: the menu background itself
            self.assertEqual(bg.name().lower(), QColor(p["card"]).name().lower(), theme)
            menu.close()

    def test_both_search_fields_are_narrower_and_identical(self):
        row = [i for i in range(self.win.nav.count()) if self.win.nav.item(i).text() == "Reports & Logs"][0]
        self.win.nav.setCurrentRow(row)
        page = self.win.pages.currentWidget()
        self.win.resize(1360, 860)
        self.app.processEvents()
        a, b = page.reports.search, page.logs.search
        self.assertEqual((a.maximumWidth(), a.height()), (b.maximumWidth(), b.height()))
        self.assertLessEqual(a.maximumWidth(), 360)
        self.assertLessEqual(a.width(), 360)
        self.assertLess(a.width(), page.reports.card.width() // 2)
        self.assertEqual(a.width(), b.width())
        self.assertEqual(a.x(), b.x())  # aligned with each other, on the date-filter row
        self.assertGreaterEqual(page.reports_table.width(), 600)  # the table keeps its width
        self.assertEqual(a.placeholderText(), "Search reports...")
        self.assertEqual(b.placeholderText(), "Search logs...")
        page.shutdown()


if __name__ == "__main__":
    unittest.main()
