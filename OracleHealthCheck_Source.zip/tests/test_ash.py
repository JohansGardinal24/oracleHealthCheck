"""ASH: time-window rules, SQL selection, session commands, service (fake session), history. Real Oracle is NOT exercised."""
import hashlib
import os
import re
import shutil
import tempfile
import threading
import time
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest import mock

from ohc import ash, ash_service, awr
from ohc.checks.cancel import CancelToken
from ohc.checks.session import EXE, OracleSession, ToolError, ash_variant_sql
from ohc.config import environment
from ohc.security.credstore import Credentials
from tests.test_awr import make_awr_ctx

ROOT = Path(__file__).resolve().parent.parent
NOW = datetime(2026, 10, 18, 12, 0, 0)


class Windows(unittest.TestCase):
    def test_relative_units_and_span(self):
        self.assertEqual(ash.relative_window(-15).minutes_back, 15)
        self.assertEqual(ash.relative_window(-2, "hours").minutes_back, 120)
        self.assertEqual(ash.relative_window("-7", "days").minutes_back, 10080)
        self.assertEqual(ash.relative_window(-10080, "minutes").minutes_back, 10080)
        w = ash.relative_window(-15)
        self.assertEqual(w.span(NOW), (NOW - timedelta(minutes=15), NOW))        # ends now; duration plays no role
        self.assertEqual(w.minutes, 15)

    def test_relative_rejects_bad_values(self):
        for bad in (0, 5, "abc", "", "-1.5", "--3", None):
            with self.assertRaises(ash.AshError, msg=repr(bad)):
                ash.relative_window(bad)
        with self.assertRaises(ash.AshError):
            ash.relative_window(-8, "days")
        with self.assertRaises(ash.AshError):
            ash.relative_window(-10081)
        with self.assertRaises(ash.AshError):
            ash.relative_window(-5, "weeks")

    def test_absolute_end_is_begin_plus_duration(self):
        w = ash.absolute_window(2026, 10, 18, 9, 30, 15, 45, now=NOW)
        self.assertEqual(w.span(), (datetime(2026, 10, 18, 9, 30, 15), datetime(2026, 10, 18, 10, 15, 15)))
        self.assertEqual((w.mode, w.minutes), ("absolute", 45))
        self.assertIn("45 mins", w.describe())

    def test_absolute_rejects_invalid_windows(self):
        bad = [((2026, 2, 30, 1, 0, 0, 15), "not a valid date"), ((2026, 13, 1, 1, 0, 0, 15), "not a valid date"),
               ((2026, 10, 18, 25, 0, 0, 15), "not a valid date"), ((2026, 10, 18, 12, 0, 1, 15), "future"),
               ((2026, 10, 19, 0, 0, 0, 15), "future"), ((2026, 9, 1, 0, 0, 0, 15), "30 days"),
               ((2026, 10, 18, 11, 50, 0, 15), "ends in the future"), ((2026, 10, 18, 9, 0, 0, 0), "Duration"),
               ((2026, 10, 18, 9, 0, 0, 1441), "Duration"), ((2026, 10, 18, 9, 0, 0, "x"), "Duration")]
        for args, text in bad:
            with self.assertRaises(ash.AshError, msg=args) as cm:
                ash.absolute_window(*args, now=NOW)
            self.assertIn(text, str(cm.exception), args)
        ash.absolute_window(2026, 10, 18, 11, 45, 0, 15, now=NOW)       # ends exactly now: allowed
        ash.absolute_window(2026, 10, 18, 0, 0, 0, 1440, now=datetime(2026, 10, 19, 0, 0, 0))

    def test_duration_range(self):
        self.assertEqual((ash.validate_duration(1), ash.validate_duration("1440")), (1, 1440))
        for bad in (0, 1441, -5, "", "1.5", "abc"):
            with self.assertRaises(ash.AshError, msg=repr(bad)):
                ash.validate_duration(bad)

    def test_default_name_and_shared_name_rules(self):
        self.assertEqual(ash.DEFAULT_NAME, "ASH_Report_<yyyymmdd_HHMMSS>")
        self.assertEqual(awr.check_report_name(ash.DEFAULT_NAME, "html"), "")
        self.assertEqual(awr.resolve_name(ash.DEFAULT_NAME, datetime(2026, 10, 16, 1, 45, 0)), "ASH_Report_20261016_014500")
        for bad in ("../x", "a/b", "C:x", "a.html", "CON", "a b", ""):
            self.assertNotEqual(awr.check_report_name(bad, "text"), "", bad)


class Proc:
    seen: list = []
    reply = b"ASH_PERIOD|2026-10-18 11:45:00|2026-10-18 12:00:00\r\nReport generated at: x\r\n"

    def __init__(self, argv, **kw):
        Proc.seen.append([argv, kw])

    def communicate(self, data=None, timeout=None):
        Proc.seen[-1].append(bytes(data or b""))
        return Proc.reply, None


class SqlAndSession(unittest.TestCase):
    def setUp(self):
        self.home = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.home, True)
        (self.home / "bin").mkdir()
        (self.home / "bin" / ("sqlplus" + EXE)).write_text("")
        Proc.seen = []

    def make(self):
        return OracleSession(self.home, "IMS", Credentials(bytearray(b"sys"), bytearray(b"S3cret!pw")), popen=Proc)

    def test_each_mode_uses_the_documented_api_with_dbid_instance_and_dates(self):
        d = "TO_DATE('&v_bdate', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('&v_edate', 'YYYY-MM-DD HH24:MI:SS'))"
        expect = {("html", False): "ASH_REPORT_HTML(&v_dbid, &v_inst, " + d, ("text", False): "ASH_REPORT_TEXT(&v_dbid, &v_inst, " + d,
                  ("html", True): "ASH_GLOBAL_REPORT_HTML(&v_dbid, '&v_insts', " + d, ("text", True): "ASH_GLOBAL_REPORT_TEXT(&v_dbid, '&v_insts', " + d}
        for (fmt, rac), call in expect.items():
            for relative in (True, False):
                sql = ash_variant_sql(fmt, rac, relative)
                self.assertIn("DBMS_WORKLOAD_REPOSITORY." + call, sql, (fmt, rac))
                self.assertIn("SELECT dbid FROM v$database;", sql)
                self.assertIn('SPOOL "&v_file" CREATE', sql)                         # never overwrites
                self.assertIn("PROMPT ASH_PERIOD|&v_bdate|&v_edate", sql)
                self.assertEqual("gv$instance" in sql, rac)
                self.assertEqual("v$instance" in sql.replace("gv$instance", ""), not rac)
                self.assertEqual("SYSDATE - &v_minutes / 1440" in sql, relative)      # relative: begin = database now - N
                self.assertEqual("&v_begin_ts" in sql and "&v_dur / 1440" in sql, not relative)   # absolute: end = begin + duration
        for word in ("insert", "update", "delete", "drop", "alter", "create ", "grant", "truncate"):
            self.assertIsNone(re.search(r"\b%s" % word, ash_variant_sql("html", True, True).lower().replace("spool", "")), word)

    def test_relative_and_absolute_commands(self):
        s = self.make()
        s.ash_report(Path("C:/r/d/a.html"), "html", False, ash.relative_window(-20))
        argv, kw, stdin = Proc.seen[0]
        text = stdin.decode()
        self.assertNotIn("S3cret!pw", " ".join(argv))
        self.assertEqual(argv[1:], ["-s", "/nolog"])
        self.assertLess(text.index("set define off"), text.index("connect sys"))
        self.assertIn("define v_minutes=20\n", text)
        self.assertIn(f"define v_file='{Path('C:/r/d/a.html')}'", text)
        self.assertNotIn("ASH_Report.sql", text)                       # the original interactive script is not used
        self.assertIn("SYSDATE - &v_minutes", Path(re.search(r'@"([^"]+ash_report\.sql)"', text).group(1)).read_text())
        run_dir = s.run_dir
        s.close()
        self.assertFalse(run_dir.exists())                             # private work folder is removed
        Proc.seen = []
        s = self.make()
        s.ash_report(Path("C:/r/d/a.txt"), "text", True, ash.absolute_window(2026, 10, 18, 9, 30, 0, 45, now=NOW))
        text = Proc.seen[0][2].decode()
        self.assertIn("define v_begin_ts='2026-10-18 09:30:00'\ndefine v_dur=45\n", text)
        self.assertIn("ASH_GLOBAL_REPORT_TEXT", Path(re.search(r'@"([^"]+ash_report\.sql)"', text).group(1)).read_text())
        for bad in ("C:/it's.html", "C:/a&b.html", 'C:/a"b.html'):
            with self.assertRaises(ToolError):
                s.ash_report(Path(bad), "html", False, ash.relative_window(-5))
        s.close()

    def test_original_scripts_are_unchanged(self):
        recorded = dict(reversed(l.split()) for l in (ROOT / "tools" / "original_sql.sha256").read_text().splitlines() if l.strip())
        for name in ("ASH_Report.sql", "AWR_Report.sql", "ADDM_Report.sql"):
            self.assertEqual(hashlib.sha256((ROOT / "sql_src" / name).read_bytes()).hexdigest(), recorded[name], name)


class FakeService(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        env = mock.patch.dict(os.environ, {"OHC_FAKE_ORACLE": "healthy"})
        env.start()
        self.addCleanup(env.stop)
        for k in ("OHC_FAKE_ASH", "OHC_FAKE_DELAY", "OHC_FAKE_AWR"):
            os.environ.pop(k, None)
        self.ctx = make_awr_ctx(self.tmp)
        self.folder = None

    def reports(self):
        return sorted(p.name for p in (self.tmp / "reports").rglob("*") if p.is_file() and p.suffix in (".html", ".txt"))

    def test_html_relative_default_name(self):
        r = ash_service.generate_report(self.ctx, "ims", ash.relative_window(-15))
        self.assertTrue(r.ok, r.detail)
        self.assertTrue(r.simulated and r.message.startswith("SIMULATED DATA - "))
        self.assertRegex(r.path.name, r"^ASH_Report_\d{8}_\d{6}\.html$")
        self.assertEqual(r.path.parent.parent, self.tmp / "reports")
        self.assertIn("FAKE / SIMULATED DATA", r.path.read_text(encoding="utf-8"))
        self.assertEqual((r.period[1] - r.period[0]), timedelta(minutes=15))

    def test_text_rac_custom_name_absolute_window_is_recorded_exactly(self):
        w = ash.absolute_window(*(datetime.now() - timedelta(hours=3)).replace(microsecond=0).timetuple()[:6], 30)
        r = ash_service.generate_report(self.ctx, "ims", w, None, "text", "peak_rac", True)
        self.assertTrue(r.ok, r.detail)
        self.assertEqual(r.path.name, "peak_rac.txt")
        body = r.path.read_text(encoding="utf-8")
        self.assertIn("ASH Report", body)
        self.assertIn("RAC (all instances", body)
        self.assertEqual(r.period, w.span())
        e = ash.scan_history(self.tmp / "reports", index_dir=self.tmp / "config").entries[0]
        self.assertEqual((e.name, e.begin, e.end, e.db, e.rac, e.simulated, e.duration_text), ("peak_rac.txt", w.span()[0], w.span()[1], "ims", True, True, "30 mins"))

    def test_invalid_input_never_reaches_the_database(self):
        folder = self.tmp / "reports"
        with mock.patch("ohc.ash_service.launcher._open") as opened:
            w = ash.relative_window(-5)
            for kw in ({"name": "../x"}, {"name": "a/b"}, {"name": "x.html"}, {"name": "CON"}, {"name": ""}, {"fmt": "pdf"}):
                self.assertFalse(ash_service.generate_report(self.ctx, "ims", w, **kw).ok, kw)
            self.assertFalse(ash_service.generate_report(self.ctx, "ims", None).ok)
            stale = ash.Window("absolute", begin=datetime.now() + timedelta(hours=1), duration=15)
            self.assertFalse(ash_service.generate_report(self.ctx, "ims", stale).ok)
            opened.assert_not_called()
        self.assertEqual(list(folder.rglob("*.html")) if folder.exists() else [], [])

    def test_existing_report_is_never_overwritten(self):
        self.assertTrue(ash_service.generate_report(self.ctx, "ims", ash.relative_window(-5), name="same").ok)
        first = next((self.tmp / "reports").rglob("same.html"))
        first.write_text("precious", encoding="utf-8")
        r = ash_service.generate_report(self.ctx, "ims", ash.relative_window(-5), name="same")
        self.assertFalse(r.ok)
        self.assertIn("already exists", r.detail)
        self.assertEqual(first.read_text(encoding="utf-8"), "precious")
        self.assertTrue(ash_service.generate_report(self.ctx, "ims", ash.relative_window(-5), None, "text", "same").ok)   # other extension

    def test_token_name_used_twice_in_one_second_never_overwrites(self):
        results = [ash_service.generate_report(self.ctx, "ims", ash.relative_window(-5)) for _ in range(3)]
        self.assertEqual(sum(r.ok for r in results), len(self.reports()))
        for r in results:
            if not r.ok:
                self.assertIn("already exists", r.detail)
        self.assertTrue(results[0].ok)

    def test_failures_leave_no_file_and_show_the_oracle_error(self):
        for mode, text in (("empty", "empty ASH report"), ("badreport", "ORA-20019"), ("fail", "ORA-13616")):
            with mock.patch.dict(os.environ, {"OHC_FAKE_ASH": mode}):
                r = ash_service.generate_report(self.ctx, "ims", ash.relative_window(-5), name="f_" + mode)
            self.assertFalse(r.ok, mode)
            self.assertIn(text, r.message + r.detail, mode)
        with mock.patch.dict(os.environ, {"OHC_FAKE_ASH": "norac"}):
            r = ash_service.generate_report(self.ctx, "ims", ash.relative_window(-5), None, "html", "norac", True)
            self.assertFalse(r.ok)
            self.assertIn("ASH_GLOBAL_REPORT_HTML", r.detail)                  # RAC unsupported: a clear error, not a different report
            self.assertTrue(ash_service.generate_report(self.ctx, "ims", ash.relative_window(-5), None, "html", "single", False).ok)
        with mock.patch.dict(os.environ, {"OHC_FAKE_ORACLE": "down"}):
            r = ash_service.generate_report(self.ctx, "ims", ash.relative_window(-5), name="dn")
            self.assertFalse(r.ok)
            self.assertIn("ORA-01034", r.detail)
        self.assertEqual([n for n in self.reports() if n.startswith(("f_", "dn", "norac"))], [])

    def test_cancel_removes_only_its_own_incomplete_file(self):
        token, out = CancelToken(), []
        os.environ["OHC_FAKE_DELAY"] = "1"
        t = threading.Thread(target=lambda: out.append(ash_service.generate_report(self.ctx, "ims", ash.relative_window(-5), token, "html", "mine")))
        t.start()
        end = time.time() + 5
        while time.time() < end and not list((self.tmp / "reports").rglob("mine.html")):
            time.sleep(0.01)
        self.assertTrue(list((self.tmp / "reports").rglob("mine.html")))
        token.request()
        t.join(10)
        self.assertTrue(out[0].cancelled and not out[0].ok)
        self.assertEqual(self.reports(), [])

    def test_awr_is_unaffected(self):
        from ohc import awr_service
        self.assertTrue(awr_service.generate_report(self.ctx, "ims", 7, 9001, 9002).ok)
        self.assertTrue(ash_service.generate_report(self.ctx, "ims", ash.relative_window(-5)).ok)
        self.assertEqual([e.name[:3] for e in awr.scan_history(self.tmp / "reports", index_dir=self.tmp / "config").entries], ["AWR"])
        self.assertEqual([e.name[:3] for e in ash.scan_history(self.tmp / "reports", index_dir=self.tmp / "config").entries], ["ASH"])


class RealSessionPath(unittest.TestCase):
    """The service with the real OracleSession class and a stubbed sqlplus process."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.home = Path(tempfile.mkdtemp())
        for p in (self.tmp, self.home):
            self.addCleanup(shutil.rmtree, p, True)
        (self.home / "bin").mkdir()
        (self.home / "bin" / ("sqlplus" + EXE)).write_text("")
        self.ctx = make_awr_ctx(self.tmp)
        os.environ.pop("OHC_FAKE_ORACLE", None)

    def run_with(self, popen, **kw):
        env = environment.load_environment(self.ctx.environment_path)
        with mock.patch("ohc.ash_service.launcher._prepare", return_value=(self.ctx.databases.find_by_name("ims"), str(self.home), env, None)), \
                mock.patch("ohc.ash_service.launcher._open", side_effect=lambda *a, **k: OracleSession(self.home, "IMS", Credentials(bytearray(b"sys"), bytearray(b"pw")), popen=popen)):
            return ash_service.generate_report(self.ctx, "ims", ash.relative_window(-15), **kw)

    def test_success_reads_the_real_period_from_the_script_output(self):
        class Good(Proc):
            def communicate(self, data=None, timeout=None):
                f = Path(re.search(r"define v_file='([^']+)'", data.decode()).group(1))
                f.write_text("<html><title>ASH Report For ORCL</title>" + "x" * 3000 + "</html>", encoding="utf-8")
                return b"ASH_PERIOD|2026-10-18 11:45:03|2026-10-18 12:00:03\r\nReport generated at: " + str(f).encode() + b"\r\n", None
        r = self.run_with(Good, name="real1")
        self.assertTrue(r.ok, r.detail)
        self.assertFalse(r.simulated)
        self.assertEqual(r.period, (datetime(2026, 10, 18, 11, 45, 3), datetime(2026, 10, 18, 12, 0, 3)))
        e = ash.scan_history(self.tmp / "reports", index_dir=self.tmp / "config").entries[0]
        self.assertEqual((e.begin, e.end, e.simulated), (r.period[0], r.period[1], False))

    def test_no_file_and_spooled_errors_are_failures(self):
        r = self.run_with(Proc, name="nofile")
        self.assertFalse(r.ok)
        Proc.reply = b"ERROR at line 1:\r\nORA-13605: Diagnostics Pack not licensed\r\n"
        try:
            self.assertIn("ORA-13605", self.run_with(Proc, name="nofile2").detail)
        finally:
            Proc.reply = b"ASH_PERIOD|2026-10-18 11:45:00|2026-10-18 12:00:00\r\nReport generated at: x\r\n"

        class Spool(Proc):
            def communicate(self, data=None, timeout=None):
                f = Path(re.search(r"define v_file='([^']+)'", data.decode()).group(1))
                f.write_text("ORA-20024: no ASH data\n", encoding="utf-8")
                return b"Report generated at: " + str(f).encode() + b"\r\n", None
        r = self.run_with(Spool, name="spooled")
        self.assertFalse(r.ok)
        self.assertIn("ORA-20024", r.detail)
        self.assertEqual(list((self.tmp / "reports").rglob("spooled*")), [])


class History(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)

    def put(self, rel, text="x"):
        p = self.tmp / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text)
        return p

    def test_only_ash_reports_are_listed(self):
        a = self.put("2026-10-16/ASH_Report_20261016_014500.html")
        b = self.put("12.10.2026/ASH_Report_20261012_000532.txt")
        self.put("2026-10-16/AWR_Report_1_2_20261016_012216.html")
        self.put("2026-10-16/ADDM_Report_20261016_012216.html")
        self.put("2026-10-16/ims_health_20261016_010000.html")
        self.put("2026-10-16/notes.html")
        self.put("2026-10-16/ASH_Report_2026_bad.html")
        self.put("2026-10-16/ASH_Report_20261340_000000.html")
        entries = ash.scan_history(self.tmp).entries
        self.assertEqual([e.path for e in entries], [a, b])
        self.assertEqual((entries[0].db, entries[0].begin, entries[0].duration_text), ("-", None, "-"))   # legacy files: window unknown

    def test_custom_names_come_from_the_index_and_bad_metadata_is_ignored(self):
        mine = self.put("2026-10-16/peak.html")
        odd = self.put("2026-10-16/odd.html")
        gone = self.tmp / "2026-10-16" / "gone.html"
        self.assertEqual(ash.record_report(self.tmp, mine, "ORCL", False, datetime(2026, 10, 16, 1, 0), datetime(2026, 10, 16, 1, 30), True), "")
        ash.record_report(self.tmp, gone, "ORCL", False, datetime(2026, 10, 16, 1, 0), datetime(2026, 10, 16, 1, 30))
        idx = (self.tmp / ash.INDEX_NAME)
        data = idx.read_text(encoding="utf-8").replace('"version": 1,', '"version": 1, "x": 0,')
        import json
        d = json.loads(idx.read_text(encoding="utf-8"))
        d["reports"]["2026-10-16/odd.html"] = {"db": "X", "begin": "garbage", "end": None}
        idx.write_text(json.dumps(d), encoding="utf-8")
        entries = ash.scan_history(self.tmp).entries
        self.assertEqual([e.name for e in entries], ["peak.html"])
        self.assertEqual((entries[0].db, entries[0].duration_text, entries[0].rac), ("ORCL", "30 mins", True))
        idx.write_text("{ broken", encoding="utf-8")
        self.assertEqual(ash.scan_history(self.tmp).entries, [])             # damaged index: no crash, custom names just unknown

    def test_missing_folder_and_filters(self):
        self.assertFalse(ash.scan_history(self.tmp / "nope").exists)
        self.put("2026-10-16/ASH_Report_20261016_014500.html")
        self.put("2026-10-14/ASH_Report_20261014_231025.txt")
        entries = ash.scan_history(self.tmp).entries
        self.assertEqual(awr.dates_of(entries), ["2026-10-16", "2026-10-14"])
        self.assertEqual(len(awr.filter_entries(entries, "2026-10-14", "")), 1)
        self.assertEqual(len(awr.filter_entries(entries, "", "231025")), 1)
        self.assertEqual(awr.filter_entries(entries, "2026-10-16", "231025"), [])

    def test_period_parser(self):
        self.assertEqual(ash.period_from_output("x\nASH_PERIOD|2026-10-18 11:45:00|2026-10-18 12:00:00\n"), (datetime(2026, 10, 18, 11, 45), datetime(2026, 10, 18, 12)))
        self.assertIsNone(ash.period_from_output("nothing"))


if __name__ == "__main__":
    unittest.main()
