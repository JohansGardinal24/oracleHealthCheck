"""Check Results numbering: every row number, including 10 and above, is shown in full (never cut to "...") on options 1, 2 and 3 (Qt offscreen).

The check compares what is actually painted: the first column's cells at their real width against the same cells in a very wide column.
If the number were elided the pixels would differ. (A text-width formula is not used: Qt takes extra margins off the cell that a formula misses.)
"""
import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if sys.platform == "win32":  # the offscreen plugin finds no fonts on Windows, which makes every text measurement meaningless
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

import tempfile
import unittest
from pathlib import Path

from PySide6.QtCore import QRect
from PySide6.QtWidgets import QApplication

from ohc.gui.main_window import MainWindow
from tests.test_gui_run import make_ctx

ROWS = 21                      # "All Checks" runs 21 checks; option 1 runs 17, option 2 runs 4


class RowNumberDisplayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.win = MainWindow(make_ctx(Path(tmp.name)))
        self.addCleanup(self.win.deleteLater)
        self.win.resize(1360, 900)
        self.win.show()

    def settle(self):
        self.app.processEvents()
        self.app.processEvents()

    def cells(self, table, width):
        return [table.viewport().grab(QRect(0, table.rowViewportPosition(r), width, table.rowHeight(r))).toImage() for r in range(table.rowCount())]

    def test_row_numbers_10_and_above_are_not_cut_off(self):
        for theme in ("light", "dark"):
            self.win.theme.set_theme(theme)
            for row in (1, 2, 3):
                self.win._open(row)
                page = self.win.pages.widget(row)
                page._load_plan([(i, f"CHECK {i}") for i in range(ROWS)])
                self.settle()
                table = page.table
                self.assertEqual([table.item(r, 0).text() for r in range(ROWS)], [str(n) for n in range(1, ROWS + 1)], (theme, row))
                width = table.columnWidth(0)
                shown = self.cells(table, width)
                table.setColumnWidth(0, 160)                      # the same cells with all the room they could want
                self.settle()
                full = self.cells(table, width)
                table.fit_columns()
                self.settle()
                for r in range(ROWS):
                    self.assertTrue(shown[r] == full[r], f"row number {r + 1} is cut off ({theme}, option {row}, column width {width}px)")

    def test_first_column_width_is_unchanged_by_resizing_the_window(self):
        page = self.win.pages.widget(1)
        self.win._open(1)
        self.settle()
        before = page.table.columnWidth(0)
        self.win.resize(1500, 900)
        self.settle()
        self.assertEqual(page.table.columnWidth(0), before)       # a fixed column: only the flexible ones follow the window


if __name__ == "__main__":
    unittest.main()
