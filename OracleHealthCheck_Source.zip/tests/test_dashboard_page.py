"""New Dashboard page (Qt offscreen; engine real, Oracle session fake): data from logs/reports, Run/Cancel delegation, navigation cards, history
actions, empty/busy/simulated states and layout in both themes. (tests/test_dashboard.py covers the run pages.) Real Oracle and real Windows
rendering are NOT covered."""
import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if sys.platform == "win32":
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

import shutil
import tempfile
import time
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest import mock

from PySide6.QtCore import QRect, Qt
from PySide6.QtWidgets import QApplication, QLabel, QScrollArea, QWidget

from ohc import addm_service, ash, ash_service, awr_service, dashboard_data as dd
from ohc.checks import launcher
from ohc.gui.dashboard_page import DashboardPage
from ohc.gui.main_window import MainWindow
from ohc.gui.run_page import STATUS_ROLE
from tests.test_awr import make_awr_ctx
from tests.test_gui_run import wait_idle


class DataTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        env = mock.patch.dict(os.environ, {"OHC_FAKE_ORACLE": "warning"})
        env.start()
        self.addCleanup(env.stop)
        os.environ.pop("OHC_FAKE_DELAY", None)
        self.ctx = make_awr_ctx(self.tmp)

    def log(self, name, lines):
        (self.tmp / "logs").mkdir(exist_ok=True)
        p = self.tmp / "logs" / name
        p.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return p

    def test_summary_comes_from_the_real_run_log(self):
        r = launcher.run_option(self.ctx, "ims", "3", emit=lambda line: None)
        s = dd.latest_run(self.tmp / "logs", "ims")
        self.assertEqual(s.total, 21)
        self.assertEqual((s.healthy, s.warnings, s.critical), (sum(x.status in ("OK", "INFO") for x in r.results), sum(x.status == "WARNING" for x in r.results),
                                                                  sum(x.status == "CRITICAL" for x in r.results)))
        self.assertEqual(s.healthy + s.warnings + s.critical + s.other, 21)
        self.assertTrue(s.simulated)
        self.assertEqual(s.overall, r.overall)
        self.assertEqual([x.status for x in s.rows], [x.status for x in sorted(r.results, key=lambda x: x.idx)])      # the log mirrors the run
        self.assertTrue(s.db_reachable)
        self.assertEqual(s.rows[0].check_id, "CHK_01")
        self.assertIsNotNone(s.when)

    def test_problems_first_and_limited(self):
        s = dd.RunSummary(rows=[dd.CheckRow(f"CHK_{i:02d}", f"c{i}", st, "m") for i, st in
                                enumerate(["OK", "OK", "WARNING", "OK", "CRITICAL", "OK", "OK", "OK", "OK", "WARNING", "INFO"], 1)])
        rec = s.recent()
        self.assertEqual(len(rec), 8)
        self.assertEqual([r.status for r in rec[:3]], ["CRITICAL", "WARNING", "WARNING"])
        self.assertEqual([r.check_id for r in rec[3:6]], ["CHK_01", "CHK_02", "CHK_04"])          # then run order
        self.assertEqual((s.healthy, s.warnings, s.critical, s.other), (8, 2, 1, 0))

    def test_newest_log_of_the_selected_database_only(self):
        line = lambda n, st: f"[{n}] CHECK {n} : {st}  -  msg {n}"
        self.log("ohc_ims_20261018_100000.log", [line(1, "OK"), " OVERALL: OK"])
        self.log("ohc_ims_20261019_090000.log", [line(1, "CRITICAL"), line(2, "WARNING"), "garbage line", "[x] bad : OK - no", " OVERALL: CRITICAL"])
        self.log("ohc_other_20261020_090000.log", [line(1, "OK")])
        s = dd.latest_run(self.tmp / "logs", "IMS")
        self.assertEqual((s.when, s.total, s.critical, s.warnings, s.overall), (datetime(2026, 10, 19, 9, 0, 0), 2, 1, 1, "CRITICAL"))
        self.assertFalse(s.db_reachable)                                   # check 1 CRITICAL
        self.assertEqual(dd.latest_run(self.tmp / "logs", "nobody").total, 0)
        self.assertEqual(dd.latest_run(self.tmp / "missing", "ims").total, 0)
        self.assertIsNone(dd.RunSummary().db_reachable)

    def test_recent_reports_cover_all_report_types_newest_first(self):
        folder = self.tmp / "reports" / "2026-10-19"
        folder.mkdir(parents=True)
        names = {"Health": "ims_health_20261019_100000.html", "AWR": "AWR_Report_1_2_20261019_110000.html", "ASH": "ASH_Report_20261019_120000.html",
                 "ADDM": "ADDM_Report_1_2_20261019_130000.txt"}
        for n in names.values():
            (folder / n).write_text("<html>FAKE / SIMULATED DATA</html>")
        for other in ("notes.html", "AWR_Report_a_b_20261019_140000.html", "random.txt"):
            (folder / other).write_text("x")
        rows = dd.recent_reports(self.tmp / "reports", self.tmp / "logs", limit=10)
        self.assertEqual([r.kind for r in rows], ["ADDM", "ASH", "AWR", "Health"])
        self.assertEqual([r.name for r in rows], [names[k] for k in ("ADDM", "ASH", "AWR", "Health")])
        self.assertEqual(len(dd.recent_reports(self.tmp / "reports", self.tmp / "logs")), 3)
        self.assertEqual(dd.recent_reports(self.tmp / "nope", self.tmp / "logs"), [])


class Base(unittest.TestCase):
    names = ("ims",)

    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        env = mock.patch.dict(os.environ, {"OHC_FAKE_ORACLE": "warning"})
        env.start()
        self.addCleanup(env.stop)
        for k in ("OHC_FAKE_DELAY", "OHC_FAKE_AWR", "OHC_FAKE_ASH", "OHC_FAKE_ADDM"):
            os.environ.pop(k, None)
        self.ctx = make_awr_ctx(self.tmp, self.names)
        self.win = MainWindow(self.ctx)
        self.addCleanup(self.win.deleteLater)
        self.win.show()
        self.settle()
        self.d: DashboardPage = self.win.pages.widget(0)
        self.all_page = self.win.pages.widget(3)

    def settle(self):
        self.app.processEvents()
        self.app.processEvents()

    def run_dashboard(self):
        self.d.run_btn.click()
        self.assertTrue(wait_idle(self.win.gate))
        self.settle()

    def report(self, rel, text="x"):
        p = self.tmp / "reports" / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8")
        return p


class Initial(Base):
    def test_page_replaces_the_placeholder_and_nothing_runs_on_open(self):
        self.assertIsInstance(self.d, DashboardPage)
        with mock.patch.object(launcher, "run_option") as run:
            self.win.nav.setCurrentRow(1)
            self.win.nav.setCurrentRow(0)
            self.d.refresh()
            self.settle()
            run.assert_not_called()
        self.assertEqual([self.win.nav.item(i).text() for i in range(7)],
                         ["Dashboard", "1. Oracle Health Check", "2. Sync Check", "3. All Checks", "4. Database Reports", "Reports & Logs", "Settings"])

    def test_empty_state(self):
        d = self.d
        self.assertEqual([x.text() for x in (d.healthy_n, d.warn_n, d.crit_n)], ["-", "-", "-"])             # clean start: placeholders, not counts
        self.assertEqual((d.healthy_sub.text(), d.db_name.text(), d.db_sub.text()), ("no run yet", "ims", "SID ims"))
        self.assertEqual(d.donut.values, (0, 0, 0, 0))
        self.assertEqual((d.results.rowCount(), d.reports_table.rowCount()), (21, 0))                          # 21 "Not Run" rows, no reports
        self.assertEqual({d.results.item(r, 2).data(STATUS_ROLE) for r in range(21)}, {"PENDING"})
        self.assertEqual(d.results_note.text(), "Run All Checks to view results.")
        self.assertIn("No reports", d.reports_note.text())
        self.assertEqual(d.conn_label.text(), "Not checked yet")
        self.assertTrue(d.run_btn.isEnabled() and not d.cancel_btn.isEnabled())
        self.assertTrue(d.updated.text().startswith("Last Updated: "))
        self.assertIn("Version", d.footer.text())
        self.assertIn("SQL bundle: OK", d.footer.text())
        self.assertEqual(d.footer.toolTip(), d.footer.text())                    # long path: clipped on one line, never wrapped (page height)
        self.assertLessEqual(d.footer.height(), d.footer.fontMetrics().lineSpacing() + 8)

    def test_headers_and_toolbar(self):
        d = self.d
        self.assertEqual([d.results.horizontalHeaderItem(i).text() for i in range(5)], ["Check ID", "Check Name", "Status", "Message", "Time"])
        self.assertEqual([d.reports_table.horizontalHeaderItem(i).text() for i in range(4)], ["Type", "Report Name", "Created", "Action"])   # no Size column
        self.assertEqual((d.run_btn.text().strip("\u25B6 "), d.cancel_btn.text().strip("\u25A0 ")), ("Run", "Cancel"))
        self.assertEqual([d.db_combo.itemText(i) for i in range(d.db_combo.count())], ["ims"])
        self.assertEqual({k: b.text() for k, b in d.quick.items()}, {"health": "Open Health Check", "sync": "Open Sync Check", "awr": "Open AWR Page",
                                                                      "ash": "Open ASH Page", "addm": "Open ADDM Page"})

    def test_simulated_indicator_follows_fake_mode(self):
        self.assertFalse(self.d.sim_tag.isHidden())
        with mock.patch.dict(os.environ):
            os.environ.pop("OHC_FAKE_ORACLE")
            self.d.refresh()
            self.assertTrue(self.d.sim_tag.isHidden())


class RunAndCancel(Base):
    names = ("ims", "prd")

    def test_run_starts_all_checks_on_the_selected_database_without_a_second_engine(self):
        self.d.db_combo.setCurrentIndex(1)
        with mock.patch.object(type(self.all_page), "start") as start:
            self.d.run_btn.click()
            start.assert_called_once_with()
        self.assertEqual(self.all_page.db_combo.currentText(), "prd")
        self.assertEqual(self.all_page.mode, "ALL")                          # menu 3: Oracle checks + Data Guard checks

    def test_a_full_run_fills_the_dashboard_from_real_results(self):
        self.run_dashboard()
        page, d = self.all_page, self.d
        self.assertEqual(page.state_label.text(), "Completed")
        self.assertEqual(page.count_label.text(), "21 of 21 checks completed")
        results = page._result.results
        want = (sum(r.status in ("OK", "INFO") for r in results), sum(r.status == "WARNING" for r in results), sum(r.status == "CRITICAL" for r in results))
        self.assertEqual((int(d.healthy_n.text()), int(d.warn_n.text()), int(d.crit_n.text())), want)
        self.assertEqual(d.donut.values[:3], want)
        self.assertEqual(d.summary.total, 21)
        self.assertEqual(d.results.rowCount(), 21)                           # all 21 results, not 8
        states = [d.results.item(r, 2).data(STATUS_ROLE) for r in range(21)]
        self.assertEqual([d.results.item(r, 0).text() for r in range(21)], [f"CHK_{i:02d}" for i in range(1, 22)])   # ascending check ID, not problems first
        self.assertEqual(states.count("WARNING"), want[1])
        self.assertIn("[FAKE]", d.results.item(0, 3).text())
        self.assertIn("SIMULATED DATA", d.results_note.text())
        self.assertEqual(d.conn_label.text(), "Connected (simulated)")
        self.assertEqual(d.reports_table.rowCount(), 1)
        self.assertEqual((d.reports_table.item(0, 0).text(), d.reports_table.item(0, 1).text()), ("Health", Path(page._result.report_file).name))
        self.assertTrue(d.run_btn.isEnabled() and not d.cancel_btn.isEnabled())

    def test_busy_state_and_cancel_use_the_existing_mechanism(self):
        os.environ["OHC_FAKE_DELAY"] = "1"
        d, page = self.d, self.all_page
        d.run_btn.click()
        self.settle()
        self.assertTrue(self.win.gate.busy)
        self.assertFalse(d.run_btn.isEnabled() or d.db_combo.isEnabled())
        self.assertTrue(d.cancel_btn.isEnabled())
        self.assertIn("Running", d.conn_label.text())
        d.run_btn.click()                                                    # a second submission is ignored
        self.assertEqual(page.state_label.text(), "Running")
        d.cancel_btn.click()
        self.assertTrue(page._cancelling)                                    # the RunPage's own cancellation was used
        self.assertFalse(d.cancel_btn.isEnabled())
        self.assertTrue(wait_idle(self.win.gate))
        self.settle()
        self.assertEqual(page.state_label.text(), "Cancelled")
        self.assertTrue(d.run_btn.isEnabled() and not d.cancel_btn.isEnabled())
        self.assertNotIn("Running", d.conn_label.text())

    def test_cancel_also_stops_a_run_started_from_another_page(self):
        os.environ["OHC_FAKE_DELAY"] = "1"
        other = self.win.pages.widget(1)
        other.run_btn.click()
        self.settle()
        self.assertTrue(self.d.cancel_btn.isEnabled() and not self.d.run_btn.isEnabled())
        self.d.cancel_btn.click()
        self.assertTrue(other._cancelling)
        self.assertTrue(wait_idle(self.win.gate))

    def test_missing_credentials_are_reported_by_the_run_page(self):
        with mock.patch.dict(os.environ):
            os.environ.pop("OHC_FAKE_ORACLE")
            self.d.run_btn.click()                                           # real mode without a usable Oracle Home: the RunPage reports it
            wait_idle(self.win.gate)
            self.settle()
        self.assertFalse(self.win.gate.busy)
        self.assertTrue(self.d.run_btn.isEnabled())


class LiveResults(Base):
    """Clean start, progressive results (Dashboard and menu 3 from the same run), final consistency and all 21 rows."""

    def old_log(self):
        (self.tmp / "logs").mkdir(exist_ok=True)
        lines = [f"[{n}] CHECK {n} : CRITICAL  -  old {n}" for n in range(1, 22)]
        (self.tmp / "logs" / "ohc_ims_20260101_090000.log").write_text("\n".join(lines) + "\n OVERALL: CRITICAL\n", encoding="utf-8")

    def rows(self, table):
        return [table.item(r, 0).text() for r in range(table.rowCount())]

    def test_old_logs_are_not_shown_at_launch_but_stay_on_disk(self):
        self.old_log()
        self.report("2026-10-19/ASH_Report_20261019_120000.html")
        self.d.refresh_btn.click()
        d = self.d
        self.assertEqual((d.results.rowCount(), d.donut.values, d.summary.total), (21, (0, 0, 0, 0), 0))
        self.assertEqual({d.results.item(r, 2).data(STATUS_ROLE) for r in range(21)}, {"PENDING"})          # old logs are not shown as results
        self.assertEqual([x.text() for x in (d.healthy_n, d.warn_n, d.crit_n)], ["-", "-", "-"])
        self.assertEqual(d.results_note.text(), "Run All Checks to view results.")
        self.assertEqual(d.conn_label.text(), "Not checked yet")
        self.assertEqual(d.reports_table.rowCount(), 1)                                 # report history is kept
        self.assertTrue((self.tmp / "logs" / "ohc_ims_20260101_090000.log").is_file())   # nothing deleted

    def test_results_appear_progressively_and_match_menu_3(self):
        seen = []

        def snap():
            d, p = self.d, self.all_page
            seen.append((len(self.rows(d.results)), [d.results.item(r, 2).data(STATUS_ROLE) for r in range(d.results.rowCount())],
                         {r: p.table.item(r, 2).data(STATUS_ROLE) for r in range(p.table.rowCount())}, d.healthy_n.text(), p.count_label.text()))
        self.all_page.view_changed.connect(snap)                                       # connected after the Dashboard: it has already updated
        self.run_dashboard()
        done_counts = sorted({sum(st not in ("PENDING", "RUNNING") for st in snapshot[1]) for snapshot in seen})
        self.assertGreater(len(done_counts), 5)                                         # many intermediate states, not just "all at the end"
        self.assertEqual(done_counts[0], 0)
        self.assertEqual(done_counts[-1], 21)
        for n_rows, _dash_states, _menu_states, _h, _c in seen:
            self.assertEqual(n_rows, 21)                                                # every row is present all the time
        mid = next(x for x in seen if 0 < sum(st not in ("PENDING", "RUNNING") for st in x[1]) < 21)
        self.assertEqual(sorted(mid[1], key=str), sorted(mid[2].values(), key=str))     # same statuses in both views at the same moment
        self.assertTrue(any(st in ("PENDING", "RUNNING") for st in mid[1]))
        self.assertTrue(any(st not in ("PENDING", "RUNNING") for st in mid[1]))          # completed results stay visible while later checks wait

    def test_completed_results_stay_visible_while_a_check_is_running(self):
        os.environ["OHC_FAKE_DELAY"] = "0.3"
        self.d.run_btn.click()
        end = time.time() + 10
        while time.time() < end and sum(self.all_page._data[i]["status"] not in ("PENDING", "RUNNING") for i in self.all_page._data) < 2:
            self.app.processEvents()
            time.sleep(0.01)
        d = self.d
        done = [r for r in range(d.results.rowCount()) if d.results.item(r, 2).data(STATUS_ROLE) not in ("PENDING", "RUNNING")]
        self.assertGreaterEqual(len(done), 2)
        self.assertEqual(d.results.rowCount(), 21)
        self.assertEqual(d.results.item(0, 0).text(), "CHK_01")                           # run order while running
        self.assertIn("checks completed", d.results_note.text())
        self.assertEqual(d.summary.total, len(done))
        self.assertTrue(done and d.results.item(done[0], 4).text())                       # completion time shown
        self.assertEqual(d.donut.values[0] + d.donut.values[1] + d.donut.values[2] + d.donut.values[3], len(done))
        self.d.cancel_btn.click()
        self.assertTrue(wait_idle(self.win.gate))
        self.settle()

    def test_final_dashboard_equals_menu_3_and_the_run_result(self):
        self.old_log()
        self.run_dashboard()
        d, p = self.d, self.all_page
        self.assertEqual(d.results.rowCount(), 21)
        by_id = {d.results.item(r, 0).text(): (d.results.item(r, 1).text(), d.results.item(r, 2).data(STATUS_ROLE), d.results.item(r, 3).text())
                 for r in range(21)}
        self.assertEqual(sorted(by_id), [f"CHK_{i:02d}" for i in range(1, 22)])
        for r in range(p.table.rowCount()):                                            # menu 3 row r == check CHK_(r+1)
            idx = p.table.item(r, 0).data(Qt.ItemDataRole.UserRole + 1)
            self.assertEqual(by_id[f"CHK_{idx + 1:02d}"], (p.table.item(r, 1).text(), p.table.item(r, 2).data(STATUS_ROLE), p.table.item(r, 3).text()))
        for res in p._result.results:
            self.assertEqual(by_id[f"CHK_{res.idx + 1:02d}"][1], res.status if res.status in ("OK", "WARNING", "CRITICAL", "SKIPPED", "INFO") else "INFO")
        want = (sum(r.status in ("OK", "INFO") for r in p._result.results), sum(r.status == "WARNING" for r in p._result.results), sum(r.status == "CRITICAL" for r in p._result.results))
        self.assertEqual((int(d.healthy_n.text()), int(d.warn_n.text()), int(d.crit_n.text())), want)
        self.assertEqual(sum(d.donut.values), 21)
        self.assertEqual(d.legend["healthy"][1].text(), str(want[0]))
        self.assertNotIn("old ", " ".join(v[2] for v in by_id.values()))                # the old log never leaks in
        self.assertTrue(all(d.results.item(r, 4).text() for r in range(21)))
        ids = [d.results.item(r, 0).text() for r in range(21)]
        self.assertEqual(ids, sorted(ids))                                              # always ascending check ID, whatever the status
        self.assertTrue(d.results.verticalScrollBar().maximum() > 0)                    # scrolls to reach every row
        self.assertEqual(d.results.verticalScrollBar().value(), 0)                      # finished: back at the top
        d.results.verticalScrollBar().setValue(d.results.verticalScrollBar().maximum())
        self.assertTrue(d.results.visualItemRect(d.results.item(20, 0)).isValid())

    def test_run_started_from_menu_3_itself_is_mirrored_and_runs_once(self):
        calls = []
        real = launcher.run_option
        with mock.patch.object(launcher, "run_option", side_effect=lambda *a, **k: calls.append(a[2]) or real(*a, **k)):
            self.all_page.run_btn.click()
            self.assertTrue(wait_idle(self.win.gate))
        self.settle()
        self.assertEqual(calls, ["3"])                                                  # one execution, one engine
        self.assertEqual(self.d.results.rowCount(), 21)

    def test_cancel_keeps_both_views_consistent(self):
        os.environ["OHC_FAKE_DELAY"] = "0.5"
        self.d.run_btn.click()
        end = time.time() + 10
        while time.time() < end and self.all_page._data[0]["status"] in ("PENDING", "RUNNING"):
            self.app.processEvents()
            time.sleep(0.01)
        self.d.cancel_btn.click()
        self.assertTrue(wait_idle(self.win.gate))
        self.settle()
        d, p = self.d, self.all_page
        self.assertEqual(p.state_label.text(), "Cancelled")
        self.assertIn("Cancelled", d.results_note.text())
        by_id = {d.results.item(r, 0).text(): d.results.item(r, 2).data(STATUS_ROLE) for r in range(d.results.rowCount())}
        self.assertEqual(len(by_id), 21)
        for r in range(p.table.rowCount()):
            idx = p.table.item(r, 0).data(Qt.ItemDataRole.UserRole + 1)
            self.assertEqual(by_id[f"CHK_{idx + 1:02d}"], p.table.item(r, 2).data(STATUS_ROLE))
        self.assertIn("PENDING", by_id.values())                                         # checks that never started stay "Not Run"
        self.assertEqual(d.summary.total, sum(st not in ("PENDING", "RUNNING") for st in by_id.values()))
        self.assertTrue(d.run_btn.isEnabled() and not d.cancel_btn.isEnabled())

    def test_error_run_is_reported_in_both_views_and_leaves_no_fake_results(self):
        with mock.patch.object(launcher, "run_option", side_effect=RuntimeError("boom")):
            self.d.run_btn.click()
            self.assertTrue(wait_idle(self.win.gate))
        self.settle()
        self.assertEqual(self.all_page.state_label.text(), "Failed")
        self.assertIn("Failed", self.d.results_note.text())
        self.assertEqual(self.d.summary.total, 0)
        self.assertTrue(all(self.d.results.item(r, 2).data(STATUS_ROLE) == "PENDING" for r in range(self.d.results.rowCount())))

    def test_new_run_replaces_the_previous_session_results_and_other_database_is_clean(self):
        self.run_dashboard()
        first = self.d.results.rowCount()
        self.assertEqual(first, 21)
        self.run_dashboard()
        self.assertEqual(self.d.results.rowCount(), 21)
        self.assertEqual(self.d.summary.total, 21)

    def test_card_title_is_health_check_results(self):
        from PySide6.QtWidgets import QLabel
        texts = [lab.text() for lab in self.d.findChildren(QLabel)]
        self.assertIn("Health Check Results", texts)
        self.assertNotIn("Recent Health Check Results", texts)


class ReferenceLook(Base):
    """Initial Not Run table, Recent Reports rows/colours, status summary and proportions (reference screenshot)."""

    def test_initial_table_lists_all_21_checks_as_not_run_like_menu_3(self):
        from ohc.checks import engine
        d = self.d
        self.assertEqual(d.results.rowCount(), 21)
        self.assertEqual([d.results.item(r, 0).text() for r in range(21)], [f"CHK_{i + 1:02d}" for i in engine.plan("ALL")])
        self.assertEqual([d.results.item(r, 1).text() for r in range(21)], [engine.NAMES[i] for i in engine.plan("ALL")])
        for r in range(21):
            self.assertEqual(d.results.item(r, 2).data(STATUS_ROLE), "PENDING")           # the "Not Run" badge, as in menu 3
            self.assertEqual((d.results.item(r, 3).text(), d.results.item(r, 4).text()), ("-", "-"))
        self.assertEqual(self.all_page.table.rowCount(), 21)
        self.assertEqual([self.all_page.table.item(r, 1).text() for r in range(21)], [d.results.item(r, 1).text() for r in range(21)])

    def test_old_reports_and_logs_do_not_change_the_initial_table(self):
        (self.tmp / "logs").mkdir(exist_ok=True)
        (self.tmp / "logs" / "ohc_ims_20260101_090000.log").write_text("[1] DB STATUS : CRITICAL  -  old\n", encoding="utf-8")
        self.report("2026-10-19/ASH_Report_20261019_120000.html")
        self.d.refresh_btn.click()
        self.assertEqual({self.d.results.item(r, 2).data(STATUS_ROLE) for r in range(21)}, {"PENDING"})
        self.assertEqual(self.d.reports_table.rowCount(), 1)

    def test_recent_reports_has_no_empty_row_and_no_amber_text(self):
        self.run_dashboard()                                                              # a fake (simulated) health report
        self.report("2026-10-19/ASH_Report_20261019_120000.html")
        self.d.refresh_btn.click()
        self.settle()
        t = self.d.reports_table
        n = t.rowCount()
        self.assertEqual(n, 2)
        self.assertEqual(t.height() - 2 * t.frameWidth() - t.horizontalHeader().height(), 28 * n + 2)     # header + n rows, nothing below
        for r in range(n):
            for c in (0, 1, 2):
                brush = t.item(r, c).foreground()
                self.assertNotEqual(brush.color().name().upper(), "#F59E0B", (r, c))
                self.assertEqual(brush.style(), Qt.BrushStyle.NoBrush, (r, c))              # theme text colour (black on the light theme)
        self.assertIn("Simulated report", " ".join(t.item(r, 1).toolTip() for r in range(n)))
        self.assertEqual(t.rowCount(), len([1 for r in range(n) if t.cellWidget(r, 3) is not None]))

    def test_reports_table_hidden_when_there_are_no_reports(self):
        self.assertEqual(self.d.reports_table.rowCount(), 0)
        self.assertTrue(self.d.reports_table.isHidden())
        self.assertFalse(self.d.reports_note.isHidden())

    def test_status_summary_counts_sit_next_to_their_labels(self):
        d = self.d
        self.win.resize(1360, 860)
        self.settle()
        self.assertGreaterEqual(d.donut.width(), 120)
        for key in ("healthy", "warnings", "critical"):
            dot, value, caption = d.legend[key]
            gap = value.mapTo(d, value.rect().topLeft()).x() - (caption.mapTo(d, caption.rect().topLeft()).x() + caption.fontMetrics().horizontalAdvance(caption.text()))
            self.assertLessEqual(gap, 60, key)
        card_right = d.donut.parentWidget().mapTo(d, d.donut.parentWidget().rect().topRight()).x()
        self.assertLess(d.legend["healthy"][1].mapTo(d, d.legend["healthy"][1].rect().topRight()).x(), card_right - 80)   # not pushed to the far right

    def test_proportions_follow_the_reference(self):
        d = self.d
        self.win.resize(1360, 860)
        self.settle()
        res, rep = d.results.parentWidget(), d.reports_table.parentWidget()
        summ = d.donut.parentWidget()
        self.assertAlmostEqual(res.width() / (rep.width()), 5 / 4, delta=0.15)             # reference: results card ~1.2x the right column
        self.assertGreater(summ.height(), rep.height() - 40)                               # the summary card took the height the reports card does not need
        for card in (res, summ, rep):
            self.assertTrue(card.geometry().isValid())


class StableControls(Base):
    """Run / Cancel never move while the status text changes; the Open Report button is never clipped."""

    def positions(self):
        d = self.d
        pos = lambda w: (w.mapTo(d, w.rect().topLeft()).x(), w.mapTo(d, w.rect().topLeft()).y(), w.width(), w.height())
        return pos(d.run_btn), pos(d.cancel_btn), d.conn_label.width()

    def test_run_and_cancel_do_not_move_for_any_status_text(self):
        from ohc.gui.dashboard_page import STATUS_TEXTS
        for size in ((1200, 760), (1360, 860)):
            self.win.resize(*size)
            self.settle()
            ref = self.positions()
            for text in STATUS_TEXTS + ("Running ... 0 of 21 checks completed", "Running ... 6 of 21 checks completed", "Running ..."):
                self.d.conn_label.setText(text)
                self.settle()
                self.assertEqual(self.positions(), ref, (size, text))
            fm = self.d.conn_label.fontMetrics()
            self.assertGreaterEqual(self.d.conn_label.width(), max(fm.horizontalAdvance(t) for t in STATUS_TEXTS))
            self.assertLessEqual(self.d.minimumSizeHint().width() + 300, 1200)          # the reserved area does not widen the page

    def test_run_and_cancel_stay_put_during_a_real_run_and_cancel_is_clickable(self):
        os.environ["OHC_FAKE_DELAY"] = "0.15"
        ref = self.positions()
        self.d.run_btn.click()
        seen, end = [], time.time() + 20
        while self.win.gate.busy if hasattr(self.win.gate, "busy") else self.all_page._thread is not None:
            self.app.processEvents()
            self.d._poll_run()
            seen.append((self.positions(), self.d.cancel_btn.isEnabled(), self.d.conn_label.text()))
            time.sleep(0.02)
            if time.time() > end:
                self.d.cancel_btn.click()
                break
        self.assertGreater(len({t for _p, _c, t in seen}), 3)                              # the text really changed during the run
        self.assertTrue(any(c for _p, c, t in seen if t.startswith("Running")))
        for pos, cancel_enabled, text in seen:
            self.assertEqual(pos, ref, text)
            if text.startswith("Running"):
                self.assertTrue(cancel_enabled, text)                                           # Cancel is usable for the whole run
        self.assertTrue(wait_idle(self.win.gate))
        self.settle()
        self.assertEqual(self.positions(), ref)

    def test_open_report_button_has_room_for_its_text(self):
        from ohc.gui.dashboard_page import OPEN_TEXT
        self.report("2026-10-19/ASH_Report_20261019_120000.html")
        self.report("2026-10-19/AWR_Report_1_2_20261019_110000.html")
        self.report("2026-10-20/AWR_Report_1_2_20261020_110000.html")
        for theme in ("light", "dark"):
            self.win.theme.set_theme(theme)
            for size in ((1200, 760), (1360, 860)):
                self.win.resize(*size)
                self.d.refresh_btn.click()
                self.settle()
                self.settle()
                t = self.d.reports_table
                self.assertEqual(t.rowCount(), 3)
                need = t.fontMetrics().horizontalAdvance(OPEN_TEXT) + 16
                self.assertGreaterEqual(t.columnWidth(3), need + 8, (theme, size))                       # column: text + padding + cell margins
                for r in range(3):
                    holder = t.cellWidget(r, 3)
                    btn = holder.open_btn
                    self.assertGreaterEqual(btn.width(), need, (theme, size, r))
                    self.assertGreaterEqual(btn.width(), btn.sizeHint().width(), (theme, size, r))      # not squeezed below its natural size
                    self.assertLessEqual(btn.mapTo(holder, btn.rect().topRight()).x(), holder.width(), (theme, size, r))
                self.assertFalse(t.horizontalScrollBar().isVisible(), (theme, size))
                self.assertGreaterEqual(t.columnWidth(1), 60, (theme, size))                              # report-name column still has room


class RunModeAndOrder(Base):
    """Settings > Test Connection classifies the database (SWITCHOVER_STATUS); Dashboard Run follows it; results are listed by check ID."""

    def entry(self):
        return self.ctx.databases.find_by_name("ims")

    def do_test_connection(self, switchover=None, scenario=None):
        env = {}
        if switchover is not None:
            env["OHC_FAKE_SWITCHOVER"] = switchover
        if scenario is not None:
            env["OHC_FAKE_ORACLE"] = scenario
        with mock.patch.dict(os.environ, env):
            sp = self.win.settings_page
            sp.refresh_databases(self.entry().id)
            self.assertTrue(sp.test_btn.isEnabled())
            sp.test_btn.click()
            self.assertTrue(wait_idle(self.win.gate))
            self.settle()
        return sp.status.text()

    def run_options(self):
        """Click Dashboard Run with launcher.run_option recorded; returns the menu options that were executed."""
        calls, real = [], launcher.run_option
        with mock.patch.object(launcher, "run_option", side_effect=lambda *a, **k: calls.append(a[2]) or real(*a, **k)):
            self.d.refresh()
            self.d.run_btn.click()
            self.assertTrue(wait_idle(self.win.gate))
        self.settle()
        return calls

    def test_not_allowed_is_standard_and_dashboard_run_executes_menu_1(self):
        text = self.do_test_connection("NOT ALLOWED")
        self.assertEqual((self.entry().run_mode, self.entry().switchover_status), ("standard", "NOT ALLOWED"))
        self.assertIn("1. Oracle Health Check", text)
        self.assertEqual(self.run_options(), ["1"])
        self.assertEqual(self.d.results.rowCount(), 17)                                  # the 17 checks of menu 1 only
        self.assertEqual(self.d.summary.total, 17)

    def test_every_other_status_is_data_guard_and_dashboard_run_executes_menu_3(self):
        for status in ("TO STANDBY", "FAILED DESTINATION", "SESSIONS ACTIVE", "TO PRIMARY"):
            self.do_test_connection(status)
            self.assertEqual((self.entry().run_mode, self.entry().switchover_status), ("dataguard", status), status)
        self.assertEqual(self.run_options(), ["3"])
        self.assertEqual(self.d.results.rowCount(), 21)

    def test_not_classified_yet_keeps_the_all_checks_behaviour_without_querying(self):
        from ohc.checks import fake
        self.assertEqual(self.entry().run_mode, "")
        with mock.patch.object(fake.FakeOracleSession, "switchover_status", side_effect=AssertionError("Run must not classify")) as q:
            self.assertEqual(self.run_options(), ["3"])
            self.assertEqual(q.call_count, 0)                                            # Run never queries SWITCHOVER_STATUS
        self.assertIn("Test Connection", self.d.run_btn.toolTip())

    def test_classification_query_runs_once_per_test_connection_only(self):
        from ohc.checks import fake
        real = fake.FakeOracleSession.switchover_status
        with mock.patch.object(fake.FakeOracleSession, "switchover_status", autospec=True, side_effect=real) as q:
            self.do_test_connection("NOT ALLOWED")
            self.assertEqual(q.call_count, 1)
            self.run_options()
            self.assertEqual(q.call_count, 1)                                            # runs reuse the saved classification

    def test_failed_query_is_not_misclassified_and_run_falls_back_to_all_checks(self):
        self.do_test_connection("NOT ALLOWED")
        self.assertEqual(self.entry().run_mode, "standard")
        text = self.do_test_connection("ERROR")
        self.assertEqual((self.entry().run_mode, self.entry().switchover_status), ("", ""))   # not guessed, not kept stale
        self.assertIn("could not be determined", text)
        self.assertEqual(self.run_options(), ["3"])

    def test_unreachable_database_keeps_the_saved_classification(self):
        self.do_test_connection("NOT ALLOWED")
        self.do_test_connection(scenario="down")
        self.assertEqual(self.entry().run_mode, "standard")

    def test_saved_mode_survives_a_restart_and_resets_when_the_server_changes(self):
        from ohc.config import dbadmin
        from ohc.config.databases import DatabaseStore
        self.do_test_connection("NOT ALLOWED")
        self.assertEqual(DatabaseStore(self.ctx.databases.path).get(self.entry().id).run_mode, "standard")
        dbadmin.update_database(self.ctx.databases, self.ctx.credentials_dir, self.entry().id, notes="only a note", backend=self.ctx.backend)
        self.assertEqual(self.entry().run_mode, "standard")
        dbadmin.update_database(self.ctx.databases, self.ctx.credentials_dir, self.entry().id, sid="OTHER", backend=self.ctx.backend)
        self.assertEqual((self.entry().run_mode, self.entry().switchover_status), ("", ""))

    def test_results_are_listed_by_check_id_with_status_message_and_time_kept(self):
        self.run_dashboard()
        d, p = self.d, self.all_page
        ids = [d.results.item(r, 0).text() for r in range(21)]
        self.assertEqual(ids, [f"CHK_{i:02d}" for i in range(1, 22)])
        states = [d.results.item(r, 2).data(STATUS_ROLE) for r in range(21)]
        self.assertIn("WARNING", states)
        self.assertNotEqual(states[:3], sorted(states)[:3])                               # warnings stay where their check ID is
        for r in range(p.table.rowCount()):
            idx = p.table.item(r, 0).data(Qt.ItemDataRole.UserRole + 1)
            row = ids.index(f"CHK_{idx + 1:02d}")
            self.assertEqual(d.results.item(row, 2).data(STATUS_ROLE), p.table.item(r, 2).data(STATUS_ROLE))
            self.assertEqual(d.results.item(row, 3).text(), p.table.item(r, 3).text())
            self.assertRegex(d.results.item(row, 4).text(), r"^\d\d:\d\d:\d\d$")

    def test_ascending_order_also_while_the_run_is_in_progress(self):
        seen = []
        self.all_page.view_changed.connect(lambda: seen.append([self.d.results.item(r, 0).text() for r in range(self.d.results.rowCount())]))
        self.run_dashboard()
        self.assertTrue(seen)
        for ids in seen:
            self.assertEqual(ids, sorted(ids))

    def test_standard_database_clean_state_lists_only_the_menu_1_checks(self):
        from ohc.checks import engine
        self.do_test_connection("NOT ALLOWED")
        self.d.refresh()
        self.assertEqual([self.d.results.item(r, 0).text() for r in range(self.d.results.rowCount())],
                         [f"CHK_{i + 1:02d}" for i in engine.plan("SQL")])
        self.assertEqual(self.d.results_note.text(), "Run Health Check to view results.")


class RunAfterSettingsChange(Base):
    """Dashboard Run after a database was added in Settings in this session (the menu 1 / 3 pages only refresh their list when shown)."""

    def add_database(self, name="ims2"):
        from ohc.config.databases import DatabaseEntry
        from ohc.security import credstore
        entry = DatabaseEntry(id=credstore.new_database_id(), name=name)
        self.ctx.databases.add(entry)
        credstore.save_credentials(self.ctx.credentials_dir, entry.id, "sys", "pw", backend=self.ctx.backend)
        return entry

    def select_on_dashboard(self, entry):
        self.d.refresh_databases()
        self.d.db_combo.setCurrentIndex(self.d.db_combo.findData(entry.id))
        self.assertEqual(self.d._db().name, entry.name)

    def run_and_record(self):
        calls, real = [], launcher.run_option
        with mock.patch.object(launcher, "run_option", side_effect=lambda *a, **k: calls.append((a[1], a[2])) or real(*a, **k)):
            self.d.run_btn.click()
            self.assertTrue(wait_idle(self.win.gate))
        self.settle()
        return calls

    def test_run_uses_a_database_added_after_startup_not_the_stale_one(self):
        entry = self.add_database()
        self.assertEqual(self.all_page.db_combo.count(), 1)                              # the run pages do not know it yet
        self.select_on_dashboard(entry)
        self.assertEqual(self.run_and_record(), [("ims2", "3")])                         # runs on the selected database, never on "ims"
        self.assertEqual(self.d.results.rowCount(), 21)
        self.assertEqual(self.d.summary.db, "ims2")

    def test_standard_database_added_after_startup_runs_menu_1(self):
        entry = self.add_database()
        from ohc.config import dbadmin
        dbadmin.set_run_mode(self.ctx.databases, entry.id, "standard", "NOT ALLOWED")
        self.select_on_dashboard(entry)
        self.assertEqual(self.run_and_record(), [("ims2", "1")])

    def test_after_settings_test_connection_the_first_click_on_run_works(self):
        entry = self.add_database()
        self.win.nav.setCurrentRow(6)                                                    # Settings, as the user does
        self.settle()
        with mock.patch.dict(os.environ, {"OHC_FAKE_SWITCHOVER": "NOT ALLOWED"}):
            sp = self.win.settings_page
            sp.refresh_databases(entry.id)
            sp.test_btn.click()
            self.assertTrue(wait_idle(self.win.gate))
            self.settle()
        self.assertFalse(self.win.gate.busy)
        self.win.nav.setCurrentRow(0)                                                    # the sidebar, as the user does
        self.settle()
        self.d.db_combo.setCurrentIndex(self.d.db_combo.findData(entry.id))
        self.assertTrue(self.d.run_btn.isEnabled())
        self.assertEqual(self.run_and_record(), [("ims2", "1")])                         # first click, no refresh needed

    def test_a_refused_start_is_explained_on_the_dashboard(self):
        from ohc.gui import outcomes
        with mock.patch.object(outcomes, "fake_status", return_value=("Simulated mode is set up wrongly", "bad")):
            calls = self.run_and_record()
        self.assertEqual(calls, [])
        self.assertIn("Simulated mode is set up wrongly", self.d.results_note.text())

    def test_a_missing_database_on_the_run_page_is_reported_and_nothing_runs(self):
        with mock.patch.object(self.all_page, "refresh_databases"), mock.patch.object(self.all_page.db_combo, "findData", return_value=-1):
            calls = self.run_and_record()
        self.assertEqual(calls, [])
        self.assertIn("not available", self.d.results_note.text())

    def test_run_follows_the_gate_even_if_refresh_fails_when_a_job_ends(self):
        self.win.gate.begin()                                                            # e.g. Test Connection starts
        self.assertFalse(self.d.run_btn.isEnabled())
        self.win.gate.busy = False                                                       # ... and ends, but refreshing the Dashboard fails
        with mock.patch.object(self.d, "refresh", side_effect=RuntimeError("boom")):
            with self.assertRaises(RuntimeError):
                self.d._gate_changed(False)
        self.assertTrue(self.d.run_btn.isEnabled())                                      # Run is usable again although refresh() raised
        self.assertFalse(self.d._poll.isActive())


class Navigation(Base):
    def test_cards_navigate_and_start_nothing(self):
        d, win = self.d, self.win
        dbp = win.pages.widget(4)
        with mock.patch.object(type(self.all_page), "start") as start, mock.patch.object(awr_service, "load_snapshots") as load, \
                mock.patch.object(ash_service, "generate_report") as ash_gen, mock.patch.object(addm_service, "generate_report") as addm_gen, \
                mock.patch.object(launcher, "run_option") as run:
            for key, row, tab in (("health", 1, None), ("sync", 2, None), ("awr", 4, 0), ("ash", 4, 1), ("addm", 4, 2)):
                win.nav.setCurrentRow(0)
                d.quick[key].click()
                self.settle()
                self.assertEqual(win.nav.currentRow(), row, key)
                self.assertEqual(win.pages.currentIndex(), row, key)
                if tab is not None:
                    self.assertEqual(dbp.tabs.currentIndex(), tab, key)
                    self.assertEqual((dbp._awr_cards[0].isVisible(), dbp.ash.isVisible(), dbp.addm.isVisible()), (tab == 0, tab == 1, tab == 2), key)
            for mocked in (start, load, ash_gen, addm_gen, run):
                mocked.assert_not_called()
        self.assertFalse(win.gate.busy)

    def test_view_all_links(self):
        self.d.view_results.click()
        self.assertEqual(self.win.nav.currentRow(), 5)                       # Reports & Logs
        self.win.nav.setCurrentRow(0)
        self.d.view_reports.click()                                          # no report yet -> Reports & Logs
        self.assertEqual(self.win.nav.currentRow(), 5)
        ash_report = self.report("2026-10-19/ASH_Report_20261019_120000.html")
        self.d.refresh()
        self.win.nav.setCurrentRow(0)
        self.d.view_reports.click()                                          # newest is an ASH report -> its tab
        self.assertEqual((self.win.nav.currentRow(), self.win.pages.widget(4).tabs.currentIndex()), (4, 1))
        self.assertTrue(ash_report.exists())


class Reports(Base):
    def test_recent_reports_open_their_own_file(self):
        files = [self.report("2026-10-19/ASH_Report_20261019_120000.html"), self.report("2026-10-19/AWR_Report_1_2_20261019_110000.html"),
                 self.report("2026-10-19/ADDM_Report_1_2_20261019_100000.txt"), self.report("2026-10-18/ADDM_Report_3_4_20261018_100000.txt")]
        self.d.refresh_btn.click()
        d = self.d
        self.assertEqual([d.reports_table.item(r, 0).text() for r in range(3)], ["ASH", "AWR", "ADDM"])
        with mock.patch("ohc.gui.dashboard_page.QDesktopServices.openUrl") as opener:
            for row in range(3):
                opener.reset_mock()
                holder = d.reports_table.cellWidget(row, 3)
                self.assertEqual(holder.open_btn.text(), "Open Report")
                holder.open_btn.click()
                self.assertEqual(Path(opener.call_args.args[0].toLocalFile()), Path(d.reports_table.item(row, 1).data(Qt.ItemDataRole.UserRole)))
                self.assertEqual(Path(opener.call_args.args[0].toLocalFile()), files[row])

    def test_a_missing_file_is_reported_not_opened(self):
        f = self.report("2026-10-19/ASH_Report_20261019_120000.html")
        self.d.refresh_btn.click()
        f.unlink()
        with mock.patch("ohc.gui.dashboard_page.QDesktopServices.openUrl") as opener:
            self.d.reports_table.cellWidget(0, 3).open_btn.click()
            opener.assert_not_called()
        self.settle()
        self.assertIn("no longer exists", self.d.reports_note.text())
        self.assertEqual(self.d.reports_table.rowCount(), 0)

    def test_refresh_picks_up_new_reports_and_runs(self):
        self.assertEqual(self.d.reports_table.rowCount(), 0)
        self.report("2026-10-19/ASH_Report_20261019_120000.html")
        self.d.refresh_btn.click()
        self.assertEqual(self.d.reports_table.rowCount(), 1)
        launcher.run_option(self.ctx, "ims", "3", emit=lambda line: None)           # writes a log outside the GUI: it is NOT shown as a current result
        self.d.refresh_btn.click()
        self.assertEqual((self.d.summary.total, self.d.results.rowCount()), (0, 21))
        self.assertEqual({self.d.results.item(r, 2).data(STATUS_ROLE) for r in range(21)}, {"PENDING"})

    def test_simulated_reports_are_marked(self):
        self.run_dashboard()
        item = self.d.reports_table.item(0, 1)
        self.assertIn("Simulated report", item.toolTip())


class Layout(Base):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        from PySide6.QtGui import QFont, QFontDatabase           # Segoe UI has Arial-like widths; see test_awr_page.Layout
        cls._old_font = cls.app.font()
        for family in ("Segoe UI", "Arial", "Liberation Sans"):
            if family in QFontDatabase.families():
                cls.app.setFont(QFont(family, 9))
                break

    @classmethod
    def tearDownClass(cls):
        cls.app.setFont(cls._old_font)

    def check(self, w, h, theme):
        self.win.theme.set_theme(theme)
        self.win.resize(w, h)
        self.settle()
        self.run_dashboard()
        self.report("2026-10-19/ASH_Report_20261019_120000.html")
        self.report("2026-10-19/AWR_Report_1_2_20261019_110000.html")
        self.d.refresh_btn.click()
        self.settle()
        self.settle()
        d, tag = self.d, (w, h, theme)
        self.assertEqual((self.win.width(), self.win.height()), (w, h), tag)
        self.assertLessEqual(d.minimumSizeHint().width() + 300, 1200, tag)
        self.assertLessEqual(d.minimumSizeHint().height() + 60, 760, tag)
        self.assertLessEqual(d.minimumSizeHint().height() + 60, 760 - 25, tag)        # headroom: a taller font/DPI (Segoe UI) must still fit
        self.assertLessEqual(d.minimumSizeHint().height(), d.height(), tag)
        self.assertEqual(d.findChildren(QScrollArea), [], tag)
        for wdg in d.findChildren(QWidget):
            if wdg.isVisibleTo(d) and wdg.width() and wdg.height() and not wdg.visibleRegion().isEmpty():
                vis = wdg.visibleRegion().boundingRect()
                r = wdg.mapTo(d, vis.topLeft())
                self.assertTrue(0 <= r.x() and r.x() + vis.width() <= d.width() + 1 and 0 <= r.y() and r.y() + vis.height() <= d.height() + 1, (tag, wdg))
        for table in (d.results, d.reports_table):
            self.assertFalse(table.horizontalScrollBar().isVisible(), tag)
        self.assertFalse(d.reports_table.verticalScrollBar().isVisible(), tag)
        self.assertTrue(d.results.verticalScrollBar().isVisible(), tag)                # 21 results do not fit: the table scrolls
        self.assertLessEqual(sum(d.results.columnWidth(c) for c in range(5)), d.results.viewport().width() + 1, tag)   # scrollbar does not clip a column
        self.assertGreaterEqual(d.results.viewport().height() // 28, 7, tag)           # multiple result rows are visible together
        n = d.reports_table.rowCount()                                                  # exactly the real rows: no blank row under the last report
        self.assertEqual(d.reports_table.isVisibleTo(d), n > 0, tag)
        if n:
            self.assertGreaterEqual(d.reports_table.viewport().height() // 28, n, tag)
            self.assertLess(d.reports_table.viewport().height(), 28 * (n + 1), tag)
        self.assertGreaterEqual(d.donut.width(), 120, tag)                              # enlarged status ring
        self.assertGreaterEqual(d.donut.height(), 120, tag)
        for key, btn in d.quick.items():                                                # quick-card title, description and button never overlap
            card = btn.parentWidget()
            title = next(x for x in card.findChildren(QLabel) if x.objectName() == "quickTitle")
            subs = [x for x in card.findChildren(QLabel) if x.objectName() != "quickTitle" and x.wordWrap()]
            tr, sr, br = (QRect(x.mapTo(d, x.rect().topLeft()), x.size()) for x in (title, subs[0], btn))
            self.assertLessEqual(tr.bottom(), sr.top(), (tag, key))                     # title / description / button never overlap
            self.assertLessEqual(sr.bottom(), br.top(), (tag, key))
            self.assertGreaterEqual(title.height(), title.heightForWidth(title.width()), (tag, key))
        for row in range(d.reports_table.rowCount()):
            holder = d.reports_table.cellWidget(row, 3)
            self.assertLessEqual(holder.open_btn.sizeHint().width() + 8, d.reports_table.columnWidth(3), (tag, row))
        for key, btn in d.quick.items():                                      # quick-action buttons show their whole text
            self.assertGreaterEqual(btn.width(), btn.fontMetrics().horizontalAdvance(btn.text()) + 8, (tag, key))

        def box(x):
            return QRect(x.mapTo(d, x.rect().topLeft()), x.size())
        row = (d.db_combo, d.dot, d.conn_label, d.run_btn, d.cancel_btn)
        for a, b in zip(row, row[1:]):
            self.assertLessEqual(box(a).right(), box(b).left() + 1, (tag, a, b))
        self.assertLess(box(d.run_btn).bottom(), box(d.results).top(), tag)
        self.assertLess(box(d.results).bottom(), box(d.quick["health"]).top(), tag)

    def test_1360x860_dark(self):
        self.check(1360, 860, "dark")

    def test_1360x860_light(self):
        self.check(1360, 860, "light")

    def test_1200x760_dark(self):
        self.check(1200, 760, "dark")

    def test_1200x760_light(self):
        self.check(1200, 760, "light")

    def test_tables_keep_three_rows_even_at_their_minimum_size_with_a_taller_header(self):
        """Regression (Windows 1200x760): the minimum height assumed a 28 px header, so a taller header left a 2-row viewport."""
        d = self.d
        self.win.resize(1200, 760)
        for header in (28, 36, 44):
            for table in (d.results, d.reports_table):
                table.horizontalHeader().setFixedHeight(header)
                table.fit_columns()                                                  # what a resize/show does (emits `fitted`)
            self.settle()
            self.settle()
            room = d.results.minimumHeight() - d.results.horizontalHeader().height() - 2 * d.results.frameWidth()
            self.assertGreaterEqual(room // 28, 3, header)
            rep = d.reports_table                                                      # sized to its real rows (none here: hidden)
            self.assertEqual((rep.minimumHeight() - rep.horizontalHeader().height() - 2 * rep.frameWidth()) // 28, rep.rowCount(), header)
            self.assertLessEqual(d.minimumSizeHint().height() + 60, 760, header)       # and the page still fits the 1200x760 window
            self.assertEqual((self.win.width(), self.win.height()), (1200, 760), header)

    def test_chart_colours_follow_the_theme(self):
        self.run_dashboard()
        dark = self.d.donut.center_pen.name()
        self.win.theme.set_theme("light")
        self.settle()
        self.assertNotEqual(self.d.donut.center_pen.name(), dark)
        self.win.theme.set_theme("dark")
        self.settle()
        self.assertEqual(self.d.donut.center_pen.name(), dark)


if __name__ == "__main__":
    unittest.main()
