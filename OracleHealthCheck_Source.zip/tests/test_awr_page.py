"""Database Reports / AWR page (Qt offscreen, fake Oracle session only): initial state, explicit loading, selection, validation,
database switching, failures, cancellation, generation, history and layout. Real Oracle and real Windows rendering are NOT covered."""
import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if sys.platform == "win32":
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

import shutil
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

from PySide6.QtCore import QRect, Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QLabel, QScrollArea, QWidget

from ohc import awr, awr_service
from ohc.gui.awr_page import DatabaseReportsPage
from ohc.gui.main_window import MainWindow
from tests.test_awr import make_awr_ctx
from tests.test_gui_run import wait_idle

ROW = 4   # "4. Database Reports"


class Base(unittest.TestCase):
    names = ("ims",)

    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        env = mock.patch.dict(os.environ, {"OHC_FAKE_ORACLE": "healthy"})
        env.start()
        self.addCleanup(env.stop)
        for key in ("OHC_FAKE_AWR", "OHC_FAKE_DELAY"):
            os.environ.pop(key, None)
        self.ctx = make_awr_ctx(self.tmp, self.names)
        self.win = MainWindow(self.ctx)
        self.addCleanup(self.win.deleteLater)
        self.win.show()
        self.win.nav.setCurrentRow(ROW)
        self.settle()
        self.page: DatabaseReportsPage = self.win.pages.widget(ROW)

    def settle(self):
        self.app.processEvents()
        self.app.processEvents()

    def load(self, days=7):
        self.page.days.setValue(days)
        self.page.load_btn.click()
        self.assertTrue(wait_idle(self.win.gate))

    def radio(self, row, side=0):
        return self.page.table.cellWidget(row, 0 if side == 0 else 2)

    def click(self, widget):
        QTest.mouseClick(widget, Qt.MouseButton.LeftButton)

    def radios(self):
        t = self.page.table
        return [t.cellWidget(r, c) for r in range(t.rowCount()) for c in (0, 2) if t.cellWidget(r, c) is not None]

    def ids(self):
        return [int(w.text()) for w in self.radios()]

    def report(self, rel, size=10):
        p = self.tmp / "reports" / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b"<html>" + b"x" * size)
        return p


class InitialState(Base):
    def test_page_replaces_the_placeholder_and_nothing_is_queried(self):
        with mock.patch.object(awr_service, "load_snapshots") as load, mock.patch.object(awr_service, "generate_report") as gen:
            win = MainWindow(self.ctx)
            self.addCleanup(win.deleteLater)
            win.show()
            win.nav.setCurrentRow(ROW)
            self.settle()
            page = win.pages.widget(ROW)
            self.assertIsInstance(page, DatabaseReportsPage)
            page.days.setValue(30)
            self.settle()
            load.assert_not_called()      # opening the page and changing Days back never query
            gen.assert_not_called()

    def test_controls_before_loading(self):
        p = self.page
        self.assertEqual(p.days.value(), 7)
        self.assertEqual((p.days.minimum(), p.days.maximum()), (1, 365))
        self.assertEqual(p.table.rowCount(), 0)
        self.assertFalse(p.begin_edit.isEnabled())
        self.assertFalse(p.end_edit.isEnabled())
        self.assertTrue(p.load_btn.isEnabled())
        self.assertFalse(p.generate_btn.isEnabled())
        self.assertFalse(p.cancel_btn.isEnabled())
        self.assertFalse(p.open_check.isChecked())
        self.assertTrue(p.rac_check.isEnabled() and not p.rac_check.isChecked())
        self.assertTrue(p.type_combo.isEnabled())
        self.assertEqual([p.type_combo.itemText(i) for i in range(p.type_combo.count())], ["HTML", "Text"])
        self.assertEqual(p.type_combo.currentText(), "HTML")
        self.assertEqual(p.name_edit.text(), "AWR_Report_<begin>_<end>_<yyyymmdd_HHMMSS>")     # the legacy pattern, editable
        self.assertEqual(p.ext_label.text(), ".html")
        self.assertEqual([p.tabs.tabText(i) for i in range(3)], ["AWR Report", "ASH Report", "ADDM Report"])
        self.assertEqual([p.tabs.isTabEnabled(i) for i in range(3)], [True, True, True])     # AWR, ASH and ADDM are live

    def test_snapshot_headers_and_forbidden_labels(self):
        p = self.page
        self.assertEqual([p.table.horizontalHeaderItem(i).text() for i in range(6)], ["Snap ID", "Time", "Snap ID", "Time", "Instance", "Duration"])
        texts = {w.text() for w in p.findChildren(QLabel)}
        for forbidden in ("SNAP INTERVAL", "Snap Interval", "Left", "Right"):
            self.assertNotIn(forbidden, texts)
        self.assertEqual(p.hist.rowCount(), 0)
        self.assertEqual([p.hist.horizontalHeaderItem(i).text() for i in range(6)],
                         ["Date & Time", "DB", "Snapshot Range", "File Name", "Size", "Actions"])
        self.assertIn("reports folder does not exist", p.hist_note.text())     # nothing generated yet

    def test_fake_indicator_is_visible(self):
        self.assertFalse(self.page.sim_tag.isHidden())
        with mock.patch.dict(os.environ):
            os.environ.pop("OHC_FAKE_ORACLE")
            self.page._refresh_fake()
            self.assertTrue(self.page.sim_tag.isHidden())

    def test_busy_state_follows_the_shared_gate(self):
        self.win.gate.begin()
        self.settle()
        self.assertFalse(self.page.load_btn.isEnabled())
        self.assertFalse(self.page.db_combo.isEnabled())
        self.win.gate.end()
        self.settle()
        self.assertTrue(self.page.load_btn.isEnabled())


class Loading(Base):
    def test_explicit_load_fills_paired_rows(self):
        self.load()
        p = self.page
        self.assertEqual(p.table.rowCount(), 31)                          # 61 snapshots -> 30 pairs + 1 odd
        self.assertEqual(sorted(self.ids()), list(range(9001, 9062)))     # every snapshot once, no repeats
        self.assertEqual(self.radio(0).text(), "9001")
        self.assertEqual(self.radio(0, 1).text(), "9002")
        self.assertEqual(self.radio(1).text(), "9003")
        last = p.table.rowCount() - 1
        self.assertEqual(self.radio(last).text(), "9061")
        self.assertIsNone(p.table.cellWidget(last, 2))                    # odd count: right-hand cells stay empty
        self.assertEqual((p.table.item(last, 2).text(), p.table.item(last, 3).text()), ("", ""))
        self.assertEqual(p.table.item(0, 4).text(), "1")
        self.assertEqual(p.table.item(0, 5).text(), "60 mins")
        self.assertTrue(p.begin_edit.isEnabled() and p.end_edit.isEnabled())
        self.assertIn("SIMULATED DATA", p.status.toPlainText())
        self.assertIn("Loaded 61", p.status.toPlainText())
        self.assertFalse(p.cancel_btn.isEnabled())

    def test_load_runs_in_the_background_and_disables_conflicting_controls(self):
        release, seen = threading.Event(), {}

        def slow(ctx, name, days, token=None):
            seen["args"] = (name, days)
            release.wait(10)
            return awr_service.AwrResult("snapshots", False, True, "cancelled", db=name)
        with mock.patch.object(awr_service, "load_snapshots", slow):
            self.page.days.setValue(3)
            self.page.load_btn.click()
            self.settle()
            p = self.page
            self.assertTrue(self.win.gate.busy)
            self.assertFalse(p.load_btn.isEnabled() or p.generate_btn.isEnabled() or p.db_combo.isEnabled() or p.days.isEnabled())
            self.assertTrue(p.cancel_btn.isEnabled())
            self.assertIn("Loading", p.status.toPlainText())
            release.set()
            self.assertTrue(wait_idle(self.win.gate))
        self.assertEqual(seen["args"], ("ims", 3))
        self.assertTrue(self.page.load_btn.isEnabled())
        self.assertFalse(self.page.cancel_btn.isEnabled())

    def test_even_count_has_no_empty_cells(self):
        self.load(days=1)       # 24 snapshots
        self.assertEqual(self.page.table.rowCount(), 12)
        self.assertIsNotNone(self.page.table.cellWidget(11, 2))

    def test_failure_empty_and_cancellation_clear_everything(self):
        self.load()
        self.assertEqual(self.page.table.rowCount(), 31)
        self.click(self.radio(0))
        for mode, text in (("fail", "ORA-00942"), ("empty", "No snapshots were found")):
            self.load()                                   # first an OK load so there is something stale to clear
            self.assertGreater(self.page.table.rowCount(), 0)
            with mock.patch.dict(os.environ, {"OHC_FAKE_AWR": mode}):
                self.load()
            p = self.page
            self.assertEqual(p.table.rowCount(), 0, mode)
            self.assertEqual((p.begin_edit.text(), p.end_edit.text()), ("", ""), mode)
            self.assertFalse(p.begin_edit.isEnabled() or p.end_edit.isEnabled() or p.generate_btn.isEnabled(), mode)
            self.assertIn(text, p.status.toPlainText(), mode)
            self.assertEqual(p._status_level, "bad" if mode == "fail" else "warn")

    def test_tool_error_is_shown(self):
        os.environ["OHC_FAKE_ORACLE"] = "down"
        self.load()
        self.assertEqual(self.page.table.rowCount(), 0)
        self.assertIn("ORA-01034", self.page.status.toPlainText())

    def test_cancel_while_loading(self):
        os.environ["OHC_FAKE_DELAY"] = "1"
        self.page.load_btn.click()
        self.settle()
        self.assertTrue(self.page.cancel_btn.isEnabled())
        self.page.cancel_btn.click()
        self.assertFalse(self.page.cancel_btn.isEnabled())
        self.assertTrue(wait_idle(self.win.gate))
        p = self.page
        self.assertEqual(p.table.rowCount(), 0)
        self.assertFalse(p.begin_edit.isEnabled())
        self.assertIn("cancelled", p.status.toPlainText())
        self.assertTrue(p.load_btn.isEnabled())


class TwoDatabases(Base):
    names = ("ims", "prd")

    def test_database_switch_clears_snapshots_and_selection(self):
        self.load()
        self.click(self.radio(0))
        self.click(self.radio(0, 1))
        self.assertEqual((self.page.begin_edit.text(), self.page.end_edit.text()), ("9001", "9002"))
        self.page.db_combo.setCurrentIndex(1)
        self.settle()
        p = self.page
        self.assertEqual(p.table.rowCount(), 0)
        self.assertEqual((p.begin_edit.text(), p.end_edit.text()), ("", ""))
        self.assertFalse(p.begin_edit.isEnabled() or p.generate_btn.isEnabled())
        self.assertIn("prd", p.status.toPlainText())
        self.assertEqual(p._target, "begin")

    def test_the_selected_database_is_the_one_queried(self):
        self.page.db_combo.setCurrentIndex(1)
        with mock.patch.object(awr_service, "load_snapshots", return_value=awr_service.AwrResult("snapshots", False, message="m")) as load:
            self.page.load_btn.click()
            wait_idle(self.win.gate)
        self.assertEqual(load.call_args.args[1], "prd")


class Selection(Base):
    def setUp(self):
        super().setUp()
        self.load()

    def test_radio_fills_begin_then_end_and_stays_on_end(self):
        p = self.page
        self.assertEqual(p._target, "begin")
        self.assertIn("Begin", p.caption.text())
        self.click(self.radio(0))
        self.assertEqual((p.begin_edit.text(), p.end_edit.text(), p._target), ("9001", "", "end"))
        self.assertIn("End", p.caption.text())
        self.click(self.radio(0, 1))
        self.assertEqual((p.begin_edit.text(), p.end_edit.text(), p._target), ("9001", "9002", "end"))
        self.click(self.radio(1))                                   # later picks keep filling End
        self.assertEqual((p.begin_edit.text(), p.end_edit.text()), ("9001", "9003"))

    def test_each_snapshot_has_its_own_radio_and_highlights_follow_the_fields(self):
        p = self.page
        self.click(self.radio(2))
        self.click(self.radio(3, 1))
        checked = [int(r.text()) for r in self.radios() if r.isChecked()]
        self.assertEqual(sorted(checked), [9005, 9008])
        self.assertEqual(self.radio(2).property("mark"), "begin")
        self.assertEqual(self.radio(3, 1).property("mark"), "end")
        self.click(self.radio(0))                                    # End is the target: End moves, Begin stays
        self.assertEqual(self.radio(3, 1).property("mark"), "")
        self.assertEqual(self.radio(0).property("mark"), "end")
        self.assertEqual(self.radio(2).property("mark"), "begin")

    def test_clicking_an_input_makes_it_the_target(self):
        p = self.page
        self.click(self.radio(0))
        self.click(self.radio(0, 1))
        self.click(p.begin_edit)
        self.assertEqual(p._target, "begin")
        self.assertEqual(p.begin_edit.property("active"), "true")
        self.assertEqual(p.end_edit.property("active"), "false")
        self.click(self.radio(4))
        self.assertEqual((p.begin_edit.text(), p.end_edit.text(), p._target), ("9009", "9002", "end"))
        self.click(p.end_edit)
        self.assertEqual(p._target, "end")

    def test_typing_never_overwrites_the_other_field_or_moves_the_target(self):
        p = self.page
        self.click(self.radio(0))                        # Begin 9001, target End
        self.click(self.radio(0, 1))                     # End 9002
        before = p._target
        p.begin_edit.clear()
        QTest.keyClicks(p.begin_edit, "9005")            # typing without a click
        self.assertEqual((p.begin_edit.text(), p.end_edit.text(), p._target), ("9005", "9002", before))
        QTest.keyClicks(p.end_edit, "0")
        self.assertEqual((p.begin_edit.text(), p.end_edit.text(), p._target), ("9005", "90020", before))

    def test_regaining_window_focus_does_not_flip_the_target(self):
        p = self.page
        self.click(self.radio(0))
        self.assertEqual(p._target, "end")
        from PySide6.QtCore import QEvent
        from PySide6.QtGui import QFocusEvent
        p.eventFilter(p.begin_edit, QFocusEvent(QEvent.Type.FocusIn, Qt.FocusReason.ActiveWindowFocusReason))
        self.assertEqual(p._target, "end")

    def test_validation_and_generate_button(self):
        p = self.page
        def state(b, e):
            p.begin_edit.setText(b)
            p.end_edit.setText(e)
            return p.generate_btn.isEnabled(), p.range_msg.text(), p.range_msg.objectName()
        self.assertFalse(state("", "")[0])
        self.assertFalse(state("9001", "")[0])
        self.assertFalse(state("", "9002")[0])
        ok, msg, level = state("abc", "9002")
        self.assertEqual((ok, level), (False, "bad"))
        self.assertFalse(state("9001", "9x2")[0])
        self.assertFalse(state("9002", "9002")[0])
        ok, msg, level = state("9005", "9002")
        self.assertEqual((ok, level), (False, "bad"))
        self.assertIn("lower", msg)
        ok, msg, level = state("9001", "9002")
        self.assertEqual((ok, level), (True, "muted"))
        self.assertEqual(p.name_edit.text(), "AWR_Report_9001_9002_<yyyymmdd_HHMMSS>")

    def test_manual_ids_outside_the_loaded_list_are_allowed_with_a_warning(self):
        p = self.page
        p.begin_edit.setText("5")
        p.end_edit.setText("9002")
        self.assertTrue(p.generate_btn.isEnabled())
        self.assertEqual(p.range_msg.objectName(), "warn")
        self.assertIn("not in the loaded list", p.range_msg.text())

    def test_restart_between_loaded_snapshots_is_flagged(self):
        os.environ["OHC_FAKE_AWR"] = "restart"
        self.load()
        p = self.page
        p.begin_edit.setText("9001")
        p.end_edit.setText("9061")
        self.assertTrue(p.generate_btn.isEnabled())
        self.assertEqual(p.range_msg.objectName(), "warn")
        self.assertIn("restarted", p.range_msg.text())

    def test_capped_list_is_announced(self):
        os.environ["OHC_FAKE_AWR"] = "capped"
        self.load()
        self.assertEqual(len(self.ids()), 2000)
        self.assertIn("capped at 2,000", self.page.status.toPlainText())
        self.assertEqual(self.page._status_level, "warn")


class Options(Base):
    def select(self):
        self.load()
        self.click(self.radio(0))
        self.click(self.radio(0, 1))

    def generate(self):
        self.page.generate_btn.click()
        self.assertTrue(wait_idle(self.win.gate))

    def test_report_type_is_a_usable_two_item_dropdown_defaulting_to_html(self):
        p = self.page
        self.assertTrue(p.type_combo.isEnabled())
        self.assertEqual([(p.type_combo.itemText(i), p.type_combo.itemData(i)) for i in range(2)], [("HTML", "html"), ("Text", "text")])
        self.assertEqual(p.type_combo.count(), 2)
        self.assertEqual(p.type_combo.currentData(), "html")
        QTest.keyClick(p.type_combo, Qt.Key.Key_Down)                    # keyboard access
        self.assertEqual((p.type_combo.currentData(), p.ext_label.text()), ("text", ".txt"))
        QTest.keyClick(p.type_combo, Qt.Key.Key_Up)
        self.assertEqual((p.type_combo.currentData(), p.ext_label.text()), ("html", ".html"))
        p.type_combo.setCurrentIndex(1)
        self.assertEqual(p.ext_label.text(), ".txt")

    def test_include_rac_is_a_visible_clickable_checkbox(self):
        p = self.page
        self.assertTrue(p.rac_check.isEnabled() and p.rac_check.isVisible())
        self.assertFalse(p.rac_check.isChecked())
        QTest.mouseClick(p.rac_check, Qt.MouseButton.LeftButton, pos=p.rac_check.rect().center())
        self.assertTrue(p.rac_check.isChecked())
        QTest.keyClick(p.rac_check, Qt.Key.Key_Space)
        self.assertFalse(p.rac_check.isChecked())
        self.assertGreaterEqual(p.rac_check.sizeHint().width() - 4, p.rac_check.fontMetrics().horizontalAdvance(p.rac_check.text()))

    def test_report_name_is_editable_and_ids_no_longer_overwrite_a_custom_name(self):
        p = self.page
        self.load()
        self.assertTrue(p.name_edit.isEnabled() and not p.name_edit.isReadOnly())
        self.click(self.radio(0))
        self.click(self.radio(0, 1))
        self.assertEqual(p.name_edit.text(), "AWR_Report_9001_9002_<yyyymmdd_HHMMSS>")
        p.name_edit.selectAll()
        QTest.keyClicks(p.name_edit, "prod_peak-1")
        self.assertEqual(p.name_edit.text(), "prod_peak-1")
        self.click(self.radio(1))
        self.assertEqual(p.name_edit.text(), "prod_peak-1")
        self.assertTrue(p.generate_btn.isEnabled())

    def test_invalid_names_are_rejected_and_block_generation(self):
        p = self.page
        self.select()
        for bad in ("", "../x", "a/b", "a\\b", "C:evil", "a.b", "x.html", "my report", "a&b", "it's", "CON", "nul", "a" * 101,
                    "<yyyymmdd_HHMMSS>x<yyyymmdd_HHMMSS>"):
            p.name_edit.setText(bad)
            self.assertFalse(p.generate_btn.isEnabled(), repr(bad))
            self.assertEqual(p.name_edit.property("invalid"), "true", repr(bad))
            self.assertIn("Report Name", p.status.toPlainText(), repr(bad))
        for good in ("prod_1", "AWR-2026_10", "x_<yyyymmdd_HHMMSS>", "<yyyymmdd_HHMMSS>"):
            p.name_edit.setText(good)
            self.assertTrue(p.generate_btn.isEnabled(), good)
            self.assertEqual(p.name_edit.property("invalid"), "false", good)

    def test_selected_options_reach_the_generation_call(self):
        self.select()
        p = self.page
        ok = awr_service.AwrResult("report", False, message="stub")
        with mock.patch.object(awr_service, "generate_report", return_value=ok) as gen:
            self.generate()                                              # defaults: the legacy path
            self.assertEqual(gen.call_args.args[3:5], (9001, 9002))
            self.assertEqual(gen.call_args.args[6:], ("html", "AWR_Report_9001_9002_<yyyymmdd_HHMMSS>", False))
            p.type_combo.setCurrentIndex(1)
            p.name_edit.setText("peak_text")
            p.rac_check.setChecked(True)
            self.generate()
            self.assertEqual(gen.call_args.args[6:], ("text", "peak_text", True))
        self.assertEqual(p.status.toPlainText(), "stub")

    def test_custom_html_text_and_rac_reports_are_really_created(self):
        self.select()
        p = self.page
        folder = awr_service.report_folder(self.ctx)
        p.name_edit.setText("peak_html")
        self.generate()
        html = folder / "peak_html.html"
        self.assertTrue(html.is_file(), p.status.toPlainText())
        self.assertIn("<html", html.read_text(encoding="utf-8"))
        self.assertFalse(list(folder.glob("AWR_Report_*")))              # renamed, not copied
        p.type_combo.setCurrentIndex(1)
        p.name_edit.setText("peak_text")
        self.generate()
        text = folder / "peak_text.txt"
        self.assertTrue(text.is_file(), p.status.toPlainText())
        self.assertIn("WORKLOAD REPOSITORY", text.read_text(encoding="utf-8"))
        self.assertIn("single instance", text.read_text(encoding="utf-8"))
        p.rac_check.setChecked(True)
        p.name_edit.setText("peak_rac")
        self.generate()
        self.assertIn("RAC (all instances", (folder / "peak_rac.txt").read_text(encoding="utf-8"))
        self.assertEqual(sorted(p.hist.item(r, 3).text() for r in range(p.hist.rowCount())), ["peak_html.html", "peak_rac.txt", "peak_text.txt"])
        self.assertEqual(p.hist.item(0, 2).text(), "9001 - 9002")      # custom-named reports are in the history with their range and DB
        self.assertEqual(p.hist.item(0, 1).text(), "ims [SIM]")

    def test_an_existing_report_is_never_overwritten(self):
        self.select()
        p = self.page
        folder = awr_service.report_folder(self.ctx)
        folder.mkdir(parents=True, exist_ok=True)
        (folder / "taken.html").write_text("precious", encoding="utf-8")
        p.name_edit.setText("taken")
        self.assertFalse(p.generate_btn.isEnabled())
        self.assertIn("already exists", p.status.toPlainText())
        self.assertEqual((folder / "taken.html").read_text(encoding="utf-8"), "precious")
        p.type_combo.setCurrentIndex(1)                                  # another extension is another file
        self.assertTrue(p.generate_btn.isEnabled())

    def test_options_are_disabled_while_a_job_runs(self):
        self.select()
        os.environ["OHC_FAKE_DELAY"] = "1"
        self.page.generate_btn.click()
        self.settle()
        p = self.page
        self.assertFalse(p.type_combo.isEnabled() or p.name_edit.isEnabled() or p.rac_check.isEnabled())
        p.cancel_btn.click()
        self.assertTrue(wait_idle(self.win.gate))
        self.assertTrue(p.type_combo.isEnabled() and p.name_edit.isEnabled() and p.rac_check.isEnabled())

    def test_options_fit_the_panel(self):
        p = self.page
        self.win.resize(1200, 760)
        self.settle()
        for w in (p.type_combo, p.name_edit, p.rac_check, p.open_check, p.ext_label):
            r = QRect(w.mapTo(p, w.rect().topLeft()), w.size())
            self.assertTrue(QRect(0, 0, p.width(), p.height()).contains(r), w)
        self.assertGreaterEqual(p.name_edit.width(), 200)
        self.assertGreaterEqual(p.type_combo.width(), 120)


class ClickAndHover(Base):
    def setUp(self):
        super().setUp()
        self.load()

    def cell_pos(self, row, col):
        return self.page.table.visualRect(self.page.table.model().index(row, col)).center()

    def move_to(self, row, col):
        from PySide6.QtCore import QEvent, QPointF
        from PySide6.QtGui import QMouseEvent
        pos = QPointF(self.cell_pos(row, col))
        view = self.page.table.viewport()
        QApplication.sendEvent(view, QMouseEvent(QEvent.Type.MouseMove, pos, view.mapToGlobal(pos), Qt.MouseButton.NoButton,
                                                 Qt.MouseButton.NoButton, Qt.KeyboardModifier.NoModifier))
        self.settle()

    def click_cell(self, row, col):
        QTest.mouseClick(self.page.table.viewport(), Qt.MouseButton.LeftButton, pos=self.cell_pos(row, col))

    def test_clicking_a_timestamp_selects_that_snapshot_with_the_normal_begin_end_logic(self):
        p = self.page
        self.click_cell(0, 1)                                           # left time cell of 9001
        self.assertEqual((p.begin_edit.text(), p.end_edit.text(), p._target), ("9001", "", "end"))
        self.click_cell(0, 3)                                           # right time cell of 9002
        self.assertEqual((p.begin_edit.text(), p.end_edit.text(), p._target), ("9001", "9002", "end"))
        self.click_cell(1, 1)
        self.assertEqual((p.begin_edit.text(), p.end_edit.text()), ("9001", "9003"))
        self.assertEqual(self.radio(0).property("mark"), "begin")       # the radios follow, as for a radio click
        self.assertEqual(self.radio(1).property("mark"), "end")
        self.click(p.begin_edit)
        self.click_cell(2, 3)                                           # 9006 into the targeted Begin field
        self.assertEqual((p.begin_edit.text(), p.end_edit.text()), ("9006", "9003"))

    def test_clicking_the_snap_id_cell_away_from_the_dot_selects_too(self):
        p = self.page
        radio = self.radio(0, 1)
        QTest.mouseClick(radio, Qt.MouseButton.LeftButton, pos=radio.rect().center())
        self.assertEqual(p.begin_edit.text(), "9002")

    def test_cells_that_are_not_a_snapshot_do_nothing(self):
        p = self.page
        last = p.table.rowCount() - 1
        for row, col in ((last, 3), (0, 4), (0, 5)):                    # empty right cell of the odd row, Instance, Duration
            self.click_cell(row, col)
        self.assertEqual((p.begin_edit.text(), p.end_edit.text(), p._target), ("", "", "begin"))

    def test_hover_highlights_the_snapshot_and_shows_a_pointer(self):
        p, view = self.page, self.page.table.viewport()
        self.move_to(1, 1)
        self.assertEqual(p._hover, 9003)
        self.assertEqual(self.radio(1).property("hover"), "true")
        self.assertEqual(p.table.item(1, 1).background().style(), Qt.BrushStyle.SolidPattern)
        self.assertEqual(view.cursor().shape(), Qt.CursorShape.PointingHandCursor)
        self.move_to(1, 3)                                              # moves to the neighbour: the old one is released
        self.assertEqual(p._hover, 9004)
        self.assertEqual(self.radio(1).property("hover"), "false")
        self.assertEqual(p.table.item(1, 1).background().style(), Qt.BrushStyle.NoBrush)
        self.move_to(1, 4)                                              # Instance column: not a snapshot
        self.assertIsNone(p._hover)
        self.assertEqual(view.cursor().shape(), Qt.CursorShape.ArrowCursor)
        self.assertEqual(p.table.item(1, 3).background().style(), Qt.BrushStyle.NoBrush)

    def test_hovering_the_snap_id_cell_highlights_it_and_its_time(self):
        from PySide6.QtCore import QEvent
        p, radio = self.page, self.radio(2)
        QApplication.sendEvent(radio, QEvent(QEvent.Type.Enter))
        self.assertEqual((p._hover, radio.property("hover")), (9005, "true"))
        self.assertEqual(p.table.item(2, 1).background().style(), Qt.BrushStyle.SolidPattern)
        self.assertEqual(radio.cursor().shape(), Qt.CursorShape.PointingHandCursor)
        QApplication.sendEvent(radio, QEvent(QEvent.Type.Leave))
        self.assertIsNone(p._hover)
        self.assertEqual(radio.property("hover"), "false")

    def test_hover_never_hides_the_begin_and_end_colours(self):
        p = self.page
        self.click_cell(0, 1)
        self.click_cell(0, 3)
        before = (p.table.item(0, 1).background().color().name(), p.table.item(0, 3).background().color().name())
        self.move_to(0, 1)
        self.move_to(1, 1)
        self.assertEqual((p.table.item(0, 1).background().color().name(), p.table.item(0, 3).background().color().name()), before)
        self.assertEqual((self.radio(0).property("mark"), self.radio(0, 1).property("mark")), ("begin", "end"))


class Generation(Base):
    def select(self, b=0, e=1):
        self.click(self.radio(b))
        self.click(self.radio(e))

    def test_generate_adds_the_report_to_the_history_even_when_filters_hide_it(self):
        self.load()
        self.click(self.radio(0))
        self.click(self.radio(0, 1))
        self.page.search.setText("zzz-no-match")
        with mock.patch("ohc.gui.awr_page.QDesktopServices.openUrl") as opener:
            self.page.generate_btn.click()
            self.assertTrue(wait_idle(self.win.gate))
            opener.assert_not_called()                                  # "open after generation" is off by default
        p = self.page
        self.assertEqual(p.hist.rowCount(), 1)
        self.assertEqual(p.search.text(), "")
        self.assertIn("AWR report created", p.status.toPlainText())
        self.assertRegex(p.hist.item(0, 3).text(), r"^AWR_Report_9001_9002_\d{8}_\d{6}\.html$")
        self.assertEqual((p.hist.item(0, 1).text(), p.hist.item(0, 2).text()), ("ims [SIM]", "9001 - 9002"))
        self.assertTrue(Path(p.hist.item(0, 3).data(Qt.ItemDataRole.UserRole)).is_file())
        self.assertFalse(p.cancel_btn.isEnabled())

    def test_open_after_generation(self):
        self.load()
        self.click(self.radio(0))
        self.click(self.radio(0, 1))
        self.page.open_check.setChecked(True)
        with mock.patch("ohc.gui.awr_page.QDesktopServices.openUrl") as opener:
            self.page.generate_btn.click()
            wait_idle(self.win.gate)
        opener.assert_called_once()
        self.assertEqual(Path(opener.call_args.args[0].toLocalFile()), Path(self.page.hist.item(0, 3).data(Qt.ItemDataRole.UserRole)))

    def test_failure_is_reported_and_adds_nothing(self):
        self.load()
        self.page.begin_edit.setText("1")                 # unknown to the repository: allowed with a warning, Oracle rejects it
        self.page.end_edit.setText("2")
        self.assertTrue(self.page.generate_btn.isEnabled())
        self.page.generate_btn.click()
        wait_idle(self.win.gate)
        self.assertIn("ORA-20019", self.page.status.toPlainText())
        self.assertEqual(self.page._status_level, "bad")
        self.assertEqual(self.page.hist.rowCount(), 0)
        self.assertTrue(self.page.load_btn.isEnabled())

    def test_cancel_during_generation_removes_the_partial_file(self):
        self.load()
        self.click(self.radio(0))
        self.click(self.radio(0, 1))
        os.environ["OHC_FAKE_DELAY"] = "1"
        self.page.generate_btn.click()
        end = time.time() + 5
        while time.time() < end and not list((self.tmp / "reports").rglob("AWR_Report_*.html")):
            self.app.processEvents()
            time.sleep(0.01)
        self.page.cancel_btn.click()
        self.assertTrue(wait_idle(self.win.gate))
        self.assertEqual(list((self.tmp / "reports").rglob("AWR_Report_*.html")), [])
        self.assertIn("cancelled", self.page.status.toPlainText())
        self.assertEqual(self.page.hist.rowCount(), 0)
        self.assertTrue(self.page.generate_btn.isEnabled())       # the selection is kept: the user can simply try again


class History(Base):
    def make(self):
        self.files = {
            "a": self.report("2026-10-16/AWR_Report_9235_9236_20261016_012216.html", 100),
            "b": self.report("2026-10-14/AWR_Report_9230_9237_20261014_231025.html", 3 * 1024 * 1024),
            "c": self.report("2026-10-12/AWR_Report_9228_9231_20261012_000532.html", 5000),
            "d": self.report("12.10.2026/AWR_Report_9218_9226_20261010_210834.html", 7000),
            "e": self.report("2026-10-08/AWR_Report_9209_9217_20261008_194512.html", 9000),
        }
        self.report("2026-10-16/ims_health_20261016_010000.html")
        self.page.refresh_btn.click()

    def test_existing_reports_in_date_folders_are_discovered_newest_first(self):
        self.make()
        p = self.page
        self.assertEqual(p.hist.rowCount(), 5)
        self.assertEqual([p.hist.item(r, 3).text() for r in range(5)], [self.files[k].name for k in "abcde"])
        self.assertEqual(p.hist.item(0, 0).text(), "2026-10-16 01:22")
        self.assertEqual(p.hist.item(1, 4).text(), "3.0 MB")
        self.assertEqual(p.hist.item(1, 2).text(), "9230 - 9237")
        self.assertTrue(p.hist_note.isHidden())

    def test_every_row_opens_its_own_report_from_the_button_and_from_the_menu(self):
        self.make()
        p = self.page
        with mock.patch("ohc.gui.awr_page.QDesktopServices.openUrl") as opener:
            for row in range(p.hist.rowCount()):
                expected = Path(p.hist.item(row, 3).data(Qt.ItemDataRole.UserRole))
                holder = p.hist.cellWidget(row, 5)
                opener.reset_mock()
                holder.open_btn.click()
                self.assertEqual(Path(opener.call_args.args[0].toLocalFile()), expected, row)
                opener.reset_mock()
                holder.menu_btn.menu().actions()[0].trigger()            # "Open Report" in the row's menu
                self.assertEqual(Path(opener.call_args.args[0].toLocalFile()), expected, row)
            self.assertEqual({p.hist.cellWidget(r, 5).path for r in range(5)}, set(self.files.values()))
            holder = p.hist.cellWidget(2, 5)
            opener.reset_mock()
            holder.menu_btn.menu().actions()[1].trigger()                # "Open Containing Folder"
            self.assertEqual(Path(opener.call_args.args[0].toLocalFile()), self.files["c"].parent)

    def test_button_follows_its_file_after_the_list_is_filtered(self):
        self.make()
        p = self.page
        p.search.setText("9209")
        self.assertEqual(p.hist.rowCount(), 1)
        with mock.patch("ohc.gui.awr_page.QDesktopServices.openUrl") as opener:
            p.hist.cellWidget(0, 5).open_btn.click()
        self.assertEqual(Path(opener.call_args.args[0].toLocalFile()), self.files["e"])

    def test_date_filter_and_search(self):
        self.make()
        p = self.page
        self.assertEqual(p.date_combo.itemText(0), "All dates")
        self.assertEqual(p.date_combo.count(), 6)            # all + five different run dates
        p.date_combo.setCurrentIndex(p.date_combo.findData("2026-10-14"))
        self.assertEqual(p.hist.rowCount(), 1)
        p.date_combo.setCurrentIndex(0)
        p.search.setText("20261012")
        self.assertEqual(p.hist.rowCount(), 1)
        p.search.setText("nothing")
        self.assertEqual(p.hist.rowCount(), 0)
        self.assertIn("No reports match", p.hist_note.text())
        p.search.setText("")
        self.assertEqual(p.hist.rowCount(), 5)

    def test_missing_file_is_reported_not_opened(self):
        self.make()
        p = self.page
        self.files["a"].unlink()
        with mock.patch("ohc.gui.awr_page.QDesktopServices.openUrl") as opener:
            p.hist.cellWidget(0, 5).open_btn.click()
        opener.assert_not_called()
        self.assertIn("no longer exists", p.status.toPlainText())
        self.assertEqual(p.hist.rowCount(), 4)

    def test_history_refreshes_when_the_page_is_shown_again(self):
        self.win.nav.setCurrentRow(0)
        self.settle()
        self.report("2026-10-16/AWR_Report_1_2_20261016_000001.html")
        self.win.nav.setCurrentRow(ROW)
        self.settle()
        self.assertEqual(self.page.hist.rowCount(), 1)


class Layout(Base):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        # Segoe UI (Windows) has Arial-like widths; the sandbox default (DejaVu) is ~15% wider and would make text-fit checks meaningless
        from PySide6.QtGui import QFont, QFontDatabase
        cls._old_font = cls.app.font()
        for family in ("Segoe UI", "Arial", "Liberation Sans"):
            if family in QFontDatabase.families():
                cls.app.setFont(QFont(family, 9))
                break

    @classmethod
    def tearDownClass(cls):
        cls.app.setFont(cls._old_font)

    def prepare(self, w, h, theme):
        self.win.theme.set_theme(theme)
        self.win.resize(w, h)
        self.settle()
        self.load()
        self.click(self.radio(0))
        self.click(self.radio(0, 1))
        for i, (d, b, e) in enumerate((("2026-10-16", 9235, 9236), ("2026-10-14", 9230, 9237), ("2026-10-12", 9228, 9231),
                                       ("2026-10-10", 9218, 9226), ("2026-10-08", 9209, 9217), ("2026-10-06", 9100, 9101))):
            self.report(f"{d}/AWR_Report_{b}_{e}_{d.replace('-', '')}_0{i}2216.html", 8 * 1024 * 1024 // 4)
        self.page.refresh_btn.click()
        self.settle()
        self.settle()

    def check(self, w, h, theme, snap_rows, hist_rows):
        self.prepare(w, h, theme)
        p, tag = self.page, (w, h, theme)
        self.assertEqual((self.win.width(), self.win.height()), (w, h), tag)
        self.assertLessEqual(p.minimumSizeHint().width() + 300, 1200, tag)
        self.assertLessEqual(p.minimumSizeHint().height() + 60, 760, tag)
        self.assertLessEqual(p.minimumSizeHint().height(), p.height(), tag)
        self.assertEqual(p.findChildren(QScrollArea), [], tag)
        for wdg in p.findChildren(QWidget):                            # nothing sticks out of the page
            if wdg.isVisibleTo(p) and wdg.width() and wdg.height() and not wdg.visibleRegion().isEmpty():   # scrolled-out cell widgets excluded
                # only the visible part counts: a table's cell widget in a partly scrolled row is clipped by the table viewport
                vis = wdg.visibleRegion().boundingRect()
                r = wdg.mapTo(p, vis.topLeft())
                self.assertTrue(0 <= r.x() and r.x() + vis.width() <= p.width() + 1 and 0 <= r.y() and r.y() + vis.height() <= p.height() + 1,
                                (tag, wdg, wdg.parent(), r, vis.size()))
        # no horizontal scrollbars, several rows of each table visible together
        self.assertFalse(p.table.horizontalScrollBar().isVisible(), tag)
        self.assertFalse(p.hist.horizontalScrollBar().isVisible(), tag)
        self.assertGreaterEqual(p.table.viewport().height() // 24, snap_rows, tag)
        self.assertGreaterEqual(p.hist.viewport().height() // 30, hist_rows, tag)
        self.assertEqual(p.hist.rowCount(), 6, tag)
        # IDs and timestamps are never clipped
        fm = p.table.fontMetrics()
        for row in range(min(5, p.table.rowCount())):
            for col in (0, 2):
                self.assertLessEqual(p.table.cellWidget(row, col).sizeHint().width(), p.table.columnWidth(col), (tag, row, col))
            for col in (1, 3):
                item = p.table.item(row, col)
                self.assertLessEqual(fm.horizontalAdvance(item.text()) + 12, p.table.columnWidth(col), (tag, row, col, item.text()))
        # history: file names and the whole action cell are visible
        hfm = p.hist.fontMetrics()
        for row in range(p.hist.rowCount()):
            self.assertLessEqual(hfm.horizontalAdvance(p.hist.item(row, 3).text()) + 12, p.hist.columnWidth(3), (tag, row))
            holder = p.hist.cellWidget(row, 5)
            self.assertLessEqual(holder.open_btn.sizeHint().width() + holder.menu_btn.width() + 8, p.hist.columnWidth(5), (tag, row))
            self.assertGreaterEqual(p.hist.rowViewportPosition(row), 0)
        # no overlap between neighbours
        def box(wdg):
            return QRect(wdg.mapTo(p, wdg.rect().topLeft()), wdg.size())
        rows = ((p.days, p.load_btn, p.caption), (p.begin_edit, p.end_edit), (p.generate_btn, p.cancel_btn, p.status))
        for group in rows[:2]:
            for a, b in zip(group, group[1:]):
                self.assertFalse(box(a).intersects(box(b)), (tag, a, b))
        for a, b in zip(rows[2], rows[2][1:]):
            self.assertLessEqual(box(a).bottom(), box(b).top() + 1, (tag, a, b))
        self.assertLessEqual(box(p.table).bottom(), box(p.begin_edit).top(), tag)
        self.assertLessEqual(box(p.begin_edit).bottom(), box(p.range_msg).top() + 1, tag)
        self.assertLess(box(p.table).top(), box(p.hist).top(), tag)

    def test_1360x860_dark(self):
        self.check(1360, 860, "dark", snap_rows=5, hist_rows=5)

    def test_1360x860_light(self):
        self.check(1360, 860, "light", snap_rows=5, hist_rows=5)

    def test_1200x760_dark(self):
        self.check(1200, 760, "dark", snap_rows=4, hist_rows=3)

    def test_1200x760_light(self):
        self.check(1200, 760, "light", snap_rows=4, hist_rows=3)

    def test_partly_visible_history_rows_stay_inside_the_table_and_the_page(self):
        """Regression: the Actions cell widget of a half-visible row extends past the table viewport (clipped, not drawn)."""
        for theme in ("dark", "light"):
            self.prepare(1200, 760, theme)
            for i in range(10):
                self.report(f"2026-09-{i + 1:02d}/AWR_Report_1_2_202609{i + 1:02d}_000000.html")
            p = self.page
            p.refresh_btn.click()
            self.settle()
            view = p.hist.viewport()
            self.assertGreater(p.hist.rowCount(), p.hist.viewport().height() // 30 + 1, theme)      # more rows than fit
            self.assertEqual(p.findChildren(QScrollArea), [], theme)
            page_rect = QRect(0, 0, p.width(), p.height())
            self.assertTrue(page_rect.contains(QRect(p.hist.mapTo(p, p.hist.rect().topLeft()), p.hist.size())), theme)
            for row in range(p.hist.rowCount()):
                holder = p.hist.cellWidget(row, 5)
                vis = holder.visibleRegion().boundingRect()
                if not vis.isEmpty():
                    self.assertTrue(page_rect.contains(QRect(holder.mapTo(p, vis.topLeft()), vis.size())), (theme, row))
                    self.assertLessEqual(holder.mapTo(view, vis.bottomRight()).y(), view.height(), (theme, row))

    def test_long_status_does_not_grow_the_page(self):
        self.prepare(1200, 760, "dark")
        self.settle()                                  # the layout (incl. the hidden ASH tab) is fully polished before measuring
        before = (self.page.minimumSizeHint(), self.win.minimumSizeHint())
        self.page._set_status("bad", "x" * 400, "\n".join(f"ORA-{i:05d}: " + "long message " * 12 for i in range(6)))
        self.settle()
        self.assertEqual((self.page.minimumSizeHint(), self.win.minimumSizeHint()), before)
        self.assertEqual((self.win.width(), self.win.height()), (1200, 760))


if __name__ == "__main__":
    unittest.main()
