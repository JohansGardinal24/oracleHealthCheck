import os
import shutil
import tempfile
import time
import unittest
from datetime import datetime
from pathlib import Path

from ohc.checks import dg, engine
from ohc.checks.session import OracleSession, QueryTimeout, ToolError
from ohc.config import thresholds
from ohc.security.credstore import Credentials

TH = dict(thresholds.DEFAULTS)
OKLINE = "OK|fine"
CFG_OK = "Configuration - dg\n\n  Protection Mode: MaxPerformance\n  Members:\n  prim - Primary database\n    stby - Physical standby database\n\nConfiguration Status:\nSUCCESS   (status updated 3 seconds ago)\n"
SD_OK = "Database - stby\n  Transport Lag:      0 seconds (computed 0 seconds ago)\n  Apply Lag:          1 minute 5 seconds (computed 0 seconds ago)\nDatabase Status:\nSUCCESS\n"


class FakeSession:
    def __init__(self, v=None, svc="STATE : 4  RUNNING", info="OPEN|PRIMARY|READ WRITE|IMS|IMS", cfg=CFG_OK, sd=SD_OK):
        self.v, self.svc, self.info, self.cfg, self.sd, self.calls = v or {}, svc, info, cfg, sd, []

    def service_query(self, sid):
        return self.svc

    def sql(self, mode, name):
        self.calls.append((mode, name))
        if name == "v_db_info.sql":
            return self.info + "\n"
        if mode == "value":
            return self.v.get(name, OKLINE) + "\n"
        return f"output of {name}\n"

    def dgmgrl(self, commands):
        return self.cfg if commands[0] == "show configuration" else self.sd

    def server_spec(self, warn, crit):
        return "== CPU ==\nraw spec", "OK|Disk: highest 40% at C:"


class RunTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.lines = []

    def run_mode(self, mode, session, th=TH, now=datetime(2026, 10, 13, 9, 30, 5)):
        return engine.run_checks(mode, "IMS", "IMS", session, th, log_dir=self.tmp / "logs", report_base=self.tmp / "reports",
                                 emit=self.lines.append, now=now, hostname="HOST1")

    def ids(self, r):
        return [x.idx for x in r.results]

    def test_all_mode_runs_21_checks_in_order(self):
        r = self.run_mode("ALL", FakeSession())
        self.assertEqual(self.ids(r), list(range(21)))
        self.assertEqual((r.overall, r.exit_code), ("OK", 0))
        self.assertEqual(r.log_file.name, "ohc_IMS_20261013_093005.log")
        self.assertEqual(r.report_file, self.tmp / "reports" / "2026-10-13" / "IMS_health_20261013_093005.html")
        self.assertTrue(r.report_file.is_file() and r.log_file.is_file())
        self.assertIn("DR SYNC", " ".join(x.name for x in r.results))

    def test_option_subsets(self):
        self.assertEqual(self.ids(self.run_mode("SQL", FakeSession())), [0, 2, 3, 6, 7] + list(range(9, 21)))
        self.assertEqual(self.ids(self.run_mode("DG", FakeSession(), now=datetime(2026, 10, 13, 9, 31, 0))), [1, 4, 5, 8])

    def test_db_not_running(self):
        s = FakeSession(svc="STATE : 1  STOPPED")
        r = self.run_mode("SQL", s)
        by = {x.idx: x for x in r.results}
        self.assertEqual((by[0].status, by[0].message), ("CRITICAL", "Instance not running"))
        self.assertEqual(self.ids(r), [0, 2] + [3, 6, 7] + list(range(9, 21)))
        self.assertTrue(all(by[i].status == "SKIPPED" for i in [3, 6, 7, 9, 20]))
        self.assertEqual(r.exit_code, 2)
        r = self.run_mode("ALL", s, now=datetime(2026, 10, 13, 9, 31, 0))
        self.assertEqual(self.ids(r), list(range(21)))
        self.assertEqual({x.idx: x.status for x in r.results}[1], "SKIPPED")

    def test_warning_and_failure_statuses(self):
        s = FakeSession(v={"v_locks.sql": "WARNING|1 blocker", "v_sys.sql": "ORA-00942: table or view does not exist",
                           "v_dbfiles.sql": "garbage"})
        r = self.run_mode("SQL", s)
        by = {x.idx: x for x in r.results}
        self.assertEqual(by[10].status, "WARNING")
        self.assertEqual((by[6].status, by[6].message), ("WARNING", "Query failed: ORA-00942: table or view does not exist"))
        self.assertEqual((by[7].status, by[7].message), ("CRITICAL", "Query failed: garbage"))
        self.assertEqual(r.exit_code, 2)

    def test_tablespace_combines_and_mounted_skip(self):
        r = self.run_mode("SQL", FakeSession(v={"v_tbs.sql": "OK|tbs ok", "v_temp_hist.sql": "WARNING|temp high"}))
        t = [x for x in r.results if x.idx == 3][0]
        self.assertEqual((t.status, t.message), ("WARNING", "tbs ok; temp high"))
        r = self.run_mode("SQL", FakeSession(info="MOUNTED|PHYSICAL STANDBY|MOUNTED|STBY|STBY"), now=datetime(2026, 10, 13, 9, 32, 0))
        by = {x.idx: x for x in r.results}
        self.assertEqual((by[0].status, by[3].status, by[3].message), ("OK", "SKIPPED", "DB not open"))

    def test_db_status_rules(self):
        for info, want in (("OPEN|PRIMARY|READ ONLY|A|A", "CRITICAL"), ("OPEN|PHYSICAL STANDBY|READ ONLY WITH APPLY|A|A", "OK"),
                           ("OPEN|SOMETHING|READ WRITE|A|A", "WARNING")):
            r = self.run_mode("SQL", FakeSession(info=info), now=datetime(2026, 10, 13, 9, 40, 0))
            self.assertEqual(r.results[0].status, want, info)

    def test_cannot_connect(self):
        r = self.run_mode("SQL", FakeSession(info="ORA-01017: invalid username/password; logon denied"))
        self.assertEqual(r.results[0].status, "CRITICAL")
        self.assertIn("ORA-01017", r.results[0].message)

    def test_report_and_log_content(self):
        r = self.run_mode("ALL", FakeSession(v={"v_rman.sql": "WARNING|<b>x</b>"}))
        page = r.report_file.read_text(encoding="utf-8")
        self.assertIn("&lt;b&gt;x&lt;/b&gt;", page)
        self.assertIn('<a href="#chk9">RMAN BACKUP STATUS</a>', page)
        log = r.log_file.read_bytes().decode("utf-8")
        self.assertIn("----- [1] DB STATUS -----\r\n", log)
        self.assertIn(">> [9] RMAN BACKUP STATUS : WARNING  -  <b>x</b>\r\n", log)
        self.assertTrue(log.rstrip().endswith("Report: " + str(r.report_file)))
        self.assertEqual(self.lines[-3:-1], [f" Log   : {r.log_file}", f" Report: {r.report_file}"])

    def test_timeout_is_a_failed_check_not_a_skip(self):
        class Slow(FakeSession):
            def sql(self, mode, name):
                if name == "v_fra.sql":
                    raise QueryTimeout("sqlplus did not finish within 1 seconds")
                return super().sql(mode, name)
        r = self.run_mode("ALL", Slow())
        fra = [x for x in r.results if x.idx == 4][0]
        self.assertEqual(fra.status, "CRITICAL")
        self.assertIn("timed out", fra.message)

    def test_cleanup_retention(self):
        logs, reports = self.tmp / "logs", self.tmp / "reports"
        (reports / "old").mkdir(parents=True)
        (reports / "new").mkdir()
        logs.mkdir()
        old_log, new_log, other = logs / "ohc_a.log", logs / "ohc_b.log", logs / "keep.txt"
        for f in (old_log, new_log, other):
            f.write_text("x")
        past = time.time() - 40 * 86400
        for p in (old_log, other, reports / "old"):
            os.utime(p, (past, past))
        self.assertEqual(engine.cleanup(logs, reports, 30), [])
        self.assertEqual((old_log.exists(), new_log.exists(), other.exists()), (False, True, True))
        self.assertEqual(((reports / "old").exists(), (reports / "new").exists()), (False, True))

    def test_dotnet_date_format(self):
        d = datetime(2026, 3, 7)
        self.assertEqual(engine.format_dotnet_date(d, "yyyy-MM-dd"), "2026-03-07")
        self.assertEqual(engine.format_dotnet_date(d, "dd.MM.yy"), "07.03.26")
        self.assertEqual(engine.format_dotnet_date(d, "d_M_yyyy"), "7_3_2026")

    def test_probe(self):
        self.assertEqual(engine.probe_database(FakeSession(), "IMS").kind, "OK")
        self.assertEqual(engine.probe_database(FakeSession(svc="FAILED 1060"), "IMS").kind, "NOTFOUND")
        self.assertEqual(engine.probe_database(FakeSession(svc="STOPPED"), "IMS").kind, "DOWN")
        self.assertEqual(engine.probe_database(FakeSession(info="ORA-01017: invalid username"), "IMS").kind, "LOGIN")
        self.assertEqual(engine.probe_database(FakeSession(info="ORA-12541: TNS:no listener"), "IMS").kind, "OTHER")


class DgTests(unittest.TestCase):
    def test_lag_seconds(self):
        self.assertEqual(dg.lag_seconds("1 day 2 hours 3 minutes 4 seconds"), 93784)
        self.assertEqual(dg.lag_seconds("0 seconds"), 0)
        self.assertEqual(dg.lag_seconds("(unknown)"), -1)
        self.assertEqual(dg.lag_seconds(""), -1)

    def run_dg(self, cfg, sd=SD_OK):
        return dg.dr_sync(lambda c: cfg if c[0] == "show configuration" else sd, 120, 600)[1]

    def test_ok_warning_critical(self):
        self.assertEqual(self.run_dg(CFG_OK), "OK|Config SUCCESS; stby: transport 0s, apply 65s")
        self.assertTrue(self.run_dg(CFG_OK, SD_OK.replace("1 minute 5 seconds", "3 minutes")).startswith("WARNING|"))
        self.assertTrue(self.run_dg(CFG_OK, SD_OK.replace("1 minute 5 seconds", "11 minutes")).startswith("CRITICAL|"))
        self.assertTrue(self.run_dg(CFG_OK, SD_OK.replace("SUCCESS", "ERROR")).startswith("CRITICAL|"))
        self.assertTrue(self.run_dg(CFG_OK.replace("SUCCESS", "WARNING")).startswith("CRITICAL|"))

    def test_broker_problems(self):
        self.assertTrue(self.run_dg("ORA-16532: Oracle Data Guard broker configuration does not exist").startswith("WARNING|"))
        self.assertTrue(self.run_dg("DGM-17016: failed\nORA-12514").startswith("CRITICAL|Cannot read broker status: DGM-17016"))
        self.assertTrue(self.run_dg("Configuration Status:\nSUCCESS\n").startswith("WARNING|Config status SUCCESS, but no standby"))

    def test_dgmgrl_cannot_run(self):
        def boom(cmds):
            raise ToolError("not found")
        self.assertTrue(dg.dr_sync(boom, 120, 600)[1].startswith("CRITICAL|Cannot run dgmgrl"))


class FakeProc:
    seen = []

    def __init__(self, argv, **kw):
        FakeProc.seen.append((argv, kw))

    def communicate(self, data=None, timeout=None):
        FakeProc.seen[-1] += (bytes(data or b""),)
        return b"OK|from fake\r\n", None


class SessionTests(unittest.TestCase):
    def setUp(self):
        self.home = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.home, True)
        (self.home / "bin").mkdir()
        for n in ("sqlplus", "dgmgrl"):
            (self.home / "bin" / (n + engine_exe())).write_text("")
        FakeProc.seen = []

    def make(self, pw=b"S3cret!pw", **kw):
        return OracleSession(self.home, "IMS", Credentials(bytearray(b"sys"), bytearray(pw)), [("TBS_WARN", 70)], popen=FakeProc, **kw)

    def test_password_only_on_stdin_and_run_dir_removed(self):
        s = self.make(dg_service="IMS_DG", nls_lang="AMERICAN_AMERICA.WE8MSWIN1252")
        run_dir = s.run_dir
        self.assertEqual(s.sql("value", "v_tbs.sql"), "OK|from fake\r\n")
        s.dgmgrl(["show configuration", "exit"])
        for entry in FakeProc.seen:
            argv, kw, stdin = entry
            self.assertNotIn("S3cret!pw", " ".join(argv))
            self.assertIn(b"S3cret!pw", stdin)
            self.assertEqual(kw["env"]["ORACLE_SID"], "IMS")
            self.assertEqual(kw["env"]["NLS_LANG"], "AMERICAN_AMERICA.WE8MSWIN1252")
        sql_in = FakeProc.seen[0][2].decode()
        self.assertIn('connect sys/"S3cret!pw" as sysdba', sql_in)
        self.assertIn("define TBS_WARN=70", sql_in)
        self.assertTrue(sql_in.rstrip().endswith("exit"))
        self.assertIn('connect sys/"S3cret!pw"@IMS_DG', FakeProc.seen[1][2].decode())
        self.assertTrue((run_dir / "v_tbs.sql").is_file())
        self.assertFalse(any(b"S3cret" in p.read_bytes() for p in run_dir.iterdir()))
        s.close()
        self.assertFalse(run_dir.exists())

    def test_rejects_unusable_password(self):
        with self.assertRaises(ToolError):
            self.make(pw=b'bad"pw')

    def test_missing_sqlplus(self):
        (self.home / "bin" / ("sqlplus" + engine_exe())).unlink()
        s = self.make()
        self.addCleanup(s.close)
        with self.assertRaises(ToolError):
            s.sql("value", "v_tbs.sql")


def engine_exe():
    from ohc.checks.session import EXE
    return EXE


if __name__ == "__main__":
    unittest.main()
