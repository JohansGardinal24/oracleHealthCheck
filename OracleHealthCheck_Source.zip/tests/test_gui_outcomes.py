import os
import unittest
from pathlib import Path
from unittest import mock

from ohc.checks import fake
from ohc.checks.engine import ProbeResult, RunResult
from ohc.checks.session import ToolError
from ohc.gui import outcomes


def result(overall, code):
    return RunResult("ALL", "ims", overall, code, [], Path("a.log"), Path("a.html"), "2026-10-13 10:00:00")


class OutcomeTests(unittest.TestCase):
    def test_run_levels_and_text(self):
        for overall, code, level in (("OK", 0, "ok"), ("WARNING", 1, "warn"), ("CRITICAL", 2, "bad")):
            o = outcomes.for_run(result(overall, code))
            self.assertEqual((o.level, o.text()), (level, f"OVERALL: {overall} (exit code {code})"))
        self.assertTrue(outcomes.for_run(result("WARNING", 1), fake=True).text().startswith("SIMULATED DATA - OVERALL: WARNING"))

    def test_probe(self):
        self.assertEqual(outcomes.for_probe(ProbeResult("OK", "CONNECTED")).level, "ok")
        o = outcomes.for_probe(ProbeResult("LOGIN", "LOGIN FAILED", "ORA-01017"), fake=True)
        self.assertEqual((o.level, o.exit_code, o.detail), ("bad", None, "ORA-01017"))
        self.assertEqual(o.text(), "SIMULATED DATA - LOGIN: LOGIN FAILED")

    def test_errors(self):
        o = outcomes.for_error(ToolError("Oracle Home is not configured"))
        self.assertEqual((o.level, o.exit_code, o.headline), ("bad", 3, "TOOL / CONFIGURATION ERROR"))
        self.assertEqual(o.detail, "Oracle Home is not configured")
        self.assertIn("Unexpected error", outcomes.for_error(RuntimeError("x")).detail)

    def test_fake_status(self):
        with mock.patch.dict(os.environ):
            os.environ.pop("OHC_FAKE_ORACLE", None)
            self.assertEqual(outcomes.fake_status(), ("", ""))
            os.environ["OHC_FAKE_ORACLE"] = "critical"
            text, level = outcomes.fake_status()
            self.assertEqual(level, "warn")
            self.assertIn("FAKE / SIMULATED DATA", text)
            os.environ["OHC_FAKE_ORACLE"] = "nonsense"
            self.assertEqual(outcomes.fake_status()[1], "bad")

    def test_fake_data_guard_output_is_labelled(self):
        s = fake.FakeOracleSession("healthy", "ims")
        for cmd in ("show configuration", "show database stby"):
            self.assertIn("[FAKE / SIMULATED]", s.dgmgrl([cmd, "exit"]))


if __name__ == "__main__":
    unittest.main()
