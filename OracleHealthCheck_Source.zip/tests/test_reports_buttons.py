"""Reports & Logs: the buttons inside table rows must show their full text (no vertical clipping) in both themes."""
import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if sys.platform == "win32":
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

import shutil
import tempfile
import unittest
from pathlib import Path

from PySide6.QtWidgets import QApplication, QPushButton

from ohc.gui.main_window import MainWindow
from tests.test_gui_run import make_ctx
from tests.test_reports_page import make_runs, wait_for


class ButtonClippingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        ctx = make_ctx(self.tmp)
        make_runs(self.tmp)
        self.win = MainWindow(ctx)
        self.addCleanup(self.win.deleteLater)
        self.win.show()
        row = [self.win.nav.item(i).text() for i in range(self.win.nav.count())].index("Reports & Logs")
        self.win.nav.setCurrentRow(row)
        self.page = self.win.pages.currentWidget()
        self.assertTrue(wait_for(lambda: not self.page.scanning and self.page._scans))
        self.addCleanup(self.page.shutdown)

    def cells(self):
        for table, col in ((self.page.reports_table, 5), (self.page.logs_table, 4)):
            for r in range(table.rowCount()):
                yield table, r, table.cellWidget(r, col)

    def test_button_text_fits_inside_every_button_and_row_in_both_themes(self):
        for theme in ("light", "dark"):
            self.win.theme.set_theme(theme)
            for size in ((1200, 760), (1360, 860)):
                self.win.resize(*size)
                self.app.processEvents()
                seen = 0
                for table, r, cell in self.cells():
                    for btn in cell.findChildren(QPushButton):
                        seen += 1
                        need = btn.fontMetrics().height() + 8  # the text plus a little breathing room
                        self.assertGreaterEqual(btn.height(), need, (theme, size, btn.text(), btn.height(), need))
                        self.assertGreaterEqual(btn.height(), btn.sizeHint().height(), (theme, btn.text()))  # not squeezed below its own hint
                        self.assertLessEqual(btn.geometry().bottom(), cell.height() - 1, (theme, btn.text()))
                        # vertically centred in the row (the dropdown arrow included)
                        self.assertLessEqual(abs(btn.geometry().center().y() - cell.height() // 2), 1, (theme, btn.text()))
                self.assertGreaterEqual(seen, 15, theme)  # 5 reports + 5 logs x 2 buttons

    def test_widths_and_actions_are_unchanged(self):
        table = self.page.reports_table
        self.assertEqual([table.columnWidth(c) for c in (0, 1, 2, 4, 5)], [150, 110, 90, 80, 150])
        logs = self.page.logs_table
        self.assertEqual([logs.columnWidth(c) for c in (0, 1, 3, 4)], [150, 110, 80, 190])
        self.assertEqual([b.text() for b in logs.cellWidget(0, 4).findChildren(QPushButton)], ["View Log", "\u25BE"])
        self.assertEqual([b.text() for b in table.cellWidget(0, 5).findChildren(QPushButton)], ["Open Report"])


if __name__ == "__main__":
    unittest.main()
