"""Smoke tests: paths, the --selftest / --verify-sql switches and the main window.

Run from the project root:
    python -m unittest discover -s tests -t . -v
"""
import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")  # no visible window during tests

import contextlib
import io
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from ohc import app, paths


class PathsTests(unittest.TestCase):
    def test_dev_mode_root_is_dev_home(self):
        with mock.patch.dict(os.environ):
            os.environ.pop("OHC_DEV_HOME", None)
            self.assertFalse(paths.is_frozen())
            self.assertEqual(paths.app_root().name, "dev_home")

    def test_dev_override_via_environment_variable(self):
        with tempfile.TemporaryDirectory() as d, mock.patch.dict(os.environ, {"OHC_DEV_HOME": d}):
            self.assertEqual(paths.app_root(), Path(d).resolve())

    def test_frozen_root_is_exe_folder_and_override_is_ignored(self):
        with tempfile.TemporaryDirectory() as d:
            exe = Path(d) / "OracleHealthCheck.exe"
            with mock.patch.object(sys, "frozen", True, create=True), \
                 mock.patch.object(sys, "executable", str(exe)), \
                 mock.patch.dict(os.environ, {"OHC_DEV_HOME": "X:\\somewhere\\else"}):
                self.assertTrue(paths.is_frozen())
                self.assertEqual(paths.app_root(), Path(d).resolve())


class SelfTestTests(unittest.TestCase):
    def _main(self, args):
        with contextlib.redirect_stdout(io.StringIO()):
            return app.main(args)

    def test_selftest_without_qt_is_ok(self):
        ok, lines = app.selftest(check_qt=False)
        self.assertTrue(ok)
        self.assertTrue(any(l.startswith("SQL bundle OK: ") for l in lines))
        self.assertEqual(lines[-1], "RESULT: OK")

    def test_verify_sql_only_output(self):
        ok, lines = app.selftest(sql_only=True)
        self.assertTrue(ok)
        self.assertEqual(len(lines), 2)

    def test_selftest_switch_writes_out_file_and_checks_qt(self):
        with tempfile.TemporaryDirectory() as d:
            out = Path(d) / "self.txt"
            self.assertEqual(self._main(["--selftest", "--out", str(out)]), 0)
            text = out.read_text(encoding="utf-8")
            self.assertIn("platform plugin:", text)
            self.assertIn("RESULT: OK", text)

    def test_verify_sql_switch_reports_failure_with_exit_code_1(self):
        with mock.patch("ohc.resources.sql_access.verify", return_value=["a.sql: tampered"]):
            ok, lines = app.selftest(sql_only=True)
            self.assertFalse(ok)
            self.assertEqual(lines[-1], "RESULT: FAILED")
            self.assertEqual(self._main(["--verify-sql"]), 1)

    def test_bad_arguments_return_2(self):
        for args in (["--bogus"], ["--out"], ["--out", "x.txt"], ["--selftest", "--verify-sql"]):
            self.assertEqual(self._main(args), 2, args)


class MainWindowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from PySide6.QtWidgets import QApplication

        cls.qapp = QApplication.instance() or QApplication([])

    def test_seven_pages_in_the_expected_order(self):
        from ohc.gui.main_window import MainWindow

        w = MainWindow()
        names = [w.nav.item(i).text() for i in range(w.nav.count())]
        self.assertEqual(names, ["Dashboard", "1. Oracle Health Check", "2. Sync Check",
                                 "3. All Checks", "4. Database Reports", "Reports & Logs", "Settings"])
        self.assertEqual(w.pages.count(), 7)

    def test_selecting_a_nav_item_switches_the_page(self):
        from ohc.gui.main_window import MainWindow

        w = MainWindow()
        self.assertEqual(w.pages.currentIndex(), 0)
        w.nav.setCurrentRow(6)
        self.assertEqual(w.pages.currentIndex(), 6)


if __name__ == "__main__":
    unittest.main()