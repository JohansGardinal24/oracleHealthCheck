"""DPAPI wrapper tests. Real encryption runs only on Windows; validation and source checks run anywhere."""
import ast
import sys
import unittest
from pathlib import Path

from ohc.security import dpapi
from ohc.security.dpapi import DpapiError, DpapiUnavailableError

SECRET = b"S3cret-P@ss\x00\xff-marker-98765"
ENTROPY = b"OHC-test-entropy|0123456789abcdef"
SOURCE = Path(dpapi.__file__).read_text(encoding="utf-8")


class ValidationAndSource(unittest.TestCase):
    def test_argument_validation_happens_before_any_platform_check(self):
        for bad in ("text", None, 123):
            with self.assertRaises(TypeError):
                dpapi.protect(bad)
            with self.assertRaises(TypeError):
                dpapi.unprotect(bad)
        with self.assertRaises(TypeError):
            dpapi.protect(b"x", "entropy")
        for empty in (b"", bytearray()):
            with self.assertRaises(ValueError):
                dpapi.protect(empty)
            with self.assertRaises(ValueError):
                dpapi.unprotect(empty)

    def test_code_does_not_use_powershell_subprocess_or_machine_scope(self):
        tree = ast.parse(SOURCE)
        imported = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imported |= {a.name.split(".")[0] for a in node.names}
            elif isinstance(node, ast.ImportFrom):
                imported.add((node.module or "").split(".")[0])
        self.assertTrue({"subprocess", "os"}.isdisjoint(imported), imported)
        docstring = ast.get_docstring(tree, clean=False)
        strings = [n.value.lower() for n in ast.walk(tree)
                   if isinstance(n, ast.Constant) and isinstance(n.value, str) and n.value != docstring]
        for forbidden in ("powershell", "local_machine", "cmd.exe"):
            self.assertFalse(any(forbidden in t for t in strings), forbidden)

    def test_ui_is_forbidden(self):
        self.assertEqual(dpapi._UI_FORBIDDEN, 1)

    def test_wipe_zeroes_in_place(self):
        buf = bytearray(b"secret")
        same = buf
        dpapi.wipe(buf)
        self.assertIs(buf, same)
        self.assertEqual(bytes(buf), bytes(6))

    def test_error_text_contains_only_operation_and_code(self):
        err = DpapiError("unprotect", 13)
        self.assertEqual(str(err), "DPAPI unprotect failed (Win32 error 13)")
        self.assertEqual((err.operation, err.code), ("unprotect", 13))

    @unittest.skipIf(sys.platform == "win32", "non-Windows behaviour")
    def test_non_windows_reports_unavailable(self):
        with self.assertRaises(DpapiUnavailableError):
            dpapi.protect(b"x")
        with self.assertRaises(DpapiUnavailableError):
            dpapi.unprotect(b"x")


@unittest.skipUnless(sys.platform == "win32", "needs Windows DPAPI")
class RealWindowsDpapi(unittest.TestCase):
    def test_round_trip_without_entropy(self):
        blob = dpapi.protect(SECRET)
        self.assertIsInstance(blob, bytes)
        self.assertNotIn(SECRET, blob)
        out = dpapi.unprotect(blob)
        self.assertIsInstance(out, bytearray)
        self.assertEqual(bytes(out), SECRET)

    def test_round_trip_with_entropy_and_bytearray_input_is_not_modified(self):
        data = bytearray(SECRET)
        blob = dpapi.protect(data, ENTROPY)
        self.assertEqual(bytes(data), SECRET, "protect() must not change its input")
        self.assertEqual(bytes(dpapi.unprotect(blob, ENTROPY)), SECRET)

    def test_wrong_or_missing_entropy_fails(self):
        blob = dpapi.protect(SECRET, ENTROPY)
        for wrong in (b"other-entropy", b"", ENTROPY + b"x"):
            with self.assertRaises(DpapiError) as cm:
                dpapi.unprotect(blob, wrong)
            self.assertEqual(cm.exception.operation, "unprotect")
            self.assertIsInstance(cm.exception.code, int)
            self.assertNotIn(SECRET.decode("latin-1"), str(cm.exception))

    def test_entropy_is_required_when_it_was_used_and_vice_versa(self):
        with self.assertRaises(DpapiError):
            dpapi.unprotect(dpapi.protect(SECRET), ENTROPY)

    def test_truncated_and_modified_blobs_fail(self):
        blob = dpapi.protect(SECRET, ENTROPY)
        flipped_last = blob[:-1] + bytes([blob[-1] ^ 0xFF])
        for bad in (blob[:-1], blob[:10], blob[:1], flipped_last, b"\x00" * len(blob), b"not a blob at all"):
            with self.assertRaises(DpapiError):
                dpapi.unprotect(bad, ENTROPY)

    def test_each_protect_call_produces_a_different_blob(self):
        self.assertNotEqual(dpapi.protect(SECRET), dpapi.protect(SECRET))

    def test_binary_and_large_payloads(self):
        for data in (bytes(range(256)) * 4, b"\x00" * 64, b"x" * 200_000):
            self.assertEqual(bytes(dpapi.unprotect(dpapi.protect(data, ENTROPY), ENTROPY)), data)

    def test_returned_plaintext_can_be_wiped(self):
        out = dpapi.unprotect(dpapi.protect(SECRET))
        dpapi.wipe(out)
        self.assertEqual(bytes(out), bytes(len(SECRET)))


if __name__ == "__main__":
    unittest.main()