"""Run pages, Test Connection and the background worker (Qt offscreen; the engine is replaced by fakes)."""
import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

from PySide6.QtGui import QCloseEvent
from PySide6.QtWidgets import QApplication

from ohc.checks.engine import CheckResult, ProbeResult, RunResult
from ohc.checks.session import ToolError
from ohc.config.databases import DatabaseEntry, DatabaseStore
from ohc.config.settings import SettingsStore
from ohc.gui.context import AppContext
from ohc.gui.main_window import MainWindow
from ohc.gui.run_page import STATUS_ROLE
from ohc.gui.run_page import RunPage
from ohc.security import credstore
from tests.test_credstore import FakeBackend


def make_ctx(root: Path, with_db=True) -> AppContext:
    user = root / "user" / "me"
    ctx = AppContext(root, SettingsStore(user / "settings.json"), DatabaseStore(user / "databases.json"), user / "credentials",
                     root / "config" / "environment.json", root / "config" / "thresholds.json", backend=FakeBackend())
    if with_db:
        ctx.databases.add(DatabaseEntry(id=credstore.new_database_id(), name="ims"))
    return ctx


def wait_idle(gate, timeout=10.0) -> bool:
    end = time.time() + timeout
    while gate.busy and time.time() < end:
        QApplication.processEvents()
        time.sleep(0.01)
    QApplication.processEvents()
    return not gate.busy


def run_result(overall="WARNING", code=1):
    return RunResult("ALL", "ims", overall, code, [], Path("a.log"), Path("a.html"), "2026-10-13 10:00:00")


class GuiRunTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        env = mock.patch.dict(os.environ)
        env.start()
        self.addCleanup(env.stop)
        os.environ.pop("OHC_FAKE_ORACLE", None)
        self.ctx = make_ctx(Path(self._tmp.name))
        self.win = MainWindow(self.ctx)
        self.addCleanup(self.win.deleteLater)

    def page(self, row) -> RunPage:
        return self.win.pages.widget(row)

    def test_run_pages_replace_the_placeholders(self):
        self.assertEqual([self.page(r).option for r in (1, 2, 3)], ["1", "2", "3"])
        self.assertTrue(all(isinstance(self.page(r), RunPage) for r in (1, 2, 3)))

    def test_navigation_alone_runs_nothing(self):
        with mock.patch("ohc.checks.launcher.run_option") as run, mock.patch("ohc.checks.launcher.test_connection") as test:
            for row in range(7):
                self.win.nav.setCurrentRow(row)
                QApplication.processEvents()
            run.assert_not_called()
            test.assert_not_called()

    def test_run_shows_progress_and_final_status(self):
        def fake_run(ctx, name, option, emit, on_event=None, cancel=None):
            on_event(("plan", [(0, "DB STATUS"), (1, "DR SYNC")]))
            on_event(("start", 0, "DB STATUS"))
            on_event(("done", CheckResult(0, "DB STATUS", "OK", "fine", 1.5, "raw output")))
            return run_result("WARNING", 1)
        with mock.patch("ohc.checks.launcher.run_option", side_effect=fake_run) as run:
            page = self.page(2)
            page.run_btn.click()
            self.assertTrue(wait_idle(self.win.gate))
        self.assertEqual(run.call_args.args[1:3], ("ims", "2"))
        self.assertEqual(page.table.item(0, 2).data(STATUS_ROLE), "OK")
        self.assertEqual(page.table.item(0, 3).text(), "fine")
        self.assertEqual(page.status.text(), "OVERALL: WARNING (exit code 1)")
        self.assertEqual(page.status.objectName(), "warn")
        self.assertEqual(page.table.rowCount(), 2)
        self.assertEqual(page.progress.value(), 1)
        self.assertTrue(page.run_btn.isEnabled())

    def test_tool_error_is_shown_not_hidden(self):
        with mock.patch("ohc.checks.launcher.run_option", side_effect=ToolError("Oracle Home is not configured")):
            page = self.page(1)
            page.run_btn.click()
            self.assertTrue(wait_idle(self.win.gate))
        self.assertEqual(page.status.text().splitlines()[0], "TOOL / CONFIGURATION ERROR (exit code 3)")  # the reason is on the next line
        self.assertEqual(page.status.objectName(), "bad")
        self.assertIn("Oracle Home is not configured", page.status.text())

    def test_unexpected_exception_does_not_crash(self):
        with mock.patch("ohc.checks.launcher.run_option", side_effect=RuntimeError("boom")):
            page = self.page(3)
            page.run_btn.click()
            self.assertTrue(wait_idle(self.win.gate))
        self.assertIn("Unexpected error", page.status.text())
        self.assertTrue(page.run_btn.isEnabled())

    def test_busy_state_disables_everything_and_blocks_closing(self):
        release = threading.Event()

        def slow(ctx, name, option, emit, on_event=None, cancel=None):
            emit("started")
            release.wait(10)
            return run_result("OK", 0)
        with mock.patch("ohc.checks.launcher.run_option", side_effect=slow):
            self.page(1).run_btn.click()
            self.assertTrue(self.win.gate.busy)
            self.assertFalse(any(self.page(r).run_btn.isEnabled() for r in (1, 2, 3)))
            self.assertFalse(self.win.settings_page.test_btn.isEnabled())
            event = QCloseEvent()
            with mock.patch("ohc.gui.main_window.QMessageBox.information") as info:
                self.win.closeEvent(event)
            info.assert_called_once()
            self.assertFalse(event.isAccepted())
            release.set()
            self.assertTrue(wait_idle(self.win.gate))
        self.assertTrue(all(self.page(r).run_btn.isEnabled() for r in (1, 2, 3)))
        again = QCloseEvent()
        self.win.closeEvent(again)
        self.assertTrue(again.isAccepted())

    def test_fake_indicator(self):
        self.assertTrue(self.win.fake_banner.isHidden())
        os.environ["OHC_FAKE_ORACLE"] = "warning"
        win = MainWindow(self.ctx)
        self.addCleanup(win.deleteLater)
        self.assertFalse(win.fake_banner.isHidden())
        self.assertIn("FAKE / SIMULATED DATA", win.fake_banner.text())
        with mock.patch("ohc.checks.launcher.run_option", return_value=run_result("WARNING", 1)):
            page = win.pages.widget(3)
            page.run_btn.click()
            self.assertTrue(wait_idle(win.gate))
        self.assertTrue(page.status.text().startswith("SIMULATED DATA - OVERALL: WARNING"))
        self.assertFalse(hasattr(page, "fake_label"))  # one banner only: the window's

    def test_invalid_fake_variable_blocks_the_run(self):
        os.environ["OHC_FAKE_ORACLE"] = "nonsense"
        with mock.patch("ohc.checks.launcher.run_option") as run:
            page = self.page(1)
            page.run_btn.click()
            QApplication.processEvents()
            run.assert_not_called()
        self.assertEqual(page.status.objectName(), "bad")

    def test_no_database_disables_run(self):
        with tempfile.TemporaryDirectory() as other:
            page = RunPage(make_ctx(Path(other), with_db=False), "1", "t", "b", self.win.gate)
            self.assertFalse(page.run_btn.isEnabled())

    def test_test_connection_button(self):
        settings = self.win.settings_page
        self.assertTrue(settings.test_btn.isEnabled())
        with mock.patch("ohc.checks.launcher.test_connection", return_value=ProbeResult("OK", "CONNECTED  -  PRIMARY")) as probe:
            settings.test_btn.click()
            self.assertTrue(wait_idle(self.win.gate))
        self.assertEqual(probe.call_args.args[1], "ims")
        self.assertEqual(settings.status.objectName(), "ok")
        self.assertIn("OK: CONNECTED", settings.status.text())
        with mock.patch("ohc.checks.launcher.test_connection", return_value=ProbeResult("DOWN", "INSTANCE NOT RUNNING", "ORA-01034")):
            settings.test_btn.click()
            self.assertTrue(wait_idle(self.win.gate))
        self.assertEqual(settings.status.objectName(), "bad")
        self.assertIn("ORA-01034", settings.status.text())

    def test_test_connection_disabled_without_database(self):
        with tempfile.TemporaryDirectory() as other:
            win = MainWindow(make_ctx(Path(other), with_db=False))
            self.addCleanup(win.deleteLater)
            self.assertFalse(win.settings_page.test_btn.isEnabled())


if __name__ == "__main__":
    unittest.main()
