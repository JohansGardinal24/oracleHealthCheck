"""INFO-versus-OK: the ten informational checks of the original tool are recorded as INFO."""
import tempfile
import unittest
from pathlib import Path

from ohc.checks import engine, fake
from tests.test_fake_oracle import TH

INFO_CHECKS = {9: "TOP 5 WAIT EVENTS", 10: "ACTIVE LOCKS", 11: "INDEX STATISTICS", 12: "SEGMENT SIZE", 15: "IMS SCHEDULERS",
               16: "IMS SCHEDULE JOBS", 17: "PARALLEL DEGREE INDEXES", 18: "SCHEDULER RUNNING JOBS",
               19: "DAILY DUMP JOB HISTORY", 20: "DB PATCH DETAILS"}
SQL_SRC = Path(__file__).resolve().parent.parent / "sql_src"


class Stub:
    """Answers every verdict script with the text the real script would print."""
    simulated = False

    def __init__(self, base):
        self.base = base

    def __getattr__(self, name):
        return getattr(self.base, name)

    def sql(self, mode, name):
        if mode == "val" and name.startswith("v_") and (SQL_SRC / name).read_text(encoding="utf-8", errors="replace").lstrip().startswith("select 'INFO|"):
            return "INFO|from the real script\n"
        return self.base.sql(mode, name)


def run(session):
    with tempfile.TemporaryDirectory() as tmp:
        return engine.run_checks("ALL", "ims", "ims", session, TH, log_dir=Path(tmp) / "l", report_base=Path(tmp) / "r", emit=lambda x: None)


class InfoTests(unittest.TestCase):
    def test_the_original_scripts_of_exactly_these_ten_checks_answer_info(self):
        scripts = {i: engine.SIMPLE[i][1] for i in INFO_CHECKS}
        for idx, name in scripts.items():
            self.assertTrue((SQL_SRC / name).read_text(encoding="utf-8", errors="replace").lstrip().startswith("select 'INFO|"), name)
        others = [engine.SIMPLE[i][1] for i in engine.SIMPLE if i not in INFO_CHECKS]
        for name in others:
            self.assertNotIn("select 'INFO|", (SQL_SRC / name).read_text(encoding="utf-8", errors="replace"), name)

    def test_engine_records_info_from_the_real_script_output(self):
        for scenario in ("healthy", "critical"):
            r = run(Stub(fake.FakeOracleSession(scenario, "ims")))
            got = {x.idx: x.status for x in r.results}
            self.assertTrue(all(got[i] == "INFO" for i in INFO_CHECKS), (scenario, got))

    def test_fake_backend_now_shows_info_not_ok(self):
        for scenario in ("healthy", "warning", "critical"):
            r = run(fake.FakeOracleSession(scenario, "ims"))
            got = {x.idx: x.status for x in r.results}
            self.assertTrue(all(got[i] == "INFO" for i in INFO_CHECKS), (scenario, {i: got[i] for i in INFO_CHECKS}))
            self.assertTrue(all(x.message.startswith("[FAKE]") for x in r.results))
        self.assertEqual(run(fake.FakeOracleSession("healthy", "ims")).overall, "OK")  # INFO never raises the overall status
        self.assertEqual(run(fake.FakeOracleSession("warning", "ims")).overall, "WARNING")  # still driven by real WARNING checks

    def test_other_checks_keep_their_status(self):
        got = {x.idx: x.status for x in run(fake.FakeOracleSession("healthy", "ims")).results}
        self.assertTrue(all(got[i] == "OK" for i in got if i not in INFO_CHECKS))


if __name__ == "__main__":
    unittest.main()
