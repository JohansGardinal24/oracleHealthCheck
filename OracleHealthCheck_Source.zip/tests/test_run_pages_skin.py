"""Options 1, 2 and 3 share one look and one wave; their run logic is unchanged (Qt offscreen)."""
import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
import tempfile
import unittest
from pathlib import Path

from PySide6.QtWidgets import QApplication

from ohc.gui import run_skin
from ohc.gui.main_window import MainWindow
from tests.test_gui_run import make_ctx


class SharedLookTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.win = MainWindow(make_ctx(Path(tmp.name)))
        self.addCleanup(self.win.deleteLater)

    def test_three_pages_share_the_skin_and_the_wave_implementation(self):
        for row in (1, 2, 3):
            page = self.win.pages.widget(row)
            self.assertTrue(page._skin, row)
            self.assertIs(type(page._backdrop), run_skin.PageBackdrop, row)
            self.assertIs(page._backdrop._WAVE_LAYERS, run_skin.PageBackdrop._WAVE_LAYERS, row)

    def test_heading_icon_is_the_sidebar_icon_of_each_page(self):
        for row, kind in ((1, "health"), (2, "sync"), (3, "checks")):
            self.assertEqual([k for _l, k, size in self.win.pages.widget(row)._icons if size == 32], [kind], row)

    def test_other_pages_are_not_given_a_wave(self):
        for row in (0, 4, 5, 6):
            self.assertFalse(hasattr(self.win.pages.widget(row), "_backdrop"), row)

    def test_progress_counting_is_unchanged_for_sync_and_all_checks(self):
        for row, text in ((2, "1 of 2 checks completed"), (3, "1 of 2 checks completed"), (1, "0 of 2 checks completed \u00B7 1 cancelled")):
            page = self.win.pages.widget(row)
            page._load_plan([(1, "A"), (4, "B")])
            page._set_row(1, "CANCELLED", "Cancelled")
            page._progress()
            self.assertEqual(page.count_label.text(), text, row)

    def test_themes_switch_on_all_three_pages(self):
        for theme in ("light", "dark"):
            self.win.theme.set_theme(theme)
            self.app.processEvents()
            for row in (1, 2, 3):
                self.assertEqual(self.win.pages.widget(row)._theme_name(), theme)


if __name__ == "__main__":
    unittest.main()
