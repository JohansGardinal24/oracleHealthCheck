"""No-Qt tests: AWR/ASH/ADDM index location (config folder), SWITCHOVER_STATUS classification and the saved run mode."""
import json
import os
import shutil
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest import mock

from ohc import addm, ash, awr, dashboard_data as dd
from ohc.checks import engine, fake
from ohc.checks.session import QueryTimeout, ToolError
from ohc.config import dbadmin
from ohc.config.databases import DatabaseEntry, DatabaseStore, DatabasesError
from ohc.security import credstore

B, E, WHEN = datetime(2026, 10, 16, 1, 0), datetime(2026, 10, 16, 1, 30), datetime(2026, 10, 16, 2, 0)


class IndexLocation(unittest.TestCase):
    def setUp(self):
        self.root = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.root, True)
        self.reports, self.config = self.root / "reports", self.root / "config"
        (self.reports / "2026-10-16").mkdir(parents=True)

    def put(self, name):
        p = self.reports / "2026-10-16" / name
        p.write_text("x", encoding="utf-8")
        return p

    def record_all(self, index_dir):
        a, s, d = self.put("my_awr.html"), self.put("my_ash.html"), self.put("my_addm.txt")
        self.assertEqual(awr.record_report(self.reports, a, "ORCL", False, 11, 12, False, WHEN, index_dir=index_dir), "")
        self.assertEqual(ash.record_report(self.reports, s, "ORCL", False, B, E, False, WHEN, index_dir=index_dir), "")
        self.assertEqual(addm.record_report(self.reports, d, "ORCL", False, 11, 12, False, WHEN, index_dir=index_dir), "")
        return a, s, d

    def test_indexes_are_written_to_config_and_never_to_reports(self):
        self.record_all(awr.index_dir_for(self.root))
        for name in (awr.INDEX_NAME, ash.INDEX_NAME, addm.INDEX_NAME):
            self.assertTrue((self.config / name).is_file(), name)
            self.assertFalse((self.reports / name).exists(), name)
        self.assertEqual([x for x in os.listdir(self.config) if x.endswith(".tmp")], [])
        self.assertEqual(sorted(p.name for p in (self.reports / "2026-10-16").iterdir()), ["my_addm.txt", "my_ash.html", "my_awr.html"])   # reports stay

    def test_history_is_found_from_the_config_indexes(self):
        a, s, d = self.record_all(awr.index_dir_for(self.root))
        cfg = self.config
        self.assertEqual([(e.path, e.db) for e in awr.scan_history(self.reports, index_dir=cfg).entries], [(a, "ORCL")])
        self.assertEqual([(e.path, e.db) for e in ash.scan_history(self.reports, index_dir=cfg).entries], [(s, "ORCL")])
        self.assertEqual([(e.path, e.db) for e in addm.scan_history(self.reports, index_dir=cfg).entries], [(d, "ORCL")])
        names = {r.kind: r.path for r in dd.recent_reports(self.reports, None, 10, index_dir=cfg)}      # Dashboard history
        self.assertEqual(names, {"AWR": a, "ASH": s, "ADDM": d})

    def test_an_index_left_in_reports_by_an_older_version_is_still_read_and_then_migrated(self):
        a = self.put("old_awr.html")
        awr.record_report(self.reports, a, "OLD", False, 1, 2, False, WHEN)                      # old behaviour: index next to the reports
        self.assertTrue((self.reports / awr.INDEX_NAME).is_file())
        cfg = awr.index_dir_for(self.root)
        self.assertEqual([(e.path, e.db) for e in awr.scan_history(self.reports, index_dir=cfg).entries], [(a, "OLD")])   # history kept
        new = self.put("new_awr.html")
        awr.record_report(self.reports, new, "NEW", False, 3, 4, False, WHEN, index_dir=cfg)
        got = {e.path.name: e.db for e in awr.scan_history(self.reports, index_dir=cfg).entries}
        self.assertEqual(got, {"old_awr.html": "OLD", "new_awr.html": "NEW"})                    # nothing lost
        self.assertTrue((self.config / awr.INDEX_NAME).is_file())
        self.assertFalse((self.reports / awr.INDEX_NAME).exists())                               # the old file is gone only after the new one exists

    def test_ash_and_addm_legacy_indexes_migrate_the_same_way(self):
        s, d = self.put("old_ash.html"), self.put("old_addm.txt")
        ash.record_report(self.reports, s, "OLD", False, B, E, False, WHEN)
        addm.record_report(self.reports, d, "OLD", False, 1, 2, False, WHEN)
        cfg = awr.index_dir_for(self.root)
        self.assertEqual([e.db for e in ash.scan_history(self.reports, index_dir=cfg).entries], ["OLD"])
        self.assertEqual([e.db for e in addm.scan_history(self.reports, index_dir=cfg).entries], ["OLD"])
        ash.record_report(self.reports, self.put("n.html"), "N", False, B, E, False, WHEN, index_dir=cfg)
        addm.record_report(self.reports, self.put("n.txt"), "N", False, 3, 4, False, WHEN, index_dir=cfg)
        self.assertEqual(sorted(e.db for e in ash.scan_history(self.reports, index_dir=cfg).entries), ["N", "OLD"])
        self.assertEqual(sorted(e.db for e in addm.scan_history(self.reports, index_dir=cfg).entries), ["N", "OLD"])
        self.assertFalse((self.reports / ash.INDEX_NAME).exists() or (self.reports / addm.INDEX_NAME).exists())

    def test_config_entry_wins_and_damaged_files_never_break_the_list(self):
        a = self.put("x.html")
        awr.record_report(self.reports, a, "LEGACY", False, 1, 2, False, WHEN)
        cfg = awr.index_dir_for(self.root)
        awr.record_report(self.reports, a, "CONFIG", False, 1, 2, False, WHEN, index_dir=cfg)
        self.assertEqual(awr.scan_history(self.reports, index_dir=cfg).entries[0].db, "CONFIG")
        self.assertFalse((self.reports / awr.INDEX_NAME).exists())                                # migrated on write
        awr.record_report(self.reports, a, "LEGACY", False, 1, 2, False, WHEN)                    # an old-version index appears again
        (self.config / awr.INDEX_NAME).write_text("{ broken", encoding="utf-8")
        self.assertEqual(awr.scan_history(self.reports, index_dir=cfg).entries[0].db, "LEGACY")   # a damaged new index falls back to the old one
        (self.reports / awr.INDEX_NAME).write_text("{ broken", encoding="utf-8")
        self.assertEqual(awr.scan_history(self.reports, index_dir=cfg).entries, [])               # both damaged: empty list, no crash

    def test_unwritable_config_reports_a_problem_text_instead_of_raising(self):
        blocker = self.root / "config"
        blocker.write_text("a file where the folder should be", encoding="utf-8")
        text = awr.record_report(self.reports, self.put("y.html"), "X", False, 1, 2, False, WHEN, index_dir=blocker)
        self.assertIn("could not be saved", text)


class FakeSession:
    def __init__(self, text=None, exc=None):
        self.text, self.exc = text, exc

    def switchover_status(self):
        if self.exc:
            raise self.exc
        return self.text


class Classify(unittest.TestCase):
    def mode(self, text=None, exc=None):
        return engine.classify_run_mode(FakeSession(text, exc))

    def test_not_allowed_is_a_standard_database(self):
        r = self.mode("SWITCHOVER_STATUS|NOT ALLOWED\n")
        self.assertEqual((r.mode, r.status, r.error), ("standard", "NOT ALLOWED", ""))
        self.assertEqual(self.mode("\n  SWITCHOVER_STATUS|not allowed  \n").mode, "standard")

    def test_every_other_valid_status_is_data_guard_related(self):
        for status in sorted(engine.SWITCHOVER_VALUES - {"NOT ALLOWED"}):
            r = self.mode(f"SWITCHOVER_STATUS|{status}\n")
            self.assertEqual((r.mode, r.status), ("dataguard", status), status)
        self.assertIn("TO STANDBY", engine.SWITCHOVER_VALUES)
        self.assertIn("FAILED DESTINATION", engine.SWITCHOVER_VALUES)

    def test_failures_are_reported_and_never_guessed(self):
        for text in ("ERROR at line 1:\nORA-00942: table or view does not exist\n", "", "SP2-0640: Not connected\n",
                     "SWITCHOVER_STATUS|\n", "SWITCHOVER_STATUS|SOMETHING NEW\n", None):
            r = self.mode(text)
            self.assertEqual(r.mode, "", repr(text))
            self.assertTrue(r.error, repr(text))
        for exc in (ToolError("sqlplus missing"), QueryTimeout("timed out")):
            r = self.mode(exc=exc)
            self.assertEqual(r.mode, "")
            self.assertIn(str(exc), r.error)

    def test_fake_session_values(self):
        for env, want in (({}, "dataguard"), ({"OHC_FAKE_SWITCHOVER": "NOT ALLOWED"}, "standard"), ({"OHC_FAKE_SWITCHOVER": "error"}, "")):
            with mock.patch.dict(os.environ, env):
                self.assertEqual(engine.classify_run_mode(fake.FakeOracleSession("healthy", "ims")).mode, want, env)
        self.assertEqual(engine.classify_run_mode(fake.FakeOracleSession("down", "ims")).mode, "")

    def test_the_query_is_one_read_only_select_of_switchover_status(self):
        from ohc.checks import session
        sql = session.SWITCHOVER_SQL.lower()
        self.assertIn("switchover_status", sql)
        self.assertIn("from v$database", sql)
        self.assertNotIn("alter", sql)


class SavedMode(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.path = self.tmp / "databases.json"
        self.store = DatabaseStore(self.path)
        self.entry = DatabaseEntry(id=credstore.new_database_id(), name="ims")
        self.store.add(self.entry)

    def test_a_file_from_the_old_version_loads_with_an_unknown_mode(self):
        old = {"schema_version": 1, "databases": [{"id": self.entry.id, "name": "ims", "sid": "", "dg_service": "", "oracle_home": "", "notes": ""}]}
        self.path.write_text(json.dumps(old), encoding="utf-8")
        e = DatabaseStore(self.path).get(self.entry.id)
        self.assertEqual((e.run_mode, e.switchover_status), ("", ""))

    def test_set_run_mode_persists_and_rejects_bad_values(self):
        dbadmin.set_run_mode(self.store, self.entry.id, "standard", "NOT ALLOWED")
        e = DatabaseStore(self.path).get(self.entry.id)
        self.assertEqual((e.run_mode, e.switchover_status), ("standard", "NOT ALLOWED"))
        before = self.path.read_text(encoding="utf-8")
        dbadmin.set_run_mode(self.store, self.entry.id, "standard", "NOT ALLOWED")           # unchanged: no write
        self.assertEqual(self.path.read_text(encoding="utf-8"), before)
        for bad in ("both", "STANDARD"):
            with self.assertRaises(DatabasesError):
                dbadmin.set_run_mode(self.store, self.entry.id, bad, "")
        with self.assertRaises(DatabasesError):
            dbadmin.set_run_mode(self.store, self.entry.id, "standard", "not allowed; drop")
        with self.assertRaises(DatabasesError):
            dbadmin.set_run_mode(self.store, "missing-id", "standard", "")


if __name__ == "__main__":
    unittest.main()
