"""Oracle Home: Settings Save and the launcher use the same file (<install root>\\config\\environment.json), also for a packaged EXE."""
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from PySide6.QtWidgets import QApplication

from ohc import paths
from ohc.checks import launcher
from ohc.checks.session import ToolError
from ohc.config import environment, jsonio, thresholds
from ohc.config.databases import DatabaseEntry
from ohc.gui.context import AppContext
from ohc.gui.settings_page import SettingsPage
from ohc.gui.theme import ThemeManager
from tests.test_awr import make_awr_ctx
from tests.test_gui_run import wait_idle


def make_home(root: Path, name="home") -> str:
    """A fake Oracle Home with bin/sqlplus and bin/dgmgrl (a local absolute path, so it passes the syntax check on any OS)."""
    ext = ".exe" if os.name == "nt" else ""
    home = root / name
    (home / "bin").mkdir(parents=True)
    for tool in ("sqlplus", "dgmgrl"):
        (home / "bin" / (tool + ext)).write_bytes(b"")
    return str(home)


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        env = mock.patch.dict(os.environ)
        env.start()
        self.addCleanup(env.stop)
        for k in ("OHC_FAKE_ORACLE", "OHC_FAKE_DELAY", "OHC_FAKE_SWITCHOVER"):
            os.environ.pop(k, None)
        self.ctx = make_awr_ctx(self.tmp)                      # config\environment.json written with a BLANK Oracle Home
        self.home = make_home(self.tmp)
        self.page = SettingsPage(self.ctx, ThemeManager(self.ctx.settings))
        self.addCleanup(self.page.deleteLater)


class SameFileForSaveAndLauncher(Base):
    def test_packaged_root_is_the_exe_folder_and_every_config_path_is_inside_it(self):
        exe_dir = self.tmp / "dist" / "OracleHealthCheck"
        exe_dir.mkdir(parents=True)
        with mock.patch.object(sys, "frozen", True, create=True), mock.patch.object(sys, "executable", str(exe_dir / "OracleHealthCheck.exe")):
            self.assertEqual(paths.app_root(), exe_dir.resolve())
            self.assertEqual(environment.default_path(), exe_dir.resolve() / "config" / "environment.json")
            self.assertEqual(thresholds.default_path(), exe_dir.resolve() / "config" / "thresholds.json")
            ctx = AppContext.ephemeral()                       # the same root/config construction the real context uses
            self.assertEqual((ctx.environment_path, ctx.thresholds_path), (environment.default_path(), thresholds.default_path()))

    def test_save_writes_the_file_the_launcher_reads_and_the_run_then_resolves_the_home(self):
        with self.assertRaises(ToolError) as blank:
            launcher._prepare(self.ctx, "ims", False)
        self.assertIn("Oracle Home is not configured", str(blank.exception))
        self.assertIn(str(self.ctx.environment_path), str(blank.exception))                  # the message names the file that was read
        self.page.home_edit.setText(self.home)
        self.assertTrue(self.page.save())
        self.assertIn(str(self.ctx.environment_path), self.page.status.text())                # Save says where it wrote
        self.assertEqual(environment.load_environment(self.ctx.environment_path).values["ORACLE_HOME"], self.home)
        entry, home, _env, _th = launcher._prepare(self.ctx, "ims", True)                     # needs sqlplus AND dgmgrl
        self.assertEqual((entry.name, home), ("ims", self.home))

    def test_a_save_that_did_not_reach_the_disk_is_reported_as_not_saved(self):
        self.page.home_edit.setText(self.home)
        with mock.patch.object(environment, "save_environment", return_value="x"):            # pretends to write, changes nothing
            self.assertFalse(self.page.save())
        self.assertIn("Not saved", self.page.status.text())
        self.assertEqual(environment.load_environment(self.ctx.environment_path).values["ORACLE_HOME"], "")

    def test_a_write_failure_is_reported_with_its_reason(self):
        self.page.home_edit.setText(self.home)
        with mock.patch.object(jsonio, "write_atomic", side_effect=jsonio.ConfigFileError("Cannot write environment.json: Access is denied")):
            self.assertFalse(self.page.save())
        self.assertIn("Access is denied", self.page.status.text())

    def test_a_trailing_backslash_is_normalised_and_still_verifies(self):
        self.page.home_edit.setText(self.home + os.sep)
        self.assertTrue(self.page.save())
        self.assertEqual(environment.load_environment(self.ctx.environment_path).values["ORACLE_HOME"], self.home)

    def test_clearing_the_home_saves_a_blank_value(self):
        self.page.home_edit.setText(self.home)
        self.page.save()
        self.page.home_edit.setText("")
        self.assertTrue(self.page.save())
        self.assertEqual(environment.load_environment(self.ctx.environment_path).values["ORACLE_HOME"], "")


class PerDatabaseOverrideStillWins(Base):
    def test_database_override_is_used_with_a_blank_shared_default(self):
        override = make_home(self.tmp, "other_home")
        entry = self.ctx.databases.find_by_name("ims")
        self.ctx.databases.update(DatabaseEntry(**{**entry.__dict__, "oracle_home": override}))
        _e, home, _env, _th = launcher._prepare(self.ctx, "ims", False)
        self.assertEqual(home, override)

    def test_database_override_beats_the_shared_default(self):
        self.page.home_edit.setText(self.home)
        self.page.save()
        override = make_home(self.tmp, "other_home")
        entry = self.ctx.databases.find_by_name("ims")
        self.ctx.databases.update(DatabaseEntry(**{**entry.__dict__, "oracle_home": override}))
        self.assertEqual(launcher._prepare(self.ctx, "ims", False)[1], override)


class TestConnectionNeedsTheSavedHome(Base):
    def click_test(self):
        calls = []
        with mock.patch.object(launcher, "test_connection", side_effect=lambda *a: calls.append(a) or (_ for _ in ()).throw(ToolError("stop"))):
            self.page.refresh_databases(self.ctx.databases.find_by_name("ims").id)
            self.page.test_btn.setEnabled(True)
            self.page.test_btn.click()
            wait_idle(self.page.gate)
        return calls

    def test_unsaved_home_in_the_box_stops_the_test_with_a_clear_message(self):
        self.page.home_edit.setText(self.home)                  # typed, not saved
        self.assertEqual(self.click_test(), [])
        self.assertIn("has not been saved", self.page.status.text())
        self.assertIn(str(self.ctx.environment_path), self.page.status.text())

    def test_saved_home_lets_the_test_run(self):
        self.page.home_edit.setText(self.home)
        self.page.save()
        self.assertEqual(len(self.click_test()), 1)

    def test_a_database_with_its_own_home_is_not_blocked(self):
        entry = self.ctx.databases.find_by_name("ims")
        self.ctx.databases.update(DatabaseEntry(**{**entry.__dict__, "oracle_home": make_home(self.tmp, "own")}))
        self.page.home_edit.setText(self.home)                  # unsaved shared default is irrelevant here
        self.assertEqual(len(self.click_test()), 1)


if __name__ == "__main__":
    unittest.main()
