"""Safe cancellation: the flag, child-process termination, partial log/report, GUI state, and a new run afterwards.

Real child processes are used for the termination tests (a Python interpreter sleeping), so they run on Windows and Linux.
The process-TREE test needs taskkill /T and therefore runs on Windows only."""
import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if sys.platform == "win32":
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

import shutil
import subprocess
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

from PySide6.QtWidgets import QApplication

from ohc.checks import engine, fake, launcher
from ohc.checks.cancel import CancelToken, RunCancelled
from ohc.checks.session import OracleSession, ToolError
from ohc.gui import outcomes
from ohc.gui.main_window import MainWindow
from ohc.gui.run_page import STATUS_ROLE
from ohc.security import credstore
from ohc.security.credstore import Credentials
from tests.test_fake_oracle import TH
from tests.test_gui_run import make_ctx, wait_idle

ROOT = Path(__file__).resolve().parent.parent
EXE = ".exe" if sys.platform == "win32" else ""
SLEEPER = [sys.executable, "-c", "import time; time.sleep(120)"]


def wait_for(cond, timeout=15.0):
    end = time.time() + timeout
    while not cond() and time.time() < end:
        QApplication.processEvents()
        time.sleep(0.01)
    QApplication.processEvents()
    return cond()


class TokenTests(unittest.TestCase):
    def test_flag_and_exception(self):
        t = CancelToken()
        t.check()
        self.assertFalse(t.requested)
        t.request()
        t.request()  # repeated requests are harmless
        self.assertTrue(t.requested)
        with self.assertRaises(RunCancelled):
            t.check()
        self.assertFalse(issubclass(RunCancelled, ToolError))  # a cancel is not a tool/configuration error (exit code 3)
        self.assertTrue(t.wait(0.01))

    def test_registered_process_is_killed_and_late_registration_too(self):
        class P:
            pid = None
            killed = 0

            def kill(self):
                self.killed += 1

        t, early, late = CancelToken(), P(), P()
        t.register(early)
        t.request()
        t.register(late)  # cancelled between starting the process and registering it
        self.assertEqual((early.killed, late.killed), (1, 1))

    def test_unkillable_process_does_not_raise(self):
        class P:
            pid = None

            def kill(self):
                raise OSError("already gone")

        t = CancelToken()
        t.register(P())
        t.request()


class ProcessTerminationTests(unittest.TestCase):
    def setUp(self):
        self.home = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.home, True)
        (self.home / "bin").mkdir()
        for n in ("sqlplus", "dgmgrl"):
            (self.home / "bin" / (n + EXE)).write_text("")
        self.procs = []
        self.addCleanup(lambda: [p.kill() for p in self.procs if p.poll() is None])

    def popen(self, *a, **kw):
        p = subprocess.Popen(*a, **kw)
        self.procs.append(p)
        return p

    def session(self, token, timeout=900):
        return OracleSession(self.home, "IMS", Credentials(bytearray(b"sys"), bytearray(b"pw")), [], popen=self.popen,
                             timeout=timeout, cancel=token)

    def test_cancel_ends_a_blocked_child_process_promptly(self):
        token, result = CancelToken(), {}
        s = self.session(token)

        def work():
            try:
                s._run(SLEEPER, bytearray(b""), self.home)
            except BaseException as exc:
                result["exc"] = exc

        th = threading.Thread(target=work)
        th.start()
        self.assertTrue(wait_for_flag(lambda: self.procs, 10))
        time.sleep(0.3)
        started = time.time()
        token.request()
        th.join(15)
        self.assertFalse(th.is_alive())
        self.assertLess(time.time() - started, 10)  # it was a 120 s sleep
        self.assertIsInstance(result.get("exc"), RunCancelled)
        self.assertIsNotNone(self.procs[0].poll())  # the child really is gone

    def test_cancel_before_start_never_launches_a_process(self):
        token = CancelToken()
        token.request()
        with self.assertRaises(RunCancelled):
            self.session(token)._run(SLEEPER, bytearray(b""), self.home)
        self.assertEqual(self.procs, [])

    def test_without_a_token_nothing_changes(self):
        out = self.session(None)._run([sys.executable, "-c", "print('hello')"], bytearray(b""), self.home)
        self.assertIn("hello", out)

    @unittest.skipUnless(sys.platform == "win32", "process-tree termination uses taskkill /T (Windows)")
    def test_windows_grandchild_is_ended_too(self):
        import ctypes

        def alive(pid: int) -> bool:  # Win32 API only: no wmic/tasklist needed
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
            if not handle:
                return False
            try:
                code = ctypes.c_ulong()
                return bool(kernel32.GetExitCodeProcess(handle, ctypes.byref(code))) and code.value == 259  # STILL_ACTIVE
            finally:
                kernel32.CloseHandle(handle)

        pidfile = self.home / "grandchild.pid"
        script = ("import subprocess,sys,time;"
                  "g=subprocess.Popen([sys.executable,'-c','import time;time.sleep(120)']);"
                  "open(sys.argv[1],'w').write(str(g.pid));time.sleep(120)")
        token = CancelToken()
        s = self.session(token)
        th = threading.Thread(target=lambda: self._swallow(lambda: s._run([sys.executable, "-c", script, str(pidfile)], bytearray(b""), self.home)))
        th.start()
        self.assertTrue(wait_for_flag(lambda: pidfile.is_file() and pidfile.read_text().strip().isdigit(), 20))
        grandchild = int(pidfile.read_text().strip())
        self.addCleanup(lambda: alive(grandchild) and subprocess.run(["taskkill", "/PID", str(grandchild), "/T", "/F"], capture_output=True))
        self.assertTrue(alive(grandchild))  # it really is running before the cancel (the test cannot pass vacuously)
        token.request()
        th.join(20)
        self.assertFalse(th.is_alive())
        self.assertTrue(wait_for_flag(lambda: not alive(grandchild), 10), "the grandchild process is still running after cancel")

    @staticmethod
    def _swallow(fn):
        try:
            return fn()
        except BaseException as exc:
            return exc


def wait_for_flag(cond, timeout):
    end = time.time() + timeout
    while not cond() and time.time() < end:
        time.sleep(0.01)
    return bool(cond())


class EngineCancelTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)

    def run_it(self, session, mode="ALL", **kw):
        return engine.run_checks(mode, "ims", "ims", session, TH, log_dir=self.tmp / "logs", report_base=self.tmp / "reports",
                                 emit=lambda x: None, **kw)

    def test_cancel_between_checks_keeps_completed_results_and_marks_the_run(self):
        full = self.run_it(fake.FakeOracleSession("warning", "ims"))
        token, done = CancelToken(), []

        def on_event(ev):
            if ev[0] == "done":
                done.append(ev[1])
                if len(done) == 5:
                    token.request()

        r = self.run_it(fake.FakeOracleSession("warning", "ims", cancel=token), on_event=on_event, cancel=token)
        self.assertTrue(r.cancelled)
        self.assertEqual((r.overall, r.exit_code), ("CANCELLED", 4))
        self.assertEqual(len(r.results), 5)
        self.assertEqual([(x.idx, x.status, x.message) for x in r.results], [(x.idx, x.status, x.message) for x in full.results[:5]])
        log = r.log_file.read_text(encoding=engine.ENC, errors="replace")
        self.assertIn("RUN CANCELLED BY THE USER - 5 of 21 checks completed", log)
        self.assertIn("OVERALL: CANCELLED", log)
        self.assertTrue(log.endswith("\r\n") or log.endswith("\n"))
        html = r.report_file.read_text(encoding="utf-8")
        self.assertIn("RUN CANCELLED BY THE USER", html)
        self.assertEqual(html.count("<h2"), 5)  # only the completed checks have a section
        self.assertTrue(html.rstrip().endswith("</html>"))  # a complete document, not a truncated one

    def test_cancel_in_the_middle_of_a_check_drops_only_that_check(self):
        token = CancelToken()
        s = fake.FakeOracleSession("healthy", "ims", delay=0.2, cancel=token)
        threading.Timer(0.5, token.request).start()
        r = self.run_it(s, cancel=token)
        self.assertTrue(r.cancelled)
        self.assertLess(len(r.results), 21)
        self.assertEqual(sorted(x.idx for x in r.results), sorted(set(x.idx for x in r.results)))  # no duplicates / half results
        self.assertTrue(r.log_file.is_file() and r.report_file.is_file())

    def test_uncancelled_run_is_unchanged(self):
        r = self.run_it(fake.FakeOracleSession("warning", "ims"), cancel=CancelToken())
        self.assertFalse(r.cancelled)
        self.assertEqual((r.overall, r.exit_code, len(r.results)), ("WARNING", 1, 21))
        self.assertNotIn("CANCELLED", r.report_file.read_text(encoding="utf-8"))

    def test_outcomes_never_report_cancel_as_ok(self):
        token = CancelToken()
        token.request()
        r = self.run_it(fake.FakeOracleSession("healthy", "ims", cancel=token), cancel=token)
        o = outcomes.for_run(r)
        self.assertTrue(o.cancelled)
        self.assertEqual((o.level, o.exit_code), ("warn", 4))
        self.assertTrue(o.text().startswith("CANCELLED"))
        self.assertNotIn("OK", o.text().split())
        e = outcomes.for_error(RunCancelled("x"))
        self.assertTrue(e.cancelled)
        self.assertEqual(e.exit_code, 4)


class CliExitCodeTests(unittest.TestCase):
    """The CLI has no cancel: exit codes stay 0-3."""

    def run_cli(self, scenario, mode="3"):
        with tempfile.TemporaryDirectory() as tmp:
            ctx = make_ctx(Path(tmp))
            (Path(tmp) / "config").mkdir()
            for n in ("environment.json", "thresholds.json"):
                (Path(tmp) / "config" / n).write_bytes((ROOT / "config" / n).read_bytes())
            credstore.save_credentials(ctx.credentials_dir, ctx.databases.entries()[0].id, "sys", "pw", backend=ctx.backend)
            with mock.patch.dict(os.environ, {"OHC_FAKE_ORACLE": scenario}), \
                    mock.patch("builtins.print"):
                return launcher.run_option(ctx, ctx.databases.entries()[0].name, mode, emit=lambda line: None)

    def test_run_option_without_token_never_cancels(self):
        for scenario, code in (("healthy", 0), ("warning", 1), ("critical", 2)):
            r = self.run_cli(scenario)
            self.assertEqual((r.exit_code, r.cancelled), (code, False), scenario)

    def test_cancelled_exit_code_is_not_a_legacy_code(self):
        self.assertNotIn(4, (0, 1, 2, 3))
        self.assertTrue(all(c in (0, 1, 2) for c in (0, 1, 2)))


class GuiCancelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.env = mock.patch.dict(os.environ, {"OHC_FAKE_ORACLE": "warning", "OHC_FAKE_DELAY": "0.05"})
        self.env.start()
        self.addCleanup(self.env.stop)
        self.ctx = make_ctx(Path(tmp.name))
        (Path(tmp.name) / "config").mkdir(exist_ok=True)
        for n in ("environment.json", "thresholds.json"):
            (Path(tmp.name) / "config" / n).write_bytes((ROOT / "config" / n).read_bytes())
        credstore.save_credentials(self.ctx.credentials_dir, self.ctx.databases.entries()[0].id, "sys", "pw", backend=self.ctx.backend)
        self.win = MainWindow(self.ctx)
        self.addCleanup(self.win.deleteLater)
        self.page = self.win.pages.widget(3)

    def done_rows(self):
        return sum(1 for r in range(self.page.table.rowCount()) if self.page.table.item(r, 2).data(STATUS_ROLE) not in ("PENDING", "RUNNING"))

    def test_cancel_stops_the_run_and_restores_the_controls(self):
        p = self.page
        self.assertFalse(p.cancel_btn.isEnabled())  # nothing running
        p.run_btn.click()
        self.assertTrue(p.cancel_btn.isEnabled() and not p.run_btn.isEnabled())
        self.assertTrue(wait_for(lambda: self.done_rows() >= 3))
        p.cancel_btn.click()
        self.assertFalse(p.cancel_btn.isEnabled())  # no second click
        self.assertEqual(p.state_label.text(), "Cancelling")
        p.cancel_btn.click()  # harmless
        self.assertTrue(wait_idle(self.win.gate, 20))
        self.assertEqual(p.state_label.text(), "Cancelled")
        self.assertTrue(p.status.text().startswith("SIMULATED DATA - CANCELLED"), p.status.text())
        self.assertNotIn("OK", p.status.text().split())
        self.assertEqual(p.state_icon.state, "cancelled")
        states = [p.table.item(r, 2).data(STATUS_ROLE) for r in range(21)]
        self.assertIn("OK", states[:3] + states)  # completed results are kept
        self.assertTrue(states.count("PENDING") + states.count("CANCELLED") > 0)
        self.assertLess(p.progress.value(), 21)
        self.assertGreaterEqual(p.progress.value(), 3)
        # controls are back
        self.assertTrue(p.run_btn.isEnabled() and p.db_combo.isEnabled())
        self.assertFalse(p.cancel_btn.isEnabled())
        self.assertFalse(self.win.gate.busy)
        self.assertTrue(p.open_file_btn.isEnabled() and p.view_log_btn.isEnabled())
        self.assertIn("CANCELLED", Path(p._result.report_file).read_text(encoding="utf-8"))
        self.assertTrue(p._result.cancelled)

    def test_a_new_run_works_after_a_cancel(self):
        p = self.page
        p.run_btn.click()
        self.assertTrue(wait_for(lambda: self.done_rows() >= 2))
        p.cancel_btn.click()
        self.assertTrue(wait_idle(self.win.gate, 20))
        self.assertEqual(p.state_label.text(), "Cancelled")
        with mock.patch.dict(os.environ, {"OHC_FAKE_DELAY": "0"}):
            p.run_btn.click()
            self.assertTrue(p.cancel_btn.isEnabled())
            self.assertTrue(wait_idle(self.win.gate, 30))
        self.assertEqual(p.state_label.text(), "Completed")
        self.assertEqual(p.status.text(), "SIMULATED DATA - OVERALL: WARNING (exit code 1)")
        self.assertEqual((p.progress.value(), p.count_label.text()), (21, "21 of 21 checks completed"))
        self.assertNotIn("CANCELLED", [p.table.item(r, 2).data(STATUS_ROLE) for r in range(21)])
        self.assertFalse(p._result.cancelled)
        self.assertFalse(p.cancel_btn.isEnabled())

    def test_cancel_only_on_the_page_that_is_running(self):
        p = self.page
        other = self.win.pages.widget(1)
        p.run_btn.click()
        self.assertTrue(p.cancel_btn.isEnabled())
        self.assertFalse(other.cancel_btn.isEnabled())
        self.assertFalse(other.run_btn.isEnabled())  # global busy gate still applies
        p.cancel_btn.click()
        self.assertTrue(wait_idle(self.win.gate, 20))
        self.assertTrue(other.run_btn.isEnabled())

    def test_cancelling_before_the_first_check_leaves_a_clean_state(self):
        p = self.page
        p.run_btn.click()
        p.cancel_btn.click()  # immediately
        self.assertTrue(wait_idle(self.win.gate, 20))
        self.assertEqual(p.state_label.text(), "Cancelled")
        self.assertTrue(p.run_btn.isEnabled())
        self.assertFalse(p.cancel_btn.isEnabled())


if __name__ == "__main__":
    unittest.main()
