"""Tests for the shared thresholds file: defaults, validation, snapshot, atomic save, CLI."""
import contextlib
import hashlib
import io
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from ohc.config import thresholds as t
from ohc.config.thresholds import ThresholdsError, ThresholdsInvalidError, ThresholdsMissingError

# The effective values of the ORIGINAL tool.conf.bat (the BAT's own fallbacks differ and apply only if a key is missing).
ORIGINAL = {
    "RETENTION_DAYS": 30, "TBS_WARN": 70, "TBS_CRIT": 90, "FRA_WARN": 70, "FRA_CRIT": 90,
    "DR_LAG_WARN": 120, "DR_LAG_CRIT": 600, "RMAN_LOOKBACK_DAYS": 7, "DISK_WARN": 80, "DISK_CRIT": 90,
    "DBFILES_WARN": 70, "DBFILES_CRIT": 90, "RESOURCE_WARN": 70, "RESOURCE_CRIT": 90,
    "USER_EXPIRY_WARNING_DAYS": 30, "USER_EXPIRY_CRITICAL_DAYS": 20, "TEMP_HIST_DAYS": 10, "LOCK_WAIT_SEC": 10,
    "USER_EXPIRY_LOOKAHEAD_DAYS": 30, "IMS_SCHEDULER_LOOKAHEAD_DAYS": 90,
    "SYS_EXPIRY_CRIT_STATUS": "EXPIRED(GRACE)", "DATA_MOVEMENT_DBS": "IMS RPP",
}


class Case(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self._tmp.name)
        self.path = self.dir / "config" / "thresholds.json"
        self.addCleanup(self._tmp.cleanup)

    def doc(self, **changes):
        values = dict(ORIGINAL)
        values.update(changes)
        return {"schema_version": 1, "thresholds": values}

    def put(self, doc_or_text, name=None):
        p = self.path if name is None else self.dir / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(doc_or_text if isinstance(doc_or_text, str) else json.dumps(doc_or_text), encoding="utf-8")
        return p

    def problems_for(self, **changes):
        try:
            t.load_thresholds(self.put(self.doc(**changes)))
        except ThresholdsInvalidError as exc:
            return exc.problems
        return []


class Defaults(Case):
    def test_defaults_equal_the_original_effective_config_values(self):
        self.assertEqual(dict(t.DEFAULTS), ORIGINAL)
        self.assertEqual(len(t.KEYS), 22)
        self.assertEqual(list(t.DEFAULTS), list(t.KEYS))

    def test_default_values_are_valid_and_every_key_is_described(self):
        self.assertEqual(t.validate_values(t.DEFAULTS), [])
        for spec in t.SPECS:
            self.assertTrue(spec.description.strip(), spec.key)

    def test_write_default_then_load_round_trips(self):
        sha = t.write_default(self.path)
        snap = t.load_thresholds(self.path)
        self.assertEqual(snap.as_dict(), ORIGINAL)
        self.assertEqual(snap.sha256, sha)
        self.assertEqual(snap.sha256, hashlib.sha256(self.path.read_bytes()).hexdigest())
        doc = json.loads(self.path.read_text(encoding="utf-8"))
        self.assertEqual(set(doc["descriptions"]), set(t.KEYS))

    def test_write_default_never_overwrites(self):
        self.put("keep me")
        with self.assertRaises(ThresholdsError):
            t.write_default(self.path)
        self.assertEqual(self.path.read_text(encoding="utf-8"), "keep me")

    def test_default_path_follows_the_install_root(self):
        with mock.patch.dict(os.environ, {"OHC_DEV_HOME": str(self.dir)}):
            self.assertEqual(t.default_path(), self.dir.resolve() / "config" / "thresholds.json")


class Snapshot(Case):
    def test_snapshot_is_immutable_and_records_hash_and_source(self):
        t.write_default(self.path)
        snap = t.load_thresholds(self.path)
        with self.assertRaises(TypeError):
            snap.values["TBS_WARN"] = 1
        with self.assertRaises(Exception):
            snap.sha256 = "x"
        rec = snap.to_record()
        self.assertEqual((rec["sha256"], rec["source"], rec["values"]), (snap.sha256, str(self.path), ORIGINAL))
        self.assertEqual(snap["TBS_WARN"], 70)

    def test_edits_after_loading_do_not_change_the_snapshot_but_the_next_load_sees_them(self):
        self.put(self.doc())
        snap = t.load_thresholds(self.path)
        self.put(self.doc(TBS_WARN=60))
        self.assertEqual(snap["TBS_WARN"], 70)
        again = t.load_thresholds(self.path)
        self.assertEqual(again["TBS_WARN"], 60)
        self.assertNotEqual(again.sha256, snap.sha256)

    def test_descriptions_and_key_order_in_the_file_do_not_matter(self):
        doc = self.doc()
        doc["thresholds"] = dict(reversed(list(doc["thresholds"].items())))
        doc["descriptions"] = {"TBS_WARN": "my note"}
        snap = t.load_thresholds(self.put(doc))
        self.assertEqual(list(snap.values), list(t.KEYS))


class FileProblems(Case):
    def test_missing_file_is_an_error_not_a_default(self):
        with self.assertRaises(ThresholdsMissingError) as cm:
            t.load_thresholds(self.path)
        self.assertIn("thresholds.json", str(cm.exception))
        self.assertFalse(self.path.exists())

    def test_invalid_json_is_reported_after_one_retry(self):
        sleeps = []
        with mock.patch.object(t, "_sleep", sleeps.append):
            with self.assertRaises(ThresholdsInvalidError):
                t.load_thresholds(self.put("{ not json"))
        self.assertEqual(sleeps, [0.25])

    def test_a_file_that_is_being_written_is_picked_up_by_the_retry(self):
        self.put("{ half written")

        def finish_writing(_seconds):
            self.put(self.doc())

        with mock.patch.object(t, "_sleep", finish_writing):
            self.assertEqual(t.load_thresholds(self.path)["TBS_WARN"], 70)

    def test_validation_problems_are_not_retried(self):
        with mock.patch.object(t, "_sleep", side_effect=AssertionError("must not sleep")):
            self.assertTrue(self.problems_for(TBS_WARN=0))

    def test_bom_utf16_and_non_object_documents(self):
        self.path.parent.mkdir(parents=True)
        self.path.write_bytes(b"\xef\xbb\xbf" + json.dumps(self.doc()).encode())
        self.assertEqual(t.load_thresholds(self.path)["TBS_WARN"], 70)
        for raw in (json.dumps(self.doc()).encode("utf-16"), b"[1, 2]", b"null", b"", b"\xff\xfe\x00"):
            self.path.write_bytes(raw)
            with mock.patch.object(t, "_sleep", lambda s: None), self.assertRaises(ThresholdsInvalidError):
                t.load_thresholds(self.path)

    def test_deeply_nested_json_does_not_crash(self):
        self.path.parent.mkdir(parents=True)
        self.path.write_text("[" * 100000, encoding="utf-8")
        with mock.patch.object(t, "_sleep", lambda s: None), self.assertRaises(ThresholdsInvalidError):
            t.load_thresholds(self.path)

    def test_duplicate_unknown_and_missing_keys(self):
        dup = '{"schema_version": 1, "thresholds": {"TBS_WARN": 1, "TBS_WARN": 2}}'
        with self.assertRaises(ThresholdsInvalidError) as cm:
            t.load_thresholds(self.put(dup))
        self.assertIn("duplicate key 'TBS_WARN'", str(cm.exception))
        doc = self.doc()
        doc["thresholds"]["TBS_WARNN"] = 5
        del doc["thresholds"]["FRA_CRIT"]
        doc["extra"] = 1
        with self.assertRaises(ThresholdsInvalidError) as cm:
            t.load_thresholds(self.put(doc))
        text = str(cm.exception)
        for fragment in ("TBS_WARNN: unknown key", "FRA_CRIT: missing", "unknown top-level key 'extra'"):
            self.assertIn(fragment, text)

    def test_schema_version_rules(self):
        for version in (None, True, "1", 0, 2):
            doc = self.doc()
            if version is None:
                del doc["schema_version"]
            else:
                doc["schema_version"] = version
            with self.assertRaises(ThresholdsInvalidError, msg=repr(version)):
                t.load_thresholds(self.put(doc))

    def test_all_problems_are_reported_together_with_their_key_names(self):
        problems = self.problems_for(TBS_WARN="70", FRA_WARN=70.5, DISK_WARN=True, LOCK_WAIT_SEC=None, RETENTION_DAYS=0)
        joined = "\n".join(problems)
        for key in ("TBS_WARN", "FRA_WARN", "DISK_WARN", "LOCK_WAIT_SEC", "RETENTION_DAYS"):
            self.assertIn(key, joined)
        self.assertGreaterEqual(len(problems), 5)


class ValueRules(Case):
    def test_retention_days_range(self):
        for ok in (1, 30, 90, 120, 3650):
            self.assertEqual(self.problems_for(RETENTION_DAYS=ok), [], ok)
        for bad in (0, -1, -30, 3651, 99999999, "30", 30.0, 30.5, None, True, [30]):
            self.assertTrue(self.problems_for(RETENTION_DAYS=bad), repr(bad))

    def test_integer_ranges_for_every_numeric_key(self):
        for spec in t.SPECS:
            if spec.pattern is not None:
                continue
            for bad in (spec.low - 1, spec.high + 1, "5", 5.5, False, None):
                self.assertTrue(self.problems_for(**{spec.key: bad}), f"{spec.key}={bad!r}")

    def test_warn_must_be_below_crit_for_every_pair(self):
        for low, high in t.ASCENDING_PAIRS:
            for lo_v, hi_v in ((50, 50), (60, 40)):
                self.assertTrue(self.problems_for(**{low: lo_v, high: hi_v}), f"{low}={lo_v} {high}={hi_v}")
            self.assertEqual(self.problems_for(**{low: 10, high: 11}), [], low)

    def test_user_expiry_ordering_is_inverse(self):
        self.assertEqual(self.problems_for(USER_EXPIRY_WARNING_DAYS=30, USER_EXPIRY_CRITICAL_DAYS=20), [])
        for warn, crit in ((20, 20), (10, 20)):
            problems = self.problems_for(USER_EXPIRY_WARNING_DAYS=warn, USER_EXPIRY_CRITICAL_DAYS=crit)
            self.assertTrue(any("must be higher than" in p for p in problems), (warn, crit))

    def test_sys_expiry_status_is_safe_for_sql_substitution(self):
        for ok in ("EXPIRED(GRACE)", "EXPIRED", "LOCKED(TIMED)", "OPEN", "X_1 Y"):
            self.assertEqual(self.problems_for(SYS_EXPIRY_CRIT_STATUS=ok), [], ok)
        for bad in ("", "x'; drop table t; --", "A'B", '"', "&LOCKED", "A;B", "A--B", "expired", "A\nB", "A" * 41, 5, None):
            self.assertTrue(self.problems_for(SYS_EXPIRY_CRIT_STATUS=bad), repr(bad))

    def test_data_movement_dbs_is_restricted_even_though_unused(self):
        for ok in ("IMS RPP", "", "IMS,RPP"):
            self.assertEqual(self.problems_for(DATA_MOVEMENT_DBS=ok), [], ok)
        for bad in ("A'B", "A&B", "A;B", "A" * 201, 1):
            self.assertTrue(self.problems_for(DATA_MOVEMENT_DBS=bad), repr(bad))


class SaveAndCli(Case):
    def test_save_validates_before_writing_anything(self):
        with self.assertRaises(ThresholdsInvalidError):
            t.save_thresholds(self.path, {**ORIGINAL, "TBS_WARN": 95})
        self.assertFalse(self.path.exists())
        t.write_default(self.path)
        before = self.path.read_bytes()
        with self.assertRaises(ThresholdsInvalidError):
            t.save_thresholds(self.path, {**ORIGINAL, "RETENTION_DAYS": 0})
        self.assertEqual(self.path.read_bytes(), before)

    def test_save_then_load_round_trips_and_leaves_no_temp_file(self):
        sha = t.save_thresholds(self.path, {**ORIGINAL, "RETENTION_DAYS": 120, "TBS_WARN": 65})
        snap = t.load_thresholds(self.path)
        self.assertEqual((snap["RETENTION_DAYS"], snap["TBS_WARN"], snap.sha256), (120, 65, sha))
        self.assertEqual([p.name for p in self.path.parent.iterdir()], ["thresholds.json"])

    def test_failed_write_keeps_the_old_file_and_cleans_up(self):
        t.write_default(self.path)
        before = self.path.read_bytes()
        with mock.patch("os.replace", side_effect=PermissionError(13, "Access is denied")):
            with self.assertRaises(ThresholdsError) as cm:
                t.save_thresholds(self.path, {**ORIGINAL, "RETENTION_DAYS": 90})
        self.assertIn("Cannot write", str(cm.exception))
        self.assertEqual(self.path.read_bytes(), before)
        self.assertEqual([p.name for p in self.path.parent.iterdir()], ["thresholds.json"])

    def run_cli(self, *argv):
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            code = t.main(list(argv))
        return code, out.getvalue()

    def test_cli_write_default_check_and_errors(self):
        code, out = self.run_cli("--write-default", str(self.path))
        self.assertEqual(code, 0)
        self.assertIn("sha256", out)
        self.assertEqual(self.run_cli("--write-default", str(self.path))[0], 1)
        code, out = self.run_cli("--check", str(self.path))
        self.assertEqual((code, out.startswith("OK: 22 keys")), (0, True))
        self.put(self.doc(TBS_WARN=99))
        code, out = self.run_cli("--check", str(self.path))
        self.assertEqual(code, 1)
        self.assertIn("TBS_WARN", out)
        self.assertEqual(self.run_cli("--bogus")[0], 2)
        self.assertEqual(self.run_cli("--check", str(self.dir / "nope.json"))[0], 1)


if __name__ == "__main__":
    unittest.main()