"""AWR: validation, snapshot parsing/pairing, history discovery, the unmodified script, the SQL*Plus session commands and the
service (fake session only - real Oracle has NOT been exercised by these tests)."""
import hashlib
import os
import re
import shutil
import tempfile
import threading
import time
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest import mock

from ohc import awr, awr_service
from ohc.checks.cancel import CancelToken
from ohc.checks.session import AWR_SNAP_SQL, EXE, OracleSession, ToolError
from ohc.config import environment, thresholds
from ohc.resources import sql_access
from ohc.security import credstore
from ohc.security.credstore import Credentials
from tests.test_gui_run import make_ctx

ROOT = Path(__file__).resolve().parent.parent


def make_awr_ctx(root: Path, names=("ims",)):
    """Project folder with config files, database profiles and stored (fake-backend) credentials."""
    ctx = make_ctx(root, with_db=False)
    environment.write_default(ctx.environment_path)
    thresholds.write_default(ctx.thresholds_path)
    from ohc.config.databases import DatabaseEntry
    for name in names:
        entry = DatabaseEntry(id=credstore.new_database_id(), name=name)
        ctx.databases.add(entry)
        credstore.save_credentials(ctx.credentials_dir, entry.id, "sys", "pw", backend=ctx.backend)
    return ctx


def snap(i, hour=0, startup=None, inst=1):
    b = datetime(2026, 10, 15, 0, 0, 7) + timedelta(hours=hour)
    return awr.Snap(i, b, b + timedelta(hours=1), inst, startup)


class Validation(unittest.TestCase):
    def test_days(self):
        for ok in (1, 7, "365", " 30 "):
            self.assertIn(awr.validate_days(ok), (1, 7, 365, 30))
        for bad in (0, 366, -1, "", "abc", "1.5", None, "7 days"):
            with self.assertRaises(awr.AwrError, msg=repr(bad)):
                awr.validate_days(bad)

    def test_range_rules(self):
        loaded = [snap(10, 0), snap(11, 1), snap(12, 2)]
        self.assertFalse(awr.check_range("", "", loaded).ok)
        self.assertFalse(awr.check_range("10", "", loaded).ok)
        self.assertFalse(awr.check_range("", "11", loaded).ok)
        for b, e in (("abc", "11"), ("10", "x1"), ("-1", "5"), ("1.5", "9"), ("10 ", "1e3")):
            r = awr.check_range(b, e, loaded)
            self.assertEqual((r.ok, r.level), (False, "bad"), (b, e))
        self.assertFalse(awr.check_range("11", "10", loaded).ok)
        self.assertFalse(awr.check_range("10", "10", loaded).ok)
        good = awr.check_range("10", "12", loaded)
        self.assertTrue(good.ok)
        self.assertEqual((good.begin, good.end, good.level), (10, 12, "muted"))

    def test_ids_outside_the_loaded_list_are_allowed_with_a_warning(self):
        r = awr.check_range("5", "11", [snap(10), snap(11)])
        self.assertTrue(r.ok)
        self.assertEqual(r.level, "warn")
        self.assertIn("not in the loaded list", r.message)
        self.assertTrue(awr.check_range("10", "999", [snap(10), snap(11)]).ok)

    def test_restart_warning_only_when_both_are_loaded_and_startups_differ(self):
        a, b = datetime(2026, 10, 1), datetime(2026, 10, 15, 3)
        loaded = [snap(1, 0, a), snap(2, 1, a), snap(3, 2, b)]
        self.assertEqual(awr.check_range("1", "2", loaded).level, "muted")
        r = awr.check_range("2", "3", loaded)
        self.assertTrue(r.ok)
        self.assertEqual(r.level, "warn")
        self.assertIn("restarted", r.message)
        self.assertNotIn("restarted", awr.check_range("2", "77", loaded).message)   # 77 is unknown: cannot be determined


class SnapshotList(unittest.TestCase):
    def test_pairs_sequential_without_repeats_and_odd_tail(self):
        rows = awr.pair_rows([snap(i, i) for i in range(1, 6)])
        self.assertEqual([(l.snap_id, r.snap_id if r else None) for l, r in rows], [(1, 2), (3, 4), (5, None)])
        self.assertEqual(awr.pair_rows([]), [])
        self.assertEqual(len(awr.pair_rows([snap(i, i) for i in range(1, 5)])), 2)

    def test_duration_text(self):
        self.assertEqual(awr.row_duration(snap(1, 0), snap(2, 1)), "60 mins")
        self.assertEqual(awr.row_duration(snap(1, 0), None), "-")
        self.assertEqual(awr.format_duration(600), "10h 00m")

    def test_parse(self):
        text = "SNAP|9002|2026-10-15 01:00:07|2026-10-15 02:00:07|1|2026-09-01 00:00:03\nSNAP|9001|2026-10-15 00:00:07|2026-10-15 01:00:07|1|\nSNAPDONE\n"
        found = awr.parse_snapshots(text)
        self.assertEqual([s.snap_id for s in found.snaps], [9001, 9002])       # sorted ascending
        self.assertIsNone(found.snaps[0].startup)
        self.assertEqual(found.snaps[1].startup, datetime(2026, 9, 1, 0, 0, 3))
        self.assertFalse(found.capped)
        self.assertEqual(awr.parse_snapshots("SNAPDONE\n").snaps, [])

    def test_cap_keeps_the_newest_2000_and_says_so(self):
        rows = [f"SNAP|{i}|2026-10-15 00:00:07|2026-10-15 01:00:07|1|" for i in range(2001, 0, -1)]
        found = awr.parse_snapshots("\n".join(rows + ["SNAPDONE"]))
        self.assertTrue(found.capped)
        self.assertEqual((len(found.snaps), found.snaps[0].snap_id, found.snaps[-1].snap_id), (2000, 2, 2001))

    def test_errors_are_reported_not_swallowed(self):
        with self.assertRaises(awr.AwrError) as cm:
            awr.parse_snapshots("ERROR at line 5:\nORA-00942: table or view does not exist\nSP2-0310: unable to open file\n")
        self.assertIn("ORA-00942", str(cm.exception))
        self.assertIn("SP2-0310", str(cm.exception))
        with self.assertRaises(awr.AwrError):
            awr.parse_snapshots("")


class ReportFiles(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)

    def put(self, rel, size=10):
        p = self.tmp / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b"x" * size)
        return p

    def test_discovers_reports_in_any_date_folder_and_ignores_other_files(self):
        a = self.put("2026-10-16/AWR_Report_9235_9236_20261016_012216.html")
        b = self.put("16.10.2026/AWR_Report_9230_9237_20261014_231025.html", 2048)
        top = self.put("AWR_Report_1_2_20261001_000000.html")
        self.put("2026-10-16/ims_health_20261016_010000.html")      # a health report: not an AWR report
        self.put("2026-10-16/AWR_Report_a_b_20261016_012216.html")  # not numeric
        self.put("2026-10-16/AWR_Report_1_2_20261340_000000.html")  # impossible date
        scan = awr.scan_history(self.tmp)
        self.assertEqual([e.path for e in scan.entries], [a, b, top])             # newest first
        self.assertEqual((scan.entries[0].begin, scan.entries[0].end, scan.entries[0].db), (9235, 9236, "-"))
        self.assertEqual(scan.entries[1].size, 2048)
        self.assertEqual(scan.entries[0].range_text, "9235 - 9236")

    def test_missing_folder_and_index(self):
        self.assertFalse(awr.scan_history(self.tmp / "nope").exists)
        p = self.put("2026-10-16/AWR_Report_9_10_20261016_012216.html")
        self.assertEqual(awr.record_report(self.tmp, p, "ORCL", False), "")
        self.assertEqual(awr.scan_history(self.tmp).entries[0].db, "ORCL")
        (self.tmp / awr.INDEX_NAME).write_text("{ not json", encoding="utf-8")        # a damaged index never breaks the list
        self.assertEqual(awr.scan_history(self.tmp).entries[0].db, "-")

    def test_filter(self):
        self.put("2026-10-16/AWR_Report_9235_9236_20261016_012216.html")
        self.put("2026-10-14/AWR_Report_9230_9237_20261014_231025.html")
        entries = awr.scan_history(self.tmp).entries
        self.assertEqual(awr.dates_of(entries), ["2026-10-16", "2026-10-14"])
        self.assertEqual(len(awr.filter_entries(entries, "2026-10-14", "")), 1)
        self.assertEqual(len(awr.filter_entries(entries, "", "9237")), 1)
        self.assertEqual(len(awr.filter_entries(entries, "", "9230 - 9237")), 1)
        self.assertEqual(awr.filter_entries(entries, "2026-10-16", "9237"), [])

    def test_report_file_validation(self):
        good = self.put("a.html", 0)
        good.write_text("<!DOCTYPE html><html><body>" + "x" * 6000 + "</body></html>", encoding="utf-8")
        awr.check_report_file(good)
        bad = self.tmp / "b.html"
        bad.write_text("ORA-20019: Invalid snapshot IDs\nORA-06512: at line 1\n", encoding="utf-8")
        with self.assertRaises(awr.AwrError) as cm:
            awr.check_report_file(bad)
        self.assertIn("ORA-20019", str(cm.exception))
        tiny = self.tmp / "c.html"
        tiny.write_text("<html>ORA-00600: internal error</html>", encoding="utf-8")
        with self.assertRaises(awr.AwrError):
            awr.check_report_file(tiny)


class OriginalScript(unittest.TestCase):
    def test_script_is_byte_for_byte_the_original(self):
        recorded = dict(reversed(l.split()) for l in (ROOT / "tools" / "original_sql.sha256").read_text().splitlines() if l.strip())
        self.assertEqual(hashlib.sha256((ROOT / "sql_src" / "AWR_Report.sql").read_bytes()).hexdigest(), recorded["AWR_Report.sql"])
        self.assertEqual(hashlib.sha256(sql_access.get_sql("AWR_Report.sql")).hexdigest(), recorded["AWR_Report.sql"])
        self.assertEqual(recorded["AWR_Report.sql"], "cfad647ea30215c4c7b6645916cec513d56ca92037ae0498dd26a289ec996d8b")
        self.assertEqual(sql_access.verify(), [])


class ReportNames(unittest.TestCase):
    def test_valid_names(self):
        for good in ("prod_peak", "AWR-2026_10", awr.default_name(1, 2), awr.NAME_TOKEN, "x" * 100):
            self.assertEqual(awr.check_report_name(good, "html"), "", good)
            self.assertEqual(awr.check_report_name(good, "text"), "", good)

    def test_invalid_names(self):
        bad = ("", "../x", "..", "a/b", "a\\b", "C:x", "\\\\srv\\share\\x", "a.b", "x.html", "x.txt", "a b", " a", "a&b", "it's", 'a"b', "a;b", "a|b",
               "CON", "con", "NUL", "COM1", "lpt9", "x" * 101, awr.NAME_TOKEN * 2, "é")
        for name in bad:
            self.assertNotEqual(awr.check_report_name(name, "html"), "", repr(name))
        self.assertNotEqual(awr.check_report_name("ok", "pdf"), "")

    def test_existing_file_is_refused_per_extension(self):
        tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, tmp, True)
        (tmp / "taken.html").write_text("x")
        self.assertIn("already exists", awr.check_report_name("taken", "html", tmp))
        self.assertEqual(awr.check_report_name("taken", "text", tmp), "")
        self.assertEqual(awr.check_report_name("taken_" + awr.NAME_TOKEN, "html", tmp), "")

    def test_defaults_and_token(self):
        self.assertEqual(awr.default_name(9, 10), "AWR_Report_9_10_<yyyymmdd_HHMMSS>")
        self.assertEqual(awr.resolve_name(awr.default_name(9, 10), datetime(2026, 10, 16, 1, 22, 16)), "AWR_Report_9_10_20261016_012216")

    def test_text_report_check(self):
        tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, tmp, True)
        good = tmp / "a.txt"
        good.write_text("WORKLOAD REPOSITORY report for\n" + "x" * 3000)
        awr.check_report_file(good, "text")
        bad = tmp / "b.txt"
        bad.write_text("ORA-20019: Invalid snapshot IDs\n")
        with self.assertRaises(awr.AwrError) as cm:
            awr.check_report_file(bad, "text")
        self.assertIn("ORA-20019", str(cm.exception))

    def test_history_lists_text_and_custom_named_reports(self):
        tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, tmp, True)
        (tmp / "2026-10-16").mkdir()
        legacy_txt = tmp / "2026-10-16" / "AWR_Report_1_2_20261016_010101.txt"
        custom = tmp / "2026-10-16" / "peak_rac.txt"
        stray = tmp / "2026-10-16" / "notes.txt"
        for f in (legacy_txt, custom, stray):
            f.write_text("x")
        awr.record_report(tmp, custom, "ORCL", False, 5, 9, True, datetime(2026, 10, 16, 12, 0, 0))
        entries = {e.name: e for e in awr.scan_history(tmp).entries}
        self.assertEqual(set(entries), {"AWR_Report_1_2_20261016_010101.txt", "peak_rac.txt"})     # an unrelated file stays out
        self.assertEqual((entries["peak_rac.txt"].db, entries["peak_rac.txt"].range_text), ("ORCL", "5 - 9"))


class Proc:
    seen: list = []
    reply = b"Report generated at: x\r\n"

    def __init__(self, argv, **kw):
        Proc.seen.append([argv, kw])

    def communicate(self, data=None, timeout=None):
        Proc.seen[-1].append(bytes(data or b""))
        return Proc.reply, None


class SessionCommands(unittest.TestCase):
    def setUp(self):
        self.home = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.home, True)
        (self.home / "bin").mkdir()
        (self.home / "bin" / ("sqlplus" + EXE)).write_text("")
        Proc.seen, Proc.reply = [], b"fine\r\n"

    def make(self):
        return OracleSession(self.home, "IMS", Credentials(bytearray(b"sys"), bytearray(b"S3cret!pw")), popen=Proc)

    def test_awr_report_runs_the_original_script_and_the_password_stays_off_the_command_line(self):
        s = self.make()
        folder = Path("C:/x/reports/2026-10-16")        # str() gives backslashes on Windows, which SQL*Plus and the legacy script expect
        s.awr_report(folder, 7, 9235, 9236)
        argv, kw, stdin = Proc.seen[0]
        self.assertNotIn("S3cret!pw", " ".join(argv))
        self.assertEqual(argv[1:], ["-s", "/nolog"])
        text = stdin.decode()
        self.assertIn('S3cret!pw', text)
        self.assertLess(text.index("set define off"), text.index("connect sys"))
        self.assertIn(f"define rpt_dir='{folder}'", text)
        self.assertNotIn("define rpt_dir='C:/x", text if os.name == "nt" else "")   # no forward-slash rewriting on Windows
        self.assertEqual(text.split("\n")[-5:], ["7", "9235", "9236", "exit", ""])        # the three ACCEPT answers, in order
        script = re.search(r'@"([^"]+AWR_Report\.sql)"', text).group(1)
        self.assertEqual(hashlib.sha256(Path(script).read_bytes()).hexdigest(), "cfad647ea30215c4c7b6645916cec513d56ca92037ae0498dd26a289ec996d8b")
        run_dir = s.run_dir
        s.close()
        self.assertFalse(run_dir.exists())

    def test_variant_script_text_html_and_rac_use_the_right_oracle_call_and_never_the_original_script(self):
        expect = {("html", False): "AWR_REPORT_HTML(&v_dbid, &v_inst,", ("text", False): "AWR_REPORT_TEXT(&v_dbid, &v_inst,",
                  ("html", True): "AWR_GLOBAL_REPORT_HTML(&v_dbid, '&v_insts',", ("text", True): "AWR_GLOBAL_REPORT_TEXT(&v_dbid, '&v_insts',"}
        for (fmt, rac), call in expect.items():
            Proc.seen = []
            s = self.make()
            s.awr_report_variant(Path("C:/x/reports/d/my_name.txt"), fmt, rac, 11, 12)
            argv, kw, stdin = Proc.seen[0]
            text = stdin.decode()
            self.assertNotIn("S3cret!pw", " ".join(argv))
            self.assertIn("define v_begin=11\ndefine v_end=12\n", text)
            self.assertIn(f"define v_file='{Path('C:/x/reports/d/my_name.txt')}'", text)
            self.assertNotIn("AWR_Report.sql", text)
            script = re.search(r'@"([^"]+awr_variant\.sql)"', text).group(1)
            sql = Path(script).read_text()
            self.assertIn(call, sql, (fmt, rac))
            self.assertIn('SPOOL "&v_file" CREATE', sql)                # never overwrites an existing file
            self.assertEqual("LISTAGG" in sql, rac)
            s.close()
        s = self.make()
        for bad in ("C:/it's.txt", "C:/a&b.txt", 'C:/a"b.txt'):
            with self.assertRaises(ToolError):
                s.awr_report_variant(Path(bad), "text", False, 1, 2)
        s.close()

    def test_report_folder_with_unusable_characters_is_refused(self):
        s = self.make()
        for bad in ("C:/it's", "C:/a&b", 'C:/a"b'):
            with self.assertRaises(ToolError):
                s.awr_report(Path(bad), 7, 1, 2)
        self.assertEqual(Proc.seen, [])
        s.close()

    def test_snapshot_query_is_read_only_and_scoped_to_this_database_and_instance(self):
        s = self.make()
        s.awr_snapshots(14)
        stdin = Proc.seen[0][2].decode()
        self.assertIn("define awr_days=14", stdin)
        sql = AWR_SNAP_SQL.lower()
        for word in ("insert", "update", "delete", "merge", "drop", "alter", "truncate", "create", "grant", "begin", "exec", "dbms_"):
            self.assertIsNone(re.search(r"\b%s\b" % word, sql), word)
        self.assertIn("s.dbid = (select dbid from v$database)", sql)
        self.assertIn("s.instance_number = (select instance_number from v$instance)", sql)
        self.assertIn("begin_interval_time >= sysdate - &awr_days", sql)
        self.assertIn("rownum <= 2001", sql)
        self.assertIn("startup_time", sql)
        s.close()

    def test_service_never_reports_success_without_a_report_file(self):
        ctx = make_awr_ctx(Path(tempfile.mkdtemp()))
        self.addCleanup(shutil.rmtree, ctx.root, True)
        os.environ.pop("OHC_FAKE_ORACLE", None)
        with mock.patch("ohc.awr_service.launcher._prepare", return_value=(ctx.databases.find_by_name("ims"), str(self.home), environment.load_environment(ctx.environment_path), None)), \
                mock.patch("ohc.awr_service.launcher._open", side_effect=lambda *a, **k: self.make()):
            Proc.reply = b"Report generated at: nothing.html\r\nORA-20019: bad\r\n"
            r = awr_service.generate_report(ctx, "ims", 7, 1, 2)
            self.assertFalse(r.ok)
            self.assertIn("ORA-20019", r.detail)
            # SQL*Plus spools an error text into the file: not a report either, and it is removed
            created = []

            class Spooler(Proc):
                def communicate(self, data=None, timeout=None):
                    folder = Path(re.search(r"define rpt_dir='([^']+)'", data.decode()).group(1))
                    f = folder / "AWR_Report_1_2_20261016_010101.html"
                    f.write_text("ORA-20024: no snapshots\n", encoding="utf-8")
                    created.append(f)
                    return b"Report generated at: " + str(f).encode() + b"\r\n", None
            with mock.patch("ohc.awr_service.launcher._open", side_effect=lambda *a, **k: OracleSession(self.home, "IMS", Credentials(bytearray(b"sys"), bytearray(b"pw")), popen=Spooler)):
                r = awr_service.generate_report(ctx, "ims", 7, 1, 2)
            self.assertFalse(r.ok)
            self.assertIn("ORA-20024", r.detail)
            self.assertFalse(created[0].exists())

            class Good(Proc):
                def communicate(self, data=None, timeout=None):
                    folder = Path(re.search(r"define rpt_dir='([^']+)'", data.decode()).group(1))
                    f = folder / "AWR_Report_1_2_20261016_010102.html"
                    f.write_text("<html>" + "x" * 5000 + "</html>", encoding="utf-8")
                    return b"Report generated at: " + str(f).encode() + b"\r\n", None
            with mock.patch("ohc.awr_service.launcher._open", side_effect=lambda *a, **k: OracleSession(self.home, "IMS", Credentials(bytearray(b"sys"), bytearray(b"pw")), popen=Good)):
                r = awr_service.generate_report(ctx, "ims", 7, 1, 2)
            self.assertTrue(r.ok, r.detail)
            self.assertTrue(r.path.is_file())
            self.assertFalse(r.simulated)


class FakeService(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        env = mock.patch.dict(os.environ, {"OHC_FAKE_ORACLE": "healthy"})
        env.start()
        self.addCleanup(env.stop)
        os.environ.pop("OHC_FAKE_AWR", None)
        os.environ.pop("OHC_FAKE_DELAY", None)
        self.ctx = make_awr_ctx(self.tmp)

    def test_load_success_and_lookback_filter(self):
        r = awr_service.load_snapshots(self.ctx, "ims", 7)
        self.assertTrue(r.ok)
        self.assertTrue(r.simulated)
        self.assertTrue(r.message.startswith("SIMULATED DATA - "))
        self.assertEqual(len(r.snaps.snaps), 61)
        self.assertEqual(len(awr_service.load_snapshots(self.ctx, "ims", 1).snaps.snaps), 24)

    def test_invalid_days_never_reach_the_database(self):
        with mock.patch("ohc.awr_service.launcher._open") as opened:
            for bad in (0, 366, "x"):
                self.assertFalse(awr_service.load_snapshots(self.ctx, "ims", bad).ok)
            opened.assert_not_called()

    def test_scenarios(self):
        for mode, ok, text in (("empty", True, "No snapshots were found"), ("fail", False, "ORA-00942"), ("capped", True, "capped at 2,000")):
            with mock.patch.dict(os.environ, {"OHC_FAKE_AWR": mode}):
                r = awr_service.load_snapshots(self.ctx, "ims", 7)
            self.assertEqual(r.ok, ok, mode)
            self.assertIn(text, r.message + r.detail, mode)
        with mock.patch.dict(os.environ, {"OHC_FAKE_ORACLE": "down"}):
            r = awr_service.load_snapshots(self.ctx, "ims", 7)
        self.assertFalse(r.ok)
        self.assertIn("ORA-01034", r.detail)

    def test_generate_success_creates_the_legacy_named_file_and_remembers_the_database(self):
        ids = [s.snap_id for s in awr_service.load_snapshots(self.ctx, "ims", 7).snaps.snaps]
        r = awr_service.generate_report(self.ctx, "ims", 7, ids[0], ids[1])
        self.assertTrue(r.ok, r.detail)
        self.assertRegex(r.path.name, r"^AWR_Report_9001_9002_\d{8}_\d{6}\.html$")
        self.assertEqual(r.path.parent.parent, self.tmp / "reports")
        self.assertIn("FAKE / SIMULATED DATA", r.path.read_text(encoding="utf-8"))
        entry = awr.scan_history(self.tmp / "reports", index_dir=self.tmp / "config").entries[0]
        self.assertEqual((entry.path, entry.db, entry.simulated), (r.path, "ims", True))
        self.assertTrue((self.tmp / "config" / awr.INDEX_NAME).is_file())                    # the index lives in config ...
        self.assertFalse((self.tmp / "reports" / awr.INDEX_NAME).exists())                   # ... not in the reports folder

    def test_generate_failure_leaves_no_file_behind(self):
        r = awr_service.generate_report(self.ctx, "ims", 7, 1, 2)          # ids unknown to the (fake) repository
        self.assertFalse(r.ok)
        self.assertIn("ORA-20019", r.detail)
        self.assertEqual(awr.scan_history(self.tmp / "reports", index_dir=self.tmp / "config").entries, [])
        self.assertFalse(awr_service.generate_report(self.ctx, "ims", 7, 9005, 9001).ok)

    def test_default_html_still_uses_the_original_script_and_the_variants_do_not(self):
        from ohc.checks.fake import FakeOracleSession as F
        ids = (9001, 9002)
        with mock.patch.object(F, "awr_report", autospec=True, side_effect=F.awr_report) as legacy, \
                mock.patch.object(F, "awr_report_variant", autospec=True, side_effect=F.awr_report_variant) as variant:
            self.assertTrue(awr_service.generate_report(self.ctx, "ims", 7, *ids).ok)
            self.assertEqual((legacy.call_count, variant.call_count), (1, 0))
            time.sleep(1.05)
            self.assertTrue(awr_service.generate_report(self.ctx, "ims", 7, *ids, name="renamed").ok)     # HTML + custom name: original script
            self.assertEqual((legacy.call_count, variant.call_count), (2, 0))
            for name, kw in (("v_text", {"fmt": "text"}), ("v_rac", {"rac": True}), ("v_both", {"fmt": "text", "rac": True})):
                self.assertTrue(awr_service.generate_report(self.ctx, "ims", 7, *ids, name=name, **kw).ok, kw)
            self.assertEqual((legacy.call_count, variant.call_count), (2, 3))

    def test_format_name_and_rac_produce_the_matching_files(self):
        folder = awr_service.report_folder(self.ctx)
        r = awr_service.generate_report(self.ctx, "ims", 7, 9001, 9002, name="my_html")
        self.assertEqual(r.path, folder / "my_html.html")
        self.assertTrue(r.ok and not list(folder.glob("AWR_Report_*")))
        entry = awr.scan_history(self.tmp / "reports", index_dir=self.tmp / "config").entries[0]
        self.assertEqual((entry.name, entry.range_text, entry.db), ("my_html.html", "9001 - 9002", "ims"))
        r = awr_service.generate_report(self.ctx, "ims", 7, 9001, 9002, fmt="text")           # default name, Text
        self.assertRegex(r.path.name, r"^AWR_Report_9001_9002_\d{8}_\d{6}\.txt$")
        self.assertIn("WORKLOAD REPOSITORY", r.path.read_text(encoding="utf-8"))
        r = awr_service.generate_report(self.ctx, "ims", 7, 9001, 9002, fmt="text", rac=True, name="rac_txt")
        self.assertIn("RAC (all instances", r.path.read_text(encoding="utf-8"))
        r = awr_service.generate_report(self.ctx, "ims", 7, 9001, 9002, fmt="html", rac=True, name="rac_html")
        self.assertIn("RAC (all instances", r.path.read_text(encoding="utf-8"))
        self.assertTrue(r.path.suffix == ".html")

    def test_invalid_or_existing_names_stop_before_the_database_is_touched(self):
        folder = awr_service.report_folder(self.ctx)
        folder.mkdir(parents=True)
        (folder / "taken.html").write_text("precious")
        with mock.patch("ohc.awr_service.launcher._open") as opened:
            for name in ("../evil", "a/b", "x.html", "CON", "", "taken"):
                r = awr_service.generate_report(self.ctx, "ims", 7, 9001, 9002, name=name)
                self.assertFalse(r.ok, name)
            self.assertFalse(awr_service.generate_report(self.ctx, "ims", 7, 9001, 9002, fmt="pdf").ok)
            opened.assert_not_called()
        self.assertEqual((folder / "taken.html").read_text(), "precious")
        self.assertEqual(list(folder.parent.rglob("evil*")), [])

    def test_cancelled_variant_removes_only_its_own_file(self):
        folder = awr_service.report_folder(self.ctx)
        token, result = CancelToken(), []
        os.environ["OHC_FAKE_DELAY"] = "1"
        t = threading.Thread(target=lambda: result.append(awr_service.generate_report(self.ctx, "ims", 7, 9001, 9002, token, "text", "mine")))
        t.start()
        end = time.time() + 5
        while time.time() < end and not (folder / "mine.txt").exists():
            time.sleep(0.01)
        self.assertTrue((folder / "mine.txt").exists())
        token.request()
        t.join(10)
        self.assertTrue(result[0].cancelled)
        self.assertFalse((folder / "mine.txt").exists())

    def test_failed_variant_reports_the_oracle_error_and_leaves_no_file(self):
        folder = awr_service.report_folder(self.ctx)
        with mock.patch.dict(os.environ, {"OHC_FAKE_AWR": "badreport"}):
            r = awr_service.generate_report(self.ctx, "ims", 7, 9001, 9002, fmt="text", rac=True, name="bad_one")
        self.assertFalse(r.ok)
        self.assertIn("ORA-20019", r.detail)
        self.assertFalse((folder / "bad_one.txt").exists())

    def test_fake_snapshots_share_one_startup_at_any_time_of_day(self):
        """Regression: the fake startup followed each row's calendar day, so a range across midnight looked like an instance restart
        and the 'valid range' tests failed depending on the time of day they ran."""
        from ohc.checks.fake import FakeOracleSession as F
        fake = object.__new__(F)
        for hour in range(24):
            rows = fake._awr_rows(datetime(2026, 10, 19, hour, 30))
            self.assertEqual(len({r[4] for r in rows}), 1, hour)
            snaps = [awr.Snap(r[0], r[1], r[2], r[3], r[4]) for r in rows]
            for b, e in ((9001, 9004), (9001, 9002), (9003, 9061)):
                self.assertEqual(awr.check_range(str(b), str(e), snaps).level, "muted", (hour, b, e))
        with mock.patch.dict(os.environ, {"OHC_FAKE_AWR": "restart"}):             # the restart scenario still has two startups
            rows = fake._awr_rows(datetime(2026, 10, 19, 12, 30))
            self.assertEqual(len({r[4] for r in rows}), 2)
            snaps = [awr.Snap(r[0], r[1], r[2], r[3], r[4]) for r in rows]
            self.assertEqual(awr.check_range("9001", "9061", snaps).level, "warn")

    def test_cancel_removes_the_incomplete_file_and_is_not_a_failure(self):
        token, result = CancelToken(), []
        os.environ["OHC_FAKE_DELAY"] = "1"
        t = threading.Thread(target=lambda: result.append(awr_service.generate_report(self.ctx, "ims", 7, 9001, 9002, token)))
        t.start()
        end = time.time() + 5
        while time.time() < end and not list((self.tmp / "reports").rglob("AWR_Report_*.html")):
            time.sleep(0.01)
        self.assertTrue(list((self.tmp / "reports").rglob("AWR_Report_*.html")), "the partial file should exist while it runs")
        token.request()
        t.join(10)
        self.assertFalse(t.is_alive())
        self.assertTrue(result[0].cancelled)
        self.assertFalse(result[0].ok)
        self.assertEqual(list((self.tmp / "reports").rglob("AWR_Report_*.html")), [])

    def test_cancel_while_loading(self):
        token, result = CancelToken(), []
        os.environ["OHC_FAKE_DELAY"] = "1"
        t = threading.Thread(target=lambda: result.append(awr_service.load_snapshots(self.ctx, "ims", 7, token)))
        t.start()
        time.sleep(0.15)
        token.request()
        t.join(10)
        self.assertTrue(result[0].cancelled)
        self.assertIsNone(result[0].snaps)

    def test_an_earlier_report_of_the_same_range_survives_a_failed_run(self):
        first = awr_service.generate_report(self.ctx, "ims", 7, 9001, 9002)
        with mock.patch.dict(os.environ, {"OHC_FAKE_AWR": "badreport"}):
            time.sleep(1.05)
            self.assertFalse(awr_service.generate_report(self.ctx, "ims", 7, 9001, 9002).ok)
        self.assertTrue(first.path.is_file())


if __name__ == "__main__":
    unittest.main()
