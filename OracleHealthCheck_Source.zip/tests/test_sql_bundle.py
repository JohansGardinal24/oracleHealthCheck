"""Tests for the SQL bundle, its integrity checks and the approved-changes record.

Run from the project root:
    python -m unittest discover -s tests -t . -v
"""
import hashlib
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from ohc.resources import sql_access, sql_bundle
from tools import gen_sql_bundle, sql_baseline


def h(ch: str) -> str:
    return ch * 64


class BundleMatchesSource(unittest.TestCase):
    def test_bundle_file_is_current_with_sql_src(self):
        fresh = gen_sql_bundle.build().text.encode("ascii")
        self.assertEqual(gen_sql_bundle.OUT.read_bytes(), fresh,
                         "sql_bundle.py is out of date: run python tools\\gen_sql_bundle.py")

    def test_generation_is_deterministic(self):
        self.assertEqual(gen_sql_bundle.build().text, gen_sql_bundle.build().text)

    def test_bundled_bytes_equal_files_on_disk(self):
        on_disk = {p.name: p.read_bytes() for p in gen_sql_bundle.SRC.glob("*.sql")}
        self.assertEqual(set(on_disk), set(sql_bundle.SQL_FILES))
        for name, data in on_disk.items():
            self.assertEqual(sql_bundle.SQL_FILES[name][1], data, name)

    def test_generated_module_text_roundtrips_exactly(self):
        ns = {}
        exec(compile(gen_sql_bundle.build().text, "<bundle>", "exec"), ns)
        for name, (sha, data) in gen_sql_bundle.build().files.items():
            self.assertEqual(ns["SQL_FILES"][name], (sha, data))


class GeneratorRejectsBadInput(unittest.TestCase):
    def _build(self, files):
        with tempfile.TemporaryDirectory() as d:
            for name, data in files.items():
                (Path(d) / name).write_bytes(data)
            return gen_sql_bundle.build(Path(d))

    def test_bom_is_rejected(self):
        with self.assertRaises(SystemExit):
            self._build({"a.sql": b"\xef\xbb\xbfselect 1 from dual;\n"})

    def test_empty_file_is_rejected(self):
        with self.assertRaises(SystemExit):
            self._build({"a.sql": b""})

    def test_non_sql_file_is_rejected(self):
        with self.assertRaises(SystemExit):
            self._build({"a.sql": b"select 1 from dual;\n", "a.sql.bak": b"x"})

    def test_crlf_gives_warning_but_keeps_bytes(self):
        b = self._build({"a.sql": b"select 1\r\nfrom dual;\r\n"})
        self.assertEqual(len(b.warnings), 1)
        self.assertEqual(b.files["a.sql"][1], b"select 1\r\nfrom dual;\r\n")


class RuntimeAccessAndTamperDetection(unittest.TestCase):
    def test_verify_is_clean(self):
        self.assertEqual(sql_access.verify(), [])

    def test_get_sql_returns_exact_bytes(self):
        name = sql_access.list_sql()[0]
        self.assertEqual(sql_access.get_sql(name), sql_bundle.SQL_FILES[name][1])

    def test_unknown_and_path_like_names_are_not_found(self):
        for bad in ("nope.sql", "..\\x.sql", "../x.sql", ""):
            with self.assertRaises(sql_access.SqlNotFoundError):
                sql_access.get_sql(bad)

    def test_modified_script_is_detected(self):
        name = sql_access.list_sql()[0]
        sha, data = sql_bundle.SQL_FILES[name]
        with mock.patch.dict(sql_bundle.SQL_FILES, {name: (sha, data + b"-- tampered\n")}):
            self.assertTrue(sql_access.verify())
            with self.assertRaises(sql_access.SqlIntegrityError):
                sql_access.get_sql(name)

    def test_modified_script_with_updated_file_hash_still_fails_bundle_hash(self):
        name = sql_access.list_sql()[0]
        new = sql_bundle.SQL_FILES[name][1] + b"-- tampered\n"
        with mock.patch.dict(sql_bundle.SQL_FILES, {name: (hashlib.sha256(new).hexdigest(), new)}):
            problems = sql_access.verify()
            self.assertTrue(any("bundle SHA-256" in p for p in problems), problems)


class ApprovedChangesLogic(unittest.TestCase):
    def rec(self, action, sha, reason="2026-01-01 deliberate change for testing"):
        return {"action": action, "sha": sha, "reason": reason}

    def test_unchanged_is_clean(self):
        problems, status = sql_baseline.evaluate({"a.sql": h("1")}, {"a.sql": h("1")}, {})
        self.assertEqual((problems, status["a.sql"]), ([], "unchanged"))

    def test_unrecorded_change_is_flagged(self):
        problems, status = sql_baseline.evaluate({"a.sql": h("1")}, {"a.sql": h("2")}, {})
        self.assertEqual(status["a.sql"], "UNAPPROVED CHANGED")
        self.assertEqual(len(problems), 1)

    def test_recorded_change_with_correct_hash_passes(self):
        problems, status = sql_baseline.evaluate(
            {"a.sql": h("1")}, {"a.sql": h("2")}, {"a.sql": self.rec("CHANGED", h("2"))})
        self.assertEqual((problems, status["a.sql"]), ([], "approved CHANGED"))

    def test_change_after_approval_is_flagged(self):
        problems, _ = sql_baseline.evaluate(
            {"a.sql": h("1")}, {"a.sql": h("3")}, {"a.sql": self.rec("CHANGED", h("2"))})
        self.assertTrue(any("differs from its recorded hash" in p for p in problems))

    def test_placeholder_or_short_reason_is_flagged(self):
        for reason in ("REASON: describe what changed and why", "short"):
            problems, _ = sql_baseline.evaluate(
                {"a.sql": h("1")}, {"a.sql": h("2")}, {"a.sql": self.rec("CHANGED", h("2"), reason)})
            self.assertEqual(len(problems), 1, reason)

    def test_added_and_removed_need_records(self):
        problems, _ = sql_baseline.evaluate({"o.sql": h("1")}, {"n.sql": h("2")}, {})
        self.assertEqual(len(problems), 2)
        problems, status = sql_baseline.evaluate(
            {"o.sql": h("1")}, {"n.sql": h("2")},
            {"n.sql": self.rec("ADDED", h("2")), "o.sql": self.rec("REMOVED", "-")})
        self.assertEqual((problems, status["n.sql"], status["o.sql"]), ([], "approved ADDED", "approved REMOVED"))

    def test_stale_record_for_unchanged_file_is_flagged(self):
        problems, _ = sql_baseline.evaluate(
            {"a.sql": h("1")}, {"a.sql": h("1")}, {"a.sql": self.rec("CHANGED", h("1"))})
        self.assertEqual(len(problems), 1)

    def test_changes_file_parsing_errors(self):
        text = "CHANGED | a.sql | " + h("a") + " | long enough reason\nbogus line\nDELETE | b.sql | x | y\n" \
               "CHANGED | a.sql | " + h("a") + " | duplicate line here\n"
        records, problems = sql_baseline.parse_changes(text)
        self.assertEqual(list(records), ["a.sql"])
        self.assertEqual(len(problems), 3)

    def test_changes_file_comments_and_blank_lines_are_ignored(self):
        self.assertEqual(sql_baseline.parse_changes("# c\n\n   \n"), ({}, []))


class RealProjectState(unittest.TestCase):
    def test_sql_src_equals_original_baseline_plus_approved_changes(self):
        problems, _status, _current = sql_baseline.load_state()
        self.assertEqual(problems, [], "\n".join(problems))


if __name__ == "__main__":
    unittest.main()