"""Identity tests. The real token calls run only on Windows."""
import os
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from ohc import app
from ohc.security import identity
from ohc.security.identity import IdentityError, WinIdentity


class IdentityContract(unittest.TestCase):
    def test_qualified_name(self):
        self.assertEqual(WinIdentity("S-1-5-21-1-2-3-1001", "bob", "PC").qualified_name, "PC\\bob")
        self.assertEqual(WinIdentity("S-1-5-21-1-2-3-1001", "bob", "").qualified_name, "bob")

    def test_identity_is_immutable(self):
        with self.assertRaises(Exception):
            WinIdentity("S-1-5-21-1-2-3-1001", "bob", "PC").account = "x"

    @unittest.skipIf(sys.platform == "win32", "non-Windows behaviour")
    def test_non_windows_raises_identity_error(self):
        with self.assertRaises(IdentityError):
            identity.current_identity()


@unittest.skipUnless(sys.platform == "win32", "needs the Windows process token")
class RealWindowsIdentity(unittest.TestCase):
    def test_sid_account_and_domain(self):
        who = identity.current_identity()
        self.assertRegex(who.sid, r"^S-1-\d+(-\d+)+$")
        self.assertTrue(who.account)
        self.assertEqual(who, identity.current_identity())  # stable across calls

    def test_sid_matches_whoami(self):
        who = identity.current_identity()
        out = subprocess.run(["whoami", "/user", "/fo", "csv", "/nh"], capture_output=True, text=True, check=True).stdout
        sids = re.findall(r"S-1-\d+(?:-\d+)+", out)
        self.assertIn(who.sid.upper(), [s.upper() for s in sids], out)


class SelfTestIdentityBlock(unittest.TestCase):
    @unittest.skipIf(sys.platform == "win32", "non-Windows behaviour")
    def test_non_windows_selftest_reports_not_applicable(self):
        ok, lines = app.selftest(check_qt=False)
        self.assertTrue(ok)
        self.assertIn("Windows account: n/a (not Windows)", lines)

    @unittest.skipUnless(sys.platform == "win32", "needs the Windows process token")
    def test_windows_selftest_shows_identity_and_creates_nothing(self):
        with tempfile.TemporaryDirectory() as d, mock.patch.dict(os.environ, {"OHC_DEV_HOME": d}):
            ok, lines = app.selftest(check_qt=False)
            text = "\n".join(lines)
            self.assertTrue(ok, text)
            self.assertRegex(text, r"Account SID: S-1-\d+(-\d+)+")
            self.assertIn("[not created yet]", text)
            self.assertEqual(list(Path(d).iterdir()), [], "the self-test must not create folders")


if __name__ == "__main__":
    unittest.main()