"""Oracle Health Check page (option "1"): redesign tests for Batch 5A (Qt offscreen).

Like test_gui_run, the engine is replaced by fakes; one test also runs the real simulated mode (OHC_FAKE_ORACLE) through the real engine.
These tests also pin what other pages rely on (Dashboard, Reports & Logs) and that Sync Check / All Checks are not touched by 5A.
"""
import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
import sys

if sys.platform == "win32":      # as test_layout / test_dashboard_page: real fonts, or the offscreen platform has none and every width is meaningless
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\\Windows\\Fonts")

import json
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

from PySide6.QtWidgets import QApplication, QFrame, QLabel, QPushButton, QScrollArea, QVBoxLayout, QWidget

from ohc.checks.engine import CheckResult
from ohc.checks.session import ToolError
from ohc.gui import run_skin
from ohc.gui.run_page import BADGES, STATUS_ROLE, BadgeDelegate, RunPage, SkinBadgeDelegate
from ohc.gui.runner import JobGate
from ohc.gui.sidebar import WIDTH as SIDEBAR_WIDTH
from ohc.gui.theme import PALETTES, ThemeManager
from tests.test_gui_run import make_ctx, run_result, wait_idle

LONG_HOME = "C:\\Users\\Someone\\Documents\\delete\\Oracle\\product\\dbhome_1_with_a_very_long_folder_name_that_cannot_break_" * 2
LONG_ERROR = ("Oracle Home is not configured. Set it in Settings (shared default or per database) and click Save. Looked in "
              "C:\\x\\config\\environment.json (ORACLE_HOME is blank there) and database ims has no Oracle Home override.")


class _AnyThresholds(dict):
    def __missing__(self, key):
        return 80


class HealthPageBase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        env = mock.patch.dict(os.environ)
        env.start()
        self.addCleanup(env.stop)
        os.environ.pop("OHC_FAKE_ORACLE", None)
        self.ctx = make_ctx(Path(self._tmp.name))
        self.gate = JobGate()
        self.theme = ThemeManager(self.ctx.settings)
        self.theme.apply()
        self.addCleanup(lambda: QApplication.instance().setStyleSheet(""))

    def page(self, option="1", themed=True) -> RunPage:
        page = RunPage(self.ctx, option, "title", "blurb", self.gate, theme=self.theme if themed else None)
        self.addCleanup(self._delete, page)
        return page

    @staticmethod
    def _delete(widget):
        try:
            widget.deleteLater()          # a host widget may already have deleted its child page
        except RuntimeError:
            pass

    def hosted(self, page, width=1200 - SIDEBAR_WIDTH, height=760 - 53) -> QWidget:
        """The page in the space a 1200 x 760 window leaves it (sidebar and top bar taken off)."""
        host = QWidget()
        host.setObjectName("content")
        layout = QVBoxLayout(host)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(page)
        host.resize(width, height)
        host.show()
        QApplication.processEvents()
        QApplication.processEvents()
        self._hosts = getattr(self, "_hosts", []) + [host]          # keep the host alive for the whole test
        self.addCleanup(host.close)
        return host


class BehaviourUnchangedTests(HealthPageBase):
    def test_run_shows_progress_and_final_status(self):
        def fake_run(ctx, name, option, emit, on_event=None, cancel=None):
            on_event(("plan", [(0, "DB STATUS"), (2, "SERVER SPEC")]))
            on_event(("start", 0, "DB STATUS"))
            on_event(("done", CheckResult(0, "DB STATUS", "OK", "fine", 1.5, "raw output")))
            return run_result("WARNING", 1)
        page = self.page()
        with mock.patch("ohc.checks.launcher.run_option", side_effect=fake_run) as run:
            page.run_btn.click()
            self.assertTrue(wait_idle(self.gate))
        self.assertEqual(run.call_args.args[1:3], ("ims", "1"))
        self.assertEqual(page.table.item(0, 2).data(STATUS_ROLE), "OK")
        self.assertEqual(page.table.item(0, 3).text(), "fine")
        self.assertEqual(page.status.text(), "OVERALL: WARNING (exit code 1)")
        self.assertEqual(page.status.objectName(), "warn")
        self.assertEqual(page.progress.value(), 1)
        self.assertEqual(page.state_label.text(), "Completed")
        self.assertTrue(page.run_btn.isEnabled())
        self.assertFalse(page.cancel_btn.isEnabled())

    def test_tool_error_is_shown_in_full(self):
        page = self.page()
        with mock.patch("ohc.checks.launcher.run_option", side_effect=ToolError(LONG_ERROR)):
            page.run_btn.click()
            self.assertTrue(wait_idle(self.gate))
        self.assertEqual(page.status.text().splitlines()[0], "TOOL / CONFIGURATION ERROR (exit code 3)")
        self.assertEqual(page.status.objectName(), "bad")
        self.assertIn(LONG_ERROR, page.status.text())          # the redesign changes how it is drawn, never the text

    def test_unexpected_exception_does_not_crash(self):
        page = self.page()
        with mock.patch("ohc.checks.launcher.run_option", side_effect=RuntimeError("boom")):
            page.run_btn.click()
            self.assertTrue(wait_idle(self.gate))
        self.assertIn("Unexpected error", page.status.text())
        self.assertTrue(page.run_btn.isEnabled())

    def test_busy_state_and_cancel(self):
        started = threading.Event()

        def slow(ctx, name, option, emit, on_event=None, cancel=None):
            on_event(("plan", [(0, "DB STATUS"), (2, "SERVER SPEC")]))
            on_event(("start", 0, "DB STATUS"))
            on_event(("done", CheckResult(0, "DB STATUS", "OK", "fine", 0.1, "raw")))
            on_event(("start", 2, "SERVER SPEC"))
            started.set()
            for _ in range(1000):
                cancel.check()                      # raises RunCancelled once Cancel was clicked
                time.sleep(0.01)
            return run_result("OK", 0)
        page = self.page()
        with mock.patch("ohc.checks.launcher.run_option", side_effect=slow):
            page.run_btn.click()
            self.assertTrue(started.wait(5))
            QApplication.processEvents()
            self.assertTrue(self.gate.busy)
            self.assertFalse(page.run_btn.isEnabled())
            self.assertTrue(page.cancel_btn.isEnabled())
            self.assertEqual(page.state_label.text(), "Running")
            page.cancel_btn.click()
            self.assertTrue(wait_idle(self.gate))
        self.assertEqual(page.state_label.text(), "Cancelled")
        self.assertEqual(page.count_label.text(), "1 of 2 checks completed \u00B7 1 cancelled")     # the cancelled check is not "completed"
        self.assertEqual(page.progress.value(), 1)
        self.assertTrue(page.status.text().startswith("CANCELLED"))
        self.assertEqual(page.table.item(0, 2).data(STATUS_ROLE), "OK")
        self.assertEqual(page.table.item(1, 2).data(STATUS_ROLE), "CANCELLED")
        self.assertTrue(page.run_btn.isEnabled())
        self.assertFalse(page.cancel_btn.isEnabled())

    def test_no_database_disables_run(self):
        self.ctx = make_ctx(Path(self._tmp.name) / "empty", with_db=False)
        page = self.page()
        self.assertFalse(page.run_btn.isEnabled())

    def test_real_simulated_run_through_the_real_engine(self):
        """OHC_FAKE_ORACLE=warning: the real launcher, engine, worker thread and fake Oracle session; nothing is mocked but credentials and thresholds."""
        os.environ["OHC_FAKE_ORACLE"] = "warning"
        env = {"schema_version": 1, "environment": {"ORACLE_HOME": "C:\\Oracle\\product\\19.0.0\\dbhome_1", "NLS_LANG": "AMERICAN_AMERICA.WE8MSWIN1252",
                                                    "REPORT_DATE_FORMAT": "yyyy-MM-dd"}, "descriptions": {}}
        self.ctx.environment_path.parent.mkdir(parents=True, exist_ok=True)
        self.ctx.environment_path.write_text(json.dumps(env))
        page = self.page()
        creds = mock.Mock()
        with mock.patch("ohc.checks.launcher.thresholds.load_thresholds", return_value=_AnyThresholds()), \
                mock.patch("ohc.checks.launcher.credstore.load_credentials", return_value=creds):
            page.run_btn.click()
            self.assertTrue(wait_idle(self.gate, 30))
        self.assertEqual(page.state_label.text(), "Completed")
        self.assertIn("OVERALL: WARNING", page.status.text())
        self.assertEqual(page.progress.value(), page.progress.maximum())
        self.assertEqual(page.table.rowCount(), 17)
        statuses = {page.table.item(r, 2).data(STATUS_ROLE) for r in range(17)}
        self.assertTrue(statuses <= set(BADGES) and "WARNING" in statuses)
        self.assertTrue(Path(page._result.report_file).is_file() and Path(page._result.log_file).is_file())
        self.assertTrue(page.open_file_btn.isEnabled() and page.view_log_btn.isEnabled())
        page.table.selectRow(3)
        QApplication.processEvents()
        self.assertTrue(page.out_view.toPlainText())             # the selected check's output is shown
        creds.wipe.assert_called()                               # credentials are still wiped after a run


class ContractOtherPagesRelyOnTests(HealthPageBase):
    """Dashboard / Reports & Logs read these; the redesign must not rename, remove or retype them."""

    ATTRIBUTES = ("db_combo", "cancel_btn", "run_btn", "state_label", "status", "count_label", "progress", "table", "tabs", "out_view",
                  "state_icon", "home_label", "det", "run_db", "run_started", "run_fake", "_data", "_row", "_total", "_thread", "view_changed",
                  "start", "cancel", "refresh_databases", "open_file_btn", "open_dir_btn", "view_log_btn", "option")

    def test_attributes_still_exist(self):
        page = self.page()
        for name in self.ATTRIBUTES:
            self.assertTrue(hasattr(page, name), name)
        self.assertEqual(page.table.columnCount(), 5)
        self.assertEqual(set(page.det), {"id", "name", "status", "time", "sql"})

    def test_view_changed_still_fires_and_data_is_mirrored(self):
        def fake_run(ctx, name, option, emit, on_event=None, cancel=None):
            on_event(("plan", [(0, "DB STATUS")]))
            on_event(("start", 0, "DB STATUS"))
            on_event(("done", CheckResult(0, "DB STATUS", "OK", "fine", 0.2, "raw")))
            return run_result("OK", 0)
        page = self.page()
        fired = []
        page.view_changed.connect(lambda: fired.append(1))
        with mock.patch("ohc.checks.launcher.run_option", side_effect=fake_run):
            page.run_btn.click()
            self.assertTrue(wait_idle(self.gate))
        self.assertTrue(fired)
        self.assertEqual(page._data[0]["status"], "OK")
        self.assertEqual(page._row[0], 0)
        self.assertEqual(page.run_db, "ims")

    def test_status_codes_and_badge_classes_are_unchanged(self):
        self.assertEqual(set(BADGES), {"OK", "WARNING", "CRITICAL", "INFO", "SKIPPED", "UNKNOWN", "RUNNING", "PENDING", "CANCELLED"})
        self.assertTrue(issubclass(SkinBadgeDelegate, BadgeDelegate))       # Reports & Logs still gets the original BadgeDelegate
        self.assertEqual(type(self.page("3").table.itemDelegateForColumn(2)), BadgeDelegate)

    def test_labels_keep_their_text(self):
        page = self.page()
        self.assertEqual(page.run_btn.text().strip(" \u25B6"), "Run Health Check")
        self.assertIn("Open Output File", [b.text() for b in page.findChildren(QPushButton)])
        self.assertIn("Open Report Folder", [b.text() for b in page.findChildren(QPushButton)])
        self.assertIn("View Full Log", [b.text() for b in page.findChildren(QPushButton)])


class OtherRunPagesUntouchedTests(HealthPageBase):
    def test_other_pages_keep_the_original_progress_wording_and_have_no_backdrop(self):
        started = threading.Event()

        def slow(ctx, name, option, emit, on_event=None, cancel=None):
            on_event(("plan", [(0, "DB STATUS"), (1, "DR SYNC")]))
            on_event(("start", 0, "DB STATUS"))
            on_event(("done", CheckResult(0, "DB STATUS", "OK", "fine", 0.1, "raw")))
            on_event(("start", 1, "DR SYNC"))
            started.set()
            for _ in range(1000):
                cancel.check()
                time.sleep(0.01)
            return run_result("OK", 0)
        page = self.page("2")
        with mock.patch("ohc.checks.launcher.run_option", side_effect=slow):
            page.run_btn.click()
            self.assertTrue(started.wait(5))
            page.cancel_btn.click()
            self.assertTrue(wait_idle(self.gate))
        self.assertEqual(page.count_label.text(), "2 of 2 checks completed")        # unchanged behaviour of Sync Check / All Checks
        self.assertFalse(hasattr(page, "_backdrop"))

    def test_sync_check_and_all_checks_are_not_skinned(self):
        for option in ("2", "3"):
            page = self.page(option)
            self.assertFalse(page._skin)
            self.assertEqual(page.styleSheet(), "")
            self.assertEqual(type(page.table.itemDelegateForColumn(2)), BadgeDelegate)
            self.assertEqual(type(page.status), QLabel)
            self.assertTrue(all(f.property("tint") is None for f in page.findChildren(QFrame)))
            self.assertEqual(page.tabs.tabIcon(0).isNull(), True)

    def test_health_check_page_is_skinned(self):
        page = self.page("1")
        self.assertTrue(page._skin)
        self.assertEqual(type(page.table.itemDelegateForColumn(2)), SkinBadgeDelegate)
        self.assertEqual([f.property("tint") for f in page.top_cards].count("info"), 2)
        self.assertFalse(page.tabs.tabIcon(0).isNull())
        self.assertFalse(page.open_file_btn.icon().isNull())


class ThemeTests(HealthPageBase):
    def test_both_themes_apply_and_follow_a_theme_change(self):
        page = self.page()
        dark = page.styleSheet()
        self.assertIn(PALETTES["dark"]["accent"], dark)
        self.assertEqual(page.state_icon.COLORS["idle"], PALETTES["dark"]["muted"])
        self.theme.set_theme("light")
        QApplication.processEvents()
        self.assertNotEqual(page.styleSheet(), dark)
        self.assertIn(run_skin.SKIN["light"]["info_bg"], page.styleSheet())
        self.assertEqual(page.state_icon.COLORS["idle"], PALETTES["light"]["muted"])
        self.theme.set_theme("dark")
        self.assertEqual(page.styleSheet(), dark)

    def test_pills_differ_per_theme_and_unknown_status_is_neutral(self):
        self.assertNotEqual(run_skin.pill("dark", "OK"), run_skin.pill("light", "OK"))
        for theme in ("dark", "light"):
            self.assertEqual(run_skin.pill(theme, "PENDING"), run_skin.SKIN[theme]["pills"]["NEUTRAL"])
            self.assertEqual(run_skin.pill(theme, "SOMETHING NEW"), run_skin.SKIN[theme]["pills"]["NEUTRAL"])
            for status in ("OK", "WARNING", "CRITICAL", "RUNNING", "CANCELLED"):
                self.assertNotEqual(run_skin.pill(theme, status), run_skin.SKIN[theme]["pills"]["NEUTRAL"])
            self.assertNotEqual(run_skin.pill(theme, "CANCELLED"), run_skin.pill(theme, "WARNING"))
            for colour in run_skin.pill(theme, "CANCELLED"):          # amber hue: red >= green > blue
                r, g, b = (int(colour[i:i + 2], 16) for i in (1, 3, 5))
                self.assertTrue(r >= g > b, (theme, colour))
        light_fill = run_skin.pill("light", "CANCELLED")[0]
        self.assertGreater(sum(int(light_fill[i:i + 2], 16) for i in (1, 3, 5)), 3 * 220)    # a light background
        self.assertEqual(run_skin.pill("light", "PENDING"), run_skin.SKIN["light"]["pills"]["NEUTRAL"])   # Not Run stays grey

    def test_details_pill_uses_the_skin_colours(self):
        def fake_run(ctx, name, option, emit, on_event=None, cancel=None):
            on_event(("plan", [(0, "DB STATUS")]))
            on_event(("start", 0, "DB STATUS"))
            on_event(("done", CheckResult(0, "DB STATUS", "WARNING", "careful", 0.2, "raw")))
            return run_result("WARNING", 1)
        page = self.page()
        with mock.patch("ohc.checks.launcher.run_option", side_effect=fake_run):
            page.run_btn.click()
            self.assertTrue(wait_idle(self.gate))
        page.table.selectRow(0)
        QApplication.processEvents()
        fill, ink = run_skin.pill("dark", "WARNING")
        self.assertIn(fill, page.det["status"].styleSheet())
        self.theme.set_theme("light")
        fill, ink = run_skin.pill("light", "WARNING")
        self.assertIn(fill, page.det["status"].styleSheet())


class LayoutTests(HealthPageBase):
    """The same limits test_layout pins for every page, checked for the redesigned page in both themes (a 1200 x 760 window)."""

    def check_layout(self, theme):
        self.theme.set_theme(theme)
        page = self.page()
        page.home_label.setText(LONG_HOME)
        host = self.hosted(page)
        size = page.minimumSizeHint()
        self.assertLessEqual(size.width(), host.width(), theme)
        self.assertLessEqual(size.height(), host.height(), theme)
        self.assertGreaterEqual(page.tabs.height(), 200, theme)
        self.assertGreaterEqual(page.out_view.height(), 150, theme)
        self.assertGreaterEqual(page.table.height(), 200, theme)
        self.assertLessEqual(page.state_icon.parentWidget().height(), 120, theme)
        self.assertEqual(page.findChildren(QScrollArea), [], theme)
        for child in page.findChildren(QWidget):
            if child.isVisibleTo(page) and not child.parentWidget() is None and child.window() is page.window():
                pos = child.mapTo(page, child.rect().topLeft())
                self.assertLessEqual(pos.x() + child.width(), page.width() + 1, (theme, child.objectName(), type(child).__name__))
        buttons = [page.open_file_btn, page.open_dir_btn, page.view_log_btn]
        parent_width = buttons[0].parentWidget().width()
        self.assertLessEqual(sum(b.width() for b in buttons), parent_width + 2, theme)          # the three buttons fit their column
        for button in buttons:
            self.assertGreaterEqual(button.width(), button.sizeHint().width() - 2, (theme, button.text()))  # none is squeezed below its text

    def test_layout_dark(self):
        self.check_layout("dark")

    def test_layout_light(self):
        self.check_layout("light")

    def test_lower_area_is_about_60_40_and_check_name_is_not_squeezed(self):
        page = self.page()
        self.hosted(page, 1360 - SIDEBAR_WIDTH, 860 - 53)
        results_card, details_card = page.table.parentWidget(), page.tabs.parentWidget()       # the two OUTER cards (not inner content)
        results, details = results_card.width(), details_card.width()
        share = results / (results + details)
        info = f"results card {results}px, details card {details}px, page minimum width {page.minimumSizeHint().width()}px, page {page.width()}px"
        self.assertTrue(0.57 <= share <= 0.63, f"results share {share:.3f}: {info}")
        self.assertGreaterEqual(page.table.columnWidth(1), 200)
        self.assertGreater(page.table.columnWidth(1), page.table.columnWidth(3) * 1.2)

    def test_backdrop_paints_wave_and_shadows_without_taking_the_mouse_or_changing_layout(self):
        from PySide6.QtCore import Qt
        for theme in ("light", "dark"):
            self.theme.set_theme(theme)
            page = self.page()
            self.hosted(page, 1360 - SIDEBAR_WIDTH, 860 - 53)
            backdrop = page._backdrop
            self.assertTrue(backdrop.testAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents))
            kids = [c for c in page._inner.children() if isinstance(c, QWidget)]
            self.assertIs(kids[0], backdrop)                              # behind every other child
            image = page._inner.grab().toImage()
            bg = image.pixelColor(2, image.height() - 3)                  # plain page background
            wave = image.pixelColor(image.width() - 40, 12)               # upper-right corner
            self.assertNotEqual(wave.name(), bg.name(), theme)
            card = page.table.parentWidget()
            below = card.mapTo(page._inner, card.rect().bottomLeft())
            shadow = image.pixelColor(below.x() + 30, below.y() + 3)      # just under the results card
            self.assertNotEqual(shadow.name(), bg.name(), theme)
            self.assertLessEqual(shadow.lightness(), bg.lightness(), theme)
        page = self.page()
        self.assertEqual(page.minimumSizeHint().height() <= 760 - 53, True)

    def test_split_stays_close_to_60_40_at_common_window_widths(self):
        for page_width in (1085, 1144):
            page = self.page()
            self.hosted(page, page_width, 860 - 53)
            results, details = page.table.parentWidget().width(), page.tabs.parentWidget().width()           # outer cards
            share = details / (results + details)
            info = f"page {page_width}px: results card {results}px, details card {details}px, page minimum width {page.minimumSizeHint().width()}px"
            self.assertLessEqual(page.minimumSizeHint().width(), page_width, "the page cannot even fit this width: " + info)
            self.assertTrue(0.38 <= share <= 0.425, f"details share {share:.3f}: {info}")
            buttons = [page.open_file_btn, page.open_dir_btn, page.view_log_btn]
            for button in buttons:
                self.assertGreaterEqual(button.width(), button.sizeHint().width() - 1, (page_width, button.text()))      # not squeezed
            self.assertLessEqual(sum(b.width() for b in buttons), buttons[0].parentWidget().width())                       # no overflow

    def test_wave_sits_in_the_upper_right_header_strip_behind_everything(self):
        from PySide6.QtCore import QPoint
        for theme in ("light", "dark"):
            self.theme.set_theme(theme)
            page = self.page()
            self.hosted(page, 1085, 860 - 53)
            inner = page._inner
            image = inner.grab().toImage()
            strip = page.top_cards[0].y()                                                  # the header strip above the first cards
            bg = image.pixelColor(10, 2)                                                   # far left, top: no wave there
            low_right = image.pixelColor(int(image.width() * 0.97), strip - 8)             # under the curve, near the cards
            corner = image.pixelColor(image.width() - 6, 10)                               # the corner the curve rises to
            above_curve = image.pixelColor(int(image.width() * 0.70), 2)                   # above the curve: nothing (not a filled band)
            self.assertNotEqual(low_right.name(), bg.name(), theme)
            self.assertNotEqual(corner.name(), bg.name(), theme)
            self.assertEqual(above_curve.name(), bg.name(), theme)
            self.assertEqual(image.pixelColor(int(image.width() * 0.30), strip - 8).name(), bg.name(), theme)   # does not reach the left half
            self.assertGreater(corner.alpha(), 0)
            self.assertGreaterEqual(abs(corner.red() - bg.red()) + abs(corner.green() - bg.green()) + abs(corner.blue() - bg.blue()), 12, theme)   # visible
            if theme == "light":
                self.assertGreater(corner.red(), corner.blue(), theme)                     # a pink/red tint, not grey
            self.assertIsNone(inner.childAt(QPoint(int(inner.width() * 0.8), 2)), theme)   # the wave never takes the mouse
            self.assertLessEqual(page._backdrop.height(), inner.height())
            self.assertGreaterEqual(strip, 40)

    def test_wave_is_as_soft_as_the_reference_and_dissolves_at_the_bottom(self):
        """Measured on the reference image (light pixels, right 45% of the header strip): mean redness 6.9, 90th percentile 21, peak 37."""
        self.theme.set_theme("light")
        page = self.page()
        self.hosted(page, 1085, 860 - 53)
        image = page._inner.grab().toImage()
        width, strip, bg = image.width(), page.top_cards[0].y(), image.pixelColor(10, 2)
        values = []
        for y in range(strip):
            for x in range(int(width * 0.55), width - 4):
                c = image.pixelColor(x, y)
                if c.red() > 190 and c.green() > 150:                       # light pixels only: no text
                    values.append((c.red() - c.blue()) - (bg.red() - bg.blue()))
        values.sort()
        mean, p90, peak = sum(values) / len(values), values[int(len(values) * 0.9)], values[-1]
        info = f"mean {mean:.1f}, p90 {p90}, peak {peak}"
        self.assertTrue(5.0 <= mean <= 9.0, info)
        self.assertTrue(14 <= p90 <= 28, info)
        self.assertTrue(25 <= peak <= 46, info)
        corner = image.pixelColor(width - 6, 10)
        bottom_right = image.pixelColor(width - 6, strip - 2)
        self.assertLess(bottom_right.red() - bottom_right.blue(), corner.red() - corner.blue())     # fades out towards the cards, no hard edge

    def test_top_cards_have_a_common_height(self):
        page = self.page()
        self.hosted(page, 1360 - SIDEBAR_WIDTH, 860 - 53)
        heights = {card.height() for card in page.top_cards}
        self.assertEqual(len(heights), 1)
        self.assertGreaterEqual(heights.pop(), 100)

    def test_long_failure_message_grows_the_status_card_and_is_shown_in_full(self):
        page = self.page()
        self.hosted(page)
        card = page.state_icon.parentWidget()
        idle_height = card.height()
        with mock.patch("ohc.checks.launcher.run_option", side_effect=ToolError(LONG_ERROR)):
            page.run_btn.click()
            self.assertTrue(wait_idle(self.gate))
        QApplication.processEvents()
        self.assertGreaterEqual(page.status.height(), page.status.heightForWidth(page.status.width()))    # nothing clipped
        self.assertGreater(card.height(), idle_height)
        with mock.patch("ohc.checks.launcher.run_option", return_value=run_result("OK", 0)):
            page.run_btn.click()
            self.assertTrue(wait_idle(self.gate))
        QApplication.processEvents()
        self.assertLessEqual(card.height(), 120)                  # a short status gives the space back


if __name__ == "__main__":
    unittest.main()
