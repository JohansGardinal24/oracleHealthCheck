"""Reports & Logs: discovery from real engine output, filtering, empty/missing states, safe opening, UI (Qt offscreen)."""
import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if sys.platform == "win32":
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

import shutil
import tempfile
import time
import unittest
from datetime import datetime
from pathlib import Path
from unittest import mock

from PySide6.QtWidgets import QApplication

from ohc.checks import engine, fake
from ohc.checks.cancel import CancelToken
from ohc.gui import report_index as ri
from ohc.gui.main_window import MainWindow
from ohc.gui.reports_page import ReportsPage
from ohc.gui.run_page import STATUS_ROLE
from tests.test_fake_oracle import TH
from tests.test_gui_run import make_ctx


class Real:
    """Wraps a fake session but is NOT simulated, so its files look like real-Oracle output."""
    simulated = False

    def __init__(self, base):
        self.base = base

    def __getattr__(self, name):
        return getattr(self.base, name)


def make_runs(root: Path) -> dict:
    """Real engine runs (fake sessions) at distinct times: OK(real), WARNING, CRITICAL, CANCELLED, plus an older OK on another day."""
    logs, reports = root / "logs", root / "reports"
    out = {}

    def run(key, scenario, when, db="ims", mode="ALL", real=False, cancel_after=None):
        token = CancelToken() if cancel_after else None
        session = fake.FakeOracleSession(scenario, db, cancel=token)
        seen = []

        def on_event(ev):
            if ev[0] == "done":
                seen.append(1)
                if cancel_after and len(seen) == cancel_after:
                    token.request()

        out[key] = engine.run_checks(mode, db, db, Real(session) if real else session, TH, log_dir=logs, report_base=reports,
                                     emit=lambda x: None, now=when, cancel=token, on_event=on_event)

    run("ok", "healthy", datetime(2026, 10, 12, 11, 5, 3), real=True)
    run("old", "healthy", datetime(2026, 10, 13, 16, 8, 12))
    run("warn", "warning", datetime(2026, 10, 14, 9, 17, 2))
    run("crit", "critical", datetime(2026, 10, 14, 17, 30, 0), mode="DG")
    run("canc", "warning", datetime(2026, 10, 15, 15, 32, 48), cancel_after=5)
    return out


class IndexTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = Path(tempfile.mkdtemp())
        cls.runs = make_runs(cls.root)
        cls.logs = ri.scan_logs(cls.root / "logs")
        cls.reports = ri.scan_reports(cls.root / "reports", cls.root / "logs")

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.root, True)

    def by_name(self, scan, run):
        path = self.runs[run].log_file if scan.entries[0].kind == "log" else self.runs[run].report_file
        return next(e for e in scan.entries if e.name == path.name)

    def test_statuses_and_counts_come_from_the_files(self):
        for scan in (self.logs, self.reports):
            self.assertEqual(len(scan.entries), 5)
            self.assertEqual([self.by_name(scan, k).status for k in ("ok", "old", "warn", "crit", "canc")],
                             ["OK", "OK", "WARNING", "CRITICAL", "CANCELLED"])
            self.assertEqual(self.by_name(scan, "ok").checks, "21")
            self.assertEqual(self.by_name(scan, "crit").checks, "4")       # option 2 runs 4 checks
            self.assertEqual(self.by_name(scan, "canc").checks, "5 of 21")  # completed of total, from the paired log

    def test_newest_first_and_metadata(self):
        for scan in (self.logs, self.reports):
            whens = [e.when for e in scan.entries]
            self.assertEqual(whens, sorted(whens, reverse=True))
            self.assertTrue(all(e.size > 0 and e.db == "ims" for e in scan.entries))
        self.assertEqual(self.logs.entries[0].when, datetime(2026, 10, 15, 15, 32, 48))

    def test_simulated_runs_are_marked_and_real_ones_are_not(self):
        for scan in (self.logs, self.reports):
            self.assertFalse(self.by_name(scan, "ok").simulated)
            self.assertEqual(self.by_name(scan, "ok").display_name, self.by_name(scan, "ok").name)
            self.assertTrue(self.by_name(scan, "warn").simulated)
            self.assertTrue(self.by_name(scan, "warn").display_name.startswith("[SIMULATED] "))
            self.assertEqual(self.by_name(scan, "warn").status, "WARNING")  # the real status stays

    def test_cancelled_report_without_its_log_shows_only_the_completed_count(self):
        with tempfile.TemporaryDirectory() as tmp:
            reports = Path(tmp) / "reports"
            shutil.copytree(self.root / "reports", reports)
            scan = ri.scan_reports(reports, Path(tmp) / "no_logs_here")
            canc = next(e for e in scan.entries if e.name == self.runs["canc"].report_file.name)
            self.assertEqual((canc.status, canc.checks), ("CANCELLED", "5"))

    def test_filters(self):
        self.assertEqual(ri.dates_of(self.logs.entries), ["2026-10-15", "2026-10-14", "2026-10-13", "2026-10-12"])
        self.assertEqual(len(ri.filter_entries(self.logs.entries, "2026-10-14")), 2)
        self.assertEqual(len(ri.filter_entries(self.logs.entries, "", "critical")), 1)
        self.assertEqual(len(ri.filter_entries(self.reports.entries, "", "20261013")), 1)   # file name
        self.assertEqual(len(ri.filter_entries(self.reports.entries, "2026-10-14", "warn")), 1)
        self.assertEqual(ri.filter_entries(self.reports.entries, "", "nothing-like-this"), [])
        self.assertEqual(len(ri.filter_entries(self.reports.entries)), 5)


class RobustnessTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        (self.tmp / "logs").mkdir()
        (self.tmp / "reports" / "2026-10-15").mkdir(parents=True)

    def test_missing_folders_and_empty_folders(self):
        missing = ri.scan_logs(self.tmp / "nope")
        self.assertEqual((missing.exists, missing.entries), (False, []))
        self.assertEqual(ri.scan_reports(self.tmp / "nope", self.tmp).entries, [])
        self.assertEqual(ri.scan_logs(self.tmp / "logs").entries, [])
        self.assertTrue(ri.scan_logs(self.tmp / "logs").exists)

    def test_odd_files_are_skipped_and_unreadable_content_is_unknown(self):
        (self.tmp / "logs" / "notes.txt").write_text("x")
        (self.tmp / "logs" / "ohc_ims_notadate.log").write_text("x")
        (self.tmp / "logs" / "ohc_ims_20261399_250000.log").write_text("x")   # impossible date
        (self.tmp / "logs" / "ohc_ims_20261015_101010.log").write_bytes(b"")  # empty
        (self.tmp / "logs" / "ohc_ims_20261015_111111.log").write_bytes(b"\xff\xfe garbage \x00 no status")
        (self.tmp / "logs" / "ohc_x_20261015_121212.log" ).mkdir()            # a folder with a log-like name
        (self.tmp / "reports" / "2026-10-15" / "ims_health_20261015_101010.html").write_text("<html>not ours</html>")
        scan = ri.scan_logs(self.tmp / "logs")
        self.assertEqual(sorted(e.name for e in scan.entries), ["ohc_ims_20261015_101010.log", "ohc_ims_20261015_111111.log"])
        self.assertTrue(all(e.status == "UNKNOWN" and e.checks == "" for e in scan.entries))
        rep = ri.scan_reports(self.tmp / "reports", self.tmp / "logs")
        self.assertEqual([(e.status, e.checks) for e in rep.entries], [("UNKNOWN", "")])

    def test_database_names_with_underscores(self):
        (self.tmp / "logs" / "ohc_PROD_ORCL_20261015_101010.log").write_text(" OVERALL: OK\n")
        e = ri.scan_logs(self.tmp / "logs").entries[0]
        self.assertEqual((e.db, e.status), ("PROD_ORCL", "OK"))

    def test_size_format(self):
        self.assertEqual([ri.format_size(n) for n in (0, 500, 1024, 120000, 3 * 1024 * 1024)], ["0 B", "500 B", "1 KB", "117 KB", "3.0 MB"])

    def test_scanning_never_modifies_files(self):
        make_runs(self.tmp)
        before = {p: (p.stat().st_mtime_ns, p.stat().st_size) for p in self.tmp.rglob("*") if p.is_file()}
        ri.scan_logs(self.tmp / "logs")
        ri.scan_reports(self.tmp / "reports", self.tmp / "logs")
        after = {p: (p.stat().st_mtime_ns, p.stat().st_size) for p in self.tmp.rglob("*") if p.is_file()}
        self.assertEqual(before, after)


def wait_for(cond, timeout=15.0):
    end = time.time() + timeout
    while not cond() and time.time() < end:
        QApplication.processEvents()
        time.sleep(0.01)
    QApplication.processEvents()
    return cond()


class PageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.ctx = make_ctx(self.tmp)

    def page(self, with_runs=True):
        self.runs = make_runs(self.tmp) if with_runs else {}
        page = ReportsPage(self.ctx)
        self.addCleanup(page.shutdown)
        page.show()
        self.assertTrue(wait_for(lambda: not page.scanning and page._scans))
        return page

    def test_tables_show_real_runs_with_badges_and_markers(self):
        page = self.page()
        self.assertEqual((page.reports_table.rowCount(), page.logs_table.rowCount()), (5, 5))
        states = [page.reports_table.item(r, 1).data(STATUS_ROLE) for r in range(5)]
        self.assertEqual(states, ["CANCELLED", "CRITICAL", "WARNING", "OK", "OK"])
        self.assertEqual(page.reports_table.item(0, 2).text(), "5 of 21")
        self.assertTrue(page.reports_table.item(0, 3).text().startswith("[SIMULATED] "))
        self.assertFalse(page.reports_table.item(4, 3).text().startswith("[SIMULATED]"))  # the real-style run
        self.assertEqual(page.reports_table.item(0, 0).text(), "2026-10-15  15:32")
        self.assertTrue(page.reports_table.item(0, 4).text().endswith(("KB", "MB")))
        self.assertIsNotNone(page.reports_table.cellWidget(0, 5))
        self.assertIsNotNone(page.logs_table.cellWidget(0, 4))
        self.assertTrue(page.empty_hidden if hasattr(page, "empty_hidden") else page.reports.empty.isHidden())

    def test_date_filter_and_search_in_the_ui(self):
        page = self.page()
        self.assertEqual([page.reports.date_combo.itemText(i) for i in range(page.reports.date_combo.count())],
                         ["All dates", "2026-10-15", "2026-10-14", "2026-10-13", "2026-10-12"])
        page.reports.date_combo.setCurrentIndex(3)
        self.assertEqual(page.reports_table.rowCount(), 1)
        self.assertEqual(page.logs_table.rowCount(), 5)  # the sections filter independently
        page.reports.date_combo.setCurrentIndex(0)
        page.logs.search.setText("warning")
        self.assertEqual(page.logs_table.rowCount(), 1)
        page.logs.search.setText("zzz")
        self.assertEqual(page.logs_table.rowCount(), 0)
        self.assertFalse(page.logs.empty.isHidden())
        self.assertIn("match the filter", page.logs.empty.text())
        page.logs.search.setText("")
        self.assertEqual(page.logs_table.rowCount(), 5)

    def test_empty_and_missing_states(self):
        page = self.page(with_runs=False)
        self.assertEqual(page.reports_table.rowCount(), 0)
        self.assertIn("does not exist", page.reports.empty.text())
        (self.tmp / "logs").mkdir()
        page.refresh = page.logs.refresh_btn
        page.logs.refresh_btn.click()
        self.assertTrue(wait_for(lambda: not page.scanning and page._scans["logs"].exists))
        self.assertIn("No logs found", page.logs.empty.text())
        self.assertTrue(page.logs_table.isHidden())

    def test_refresh_picks_up_a_new_run(self):
        page = self.page()
        before = page.reports_table.rowCount()
        engine.run_checks("DG", "ims", "ims", fake.FakeOracleSession("healthy", "ims"), TH, log_dir=self.tmp / "logs",
                          report_base=self.tmp / "reports", emit=lambda x: None, now=datetime(2026, 10, 16, 8, 0, 0))
        page.reports.refresh_btn.click()
        self.assertTrue(wait_for(lambda: not page.scanning and page.reports_table.rowCount() == before + 1))
        self.assertEqual(page.reports_table.item(0, 0).text(), "2026-10-16  08:00")

    def test_open_report_uses_the_system_browser_only(self):
        page = self.page()
        target = self.runs["warn"].report_file
        with mock.patch("ohc.gui.reports_page.QDesktopServices.openUrl", return_value=True) as opener:
            page.open_report(target)
        self.assertEqual(Path(opener.call_args.args[0].toLocalFile()), target.resolve())

    def test_missing_or_foreign_files_do_not_crash(self):
        page = self.page()
        gone = self.runs["ok"].report_file
        outside = self.tmp / "outside.html"
        outside.write_text("<html></html>")
        wrong_kind = self.runs["ok"].log_file
        with mock.patch("ohc.gui.reports_page.QMessageBox.information") as msg, \
                mock.patch("ohc.gui.reports_page.QDesktopServices.openUrl") as opener, \
                mock.patch("ohc.gui.reports_page.LogDialog.exec") as dialog:
            gone.unlink()
            page.open_report(gone)                 # deleted after listing
            page.open_report(outside)              # not inside the reports folder
            page.open_report(wrong_kind)           # not a report
            page.view_log(self.tmp / "logs" / "nope.log")
            page.view_log(outside)
            page.copy_log_path(self.tmp / "logs" / "nope.log")
        self.assertEqual(msg.call_count, 6)
        opener.assert_not_called()
        dialog.assert_not_called()
        self.assertTrue(wait_for(lambda: not page.scanning))  # a missing file triggers a refresh, not a crash

    def test_log_actions(self):
        page = self.page()
        log = self.runs["canc"].log_file
        with mock.patch("ohc.gui.reports_page.LogDialog.exec") as dialog, \
                mock.patch("ohc.gui.reports_page.LogDialog.__init__", return_value=None) as init:
            page.view_log(log)
        self.assertEqual(Path(init.call_args.args[0]), log.resolve())
        dialog.assert_called_once()
        with mock.patch("ohc.gui.reports_page.QDesktopServices.openUrl") as opener:
            page.open_log_external(log)
            page.open_log_folder(log)
        self.assertEqual(Path(opener.call_args_list[0].args[0].toLocalFile()), log.resolve())
        self.assertEqual(Path(opener.call_args_list[1].args[0].toLocalFile()), log.resolve().parent)
        page.copy_log_path(log)
        self.assertEqual(QApplication.clipboard().text(), str(log.resolve()))

    def test_huge_log_is_not_loaded_into_the_viewer(self):
        page = self.page()
        with mock.patch("ohc.gui.reports_page.BIG_LOG", 10), mock.patch("ohc.gui.reports_page.QMessageBox.information") as msg, \
                mock.patch("ohc.gui.reports_page.LogDialog.exec") as dialog:
            page.view_log(self.runs["ok"].log_file)
        msg.assert_called_once()
        dialog.assert_not_called()

    def test_page_is_wired_into_the_main_window_and_both_themes_render(self):
        os.environ.pop("OHC_FAKE_ORACLE", None)
        win = MainWindow(self.ctx)
        self.addCleanup(win.deleteLater)
        win.show()
        row = [win.nav.item(i).text() for i in range(win.nav.count())].index("Reports & Logs")
        win.nav.setCurrentRow(row)
        page = win.pages.currentWidget()
        self.assertIsInstance(page, ReportsPage)
        self.assertTrue(wait_for(lambda: not page.scanning))
        for theme in ("dark", "light"):
            win.theme.set_theme(theme)
            self.app.processEvents()
            page.grab()
        win.resize(1200, 760)
        self.app.processEvents()
        self.assertLessEqual(win.minimumSizeHint().width(), 1200)
        self.assertLessEqual(win.minimumSizeHint().height(), 760)
        page.shutdown()


if __name__ == "__main__":
    unittest.main()
