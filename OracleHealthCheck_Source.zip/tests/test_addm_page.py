"""ADDM tab of Database Reports (Qt offscreen, fake Oracle session only): tabs, snapshot range, validation, generation, history,
cancellation and layout in both themes. Real Oracle and real Windows rendering are NOT covered."""
import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if sys.platform == "win32":
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

import threading
import time
from pathlib import Path
from unittest import mock

from PySide6.QtCore import QEvent, QRect, Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QComboBox, QScrollArea, QWidget

from ohc import addm, addm_service, awr, awr_service
from tests.test_awr_page import Base
from tests.test_gui_run import wait_idle

TAB = 2


class AddmBase(Base):
    def setUp(self):
        super().setUp()
        self.page.tabs.setCurrentIndex(TAB)
        self.settle()
        self.addm = self.page.addm

    def radio(self, row, side=0):
        return self.addm.table.cellWidget(row, 0 if side == 0 else 2)

    def load(self, days=7):
        self.addm.days.setValue(days)
        self.addm.load_btn.click()
        self.assertTrue(wait_idle(self.win.gate))

    def select(self):
        """Begin 9001 (row 0 left), End 9002 (row 0 right)."""
        self.load()
        self.click(self.radio(0))
        self.click(self.radio(0, 1))

    def generate(self):
        self.addm.generate_btn.click()
        self.assertTrue(wait_idle(self.win.gate))

    def folder(self):
        return awr_service.report_folder(self.ctx)

    def hist_names(self):
        return [self.addm.hist.item(r, 3).text() for r in range(self.addm.hist.rowCount())]

    def cell_pos(self, row, col):
        return self.addm.table.visualRect(self.addm.table.model().index(row, col)).center()

    def click_cell(self, row, col):
        QTest.mouseClick(self.addm.table.viewport(), Qt.MouseButton.LeftButton, pos=self.cell_pos(row, col))


class Tabs(AddmBase):
    def test_addm_tab_is_live_and_nothing_runs_on_open(self):
        p = self.page
        self.assertEqual([p.tabs.tabText(i) for i in range(3)], ["AWR Report", "ASH Report", "ADDM Report"])
        self.assertEqual([p.tabs.isTabEnabled(i) for i in range(3)], [True, True, True])
        self.assertTrue(self.addm.isVisible() and not p.ash.isVisible() and not p.load_btn.isVisible())
        with mock.patch.object(awr_service, "load_snapshots") as load, mock.patch.object(addm_service, "generate_report") as gen:
            for i in (0, 1, 2, 0, 2):
                p.tabs.setCurrentIndex(i)
            self.settle()
            load.assert_not_called()
            gen.assert_not_called()
        self.assertEqual(self.addm.table.rowCount(), 0)

    def test_round_trips_between_all_three_tabs_keep_the_layout(self):
        """Regression for the tab-switch fix: hide the outgoing content before showing the incoming one, for every pair."""
        p = self.page
        for w, h in ((1200, 760), (1360, 860)):
            self.win.resize(w, h)
            p.tabs.setCurrentIndex(0)
            self.settle()
            self.settle()
            params, hist = p._awr_cards
            base = (self.win.size().toTuple(), p.size().toTuple(), params.geometry().getRect(), hist.geometry().getRect(), self.win.minimumSizeHint().height())
            for order in ((1, 2, 0), (2, 1, 0), (2, 0), (1, 0)):
                for i in order:
                    p.tabs.setCurrentIndex(i)
                    self.settle()
                    self.assertEqual(self.win.size().toTuple(), (w, h), (w, h, order, i))        # switching never resizes the window
                    self.assertLessEqual(self.win.minimumSizeHint().height(), h)
                self.settle()
                self.assertEqual((self.win.size().toTuple(), p.size().toTuple(), params.geometry().getRect(), hist.geometry().getRect(),
                                  self.win.minimumSizeHint().height()), base, (w, h, order))
                self.assertFalse(p.ash.isVisible() or p.addm.isVisible())


class Initial(AddmBase):
    def test_initial_state(self):
        a = self.addm
        self.assertEqual(a.days.value(), 7)
        self.assertEqual([a.table.horizontalHeaderItem(i).text() for i in range(6)], ["Snap ID", "Time", "Snap ID", "Time", "Instance", "Duration"])
        self.assertEqual(a.table.rowCount(), 0)
        self.assertFalse(a.begin_edit.isEnabled() or a.end_edit.isEnabled() or a.generate_btn.isEnabled() or a.cancel_btn.isEnabled())
        self.assertTrue(a.load_btn.isEnabled())
        self.assertFalse(hasattr(a, "type_combo"))                               # ADDM is text only: no Report Type dropdown
        self.assertFalse(any(c.currentText().startswith(("HTML", "Text")) for c in a.findChildren(QComboBox)))
        self.assertEqual((a._fmt(), a.ext_label.text()), ("text", ".txt"))
        self.assertEqual(a.name_edit.text(), "ADDM_Report_<begin>_<end>_<yyyymmdd_HHMMSS>")
        self.assertFalse(a.name_edit.property("invalid") == "true")              # the automatic preview is not an error
        self.assertTrue(a.name_edit.isEnabled() and a.rac_check.isEnabled() and not a.rac_check.isChecked() and not a.open_check.isChecked())
        self.assertEqual([a.hist.horizontalHeaderItem(i).text() for i in range(6)], ["Date & Time", "DB", "Snapshot Range", "File Name", "Size", "Actions"])
        self.assertEqual(a.date_combo.itemText(0), "All dates")
        self.assertIn("does not exist yet", a.hist_note.text())
        self.assertIn("Load Snapshots", a.status.toPlainText())
        self.assertIn("Load snapshots", a.caption.text())

    def test_the_automatic_name_stays_valid_after_a_load(self):          # regression: the placeholder preview was flagged invalid
        self.load()
        a = self.addm
        self.assertFalse(a.name_edit.property("invalid") == "true")
        self.assertNotIn("Report Name", a.status.toPlainText())


class Snapshots(AddmBase):
    def test_load_fills_paired_rows_and_enables_the_fields(self):
        self.load()
        a = self.addm
        self.assertEqual(a.table.rowCount(), 31)
        self.assertEqual((self.radio(0).text(), self.radio(0, 1).text(), self.radio(1).text()), ("9001", "9002", "9003"))
        self.assertIsNone(a.table.cellWidget(30, 2))
        self.assertEqual(a.table.item(0, 5).text(), "60 mins")
        self.assertTrue(a.begin_edit.isEnabled() and a.end_edit.isEnabled())
        self.assertIn("Loaded 61", a.status.toPlainText())
        self.assertIn("SIMULATED DATA", a.status.toPlainText())

    def test_selection_follows_the_awr_rules(self):
        self.load()
        a = self.addm
        self.assertEqual(a._target, "begin")
        self.click(self.radio(0))
        self.assertEqual((a.begin_edit.text(), a.end_edit.text(), a._target), ("9001", "", "end"))
        self.click_cell(0, 3)                                            # a click on the timestamp selects too
        self.assertEqual((a.begin_edit.text(), a.end_edit.text()), ("9001", "9002"))
        self.assertEqual((self.radio(0).property("mark"), self.radio(0, 1).property("mark")), ("begin", "end"))
        self.click(a.begin_edit)
        self.assertEqual(a._target, "begin")
        self.click(self.radio(2))
        self.assertEqual((a.begin_edit.text(), a.end_edit.text()), ("9005", "9002"))
        QTest.keyClicks(a.end_edit, "0")                                 # typing changes neither the other field nor the target
        self.assertEqual((a.begin_edit.text(), a.end_edit.text(), a._target), ("9005", "90020", "end"))      # the pick moved the target on

    def test_hover_highlight_uses_the_target_colour(self):
        self.load()
        a = self.addm
        QApplication.sendEvent(self.radio(1), QEvent(QEvent.Type.Enter))
        self.assertEqual((a._hover, self.radio(1).property("hover"), self.radio(1).property("htarget")), (9003, "true", "begin"))
        self.assertEqual(a.table.item(1, 1).background().style(), Qt.BrushStyle.SolidPattern)
        QApplication.sendEvent(self.radio(1), QEvent(QEvent.Type.Leave))
        self.assertIsNone(a._hover)

    def test_range_validation_and_generate_button(self):
        self.load()
        a = self.addm

        def state(b, e):
            a.begin_edit.setText(b)
            a.end_edit.setText(e)
            return a.generate_btn.isEnabled(), a.range_msg.objectName()
        for b, e in (("", ""), ("9001", ""), ("", "9002"), ("abc", "9002"), ("9001", "9x2"), ("9002", "9002"), ("9005", "9002"), ("-1", "5")):
            self.assertFalse(state(b, e)[0], (b, e))
        self.assertEqual(state("abc", "9002")[1], "bad")
        self.assertEqual(state("9001", "9004"), (True, "muted"))
        self.assertEqual(state("5", "9004"), (True, "warn"))               # outside the loaded list: allowed with a warning
        self.assertIn("not in the loaded list", a.range_msg.text())
        self.assertEqual(a.name_edit.text(), "ADDM_Report_5_9004_<yyyymmdd_HHMMSS>")

    def test_restart_between_snapshots_is_flagged(self):
        os.environ["OHC_FAKE_AWR"] = "restart"
        self.load()
        self.addm.begin_edit.setText("9001")
        self.addm.end_edit.setText("9061")
        self.assertTrue(self.addm.generate_btn.isEnabled())
        self.assertIn("restarted", self.addm.range_msg.text())

    def test_failure_empty_and_cancel_clear_everything(self):
        a = self.addm
        for mode, text, level in (("fail", "ORA-00942", "bad"), ("empty", "No snapshots were found", "warn")):
            self.load()
            self.assertGreater(a.table.rowCount(), 0)
            with mock.patch.dict(os.environ, {"OHC_FAKE_AWR": mode}):
                self.load()
            self.assertEqual((a.table.rowCount(), a.begin_edit.text(), a.end_edit.text()), (0, "", ""), mode)
            self.assertFalse(a.begin_edit.isEnabled() or a.generate_btn.isEnabled(), mode)
            self.assertIn(text, a.status.toPlainText(), mode)
            self.assertEqual(a._level, level)
        os.environ["OHC_FAKE_DELAY"] = "1"
        a.load_btn.click()
        self.settle()
        self.assertTrue(a.cancel_btn.isEnabled())
        a.cancel_btn.click()
        self.assertTrue(wait_idle(self.win.gate))
        self.assertEqual(a.table.rowCount(), 0)
        self.assertIn("cancelled", a.status.toPlainText())

    def test_awr_and_addm_selections_are_independent(self):
        self.select()
        self.page.tabs.setCurrentIndex(0)
        self.assertEqual(self.page.table.rowCount(), 0)                    # AWR has its own (empty) state
        self.page.load_btn.click()
        self.assertTrue(wait_idle(self.win.gate))
        self.assertEqual(self.page.table.rowCount(), 31)
        self.assertEqual((self.addm.begin_edit.text(), self.addm.end_edit.text()), ("9001", "9002"))


class TwoDatabases(AddmBase):
    names = ("ims", "prd")

    def test_database_switch_clears_the_addm_snapshots(self):
        self.select()
        self.assertEqual(self.addm.begin_edit.text(), "9001")
        self.page.db_combo.setCurrentIndex(1)
        self.settle()
        a = self.addm
        self.assertEqual((a.table.rowCount(), a.begin_edit.text(), a._target), (0, "", "begin"))
        self.assertFalse(a.begin_edit.isEnabled() or a.generate_btn.isEnabled())
        self.assertIn("prd", a.status.toPlainText())
        with mock.patch.object(awr_service, "load_snapshots", return_value=awr_service.AwrResult("snapshots", False, message="m")) as load:
            a.load_btn.click()
            wait_idle(self.win.gate)
        self.assertEqual(load.call_args.args[1], "prd")


class Options(AddmBase):
    def test_name_and_rac(self):
        a = self.addm
        self.assertEqual(a.ext_label.text(), ".txt")
        QTest.mouseClick(a.rac_check, Qt.MouseButton.LeftButton, pos=a.rac_check.rect().center())
        self.assertTrue(a.rac_check.isChecked())
        self.select()
        self.assertEqual(a.name_edit.text(), "ADDM_Report_9001_9002_<yyyymmdd_HHMMSS>")
        for bad in ("", "../x", "a/b", "C:evil", "a.b", "x.txt", "x.html", "my report", "CON", "a" * 101):
            a.name_edit.setText(bad)
            a._name_edited(bad)                                          # as typed by the user (an automatic name is only a preview)
            self.assertFalse(a.generate_btn.isEnabled(), repr(bad))
            self.assertEqual(a.name_edit.property("invalid"), "true", repr(bad))
        a.name_edit.selectAll()
        QTest.keyClicks(a.name_edit, "peak_1")
        self.assertTrue(a.generate_btn.isEnabled())
        self.click(self.radio(1))                                        # a typed name is not rewritten by later selections
        self.assertEqual(a.name_edit.text(), "peak_1")
        self.folder().mkdir(parents=True, exist_ok=True)
        (self.folder() / "taken.txt").write_text("precious")
        a.name_edit.setText("taken")
        self.assertFalse(a.generate_btn.isEnabled())
        self.assertIn("already exists", a.status.toPlainText())
        a.name_edit.setText("taken2")
        self.assertTrue(a.generate_btn.isEnabled())


class Generation(AddmBase):
    def test_options_reach_the_service(self):
        self.select()
        a = self.addm
        ok = awr_service.AwrResult("addm", False, message="stub")
        with mock.patch.object(addm_service, "generate_report", return_value=ok) as gen:
            self.generate()
            ctx, db, b, e, token, name, rac = gen.call_args.args                 # no format argument: always the text report
            self.assertEqual((db, b, e, name, rac), ("ims", 9001, 9002, "ADDM_Report_9001_9002_<yyyymmdd_HHMMSS>", False))
            a.name_edit.setText("peak")
            a.rac_check.setChecked(True)
            self.generate()
            self.assertEqual(gen.call_args.args[2:4] + gen.call_args.args[5:], (9001, 9002, "peak", True))
        self.assertEqual(a.status.toPlainText(), "stub")

    def test_text_reports_end_to_end(self):
        self.select()
        a = self.addm
        with mock.patch("ohc.gui.awr_page.QDesktopServices.openUrl") as opener:
            self.generate()
            opener.assert_not_called()
        self.assertEqual(a._level, "ok", a.status.toPlainText())
        files = list(self.folder().glob("ADDM_Report_9001_9002_*.txt"))
        self.assertEqual(list(self.folder().glob("*.html")), [])
        self.assertEqual(len(files), 1)
        self.assertEqual((a.hist.item(0, 1).text(), a.hist.item(0, 2).text(), a.hist.item(0, 3).text()), ("ims [SIM]", "9001 - 9002", files[0].name))
        a.rac_check.setChecked(True)
        a.name_edit.setText("rac_text")
        self.generate()
        text = (self.folder() / "rac_text.txt").read_text(encoding="utf-8")
        self.assertIn("ADDM Report for Task", text)
        self.assertIn("RAC (all instances", text)
        self.assertEqual(a.hist.rowCount(), 2)
        self.assertEqual(self.page.ash.hist.rowCount(), 0)                  # ASH history does not list ADDM reports
        self.page.tabs.setCurrentIndex(0)
        self.page.refresh_btn.click()
        self.assertEqual(self.page.hist.rowCount(), 0)                      # nor does AWR

    def test_open_after_generation_and_per_row_open(self):
        self.select()
        a = self.addm
        a.open_check.setChecked(True)
        with mock.patch("ohc.gui.awr_page.QDesktopServices.openUrl") as opener:
            self.generate()
            opener.assert_called_once()
        a.open_check.setChecked(False)
        a.name_edit.setText("second")
        self.generate()
        self.assertEqual(a.hist.rowCount(), 2)
        with mock.patch("ohc.gui.awr_page.QDesktopServices.openUrl") as opener:
            for row in range(2):
                expected = Path(a.hist.item(row, 3).data(Qt.ItemDataRole.UserRole))
                holder = a.hist.cellWidget(row, 5)
                opener.reset_mock()
                holder.open_btn.click()
                self.assertEqual(Path(opener.call_args.args[0].toLocalFile()), expected)
                opener.reset_mock()
                holder.menu_btn.menu().actions()[0].trigger()
                self.assertEqual(Path(opener.call_args.args[0].toLocalFile()), expected)

    def test_failures_show_the_oracle_error_and_add_nothing(self):
        self.select()
        a = self.addm
        for mode, text in (("empty", "empty ADDM report"), ("badreport", "ORA-20019"), ("fail", "ORA-13516")):
            with mock.patch.dict(os.environ, {"OHC_FAKE_ADDM": mode}):
                a.name_edit.setText("f_" + mode)
                self.generate()
            self.assertEqual(a._level, "bad", mode)
            self.assertIn(text, a.status.toPlainText(), mode)
            self.assertEqual(a.hist.rowCount(), 0, mode)
            self.assertTrue(a.generate_btn.isEnabled() and not a.cancel_btn.isEnabled(), mode)
        with mock.patch.dict(os.environ, {"OHC_FAKE_ADDM": "norac"}):
            a.rac_check.setChecked(True)
            a.name_edit.setText("nr")
            self.generate()
            self.assertIn("ANALYZE_DB", a.status.toPlainText())
        a.begin_edit.setText("1")                                         # unknown snapshots: Oracle rejects them
        a.end_edit.setText("2")
        a.name_edit.setText("unknown")
        self.generate()
        self.assertIn("ORA-13516", a.status.toPlainText())
        self.assertEqual(list(self.folder().glob("*")), [])

    def test_no_duplicate_submission_and_responsive_gui(self):
        self.select()
        a = self.addm
        release, calls = threading.Event(), []

        def slow(ctx, db, b, e, token=None, *rest):
            calls.append(1)
            release.wait(10)
            return awr_service.AwrResult("addm", False, True, "cancelled", db=db)
        with mock.patch.object(addm_service, "generate_report", slow):
            a.generate_btn.click()
            self.settle()
            self.assertTrue(self.win.gate.busy)
            self.assertFalse(a.generate_btn.isEnabled() or a.name_edit.isEnabled() or a.load_btn.isEnabled() or a.table.isEnabled())
            self.assertTrue(a.cancel_btn.isEnabled())
            a.generate()
            a.generate_btn.click()
            self.settle()
            self.assertFalse(self.page.db_combo.isEnabled())
            start = time.time()
            for _ in range(20):
                self.app.processEvents()
            self.assertLess(time.time() - start, 2)
            self.page.tabs.setCurrentIndex(0)                              # AWR is blocked by the shared gate while ADDM runs
            self.assertFalse(self.page.load_btn.isEnabled())
            self.page.tabs.setCurrentIndex(2)
            release.set()
            self.assertTrue(wait_idle(self.win.gate))
        self.assertEqual(len(calls), 1)
        self.assertTrue(a.generate_btn.isEnabled() and not a.cancel_btn.isEnabled())

    def test_cancel_removes_the_partial_file(self):
        self.select()
        a = self.addm
        os.environ["OHC_FAKE_DELAY"] = "1"
        a.generate_btn.click()
        end = time.time() + 5
        while time.time() < end and not list(self.folder().glob("ADDM_Report_*")):
            self.app.processEvents()
            time.sleep(0.01)
        self.assertTrue(a.cancel_btn.isEnabled())
        a.cancel_btn.click()
        self.assertFalse(a.cancel_btn.isEnabled())
        self.assertTrue(wait_idle(self.win.gate))
        self.assertEqual(list(self.folder().glob("ADDM_Report_*")), [])
        self.assertIn("cancelled", a.status.toPlainText())
        self.assertEqual(a.hist.rowCount(), 0)
        self.assertTrue(a.generate_btn.isEnabled())


class History(AddmBase):
    def make(self):
        self.files = {
            "a": self.report("2026-10-16/ADDM_Report_9235_9236_20261016_012216.html", 100),
            "b": self.report("2026-10-15/ADDM_Report_9230_9237_20261015_231025.txt", 3 * 1024 * 1024),
            "c": self.report("2026-10-14/ADDM_Report_9228_9231_20261014_000532.html", 5000),
        }
        for other in ("2026-10-16/AWR_Report_9235_9236_20261016_012216.html", "2026-10-16/ASH_Report_20261016_014500.html", "2026-10-16/ims_health_20261016_010000.html"):
            self.report(other)
        self.addm.refresh_btn.click()

    def test_discovery_filter_search_refresh_and_open(self):
        self.make()
        a = self.addm
        self.assertEqual(self.hist_names(), [self.files[k].name for k in "abc"])
        self.assertEqual((a.hist.item(0, 2).text(), a.hist.item(1, 4).text()), ("9235 - 9236", "3.0 MB"))
        a.date_combo.setCurrentIndex(a.date_combo.findData("2026-10-15"))
        self.assertEqual(a.hist.rowCount(), 1)
        a.date_combo.setCurrentIndex(0)
        a.search.setText("9228")
        self.assertEqual(self.hist_names(), [self.files["c"].name])
        a.search.setText("nothing")
        self.assertIn("No reports match", a.hist_note.text())
        a.search.setText("")
        new = self.report("2026-10-17/ADDM_Report_1_2_20261017_010000.txt")
        a.refresh_btn.click()
        self.assertEqual(a.hist.item(0, 3).text(), new.name)
        with mock.patch("ohc.gui.awr_page.QDesktopServices.openUrl") as opener:
            for row in range(a.hist.rowCount()):
                opener.reset_mock()
                a.hist.cellWidget(row, 5).open_btn.click()
                self.assertEqual(Path(opener.call_args.args[0].toLocalFile()), Path(a.hist.item(row, 3).data(Qt.ItemDataRole.UserRole)))
            self.files["a"].unlink()
            opener.reset_mock()
        self.assertEqual(a.hist.rowCount(), 4)                                   # (the missing-file case has its own test)

    def test_missing_file_is_reported_not_opened(self):
        self.make()
        a = self.addm
        self.files["a"].unlink()
        with mock.patch("ohc.gui.awr_page.QDesktopServices.openUrl") as opener:
            a.hist.cellWidget(0, 5).open_btn.click()
        opener.assert_not_called()
        self.assertIn("no longer exists", a.status.toPlainText())
        self.assertEqual(a.hist.rowCount(), 2)

    def test_missing_folder_is_not_an_error(self):
        self.assertEqual(self.addm.hist.rowCount(), 0)
        self.assertIn("does not exist yet", self.addm.hist_note.text())


class Layout(AddmBase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        from PySide6.QtGui import QFont, QFontDatabase           # Segoe UI has Arial-like widths; see test_awr_page.Layout
        cls._old_font = cls.app.font()
        for family in ("Segoe UI", "Arial", "Liberation Sans"):
            if family in QFontDatabase.families():
                cls.app.setFont(QFont(family, 9))
                break

    @classmethod
    def tearDownClass(cls):
        cls.app.setFont(cls._old_font)

    def check(self, w, h, theme, snap_rows, hist_rows):
        self.win.theme.set_theme(theme)
        self.win.resize(w, h)
        self.settle()
        self.select()
        for i, d in enumerate(("2026-10-16", "2026-10-15", "2026-10-14", "2026-10-13", "2026-10-12", "2026-10-11")):
            self.report(f"{d}/ADDM_Report_9{i}00_9{i}10_{d.replace('-', '')}_01{i}500.html", 2 * 1024 * 1024)
        self.addm.refresh_btn.click()
        self.settle()
        self.settle()
        p, a, tag = self.page, self.addm, (w, h, theme)
        self.assertEqual((self.win.width(), self.win.height()), (w, h), tag)
        self.assertLessEqual(p.minimumSizeHint().width() + 300, 1200, tag)
        self.assertLessEqual(p.minimumSizeHint().height() + 60, 760, tag)
        self.assertLessEqual(p.minimumSizeHint().height(), p.height(), tag)
        self.assertEqual(p.findChildren(QScrollArea), [], tag)
        for wdg in p.findChildren(QWidget):
            if wdg.isVisibleTo(p) and wdg.width() and wdg.height() and not wdg.visibleRegion().isEmpty():
                vis = wdg.visibleRegion().boundingRect()
                r = wdg.mapTo(p, vis.topLeft())
                self.assertTrue(0 <= r.x() and r.x() + vis.width() <= p.width() + 1 and 0 <= r.y() and r.y() + vis.height() <= p.height() + 1, (tag, wdg))
        self.assertFalse(a.table.horizontalScrollBar().isVisible() or a.hist.horizontalScrollBar().isVisible(), tag)
        self.assertGreaterEqual(a.table.viewport().height() // 24, snap_rows, tag)
        self.assertGreaterEqual(a.hist.viewport().height() // 30, hist_rows, tag)
        self.assertEqual(a.hist.rowCount(), 6, tag)
        fm = a.table.fontMetrics()
        for row in range(5):                                              # IDs and timestamps never clipped
            for col in (0, 2):
                self.assertLessEqual(self.radio(row, 0 if col == 0 else 1).sizeHint().width(), a.table.columnWidth(col), (tag, row, col))
            for col in (1, 3):
                self.assertLessEqual(fm.horizontalAdvance(a.table.item(row, col).text()) + 12, a.table.columnWidth(col), (tag, row, col))
        hfm = a.hist.fontMetrics()
        for row in range(a.hist.rowCount()):
            self.assertLessEqual(hfm.horizontalAdvance(a.hist.item(row, 3).text()) + 12, a.hist.columnWidth(3), (tag, row))
            holder = a.hist.cellWidget(row, 5)
            self.assertLessEqual(holder.open_btn.sizeHint().width() + holder.menu_btn.width() + 8, a.hist.columnWidth(5), (tag, row))
        for wdg in (a.name_edit,):
            self.assertGreaterEqual(wdg.width(), wdg.minimumSizeHint().width(), (tag, wdg))
        self.assertGreaterEqual(a.name_edit.width(), 200, tag)

        def box(x):
            return QRect(x.mapTo(p, x.rect().topLeft()), x.size())
        self.assertFalse(box(a.begin_edit).intersects(box(a.end_edit)), tag)
        self.assertLessEqual(box(a.generate_btn).bottom(), box(a.cancel_btn).top() + 1, tag)
        self.assertLessEqual(box(a.cancel_btn).bottom(), box(a.status).top() + 1, tag)
        self.assertLess(box(a.table).top(), box(a.hist).top(), tag)

    def test_1360x860_dark(self):
        self.check(1360, 860, "dark", 5, 5)

    def test_1360x860_light(self):
        self.check(1360, 860, "light", 5, 5)

    def test_1200x760_dark(self):
        self.check(1200, 760, "dark", 4, 3)

    def test_1200x760_light(self):
        self.check(1200, 760, "light", 4, 3)

    def test_status_colour_follows_the_theme(self):
        a = self.addm
        a._set_status("bad", "x")
        dark = a.status.styleSheet()
        self.win.theme.set_theme("light")
        self.settle()
        self.assertNotEqual(a.status.styleSheet(), dark)


if __name__ == "__main__":
    import unittest
    unittest.main()
