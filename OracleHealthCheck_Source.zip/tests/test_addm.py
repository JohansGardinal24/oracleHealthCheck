"""ADDM: SQL/API selection, session commands, service (fake session), history. Real Oracle is NOT exercised."""
import hashlib
import os
import re
import shutil
import tempfile
import threading
import time
import unittest
from datetime import datetime
from pathlib import Path
from unittest import mock

from ohc import addm, addm_service, ash, awr
from ohc.checks.cancel import CancelToken
from ohc.checks.session import EXE, OracleSession, ToolError, addm_variant_sql
from ohc.config import environment
from ohc.security.credstore import Credentials
from tests.test_awr import make_awr_ctx

ROOT = Path(__file__).resolve().parent.parent


class Naming(unittest.TestCase):
    def test_names(self):
        self.assertEqual(addm.default_name(9, 10), "ADDM_Report_9_10_<yyyymmdd_HHMMSS>")
        self.assertEqual(addm.task_name(9235, 9236, datetime(2026, 10, 16, 1, 22, 16)), "ADDM_9235_9236_20261016_012216")
        self.assertEqual(awr.check_report_name(addm.default_name(1, 2), "html"), "")        # the real default (ids filled in) is a valid name

    def test_original_scripts_are_unchanged(self):
        recorded = dict(reversed(l.split()) for l in (ROOT / "tools" / "original_sql.sha256").read_text().splitlines() if l.strip())
        for name in ("ADDM_Report.sql", "ASH_Report.sql", "AWR_Report.sql"):
            self.assertEqual(hashlib.sha256((ROOT / "sql_src" / name).read_bytes()).hexdigest(), recorded[name], name)


class Proc:
    seen: list = []
    reply = b"ADDM_TASK|ADDM_1_2_20261016_012216\r\nReport generated at: x\r\n"

    def __init__(self, argv, **kw):
        Proc.seen.append([argv, kw])

    def communicate(self, data=None, timeout=None):
        Proc.seen[-1].append(bytes(data or b""))
        return Proc.reply, None


class SqlAndSession(unittest.TestCase):
    def setUp(self):
        self.home = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.home, True)
        (self.home / "bin").mkdir()
        (self.home / "bin" / ("sqlplus" + EXE)).write_text("")
        Proc.seen = []

    def make(self):
        return OracleSession(self.home, "IMS", Credentials(bytearray(b"sys"), bytearray(b"S3cret!pw")), popen=Proc)

    def test_sql_is_text_only_and_uses_the_documented_dbms_addm_calls(self):
        import inspect
        self.assertEqual(list(inspect.signature(addm_variant_sql).parameters), ["rac"])          # no format argument: text only
        for rac in (False, True):
            sql = addm_variant_sql(rac)
            self.assertIn("DBMS_ADDM.ANALYZE_DB(:v_task, &v_begin, &v_end, &v_dbid);" if rac else
                          "DBMS_ADDM.ANALYZE_INST(:v_task, &v_begin, &v_end, &v_inst, &v_dbid);", sql)
            self.assertEqual("ANALYZE_DB" in sql, rac)
            self.assertEqual("ANALYZE_INST" in sql, not rac)
            self.assertIn("SELECT dbid FROM v$database;", sql)
            self.assertEqual("SELECT instance_number inst FROM v$instance;" in sql, not rac)
            self.assertIn("SELECT DBMS_ADDM.GET_REPORT(:v_task) FROM dual;", sql)          # exactly what the original script does
            for gone in ("GET_TASK_REPORT", "DBMS_ADVISOR", "'HTML'", "HTML"):
                self.assertNotIn(gone, sql)
            self.assertIn('SPOOL "&v_file" CREATE', sql)                                     # never overwrites
            self.assertLess(sql.index("WHENEVER SQLERROR EXIT FAILURE"), sql.index('SPOOL "&v_file"'))   # a failed analysis never leaves a file
            self.assertLess(sql.index("ANALYZE_"), sql.index('SPOOL "&v_file"'))
            self.assertIn("PROMPT ADDM_TASK|&v_task_name", sql)
            for word in ("insert ", "update ", "delete ", "drop ", "alter ", "grant ", "truncate "):
                self.assertNotIn(word, sql.lower())

    def test_command_and_stdin(self):
        s = self.make()
        s.addm_report(Path("C:/r/d/x.txt"), False, 9001, 9004, "ADDM_9001_9004_20261016_012216")
        argv, kw, stdin = Proc.seen[0]
        text = stdin.decode()
        self.assertNotIn("S3cret!pw", " ".join(argv))
        self.assertEqual(argv[1:], ["-s", "/nolog"])
        self.assertLess(text.index("set define off"), text.index("connect sys"))
        self.assertIn("define v_begin=9001\ndefine v_end=9004\ndefine v_task_name=ADDM_9001_9004_20261016_012216\n", text)
        self.assertIn(f"define v_file='{Path('C:/r/d/x.txt')}'", text)
        self.assertNotIn("ADDM_Report.sql", text)
        self.assertIn("ANALYZE_INST", Path(re.search(r'@"([^"]+addm_report\.sql)"', text).group(1)).read_text())
        run_dir = s.run_dir
        s.close()
        self.assertFalse(run_dir.exists())
        s = self.make()
        for bad in ("C:/it's.txt", "C:/a&b.txt", 'C:/a"b.txt'):
            with self.assertRaises(ToolError):
                s.addm_report(Path(bad), False, 1, 2, "ADDM_1_2_20261016_012216")
        for bad in ("x'; drop", "ADDM_1_2", "ADDM_a_b_20261016_012216"):
            with self.assertRaises(ToolError):
                s.addm_report(Path("C:/ok.txt"), False, 1, 2, bad)
        s.close()


class FakeService(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        env = mock.patch.dict(os.environ, {"OHC_FAKE_ORACLE": "healthy"})
        env.start()
        self.addCleanup(env.stop)
        for k in ("OHC_FAKE_ADDM", "OHC_FAKE_DELAY", "OHC_FAKE_AWR", "OHC_FAKE_ASH"):
            os.environ.pop(k, None)
        self.ctx = make_awr_ctx(self.tmp)

    def reports(self):
        return sorted(p.name for p in (self.tmp / "reports").rglob("*") if p.is_file() and p.suffix in (".html", ".txt"))

    def test_reports_are_always_text(self):
        r = addm_service.generate_report(self.ctx, "ims", 9001, 9004)
        self.assertTrue(r.ok, r.detail)
        self.assertTrue(r.simulated and r.message.startswith("SIMULATED DATA - "))
        self.assertRegex(r.path.name, r"^ADDM_Report_9001_9004_\d{8}_\d{6}\.txt$")      # default name, .txt
        body = r.path.read_text(encoding="utf-8")
        self.assertIn("ADDM Report for Task", body)
        self.assertNotIn("<html", body.lower())
        self.assertIn("task ADDM_9001_9004_", r.message)
        self.assertEqual(addm_service.FMT, "text")
        r = addm_service.generate_report(self.ctx, "ims", 9001, 9004, None, "my_text", True)       # custom name + RAC
        self.assertTrue(r.ok, r.detail)
        self.assertEqual(r.path.name, "my_text.txt")
        self.assertIn("RAC (all instances", r.path.read_text(encoding="utf-8"))
        self.assertEqual(self.reports(), sorted(p.name for p in (self.tmp / "reports").rglob("*.txt")))   # nothing but .txt is ever created
        e = addm.scan_history(self.tmp / "reports", index_dir=self.tmp / "config").entries[0]
        self.assertEqual((e.name, e.range_text, e.db, e.simulated), ("my_text.txt", "9001 - 9004", "ims", True))
        self.assertEqual(len(addm.scan_history(self.tmp / "reports", index_dir=self.tmp / "config").entries), 2)                # history recognises both .txt reports
        self.assertEqual(awr.scan_history(self.tmp / "reports", index_dir=self.tmp / "config").entries, [])                      # AWR never lists ADDM files
        self.assertEqual(ash.scan_history(self.tmp / "reports", index_dir=self.tmp / "config").entries, [])

    def test_there_is_no_format_argument_any_more(self):
        import inspect
        self.assertEqual(list(inspect.signature(addm_service.generate_report).parameters), ["ctx", "db_name", "begin", "end", "cancel", "name", "rac"])
        with self.assertRaises(TypeError):
            addm_service.generate_report(self.ctx, "ims", 9001, 9004, fmt="html")
        with self.assertRaises(TypeError):
            OracleSession.addm_report(mock.Mock(), Path("x.html"), "html", False, 1, 2, "ADDM_1_2_20261016_012216")

    def test_invalid_input_never_reaches_the_database(self):
        with mock.patch("ohc.addm_service.launcher._open") as opened:
            for args in ((0, 5), (5, 5), (9, 5), (-1, 3), ("1", 2), (None, 2)):
                self.assertFalse(addm_service.generate_report(self.ctx, "ims", *args).ok, args)
            for kw in ({"name": "../x"}, {"name": "a/b"}, {"name": "x.txt"}, {"name": "CON"}, {"name": ""}):
                self.assertFalse(addm_service.generate_report(self.ctx, "ims", 9001, 9002, **kw).ok, kw)
            opened.assert_not_called()
        self.assertEqual(self.reports(), [])

    def test_unknown_snapshots_and_oracle_errors_leave_no_file(self):
        r = addm_service.generate_report(self.ctx, "ims", 1, 2)
        self.assertFalse(r.ok)
        self.assertIn("ORA-13516", r.detail)
        for mode, text in (("empty", "empty ADDM report"), ("badreport", "ORA-20019"), ("fail", "ORA-13516")):
            with mock.patch.dict(os.environ, {"OHC_FAKE_ADDM": mode}):
                r = addm_service.generate_report(self.ctx, "ims", 9001, 9004, name="f_" + mode)
            self.assertFalse(r.ok, mode)
            self.assertIn(text, r.message + r.detail, mode)
        with mock.patch.dict(os.environ, {"OHC_FAKE_ADDM": "norac"}):
            r = addm_service.generate_report(self.ctx, "ims", 9001, 9004, None, "nr", True)
            self.assertFalse(r.ok)
            self.assertIn("ANALYZE_DB", r.detail)                                       # a clear error, not a different report
            self.assertTrue(addm_service.generate_report(self.ctx, "ims", 9001, 9004, None, "single", False).ok)
        with mock.patch.dict(os.environ, {"OHC_FAKE_ORACLE": "down"}):
            r = addm_service.generate_report(self.ctx, "ims", 9001, 9004, name="dn")
            self.assertIn("ORA-01034", r.detail)
        self.assertEqual(self.reports(), ["single.txt"])

    def test_existing_report_is_never_overwritten(self):
        self.assertTrue(addm_service.generate_report(self.ctx, "ims", 9001, 9004, name="same").ok)
        first = next((self.tmp / "reports").rglob("same.txt"))
        first.write_text("precious", encoding="utf-8")
        r = addm_service.generate_report(self.ctx, "ims", 9001, 9004, name="same")
        self.assertFalse(r.ok)
        self.assertIn("already exists", r.detail)
        self.assertEqual(first.read_text(encoding="utf-8"), "precious")
        results = [addm_service.generate_report(self.ctx, "ims", 9001, 9004) for _ in range(3)]    # token name, same second
        self.assertEqual(sum(x.ok for x in results), len([n for n in self.reports() if n.startswith("ADDM_Report")]))

    def test_cancel_removes_only_its_own_file(self):
        token, out = CancelToken(), []
        os.environ["OHC_FAKE_DELAY"] = "1"
        t = threading.Thread(target=lambda: out.append(addm_service.generate_report(self.ctx, "ims", 9001, 9004, token, "mine")))
        t.start()
        end = time.time() + 5
        while time.time() < end and not list((self.tmp / "reports").rglob("mine.txt")):
            time.sleep(0.01)
        self.assertTrue(list((self.tmp / "reports").rglob("mine.txt")))
        token.request()
        t.join(10)
        self.assertTrue(out[0].cancelled and not out[0].ok)
        self.assertEqual(self.reports(), [])


class RealSessionPath(unittest.TestCase):
    """The service with the real OracleSession class and a stubbed sqlplus process."""

    def setUp(self):
        self.tmp, self.home = Path(tempfile.mkdtemp()), Path(tempfile.mkdtemp())
        for p in (self.tmp, self.home):
            self.addCleanup(shutil.rmtree, p, True)
        (self.home / "bin").mkdir()
        (self.home / "bin" / ("sqlplus" + EXE)).write_text("")
        self.ctx = make_awr_ctx(self.tmp)
        os.environ.pop("OHC_FAKE_ORACLE", None)

    def run_with(self, popen, **kw):
        env = environment.load_environment(self.ctx.environment_path)
        with mock.patch("ohc.addm_service.launcher._prepare", return_value=(self.ctx.databases.find_by_name("ims"), str(self.home), env, None)), \
                mock.patch("ohc.addm_service.launcher._open", side_effect=lambda *a, **k: OracleSession(self.home, "IMS", Credentials(bytearray(b"sys"), bytearray(b"pw")), popen=popen)):
            return addm_service.generate_report(self.ctx, "ims", 9001, 9004, **kw)

    def test_success_and_failures(self):
        class Good(Proc):
            def communicate(self, data=None, timeout=None):
                f = Path(re.search(r"define v_file='([^']+)'", data.decode()).group(1))
                f.write_text("          ADDM Report for Task 'ADDM_9001_9004_x'\n" + "x" * 3000, encoding="utf-8")
                return b"ADDM_TASK|t\r\nReport generated at: " + str(f).encode() + b"\r\n", None
        r = self.run_with(Good, name="real1")
        self.assertTrue(r.ok, r.detail)
        self.assertFalse(r.simulated)
        self.assertEqual(addm.scan_history(self.tmp / "reports", index_dir=self.tmp / "config").entries[0].simulated, False)
        r = self.run_with(Proc, name="nofile")                                           # nothing written, no error text
        self.assertFalse(r.ok)
        class Err(Proc):
            def communicate(self, data=None, timeout=None):
                return b"ERROR at line 1:\r\nORA-13516: SWRF Operation failed\r\n", None
        self.assertIn("ORA-13516", self.run_with(Err, name="err").detail)

        class Spool(Proc):
            def communicate(self, data=None, timeout=None):
                f = Path(re.search(r"define v_file='([^']+)'", data.decode()).group(1))
                f.write_text("ORA-20024: no data\n", encoding="utf-8")
                return b"Report generated at: " + str(f).encode() + b"\r\n", None
        r = self.run_with(Spool, name="spooled")
        self.assertFalse(r.ok)
        self.assertIn("ORA-20024", r.detail)
        self.assertEqual(list((self.tmp / "reports").rglob("spooled*")), [])


class History(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)

    def put(self, rel):
        p = self.tmp / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("x")
        return p

    def test_only_addm_reports_are_listed(self):
        a = self.put("2026-10-16/ADDM_Report_9235_9236_20261016_012216.txt")
        b = self.put("12.10.2026/ADDM_Report_9228_9231_20261012_000532.html")
        for other in ("2026-10-16/AWR_Report_1_2_20261016_012216.html", "2026-10-16/ASH_Report_20261016_014500.html", "2026-10-16/ims_health_20261016_010000.html",
                      "2026-10-16/notes.html", "2026-10-16/ADDM_Report_a_b_20261016_012216.txt", "2026-10-16/ADDM_Report_1_2_20261340_000000.txt"):
            self.put(other)
        entries = addm.scan_history(self.tmp).entries
        self.assertEqual([e.path for e in entries], [a, b])
        self.assertEqual((entries[0].range_text, entries[0].db), ("9235 - 9236", "-"))

    def test_custom_names_index_and_damage(self):
        mine = self.put("2026-10-16/peak.html")
        self.put("2026-10-16/other.html")
        self.assertEqual(addm.record_report(self.tmp, mine, "ORCL", False, 5, 9, True, datetime(2026, 10, 16, 12)), "")
        entries = addm.scan_history(self.tmp).entries
        self.assertEqual([(e.name, e.range_text, e.db) for e in entries], [("peak.html", "5 - 9", "ORCL")])
        self.assertEqual(awr.scan_history(self.tmp).entries, [])
        (self.tmp / addm.INDEX_NAME).write_text("{ broken", encoding="utf-8")
        self.assertEqual(addm.scan_history(self.tmp).entries, [])
        self.assertFalse(addm.scan_history(self.tmp / "nope").exists)

    def test_filters(self):
        self.put("2026-10-16/ADDM_Report_1_2_20261016_014500.txt")
        self.put("2026-10-14/ADDM_Report_3_4_20261014_231025.html")
        entries = addm.scan_history(self.tmp).entries
        self.assertEqual(awr.dates_of(entries), ["2026-10-16", "2026-10-14"])
        self.assertEqual(len(awr.filter_entries(entries, "2026-10-14", "")), 1)
        self.assertEqual(len(awr.filter_entries(entries, "", "3 - 4")), 1)
        self.assertEqual(awr.filter_entries(entries, "2026-10-16", "231025"), [])


if __name__ == "__main__":
    unittest.main()
