"""The 'Generate AWR Report' button must never be squeezed below its own height (its label was clipped vertically)."""
import os
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from PySide6.QtWidgets import QApplication

from ohc.gui.main_window import MainWindow
from tests.test_awr import make_awr_ctx
from tests.test_gui_run import wait_idle

ROW = 4                                   # "4. Database Reports"
PAD_V = 9                                 # QPushButton#primary { padding: 9px 12px }
SIZES = ((900, 620), (1000, 700), (1200, 760), (1360, 860))


class GenerateButtonHeight(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        env = mock.patch.dict(os.environ, {"OHC_FAKE_ORACLE": "healthy"})
        env.start()
        self.addCleanup(env.stop)
        for key in ("OHC_FAKE_AWR", "OHC_FAKE_DELAY"):
            os.environ.pop(key, None)
        self.win = MainWindow(make_awr_ctx(self.tmp, ("ims",)))
        self.addCleanup(self.win.deleteLater)
        self.win.show()
        self.win.nav.setCurrentRow(ROW)
        self.page = self.win.pages.widget(ROW)
        self.settle()

    def settle(self):
        for _ in range(6):
            self.app.processEvents()

    def check(self, tag):
        p = self.page
        btn, cancel = p.generate_btn, p.cancel_btn
        self.assertGreaterEqual(btn.height(), btn.sizeHint().height(), tag)                # not squeezed below its natural height
        self.assertGreaterEqual(btn.height() - 2 * PAD_V - 2, btn.fontMetrics().height(), tag)   # the label's line fits between the paddings
        self.assertGreaterEqual(cancel.height(), cancel.sizeHint().height() - 1, tag)
        opt, params, hist = p._opt_panel, p._params_card, p._history_card
        self.assertGreaterEqual(opt.height(), opt.layout().minimumSize().height(), tag)      # the panel got what its content needs
        self.assertLessEqual(opt.mapTo(params, opt.rect().bottomLeft()).y(), params.height(), tag)   # and it stays inside its card
        self.assertGreaterEqual(params.height(), params.layout().minimumSize().height(), tag)        # the card is as tall as its content ...
        self.assertGreaterEqual(hist.y() - (params.y() + params.height()), p.layout().spacing(), tag)   # ... and the gap to Generated Reports is kept
        self.assertGreaterEqual(hist.height(), hist.minimumSizeHint().height(), tag)

    def test_button_is_never_clipped_at_any_supported_size_in_both_themes(self):
        for theme in ("light", "dark"):
            self.win.theme.set_theme(theme)
            for size in SIZES:
                self.win.resize(*size)
                self.settle()
                self.check((theme, size))

    def test_button_keeps_its_height_after_the_snapshots_are_loaded_and_selected(self):
        self.page.days.setValue(7)
        self.page.load_btn.click()
        self.assertTrue(wait_idle(self.win.gate))
        self.settle()
        for size in SIZES:
            self.win.resize(*size)
            self.settle()
            self.check(("loaded", size))

    def test_history_card_gives_room_only_when_needed_and_takes_it_back_on_a_bigger_window(self):
        self.win.resize(1360, 860)
        self.settle()
        p = self.page
        roomy = p._history_card.height()
        self.assertAlmostEqual(roomy, p._params_card.height(), delta=8)                     # tall window: the normal 1:1 split
        for size in ((1000, 700), (900, 620), (1000, 700), (1360, 860)):
            self.win.resize(*size)
            self.settle()
            self.check(("sequence", size))
        self.assertAlmostEqual(p._history_card.height(), roomy, delta=8)                    # and back to the normal split afterwards

    def test_bigger_fonts_do_not_clip_it_either(self):
        font = self.app.font()
        size0 = font.pointSizeF()
        self.addCleanup(lambda: (font.setPointSizeF(size0), self.app.setFont(font)))
        for pt in (10.0, 12.0):
            font.setPointSizeF(pt)
            self.app.setFont(font)
            self.win.resize(1000, 700)
            self.page.hide()
            self.page.show()                                   # showEvent re-pins from the new metrics
            self.settle()
            self.check(("font", pt))


if __name__ == "__main__":
    unittest.main()
