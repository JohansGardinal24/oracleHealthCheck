"""Settings page redesign, look only: four section cards, the shared wave + card shadows, icons, Validate / Save at the bottom. Qt offscreen.
Settings behaviour (validation, save, databases, credentials, connection test) is not touched and not tested here."""
import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if sys.platform == "win32":
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

import shutil
import tempfile
import unittest
from pathlib import Path

from PySide6.QtCore import QPoint
from PySide6.QtGui import QColor, QImage, QRegion
from PySide6.QtWidgets import QApplication, QWidget

from ohc.gui import run_skin

ROW = 6            # "Settings"
WIDGETS = ("home_edit", "browse_btn", "detect_btn", "home_status", "db_combo", "add_btn", "edit_btn", "delete_btn", "db_details", "test_btn",
           "retention", "theme_combo", "validate_btn", "save_btn", "shared_note", "status")
BUTTONS = {"browse_btn": "Browse", "detect_btn": "Detect", "add_btn": "Add Database", "edit_btn": "Edit", "delete_btn": "Delete",
           "test_btn": "Test Connection", "validate_btn": "Validate", "save_btn": "Save"}


class SkinChecks:
    """The assertions. A subclass provides self.page (SettingsPage), self.set_theme(name) and self.settle()."""

    @staticmethod
    def painted(widget):
        img = QImage(widget.size(), QImage.Format.Format_ARGB32_Premultiplied)     # only what the backdrop paints; grab() adds an opaque background
        img.fill(QColor(0, 0, 0, 0))
        widget.render(img, QPoint(0, 0), QRegion(), QWidget.RenderFlag.DrawChildren)
        return img

    def test_every_existing_widget_and_button_text_is_still_there(self):
        p = self.page
        for name in WIDGETS:
            self.assertTrue(hasattr(p, name), name)
        for name, text in BUTTONS.items():
            self.assertEqual(getattr(p, name).text(), text, name)
        self.assertEqual(p.add_btn.objectName(), "primary")
        self.assertEqual(p.save_btn.objectName(), "primary")
        self.assertEqual([p.theme_combo.itemData(i) for i in range(p.theme_combo.count())], ["dark", "light"])

    def test_four_section_cards_in_the_designed_order(self):
        p = self.page
        self.assertEqual(len(p._cards), 4)
        home, databases, retention, theme = p._cards
        pos = lambda w: w.mapTo(p, QPoint(0, 0))   # noqa: E731
        self.assertTrue(pos(home).y() < pos(databases).y() < pos(retention).y())
        self.assertEqual(pos(retention).y(), pos(theme).y())                       # retention and theme share a row ...
        self.assertTrue(pos(retention).x() < pos(theme).x())                       # ... retention on the left
        for card, widgets in ((home, ("home_edit", "browse_btn", "detect_btn", "home_status")),
                              (databases, ("db_combo", "add_btn", "edit_btn", "delete_btn", "db_details", "test_btn")),
                              (retention, ("retention",)), (theme, ("theme_combo",))):
            for name in widgets:
                self.assertTrue(card.isAncestorOf(getattr(p, name)), name)         # each control sits in its section

    def test_validate_and_save_are_at_the_bottom_below_all_cards(self):
        p = self.page
        bottom = max(c.mapTo(p, QPoint(0, c.height())).y() for c in p._cards)
        self.assertGreaterEqual(p.validate_btn.mapTo(p, QPoint(0, 0)).y(), bottom)
        self.assertEqual(p.validate_btn.mapTo(p, QPoint(0, 0)).y(), p.save_btn.mapTo(p, QPoint(0, 0)).y())
        self.assertLess(p.validate_btn.x(), p.save_btn.x())

    def test_the_page_uses_the_shared_wave_backdrop_in_the_corner_only(self):
        p = self.page
        self.assertIs(type(p._backdrop), run_skin.PageBackdrop)
        self.assertIs(p._backdrop._WAVE_LAYERS, run_skin.PageBackdrop._WAVE_LAYERS)          # the approved wave itself, not a copy
        self.assertEqual(p._backdrop.geometry(), p.rect())
        for theme in ("light", "dark"):
            self.set_theme(theme)
            img = self.painted(p._backdrop)
            y = max(3, p._cards[0].y() - 12)
            self.assertGreater(img.pixelColor(int(img.width() * 0.92), y).alpha(), 0, theme)
            self.assertEqual(img.pixelColor(int(img.width() * 0.20), y).alpha(), 0, theme)

    def test_icons_on_the_heading_the_cards_and_the_buttons_in_both_themes(self):
        p = self.page
        kinds = sorted(kind for _l, kind, _s in p._icons)
        self.assertEqual(kinds, sorted(["settings", "database", "database", "calendar", "palette", "check_circle"]))
        for theme in ("light", "dark"):
            self.set_theme(theme)
            for label, kind, _size in p._icons:
                self.assertFalse(label.pixmap().isNull(), (theme, kind))
            for name in BUTTONS:
                self.assertFalse(getattr(p, name).icon().isNull(), (theme, name))

    def test_green_check_follows_the_oracle_home_status(self):
        p = self.page
        p.home_edit.setText("")
        p._update_home_status()
        self.assertEqual(p.home_status.objectName(), "warn")                          # not configured: no check mark
        self.assertTrue(p.home_ok_icon.isHidden())
        p.home_edit.setText(r"C:\no\such\oracle\home")
        p._update_home_status()
        self.assertEqual(p.home_ok_icon.isHidden(), p.home_status.objectName() != "ok")    # whatever the real check says, the mark agrees with it


class SettingsSkinTests(SkinChecks, unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def settle(self):
        self.app.processEvents()
        self.app.processEvents()

    def setUp(self):
        from ohc.gui.main_window import MainWindow
        from tests.test_gui_run import make_ctx
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.win = MainWindow(make_ctx(self.tmp))
        self.addCleanup(self.win.deleteLater)
        self.win.resize(1360, 860)
        self.win.show()
        self.win.nav.setCurrentRow(ROW)
        self.page = self.win.pages.widget(ROW)
        self.settle()

    def set_theme(self, name):
        self.win.theme.set_theme(name)
        self.settle()


if __name__ == "__main__":
    unittest.main()
