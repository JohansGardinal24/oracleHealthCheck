"""Reports & Logs redesign, look only: the shared wave + card shadows, the document icons, and the status pills (SUCCESS = pale sage with a green check).
Qt offscreen. The scan results are synthetic entries; scanning, filtering, actions and the status codes are covered by test_reports_page."""
import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if sys.platform == "win32":
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

import shutil
import tempfile
import time
import unittest
from datetime import datetime
from pathlib import Path
from unittest import mock

from PySide6.QtCore import QPoint, QRect
from PySide6.QtGui import QColor, QImage, QPainter, QRegion
from PySide6.QtWidgets import QApplication, QStyleOptionViewItem, QWidget

from ohc.gui import report_index as ri
from ohc.gui import run_skin
from ohc.gui.reports_page import STATUS_LABEL, STATUS_STYLE
from ohc.gui.run_page import STATUS_ROLE

ROW = 5            # "Reports & Logs"
STATUSES = ("OK", "OK", "WARNING", "CRITICAL", "CANCELLED")


def make_entries(kind: str, root: Path) -> list:
    ext = "html" if kind == "report" else "log"
    return [ri.Entry(kind=kind, path=root / f"x_{i}.{ext}", name=f"x_{i}.{ext}", db="ims", when=datetime(2026, 11, 9, 8 + i, 0), status=st,
                     checks="21" if kind == "report" else "", size=2048, simulated=True) for i, st in enumerate(STATUSES)]


class SkinChecks:
    """The assertions. A subclass provides self.page (ReportsPage), self.set_theme(name) and self.settle()."""

    @staticmethod
    def painted(widget):
        img = QImage(widget.size(), QImage.Format.Format_ARGB32_Premultiplied)     # only what the backdrop paints; grab() adds an opaque background
        img.fill(QColor(0, 0, 0, 0))
        widget.render(img, QPoint(0, 0), QRegion(), QWidget.RenderFlag.DrawChildren)
        return img

    def pill_image(self, table, row):
        delegate, index = table.itemDelegateForColumn(1), table.model().index(row, 1)
        img = QImage(110, 42, QImage.Format.Format_ARGB32)
        img.fill(QColor("#FFFFFF"))
        option = QStyleOptionViewItem()
        option.rect, option.font = QRect(0, 0, 110, 42), table.font()
        painter = QPainter(img)
        delegate.paint(painter, option, index)
        painter.end()
        return img

    def test_the_page_uses_the_shared_wave_backdrop_behind_both_cards(self):
        p = self.page
        self.assertIs(type(p._backdrop), run_skin.PageBackdrop)
        self.assertIs(p._backdrop._WAVE_LAYERS, run_skin.PageBackdrop._WAVE_LAYERS)          # the approved wave itself, not a copy
        self.assertEqual(p._backdrop.geometry(), p.rect())
        self.assertTrue(p.reports.card.isVisible() and p.logs.card.isVisible())

    def test_wave_is_in_the_upper_right_corner_only_in_both_themes(self):
        p = self.page
        for theme in ("light", "dark"):
            self.set_theme(theme)
            img = self.painted(p._backdrop)
            y = max(3, p.reports.card.y() - 14)
            self.assertGreater(img.pixelColor(int(img.width() * 0.92), y).alpha(), 0, theme)
            self.assertEqual(img.pixelColor(int(img.width() * 0.20), y).alpha(), 0, theme)

    def test_document_icons_on_the_title_and_both_card_heads(self):
        p = self.page
        self.assertEqual([(kind, size) for _l, kind, size in p._icons], [("logs", 32), ("logs", 18), ("logs", 18)])    # never the heartbeat icon
        for theme in ("light", "dark"):
            self.set_theme(theme)
            for label, _kind, _size in p._icons:
                self.assertFalse(label.pixmap().isNull(), theme)

    @staticmethod
    def close(a, b, tol=28):
        return all(abs(x - y) <= tol for x, y in ((a.red(), b.red()), (a.green(), b.green()), (a.blue(), b.blue())))

    def icon_pixels(self, img, color):
        """How many pixels of the icon area (x 14..30, y 13..29) are in the icon colour."""
        return sum(1 for x in range(14, 30) for y in range(13, 29) if self.close(img.pixelColor(x, y), QColor(color)))

    def test_status_codes_are_unchanged_and_all_four_statuses_have_a_pill(self):
        p = self.page
        for table in (p.reports_table, p.logs_table):
            self.assertEqual([table.item(r, 1).data(STATUS_ROLE) for r in range(len(STATUSES))], list(STATUSES))
        self.assertEqual(STATUS_LABEL, {"OK": "SUCCESS", "WARNING": "WARNING", "CRITICAL": "CRITICAL", "CANCELLED": "CANCELLED"})
        for theme in ("light", "dark"):
            self.assertEqual(set(STATUS_STYLE[theme]), {"OK", "WARNING", "CRITICAL", "CANCELLED"})

    def test_each_status_pill_has_its_tint_and_its_icon_in_both_themes(self):
        p = self.page
        for theme in ("light", "dark"):
            self.set_theme(theme)
            seen = []
            for status in ("OK", "WARNING", "CRITICAL", "CANCELLED"):
                fill, ink, icon, _mark = STATUS_STYLE[theme][status]
                img = self.pill_image(p.reports_table, STATUSES.index(status))
                self.assertEqual(img.pixelColor(100, 21).name(), QColor(fill).name(), (theme, status))        # the capsule tint
                self.assertGreaterEqual(self.icon_pixels(img, icon), 8, (theme, status))                         # the icon, in its colour
                self.assertEqual(img.pixelColor(7, 7).name(), "#ffffff", (theme, status))                        # rounded: the cell background shows in the corner
                seen.append(img)
            for i in range(4):
                for j in range(i + 1, 4):
                    self.assertNotEqual(seen[i], seen[j], theme)                                                  # four different pills

    def test_success_pill_stays_pale_sage_with_dark_green_text(self):
        fill, ink, _icon, _mark = (QColor(c) for c in STATUS_STYLE["light"]["OK"])
        self.assertLess(fill.saturationF(), 0.2)                                                                  # quiet, not a saturated green
        self.assertGreater(fill.lightnessF(), 0.85)
        self.assertLess(ink.lightnessF(), 0.25)

    def test_reports_and_execution_logs_draw_identical_pills(self):
        p = self.page
        for theme in ("light", "dark"):
            self.set_theme(theme)
            for row in range(len(STATUSES)):
                self.assertEqual(self.pill_image(p.reports_table, row), self.pill_image(p.logs_table, row), (theme, STATUSES[row]))

    def test_the_longest_label_fits_inside_its_pill(self):
        p = self.page
        self.set_theme("light")
        img = self.pill_image(p.reports_table, STATUSES.index("CANCELLED"))
        ink = QColor(STATUS_STYLE["light"]["CANCELLED"][1])
        xs = [x for x in range(34, 108) for y in range(14, 29) if self.close(img.pixelColor(x, y), ink, 40)]
        self.assertTrue(xs and max(xs) <= 104 and min(xs) >= 32, (min(xs, default=None), max(xs, default=None)))     # text starts after the icon and ends inside the capsule


class ReportsSkinTests(SkinChecks, unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def settle(self):
        self.app.processEvents()
        self.app.processEvents()

    def setUp(self):
        from ohc.gui.main_window import MainWindow
        from tests.test_gui_run import make_ctx
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        for name, kind in (("scan_reports", "report"), ("scan_logs", "log")):
            patcher = mock.patch.object(ri, name, lambda *a, _k=kind, **k: ri.Scan(entries=make_entries(_k, self.tmp), folder=self.tmp, exists=True))
            patcher.start()
            self.addCleanup(patcher.stop)
        self.win = MainWindow(make_ctx(self.tmp))
        self.addCleanup(self.win.deleteLater)
        self.win.resize(1360, 860)
        self.win.show()
        self.win.nav.setCurrentRow(ROW)
        self.page = self.win.pages.widget(ROW)
        start = time.time()
        while (self.page.scanning or self.page.reports_table.rowCount() == 0) and time.time() - start < 5:
            self.app.processEvents()
        self.settle()

    def set_theme(self, name):
        self.win.theme.set_theme(name)
        self.settle()


if __name__ == "__main__":
    unittest.main()
