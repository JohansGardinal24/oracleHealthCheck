import os
import shutil
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest import mock

from ohc.checks import engine, fake, launcher
from ohc.checks.session import ToolError
from ohc.config import thresholds

TH = dict(thresholds.DEFAULTS)


class FakeBackendTests(unittest.TestCase):
    def run_all(self, scenario, mode="ALL"):
        tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, tmp, True)
        return engine.run_checks(mode, "ims", "ims", fake.FakeOracleSession(scenario, "ims"), TH, log_dir=tmp / "l",
                                 report_base=tmp / "r", emit=lambda x: None, now=datetime(2026, 10, 13, 12, 0, 0), hostname="H")

    def test_scenarios_and_exit_codes(self):
        for scenario, code in (("healthy", 0), ("warning", 1), ("critical", 2), ("down", 2)):
            r = self.run_all(scenario)
            self.assertEqual((r.exit_code, len(r.results)), (code, 21), scenario)
        self.assertEqual(engine.probe_database(fake.FakeOracleSession("healthy", "ims"), "ims").kind, "OK")
        self.assertEqual(engine.probe_database(fake.FakeOracleSession("down", "ims"), "ims").kind, "DOWN")

    def test_everything_is_labelled_fake(self):
        r = self.run_all("healthy")
        self.assertIn("[FAKE]", r.report_file.read_text(encoding="utf-8"))
        self.assertTrue(all(x.message.startswith("[FAKE]") for x in r.results))  # DB status and Data Guard too
        self.assertIn("FAKE / SIMULATED DATA", r.log_file.read_text(encoding=engine.ENC, errors="replace"))


class GateTests(unittest.TestCase):
    def test_gate(self):
        with mock.patch.dict(os.environ, {"OHC_FAKE_ORACLE": " Warning "}):
            self.assertEqual(launcher.fake_scenario(), "warning")
            with mock.patch("ohc.paths.is_frozen", return_value=True):
                self.assertEqual(launcher.fake_scenario(), "")  # never in the packaged EXE
        with mock.patch.dict(os.environ, {"OHC_FAKE_ORACLE": "bogus"}):
            with self.assertRaises(ToolError):
                launcher.fake_scenario()
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("OHC_FAKE_ORACLE", None)
            self.assertEqual(launcher.fake_scenario(), "")


if __name__ == "__main__":
    unittest.main()
