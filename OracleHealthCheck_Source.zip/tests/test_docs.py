"""Keeps the documentation honest: files exist, referenced project files exist,
quoted hashes and pinned versions match the project.

Run from the project root:
    python -m unittest discover -s tests -t . -v
"""
import hashlib
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
GUIDE = ROOT / "docs" / "DEV_GUIDE.md"
STATUS = ROOT / "docs" / "STATUS.md"
BASELINE = ROOT / "tools" / "original_sql.sha256"
REQ_FILES = (ROOT / "requirements.txt", ROOT / "requirements-dev.txt")

CHECKED_ROOTS = ("ohc", "tools", "tests", "packaging", "sql_src", "docs")
INLINE_PATH = re.compile(r"`((?:%s)[\\/][^`\s<>*]+)`" % "|".join(CHECKED_ROOTS))
TOOL_FILE = re.compile(r"(?<![\w`.])((?:tools|packaging)[\\/][A-Za-z0-9_.]+\.(?:py|spec|txt|sha256))")
HASH64 = re.compile(r"\b[0-9a-f]{64}\b")
PIN = re.compile(r"\b([A-Za-z][A-Za-z0-9_.-]*)==([0-9][A-Za-z0-9.]*)")

REQUIRED_GUIDE_HEADINGS = (
    "Project structure", "Development environment", "Running the application",
    "SQL bundle", "Editing and adding SQL", "Configuration and data", "Building",
    "Testing the packaged", "Distributing", "Backups", "Troubleshooting", "Not yet production-ready",
)
REQUIRED_STATUS_HEADINGS = ("Checkpoints", "Known issues", "Next task")


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")  # also proves the file is valid UTF-8


def headings(text: str) -> list:
    return [l[3:].strip() for l in text.splitlines() if l.startswith("## ")]


class DocsExistAndAreComplete(unittest.TestCase):
    def test_files_exist_and_are_not_empty(self):
        for p in (GUIDE, STATUS):
            self.assertTrue(p.is_file(), p)
            self.assertGreater(len(read(p).strip()), 500, p)

    def test_guide_has_all_required_sections(self):
        found = " | ".join(headings(read(GUIDE)))
        for keyword in REQUIRED_GUIDE_HEADINGS:
            self.assertIn(keyword, found, f"DEV_GUIDE.md is missing a section about: {keyword}")

    def test_status_has_all_required_sections(self):
        found = " | ".join(headings(read(STATUS)))
        for keyword in REQUIRED_STATUS_HEADINGS:
            self.assertIn(keyword, found, f"STATUS.md is missing a section about: {keyword}")

    def test_guide_states_that_the_app_is_not_production_ready(self):
        self.assertIn("not implemented yet", read(GUIDE).lower())


class DocsMatchTheProject(unittest.TestCase):
    def test_referenced_project_files_exist(self):
        for doc in (GUIDE, STATUS):
            text = read(doc)
            refs = set(INLINE_PATH.findall(text)) | set(TOOL_FILE.findall(text))
            self.assertTrue(refs, f"{doc.name} references no project files (check the patterns)")
            for ref in sorted(refs):
                self.assertTrue((ROOT / ref.replace("\\", "/")).exists(), f"{doc.name} mentions missing file: {ref}")

    def test_quoted_hashes_equal_the_immutable_baseline_hash(self):
        expected = hashlib.sha256(BASELINE.read_bytes()).hexdigest()
        found = set()
        for doc in (GUIDE, STATUS):
            found |= set(HASH64.findall(read(doc)))
        self.assertTrue(found, "no SHA-256 quoted in the docs")
        self.assertEqual(found, {expected})

    def test_quoted_pins_match_the_requirements_files(self):
        pins = {l.strip().lower() for f in REQ_FILES for l in read(f).splitlines() if "==" in l}
        for doc in (GUIDE, STATUS):
            for name, version in PIN.findall(read(doc)):
                self.assertIn(f"{name}=={version}".lower(), pins, f"{doc.name}: {name}=={version} not pinned")


if __name__ == "__main__":
    unittest.main()