"""Database Reports (AWR / ASH / ADDM) redesign, look only: the shared wave + card shadows, the Live Database label (driven by the app's own
state, never guessed) and the refresh icon. Qt offscreen, fake Oracle session only. Existing behaviour is covered by test_awr_page / test_ash_page /
test_addm_page; nothing here touches the backend."""
import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if sys.platform == "win32":
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

import shutil
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from PySide6.QtCore import QPoint
from PySide6.QtGui import QColor, QImage, QRegion
from PySide6.QtWidgets import QApplication, QWidget

from ohc.gui import run_skin

ROW = 4   # "4. Database Reports"


class SkinChecks:
    """The assertions. A subclass provides self.page (DatabaseReportsPage), self.set_theme(name) and self.names (the configured databases)."""
    names = ("ims",)

    def settle(self):
        self.app.processEvents()
        self.app.processEvents()

    @staticmethod
    def painted(backdrop):
        """Only what the backdrop itself paints, on a transparent image (grab() would add an opaque window background)."""
        img = QImage(backdrop.size(), QImage.Format.Format_ARGB32_Premultiplied)
        img.fill(QColor(0, 0, 0, 0))
        backdrop.render(img, QPoint(0, 0), QRegion(), QWidget.RenderFlag.DrawChildren)
        return img

    def test_live_label_follows_the_application_state(self):
        p = self.page
        with mock.patch.dict(os.environ):
            os.environ["OHC_FAKE_ORACLE"] = "healthy"                 # simulated: the existing orange tag, never the green one
            p._refresh_fake()
            self.assertFalse(p.sim_tag.isHidden())
            self.assertTrue(p.live_tag.isHidden())
            os.environ.pop("OHC_FAKE_ORACLE", None)                     # real Oracle
            p._refresh_fake()
            self.assertTrue(p.sim_tag.isHidden())
            self.assertEqual(p.live_tag.isHidden(), not self.names)     # ... and only when a database is actually selected
            self.assertIn("Live Database", p.live_tag.text())
            os.environ["OHC_FAKE_ORACLE"] = "healthy"
            p._refresh_fake()
            self.assertTrue(p.live_tag.isHidden())                      # back to simulated: the label goes away again

    def test_all_three_tabs_use_the_shared_wave_backdrop(self):
        p = self.page
        self.assertIs(type(p._backdrop), run_skin.PageBackdrop)
        self.assertIs(p._backdrop._WAVE_LAYERS, run_skin.PageBackdrop._WAVE_LAYERS)       # the approved wave itself, not a copy
        for tab in (0, 1, 2):
            p.tabs.setCurrentIndex(tab)
            self.settle()
            visible = [c for c in p._backdrop_cards if c.isVisible()]
            self.assertEqual(len(visible), 2, tab)                                          # each tab: its parameters card + its history card
            self.assertEqual(p._backdrop.geometry(), p.rect(), tab)                          # covers the page, behind everything
            self.assertEqual(p._cards_top(), min(c.mapTo(p, c.rect().topLeft()).y() for c in visible), tab)

    def test_wave_is_painted_in_the_corner_in_both_themes_and_nowhere_else(self):
        p = self.page
        for theme in ("light", "dark"):
            self.set_theme(theme)
            for tab in (0, 1, 2):
                p.tabs.setCurrentIndex(tab)
                self.settle()
                img = self.painted(p._backdrop)
                w, top = img.width(), p._cards_top()
                y = max(3, top - 14)                                                         # in the strip above the first card
                corner = img.pixelColor(int(w * 0.92), y).alpha()
                left = img.pixelColor(int(w * 0.20), y).alpha()
                self.assertGreater(corner, 0, (theme, tab))                                   # the wave is there ...
                self.assertEqual(left, 0, (theme, tab))                                       # ... only in the upper-right corner
                self.assertGreater(img.pixelColor(int(w * 0.5), p._backdrop_cards[0].mapTo(p, p._backdrop_cards[0].rect().bottomLeft()).y() + 4).alpha()
                                   if tab == 0 else 1, 0, (theme, tab))                      # soft shadow under the card

    def test_load_snapshots_buttons_keep_their_text_and_gain_the_refresh_icon(self):
        p = self.page
        for theme in ("light", "dark"):
            self.set_theme(theme)
            for button in (p.load_btn, p.addm.load_btn):
                self.assertEqual(button.text(), "Load Snapshots")
                self.assertFalse(button.icon().isNull(), theme)


class ReportSkinTests(SkinChecks, unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        from ohc.gui.main_window import MainWindow          # imported here so the assertions above can also run without the full application
        from tests.test_awr import make_awr_ctx
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        env = mock.patch.dict(os.environ, {"OHC_FAKE_ORACLE": "healthy"})
        env.start()
        self.addCleanup(env.stop)
        for key in ("OHC_FAKE_AWR", "OHC_FAKE_DELAY"):
            os.environ.pop(key, None)
        self.win = MainWindow(make_awr_ctx(self.tmp, self.names))
        self.addCleanup(self.win.deleteLater)
        self.win.resize(1360, 860)
        self.win.show()
        self.win.nav.setCurrentRow(ROW)
        self.settle()
        self.page = self.win.pages.widget(ROW)

    def set_theme(self, name):
        self.win.theme.set_theme(name)
        self.settle()


class ReportSkinNoDatabaseTests(ReportSkinTests):
    names = ()                                               # nothing configured: "Live Database" must stay hidden even in real-Oracle mode


if __name__ == "__main__":
    unittest.main()
