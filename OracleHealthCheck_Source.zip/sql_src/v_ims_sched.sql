select 'INFO|'||count(*)||' active scheduler(s) found (terminate_on within &IMS_SCHEDULER_LOOKAHEAD_DAYS days)'
from config.schedule_master where status = 'Active' and terminate_on < sysdate + &IMS_SCHEDULER_LOOKAHEAD_DAYS;
