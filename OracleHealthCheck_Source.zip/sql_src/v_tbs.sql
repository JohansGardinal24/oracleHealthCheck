select case when sum(case when pct >= &TBS_CRIT then 1 else 0 end) > 0 then 'CRITICAL'
            when sum(case when pct >= &TBS_WARN then 1 else 0 end) > 0 then 'WARNING'
            else 'OK' end
       ||'|Highest: '||nvl(max(tablespace_name) keep (dense_rank last order by pct),'n/a')||' '
       ||nvl(to_char(max(pct),'FM990.0'),'0')||'% ('
       ||nvl(sum(case when pct >= &TBS_CRIT then 1 else 0 end),0)||' critical, '
       ||nvl(sum(case when pct >= &TBS_WARN and pct < &TBS_CRIT then 1 else 0 end),0)
       ||' warning; UNDO/TEMP-current not evaluated)'
from (select m.tablespace_name, round(m.used_percent,1) pct
      from dba_tablespace_usage_metrics m, dba_tablespaces t
      where t.tablespace_name = m.tablespace_name and t.contents = 'PERMANENT');
