set lines 200
col username for a15
col profile for a20
SELECT username,
       account_status,
       expiry_date,
       profile
FROM dba_users
WHERE username = 'SYS';
