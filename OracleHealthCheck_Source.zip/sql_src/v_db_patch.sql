select 'INFO|'||case when cnt = 0 then 'No records in dba_registry_sqlpatch'
                    else cnt||' patch record(s); latest: patch '||latest_patch||' '||latest_action||' '||latest_status||' at '||to_char(latest_time,'YYYY-MM-DD HH24:MI')
               end
from (select count(*) cnt,
             max(patch_id) keep (dense_rank last order by action_time) latest_patch,
             max(action) keep (dense_rank last order by action_time) latest_action,
             max(status) keep (dense_rank last order by action_time) latest_status,
             max(action_time) latest_time
      from dba_registry_sqlpatch);
