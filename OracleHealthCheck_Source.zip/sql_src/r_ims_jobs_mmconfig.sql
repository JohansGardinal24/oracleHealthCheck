col sch_name for a30
select sch_name,to_char(last_run,'dd-mm-yyyy hh24:mi'),to_char(next_run,'dd-mm-yyyy hh24:mi') from mm_config.schedule_master where sch_name in('Active','Archive') and status='Active';
