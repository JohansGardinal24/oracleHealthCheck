set lines 200
col member for a80
col status for a10
col type for a8
select group#, type, status, member from v$logfile order by group#, member;
