set lines 200
col tablespace_name for a30
col autoext for a8
select tablespace_name, count(*) datafiles,
       round(sum(bytes)/1024/1024/1024,2) size_gb,
       round(sum(case when autoextensible='YES' then greatest(maxbytes,bytes) else bytes end)/1024/1024/1024,2) max_gb,
       max(autoextensible) autoext
from dba_data_files
group by tablespace_name
order by tablespace_name;
