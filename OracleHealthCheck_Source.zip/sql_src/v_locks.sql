select 'INFO|'||case when count(*) > 0 then count(*)||' blocking session(s) found (waiting > &LOCK_WAIT_SEC s)'
                     else 'No blocking sessions found (waiting > &LOCK_WAIT_SEC s)' end
from gv$session
where lockwait is not null and row_wait_obj# != -1 and seconds_in_wait > &LOCK_WAIT_SEC;
