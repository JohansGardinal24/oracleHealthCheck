COL owner FOR a20
COL index_name FOR a30
SELECT owner, index_name, status FROM dba_indexes WHERE PARTITIONED='NO' and STATUS <> 'VALID';
