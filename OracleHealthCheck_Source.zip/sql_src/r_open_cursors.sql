col inst_id for 9999
col configured_open_cursors for a10
col current_open_cursors for 9999999
col usage_percent for 999.99
SELECT
    p.inst_id,
    p.value AS configured_open_cursors,
    s.value AS current_open_cursors,
    ROUND((s.value / p.value) * 100, 2) AS usage_percent
FROM gv$parameter p
JOIN gv$sysstat s
    ON p.inst_id = s.inst_id
WHERE p.name = 'open_cursors'
  AND s.name = 'opened cursors current'
ORDER BY p.inst_id;
