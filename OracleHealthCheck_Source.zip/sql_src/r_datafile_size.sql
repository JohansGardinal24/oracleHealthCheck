---datafile size
SELECT SUM(bytes)/1024/1024/1024 AS GB FROM dba_data_files;
