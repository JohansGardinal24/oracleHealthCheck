set lines 999;
col action_time for a33;
col description for a63;
col STATUS for a20;
select install_id,patch_id,patch_type,action,status,action_time,description from dba_registry_sqlpatch;
