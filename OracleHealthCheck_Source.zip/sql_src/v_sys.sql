select case when account_status = '&SYS_EXPIRY_CRIT_STATUS' then 'CRITICAL' else 'OK' end
       ||'|SYS account_status = '||account_status
from dba_users where username = 'SYS';
