SET ECHO OFF
SET FEEDBACK OFF
SET HEADING ON
SET PAGESIZE 1000
SET LINESIZE 200
SET VERIFY OFF
SET TERMOUT ON
SET TRIM ON
SET TRIMSPOOL ON

-- Prompt user for number of days
PROMPT ============================================
PROMPT ADDM Report Generation
PROMPT ============================================
PROMPT 
ACCEPT num_days NUMBER PROMPT 'Enter number of days to look back: '

PROMPT 
PROMPT Available Snapshots:
PROMPT ============================================
PROMPT SNAP_ID    SNAP_TIME (actual snapshot time - same as AWR report)
PROMPT ============================================

-- Display available snapshots
SELECT snap_id, 
       TO_CHAR(end_interval_time, 'DD-MON-YYYY HH24:MI:SS') AS snap_time
FROM dba_hist_snapshot
WHERE end_interval_time >=TRUNC(SYSDATE) - (&num_days - 1)
ORDER BY snap_id;

PROMPT ============================================
PROMPT 

-- Prompt for begin and end snap IDs
ACCEPT begin_snap NUMBER PROMPT 'Enter Beginning Snapshot ID: '
ACCEPT end_snap NUMBER PROMPT 'Enter Ending Snapshot ID: '

-- Get database ID and instance number
SET TERMOUT OFF
COLUMN dbid NEW_VALUE v_dbid NOPRINT
COLUMN instance_number NEW_VALUE v_inst_num NOPRINT
SELECT dbid FROM v$database;
SELECT instance_number FROM v$instance;

-- Generate report filename and ADDM task name with timestamp
COLUMN report_name NEW_VALUE v_report_name NOPRINT
SELECT '&rpt_dir\ADDM_Report_'||TRIM(TO_CHAR(&begin_snap))||'_'||TRIM(TO_CHAR(&end_snap))||'_'||TO_CHAR(SYSDATE,'YYYYMMDD_HH24MISS')||'.txt' AS report_name 
FROM dual;

COLUMN task_name NEW_VALUE v_task_name NOPRINT
SELECT 'ADDM_'||TRIM(TO_CHAR(&begin_snap))||'_'||TRIM(TO_CHAR(&end_snap))||'_'||TO_CHAR(SYSDATE,'MMDD_HH24MISS') AS task_name 
FROM dual;

SET TERMOUT ON

PROMPT 
PROMPT Running ADDM analysis (this can take a minute)...
PROMPT 

-- Run ADDM analysis for the selected snapshot range (current instance)
VARIABLE v_task VARCHAR2(100)
BEGIN
  :v_task := '&v_task_name';
  DBMS_ADDM.ANALYZE_INST(:v_task, &begin_snap, &end_snap, &v_inst_num, &v_dbid);
END;
/

-- Set output to file
SET TERMOUT OFF
SET HEADING OFF
SET PAGESIZE 0
SET LINESIZE 1000
SET LONG 100000000
SET LONGCHUNKSIZE 100000000

SPOOL "&v_report_name"

-- Generate ADDM report (text)
SELECT DBMS_ADDM.GET_REPORT(:v_task) FROM dual;

SPOOL OFF
SET TERMOUT ON

PROMPT Report generated at: &v_report_name
PROMPT ADDM task name     : &v_task_name
PROMPT ============================================
PROMPT 

EXIT
