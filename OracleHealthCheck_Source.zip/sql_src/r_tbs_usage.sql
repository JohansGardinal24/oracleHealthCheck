set lines 200
col tablespace_name for a30
col contents for a10
select m.tablespace_name, t.contents,
       round(m.used_space*t.block_size/1024/1024/1024,2) used_gb,
       round(m.tablespace_size*t.block_size/1024/1024/1024,2) max_gb,
       round(m.used_percent,1) used_pct
from dba_tablespace_usage_metrics m, dba_tablespaces t
where t.tablespace_name = m.tablespace_name
order by m.used_percent desc;
