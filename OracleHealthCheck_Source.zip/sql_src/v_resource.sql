with r as (
  select resource_name name, current_utilization cur,
         case when upper(trim(limit_value)) = 'UNLIMITED' then null else to_number(trim(limit_value)) end lim
  from v$resource_limit where resource_name in ('processes','sessions')
  union all
  select 'open_cursors(inst'||p.inst_id||')', to_number(s.value), to_number(p.value)
  from gv$parameter p join gv$sysstat s on p.inst_id = s.inst_id
  where p.name = 'open_cursors' and s.name = 'opened cursors current')
select case when sum(case when lim > 0 and cur/lim*100 >= &RESOURCE_CRIT then 1 else 0 end) > 0 then 'CRITICAL'
            when sum(case when lim > 0 and cur/lim*100 >= &RESOURCE_WARN then 1 else 0 end) > 0 then 'WARNING'
            else 'OK' end
       ||'|'||listagg(name||' '||cur||'/'||nvl(to_char(lim),'unlimited')||case when lim > 0 then ' ('||round(cur/lim*100,1)||'%)' end,'; ') within group (order by name)
from r;
