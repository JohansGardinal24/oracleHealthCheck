select case when bad > 0 or (total > 0 and act = total) then 'CRITICAL'
            when single_cnt > 0 then 'WARNING' else 'OK' end
       ||'|'||total||' groups, '||act||' ACTIVE, '||bad||' bad member(s), '||single_cnt||' group(s) with single member'
from (select (select count(*) from v$logfile where status in ('INVALID','DELETED')) bad,
             (select count(*) from v$log where status = 'ACTIVE') act,
             (select count(*) from v$log) total,
             (select count(*) from v$log where members < 2) single_cnt
      from dual);
