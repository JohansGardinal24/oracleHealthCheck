select 'INFO|Total segment size: '||round((select sum(bytes) from dba_segments)/1024/1024/1024,2)||' GB, datafile size: '
       ||round((select sum(bytes) from dba_data_files)/1024/1024/1024,2)||' GB'
from dual;
