set lines 300
set pages 200
col log_id for 9999999999
col owner for a12
col job_name for a25
col job_subname for a20
col session_id for 999999
col running_instance for 9999
col elapsed_time for a20
SELECT
    LOG_ID,
    OWNER,
    JOB_NAME,
    JOB_SUBNAME,
    SESSION_ID,
    RUNNING_INSTANCE,
    ELAPSED_TIME
FROM
    DBA_SCHEDULER_RUNNING_JOBS;
