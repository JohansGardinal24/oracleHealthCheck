select i.status||'|'||d.database_role||'|'||d.open_mode||'|'||d.db_unique_name||'|'||d.name from v$instance i, v$database d;
