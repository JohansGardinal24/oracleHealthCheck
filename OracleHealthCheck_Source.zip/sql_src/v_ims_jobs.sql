select 'INFO|See report for last_run/next_run of Active/Archive jobs (config + mm_config)' from dual;
