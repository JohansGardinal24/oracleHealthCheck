SET ECHO OFF
SET FEEDBACK OFF
SET HEADING ON
SET PAGESIZE 1000
SET LINESIZE 200
SET VERIFY OFF
SET TERMOUT ON
SET TRIM ON
SET TRIMSPOOL ON

PROMPT ============================================
PROMPT ASH Report Generation
PROMPT ============================================
PROMPT 
PROMPT Specify the timeframe to generate the ASH report
PROMPT ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
PROMPT Enter begin time for report:
PROMPT 
PROMPT --    Valid input formats:
PROMPT --       To specify absolute begin time:
PROMPT --          [MM/DD[/YY]] HH24:MI[:SS]
PROMPT --          Examples: 02/23/03 14:30:15
PROMPT --                    02/23 14:30:15
PROMPT --                    14:30:15
PROMPT --                    14:30
PROMPT --       To specify relative begin time: (start with '-' sign)
PROMPT --          -[HH24:]MI
PROMPT --          Examples: -1:15  (SYSDATE - 1 Hr 15 Mins)
PROMPT --                    -25    (SYSDATE - 25 Mins)
PROMPT 
PROMPT Defaults to -15 mins
ACCEPT begin_time CHAR DEFAULT '-15' PROMPT 'Enter value for begin_time: '

PROMPT 
PROMPT Enter number of minutes for report duration (default: 15)
PROMPT Note: If you used relative time above (e.g. -20), just press Enter
ACCEPT duration_mins NUMBER DEFAULT '15' PROMPT 'Enter duration in minutes: '

-- Check if it's relative time (starts with -)
SET TERMOUT OFF
COLUMN is_relative NEW_VALUE v_is_relative NOPRINT
SELECT CASE WHEN SUBSTR('&begin_time',1,1) = '-' THEN 'YES' ELSE 'NO' END AS is_relative FROM dual;

-- Calculate begin and end times
COLUMN begin_date NEW_VALUE v_begin_date NOPRINT
COLUMN end_date NEW_VALUE v_end_date NOPRINT

-- For relative time with minutes only (e.g., -20)
-- The duration entered will be ignored
SELECT 
    TO_CHAR(SYSDATE - (ABS(TO_NUMBER('&begin_time')) / 1440), 'MM/DD/YY HH24:MI:SS') AS begin_date,
    TO_CHAR(SYSDATE, 'MM/DD/YY HH24:MI:SS') AS end_date
FROM dual
WHERE '&v_is_relative' = 'YES'
  AND INSTR('&begin_time', ':') = 0;

-- For relative time with hours:minutes (e.g., -1:15)
SELECT 
    TO_CHAR(SYSDATE - ((ABS(TO_NUMBER(SUBSTR('&begin_time', 2, INSTR('&begin_time',':')-2))) * 60 + 
                        ABS(TO_NUMBER(SUBSTR('&begin_time', INSTR('&begin_time',':')+1)))) / 1440), 'MM/DD/YY HH24:MI:SS') AS begin_date,
    TO_CHAR(SYSDATE, 'MM/DD/YY HH24:MI:SS') AS end_date
FROM dual
WHERE '&v_is_relative' = 'YES'
  AND INSTR('&begin_time', ':') > 0;

-- For absolute time - use the duration entered
SELECT 
    TO_CHAR(TO_DATE('&begin_time', 'MM/DD/YY HH24:MI:SS'), 'MM/DD/YY HH24:MI:SS') AS begin_date,
    TO_CHAR(TO_DATE('&begin_time', 'MM/DD/YY HH24:MI:SS') + (&duration_mins / 1440), 'MM/DD/YY HH24:MI:SS') AS end_date
FROM dual
WHERE '&v_is_relative' = 'NO';

-- Get database ID and instance number
COLUMN dbid NEW_VALUE v_dbid NOPRINT
COLUMN instance_number NEW_VALUE v_inst_num NOPRINT
SELECT dbid FROM v$database;
SELECT instance_number FROM v$instance;

-- Generate report filename with timestamp
COLUMN report_name NEW_VALUE v_report_name NOPRINT
SELECT '&rpt_dir\ASH_Report_'||TO_CHAR(SYSDATE,'YYYYMMDD_HH24MISS')||'.html' AS report_name 
FROM dual;

SET TERMOUT ON
PROMPT 
PROMPT Generating ASH report...
PROMPT Report Period: &v_begin_date to &v_end_date
PROMPT 

-- Set output to file
SET TERMOUT OFF
SET PAGESIZE 0
SET LINESIZE 32767
SET LONG 100000000
SET LONGCHUNKSIZE 100000000

SPOOL "&v_report_name"

-- Generate ASH report
SELECT output FROM TABLE(DBMS_WORKLOAD_REPOSITORY.ASH_REPORT_HTML(
    &v_dbid,
    &v_inst_num,
    TO_DATE('&v_begin_date','MM/DD/YY HH24:MI:SS'),
    TO_DATE('&v_end_date','MM/DD/YY HH24:MI:SS')
));

SPOOL OFF
SET TERMOUT ON

PROMPT ============================================
PROMPT Report generated at: &v_report_name
PROMPT ============================================
PROMPT 

EXIT