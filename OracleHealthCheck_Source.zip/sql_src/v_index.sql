select 'INFO|'||(select count(*) from dba_indexes where partitioned = 'NO' and status <> 'VALID')||' invalid/unusable index(es), '
       ||(select count(*) from dba_ind_partitions where status = 'UNUSABLE')||' unusable index partition(s), '
       ||(select count(*) from dba_ind_subpartitions where status = 'UNUSABLE')||' unusable index subpartition(s) (no severity applied, informational only)'
from dual;
