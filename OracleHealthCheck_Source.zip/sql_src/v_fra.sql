select case when space_limit is null or space_limit = 0 then 'WARNING|FRA not configured or space limit is 0'
            else case when pct >= &FRA_CRIT then 'CRITICAL' when pct >= &FRA_WARN then 'WARNING' else 'OK' end
                 ||'|FRA '||to_char(pct,'FM990.0')||'% full (used - reclaimable)' end
from (select space_limit, round((space_used - space_reclaimable)/nullif(space_limit,0)*100,1) pct from v$recovery_file_dest);
