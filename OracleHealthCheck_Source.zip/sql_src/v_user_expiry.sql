select case when nvl(c,0) > 0 then 'CRITICAL' when nvl(w,0) > 0 then 'WARNING' else 'OK' end
       ||'|'||case when tot = 0 then 'No active TRANS users expiring within &USER_EXPIRY_LOOKAHEAD_DAYS day(s)'
                   else c||' critical (<=&USER_EXPIRY_CRITICAL_DAYS d), '||w||' warning (<=&USER_EXPIRY_WARNING_DAYS d), '||(tot-c-w)||' further out (within &USER_EXPIRY_LOOKAHEAD_DAYS d)'
                        ||case when c > 0 then '; CRITICAL: '||cl end
                        ||case when w > 0 then '; WARNING: '||wl end
              end
from (select count(*) tot,
             sum(case when d <= &USER_EXPIRY_CRITICAL_DAYS then 1 else 0 end) c,
             sum(case when d > &USER_EXPIRY_CRITICAL_DAYS and d <= &USER_EXPIRY_WARNING_DAYS then 1 else 0 end) w,
             listagg(case when d <= &USER_EXPIRY_CRITICAL_DAYS then user_name||'('||d||'d)' end,'; ' on overflow truncate '...') within group (order by d) cl,
             listagg(case when d > &USER_EXPIRY_CRITICAL_DAYS and d <= &USER_EXPIRY_WARNING_DAYS then user_name||'('||d||'d)' end,'; ' on overflow truncate '...') within group (order by d) wl
      from (select user_name, trunc(expires_on - sysdate) d
            from trans.users
            where status = 'Active' and expires_on < sysdate + &USER_EXPIRY_LOOKAHEAD_DAYS));
