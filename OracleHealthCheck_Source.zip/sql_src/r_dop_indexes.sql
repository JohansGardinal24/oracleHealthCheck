col owner for a20
col index_name for a30
col table_owner for a20
col table_name for a30
SELECT OWNER ,INDEX_NAME ,INDEX_TYPE , DEGREE,TABLE_OWNER ,TABLE_NAME FROM DBA_INDEXES where DEGREE > '1';
