set lines 100
col current_datafiles for 9999999 heading "CURRENT_DATAFILES"
col db_files_limit for 9999999 heading "DB_FILES_LIMIT"
col usage_percent for 999.99 heading "USAGE_PERCENT"
SELECT
    (SELECT COUNT(*) FROM v$datafile) AS current_datafiles,
    TO_NUMBER(value) AS db_files_limit,
    ROUND(
        (SELECT COUNT(*) FROM v$datafile) / TO_NUMBER(value) * 100,
        2
    ) AS usage_percent
FROM v$parameter
WHERE name = 'db_files';
