set lines 100
select ' SID '||
sid||' ,Serial# '||serial#||' user '||username||' is getting blocked by SID '||blocking_session|| ' for last '||seconds_in_wait||' seconds and wait_event '||event||' for SQL_ID '||sql_id
||' (Locked_Object_ID '||row_wait_obj#||' locked_block_id '||row_wait_block#||' locked_row_id '||row_wait_row#||')' "Active Locks"
from
   gv$session
where
   lockwait is not null and ROW_WAIT_OBJ#!=-1 and seconds_in_wait>&LOCK_WAIT_SEC
order by
   sid;
