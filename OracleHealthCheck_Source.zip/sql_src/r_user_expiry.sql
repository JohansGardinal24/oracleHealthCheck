col user_name for a30
select user_id,user_name,status,expires_on from trans.users where status='Active' and expires_on < sysdate + &USER_EXPIRY_LOOKAHEAD_DAYS;
