select 'INFO|'||count(*)||' job(s) currently running' from dba_scheduler_running_jobs;
