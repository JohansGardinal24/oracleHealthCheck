set lines 200
col tablespace_name for a20
SELECT
    ts.tablespace_name,
    TRUNC(snap.begin_interval_time) AS usage_date,
    ROUND(AVG(hs.tablespace_usedsize * ts.block_size) / (1024 * 1024), 2) AS avg_used_mb,
    ROUND(AVG(hs.tablespace_size * ts.block_size) / (1024 * 1024), 2) AS avg_allocated_mb,
    ROUND(AVG((hs.tablespace_usedsize / NULLIF(hs.tablespace_size, 0)) * 100), 2) AS avg_pct_used
FROM
    dba_hist_tbspc_space_usage hs
JOIN
    dba_hist_snapshot snap
    ON hs.snap_id = snap.snap_id
   AND hs.dbid = snap.dbid
JOIN
    v$tablespace vts
    ON hs.tablespace_id = vts.ts#
JOIN
    dba_tablespaces ts
    ON vts.name = ts.tablespace_name
WHERE
    ts.contents = 'TEMPORARY'
    AND snap.begin_interval_time >= TRUNC(SYSDATE) - &TEMP_HIST_DAYS
GROUP BY
    ts.tablespace_name,
    TRUNC(snap.begin_interval_time)
ORDER BY
    ts.tablespace_name,
    usage_date DESC;
