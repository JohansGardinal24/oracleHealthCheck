select case when cnt > 0 then 'CRITICAL|'||cnt||' FAILED job(s) in last &RMAN_LOOKBACK_DAYS d - '||detail
            else 'OK|No FAILED RMAN job(s) in the last &RMAN_LOOKBACK_DAYS day(s)' end
from (select count(*) cnt,
             listagg(operation||' ('||nvl(object_type,'-')||') '||to_char(start_time,'YYYY-MM-DD HH24:MI'),'; ' on overflow truncate '...') within group (order by start_time desc) detail
      from v$rman_status
      where upper(status) like '%FAILED%' and start_time >= sysdate - &RMAN_LOOKBACK_DAYS and operation <> 'LIST');
