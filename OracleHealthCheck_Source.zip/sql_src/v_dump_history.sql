select 'INFO|'||case when cnt = 0 then 'No JOB_IMS_EXP runs found in the last 7 days'
                    else cnt||' run(s) in last 7 days; latest: '||latest_status||' at '||to_char(latest_start,'YYYY-MM-DD HH24:MI')||', duration '||latest_dur
               end
from (select count(*) cnt,
             max(status) keep (dense_rank first order by log_date desc) latest_status,
             max(actual_start_date) keep (dense_rank first order by log_date desc) latest_start,
             max(substr(to_char(run_duration),12,8)) keep (dense_rank first order by log_date desc) latest_dur
      from all_scheduler_job_run_details
      where job_name = 'JOB_IMS_EXP' and actual_start_date >= trunc(sysdate - 7) and owner = 'TRANS');
