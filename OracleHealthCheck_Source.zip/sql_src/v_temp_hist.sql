select case when sum(case when p >= &TBS_CRIT then 1 else 0 end) > 0 then 'CRITICAL'
            when sum(case when p >= &TBS_WARN then 1 else 0 end) > 0 then 'WARNING'
            else 'OK' end
       ||'|TEMP hist (&TEMP_HIST_DAYS d worst): '||nvl(max(tablespace_name) keep (dense_rank last order by p),'n/a')||' '
       ||nvl(to_char(max(p),'FM990.00'),'0')||'% ('
       ||nvl(sum(case when p >= &TBS_CRIT then 1 else 0 end),0)||' critical, '
       ||nvl(sum(case when p >= &TBS_WARN and p < &TBS_CRIT then 1 else 0 end),0)||' warning)'
from (select tablespace_name, max(avg_pct) p
      from (select ts.tablespace_name tablespace_name, trunc(snap.begin_interval_time) usage_date,
                   round(avg((hs.tablespace_usedsize / nullif(hs.tablespace_size,0)) * 100),2) avg_pct
            from dba_hist_tbspc_space_usage hs
            join dba_hist_snapshot snap on hs.snap_id = snap.snap_id and hs.dbid = snap.dbid
            join v$tablespace vts on hs.tablespace_id = vts.ts#
            join dba_tablespaces ts on vts.name = ts.tablespace_name
            where ts.contents = 'TEMPORARY' and snap.begin_interval_time >= trunc(sysdate) - &TEMP_HIST_DAYS
            group by ts.tablespace_name, trunc(snap.begin_interval_time))
      group by tablespace_name);
