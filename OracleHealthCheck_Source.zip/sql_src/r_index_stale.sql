SELECT MAX(last_analyzed), MIN(last_analyzed)
FROM dba_ind_statistics
WHERE stale_stats='NO' AND table_owner IN (select username from all_users where oracle_maintained = 'N');
