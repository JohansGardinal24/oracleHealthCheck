select 'INFO|Top 5 non-idle wait events collected (see report)' from dual;
