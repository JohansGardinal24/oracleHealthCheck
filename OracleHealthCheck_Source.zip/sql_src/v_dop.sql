select 'INFO|'||count(*)||' index(es) with parallel DEGREE > 1' from dba_indexes where degree > '1';
