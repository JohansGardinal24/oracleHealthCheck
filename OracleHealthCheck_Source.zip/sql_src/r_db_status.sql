set lines 300
col instance_name for a14
col host_name for a26
col instance_status for a16
col database_status for a16
col startup_time for a17
col db_name for a10
col database_role for a17
col open_mode for a20
col log_mode for a12
select i.instance_name, i.host_name, i.status instance_status, i.database_status,
       to_char(i.startup_time,'YYYY-MM-DD HH24:MI') startup_time,
       d.name db_name, d.database_role, d.open_mode, d.log_mode
from v$instance i, v$database d;
