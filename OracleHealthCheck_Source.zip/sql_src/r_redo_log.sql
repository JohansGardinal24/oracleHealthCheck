set lines 200
select group#, thread#, sequence#, round(bytes/1024/1024) size_mb, members, archived, status
from v$log order by thread#, group#;
