col sch_name for a30
select sch_id,sch_type,status,sch_name,terminate_on from config.schedule_master where status='Active' and terminate_on < sysdate + &IMS_SCHEDULER_LOOKAHEAD_DAYS;
