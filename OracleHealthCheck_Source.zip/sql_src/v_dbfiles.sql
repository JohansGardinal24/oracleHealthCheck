select case when pct >= &DBFILES_CRIT then 'CRITICAL' when pct >= &DBFILES_WARN then 'WARNING' else 'OK' end
       ||'|db_files usage '||to_char(pct,'FM990.00')||'%'
from (select round((select count(*) from v$datafile)/to_number(value)*100,2) pct from v$parameter where name = 'db_files');
