r"""Simple Git-free backup and change tracking.

Run from the project root:
    python tools\snapshot.py -m "what I just did"   create a backup zip + manifest
    python tools\snapshot.py --diff                 compare the working files with the latest snapshot
    python tools\snapshot.py --list                 list snapshots (newest last)

Snapshots go to a folder NEXT TO the project (<project>_backups) unless --dest is given.
Copy that folder to another drive or a network share now and then: a backup on the same
disk does not protect you from a disk failure.
Excluded: .venv, build, dist, __pycache__, dev_home, .git, *.pyc, *.dat.
"""
from __future__ import annotations

import hashlib
import os
import sys
import zipfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
EXCLUDE_DIRS = {".venv", "build", "dist", "__pycache__", ".git", "dev_home"}
EXCLUDE_SUFFIX = {".pyc", ".dat"}


def project_files(root: Path = ROOT) -> dict:
    """relative posix path -> SHA-256 for every file that belongs in a backup."""
    result = {}
    for folder, dirs, names in os.walk(root):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        for n in names:
            p = Path(folder) / n
            if p.suffix.lower() in EXCLUDE_SUFFIX:
                continue
            result[p.relative_to(root).as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest()
    return dict(sorted(result.items()))


def read_manifest(path: Path) -> tuple:
    note, files = "", {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith("# note:"):
            note = line[7:].strip()
        elif line and not line.startswith("#"):
            sha, _, name = line.partition("  ")
            files[name] = sha
    return note, files


def snapshots(dest: Path) -> list:
    return sorted(dest.glob("*.manifest.txt")) if dest.is_dir() else []


def diff(old: dict, new: dict) -> tuple:
    added = sorted(set(new) - set(old))
    deleted = sorted(set(old) - set(new))
    modified = sorted(n for n in set(old) & set(new) if old[n] != new[n])
    return added, modified, deleted


def create(dest: Path, note: str) -> int:
    dest.mkdir(parents=True, exist_ok=True)
    files = project_files()
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    base = dest / f"{ROOT.name}_{stamp}"
    zip_path, man_path = Path(str(base) + ".zip"), Path(str(base) + ".manifest.txt")
    manifest = [f"# created: {datetime.now().isoformat(timespec='seconds')}", f"# note: {note}"]
    manifest += [f"{sha}  {name}" for name, sha in files.items()]
    with open(man_path, "x", encoding="utf-8", newline="\n") as f:  # 'x' = never overwrite
        f.write("\n".join(manifest) + "\n")
    with zipfile.ZipFile(zip_path, "x", zipfile.ZIP_DEFLATED) as z:
        for name in files:
            z.write(ROOT / name, name)
    with zipfile.ZipFile(zip_path) as z:
        if z.testzip() is not None:
            print("ERROR: the zip failed its self-test")
            return 1
    print(f"Snapshot created: {zip_path.name}  ({len(files)} files, {zip_path.stat().st_size // 1024} KB)")
    print(f"Folder: {dest}")
    return 0


def main(argv: list) -> int:
    dest = ROOT.parent / f"{ROOT.name}_backups"
    if "--dest" in argv:
        i = argv.index("--dest")
        dest = Path(argv[i + 1])
        del argv[i:i + 2]
    if argv == ["--list"]:
        for m in snapshots(dest):
            print(f"{m.name[:-len('.manifest.txt')]}   {read_manifest(m)[0]}")
        return 0
    if argv == ["--diff"]:
        snaps = snapshots(dest)
        if not snaps:
            print("No snapshots yet. Create one with: python tools\\snapshot.py -m \"note\"")
            return 0
        note, old = read_manifest(snaps[-1])
        added, modified, deleted = diff(old, project_files())
        print(f"Compared with: {snaps[-1].name[:-len('.manifest.txt')]}  ({note})")
        for label, items in (("ADDED", added), ("MODIFIED", modified), ("DELETED", deleted)):
            for n in items:
                print(f"  {label:9s}{n}")
        if not (added or modified or deleted):
            print("  No changes since the last snapshot.")
        return 0
    if len(argv) == 2 and argv[0] == "-m" and argv[1].strip():
        return create(dest, argv[1].strip())
    print('usage: python tools\\snapshot.py -m "note" | --diff | --list   [--dest FOLDER]')
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))