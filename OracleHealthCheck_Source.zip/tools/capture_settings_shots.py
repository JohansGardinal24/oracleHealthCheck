"""Run from the project root on a real display (Windows): python tools\\capture_settings_shots.py
Writes shots\\settings_light.png and shots\\settings_dark.png of the Settings page."""
from pathlib import Path

from PySide6.QtWidgets import QApplication

from ohc.gui.main_window import MainWindow

SETTINGS_ROW = 6
app = QApplication([])
win = MainWindow()
win.resize(1583, 900)
win.show()
out = Path("shots")
out.mkdir(exist_ok=True)
for theme in ("light", "dark"):
    win.theme.set_theme(theme)
    win._open(SETTINGS_ROW)
    for _ in range(40):
        app.processEvents()
    win.grab().save(str(out / f"settings_{theme}.png"))
win.theme.set_theme("light")          # leave the saved theme as it was likely set
print("saved to", out.resolve())
