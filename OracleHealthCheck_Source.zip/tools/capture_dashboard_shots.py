"""Run from the project root on a real display (Windows): python tools\\capture_dashboard_shots.py
Writes shots\\dashboard_light.png and shots\\dashboard_dark.png of the Dashboard (run All Checks first, then capture, to see results)."""
from pathlib import Path

from PySide6.QtWidgets import QApplication

from ohc.gui.main_window import MainWindow

DASHBOARD_ROW = 0
app = QApplication([])
win = MainWindow()
win.resize(1583, 900)
win.show()
out = Path("shots")
out.mkdir(exist_ok=True)
for theme in ("light", "dark"):
    win.theme.set_theme(theme)
    win._open(DASHBOARD_ROW)
    for _ in range(40):
        app.processEvents()
    win.grab().save(str(out / f"dashboard_{theme}.png"))
win.theme.set_theme("light")
print("saved to", out.resolve())
