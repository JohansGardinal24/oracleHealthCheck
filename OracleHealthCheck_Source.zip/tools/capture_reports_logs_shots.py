"""Run from the project root on a real display (Windows): python tools\\capture_reports_logs_shots.py
Writes shots\\reports_logs_{light,dark}.png of the Reports & Logs page (set OHC_FAKE_ORACLE=healthy first for simulated runs)."""
from pathlib import Path

from PySide6.QtWidgets import QApplication

from ohc.gui.main_window import MainWindow

REPORTS_LOGS_ROW = 5
app = QApplication([])
win = MainWindow()
win.resize(1583, 900)
win.show()
out = Path("shots")
out.mkdir(exist_ok=True)
for theme in ("light", "dark"):
    win.theme.set_theme(theme)
    win._open(REPORTS_LOGS_ROW)
    for _ in range(40):
        app.processEvents()
    win.grab().save(str(out / f"reports_logs_{theme}.png"))
print("saved to", out.resolve())
