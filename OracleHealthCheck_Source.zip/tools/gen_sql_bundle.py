r"""Generate ohc/resources/sql_bundle.py from sql_src/*.sql (byte-exact).

Run from the project root:
    python tools\gen_sql_bundle.py          write / refresh the bundle
    python tools\gen_sql_bundle.py --check  verify the bundle is current (writes nothing)
"""
from __future__ import annotations

import hashlib
import os
import re
import sys
from pathlib import Path
from typing import NamedTuple

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "sql_src"
OUT = ROOT / "ohc" / "resources" / "sql_bundle.py"
NAME_RE = re.compile(r"^[A-Za-z0-9_.-]+\.sql$")
BOM = b"\xef\xbb\xbf"


class Bundle(NamedTuple):
    text: str
    files: dict  # name -> (sha256, bytes)
    bundle_sha256: str
    warnings: list


def manifest_text(files: dict) -> str:
    """'<sha256>  <name>' lines sorted by name; its SHA-256 is the bundle hash."""
    return "".join(f"{files[n][0]}  {n}\n" for n in sorted(files))


def _render(files: dict, bundle_sha: str) -> str:
    out = [
        "# GENERATED FILE - DO NOT EDIT BY HAND.",
        "# Source of truth: sql_src\\*.sql (development only; never shipped).",
        "# Regenerate:  python tools\\gen_sql_bundle.py",
        "# Verify:      python tools\\gen_sql_bundle.py --check",
        "",
        "BUNDLE_FORMAT = 1",
        f'BUNDLE_SHA256 = "{bundle_sha}"',
        f"FILE_COUNT = {len(files)}",
        "",
        "SQL_FILES = {",
    ]
    for name in sorted(files):
        sha, data = files[name]
        out.append(f'    "{name}": (')
        out.append(f'        "{sha}",')
        out.append("        (")
        for line in data.splitlines(keepends=True):
            out.append(f"            {line!r}")
        out.append("        ),")
        out.append("    ),")
    out.append("}")
    return "\n".join(out) + "\n"


def build(src: Path = SRC) -> Bundle:
    if not src.is_dir():
        raise SystemExit(f"ERROR: SQL source folder not found: {src}")
    files, warnings, errors = {}, [], []
    for p in sorted(src.iterdir(), key=lambda x: x.name):
        if not p.is_file() or not NAME_RE.match(p.name):
            errors.append(f"unexpected item in sql_src (only *.sql files with simple names): {p.name}")
            continue
        data = p.read_bytes()
        if not data:
            errors.append(f"empty file: {p.name}")
        elif data.startswith(BOM):
            errors.append(f"{p.name} starts with a UTF-8 BOM; save it as UTF-8 without BOM")
        else:
            if b"\r" in data:
                warnings.append(f"{p.name} contains CR bytes (CRLF); the original scripts use LF only")
            files[p.name] = (hashlib.sha256(data).hexdigest(), data)
    if not errors and not files:
        errors.append("sql_src contains no .sql files")
    if errors:
        raise SystemExit("ERROR:\n  " + "\n  ".join(errors))
    bundle_sha = hashlib.sha256(manifest_text(files).encode("utf-8")).hexdigest()
    return Bundle(_render(files, bundle_sha), files, bundle_sha, warnings)


def main(argv: list) -> int:
    if any(a != "--check" for a in argv):
        print("usage: python tools\\gen_sql_bundle.py [--check]")
        return 2
    b = build()
    for w in b.warnings:
        print("WARNING:", w)
    new = b.text.encode("ascii")
    if argv:  # --check
        if not OUT.is_file():
            print("FAIL: bundle file is missing. Run: python tools\\gen_sql_bundle.py")
            return 1
        if OUT.read_bytes() != new:
            print("FAIL: bundle is OUT OF DATE with sql_src. Run: python tools\\gen_sql_bundle.py")
            return 1
        print(f"OK: bundle is current ({len(b.files)} scripts, sha256 {b.bundle_sha256})")
        return 0
    OUT.parent.mkdir(parents=True, exist_ok=True)
    if OUT.is_file() and OUT.read_bytes() == new:
        print("Bundle already up to date.")
    else:
        tmp = OUT.with_name(OUT.name + ".tmp")
        tmp.write_bytes(new)
        os.replace(tmp, OUT)
        print(f"Bundle written: {OUT}")
    print(f"{len(b.files)} scripts, bundle sha256 {b.bundle_sha256}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))