r"""Developer helper for the credential store (not shipped in the EXE).

    python -m tools.cred_probe new-id
    python -m tools.cred_probe save   [--id ID] [--folder DIR]
    python -m tools.cred_probe check  --id ID [--folder DIR]
    python -m tools.cred_probe delete --id ID [--folder DIR]

The password is read from a hidden prompt, never from the command line. Only lengths are printed.
Default folder: the current Windows account's credentials folder under the development install root.
"""
from __future__ import annotations

import argparse
import getpass
import sys
from pathlib import Path

from ohc import paths, userstore
from ohc.security import credstore, dpapi


def _folder(arg) -> Path:
    return Path(arg) if arg else userstore.ensure_user_dir(paths.app_root()).credentials


def main(argv: list, backend=dpapi) -> int:
    parser = argparse.ArgumentParser(prog="cred_probe")
    parser.add_argument("action", choices=["new-id", "save", "check", "delete"])
    parser.add_argument("--id")
    parser.add_argument("--folder")
    args = parser.parse_args(argv)
    try:
        if args.action == "new-id":
            print(credstore.new_database_id())
            return 0
        if args.action == "save":
            db_id = args.id or credstore.new_database_id()
            username = input("Username: ")
            password = getpass.getpass("Password (hidden): ")
            credstore.save_credentials(_folder(args.folder), db_id, username, password, backend=backend)
            print(f"saved: id {db_id}")
            return 0
        if not args.id:
            parser.error("--id is required")
        if args.action == "check":
            with credstore.load_credentials(_folder(args.folder), args.id, backend=backend) as creds:
                print(f"OK: username {len(creds.username)} bytes, password {len(creds.password)} bytes")
            return 0
        print("deleted" if credstore.delete_credentials(_folder(args.folder), args.id) else "nothing to delete")
        return 0
    except credstore.CredentialError as exc:
        print(f"FAILED ({exc.category}): {exc}")
        return 1
    except (ValueError, TypeError) as exc:
        print(f"FAILED (input): {exc}")
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))