"""Run from the project root (real display, Windows): python tools\\capture_shots.py -> shots\\option{1,2,3}_{light,dark}.png"""
from pathlib import Path

from PySide6.QtWidgets import QApplication

from ohc.gui.main_window import MainWindow

app = QApplication([])
win = MainWindow()
win.resize(1583, 900)
win.show()
out = Path("shots")
out.mkdir(exist_ok=True)
for theme in ("light", "dark"):
    win.theme.set_theme(theme)
    for row in (1, 2, 3):
        win._open(row)
        app.processEvents()
        app.processEvents()
        win.grab().save(str(out / f"option{row}_{theme}.png"))
print("saved to", out.resolve())
