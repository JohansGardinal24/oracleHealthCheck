r"""Compare sql_src with the ORIGINAL baseline and the approved-changes record.

Run from the project root:
    python tools\sql_baseline.py              report; exit code 1 if anything is unapproved
    python tools\sql_baseline.py --suggest    print ready-to-paste lines for tools\sql_changes.txt
    python tools\sql_baseline.py --hash NAME  print the SHA-256 of sql_src\NAME

tools\original_sql.sha256 is the ORIGINAL baseline and is never edited.
tools\sql_changes.txt records deliberate changes: ACTION | filename | sha256 | reason
"""
from __future__ import annotations

import hashlib
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SQL_SRC = ROOT / "sql_src"
BASELINE = ROOT / "tools" / "original_sql.sha256"
CHANGES = ROOT / "tools" / "sql_changes.txt"
ACTIONS = ("CHANGED", "ADDED", "REMOVED")
HEX64 = re.compile(r"^[0-9a-f]{64}$")
MIN_REASON = 10


def parse_manifest(text: str) -> dict:
    """Parse '<sha256>  <name>' lines (sha256sum format)."""
    result = {}
    for n, line in enumerate(text.splitlines(), 1):
        if not line.strip():
            continue
        sha, sep, name = line.partition("  ")
        if not sep or not HEX64.match(sha) or not name:
            raise ValueError(f"baseline line {n} is not '<sha256>  <name>'")
        if name in result:
            raise ValueError(f"baseline line {n}: duplicate name {name}")
        result[name] = sha
    return result


def parse_changes(text: str) -> tuple:
    """Return (records, problems). records: name -> {action, sha, reason}."""
    records, problems = {}, []
    for n, raw in enumerate(text.splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = [p.strip() for p in line.split("|", 3)]
        if len(parts) != 4:
            problems.append(f"sql_changes.txt line {n}: expected 'ACTION | filename | sha256 | reason'")
            continue
        action, name, sha, reason = parts
        action, sha = action.upper(), sha.lower()
        if action not in ACTIONS:
            problems.append(f"sql_changes.txt line {n}: ACTION must be one of {', '.join(ACTIONS)}")
        elif not (HEX64.match(sha) or (action == "REMOVED" and sha == "-")):
            problems.append(f"sql_changes.txt line {n}: sha256 must be 64 hex characters (use - for REMOVED)")
        elif name in records:
            problems.append(f"sql_changes.txt line {n}: {name} is listed twice; keep ONE line per file")
        else:
            records[name] = {"action": action, "sha": sha, "reason": reason}
    return records, problems


def hash_dir(folder: Path) -> dict:
    return {
        p.name: hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(folder.iterdir())
        if p.is_file() and p.suffix == ".sql"
    }


def evaluate(baseline: dict, current: dict, records: dict) -> tuple:
    """Return (problems, status). Pure function: easy to unit test."""
    problems, status = [], {}
    for name in sorted(set(baseline) | set(current) | set(records)):
        b, c, r = baseline.get(name), current.get(name), records.get(name)
        if b and c and b == c:
            status[name] = "unchanged"
            if r:
                problems.append(f"{name}: has a {r['action']} record but equals the original; remove the record")
            continue
        if b and c:
            expected = "CHANGED"
        elif c:
            expected = "ADDED"
        elif b:
            expected = "REMOVED"
        else:
            problems.append(f"{name}: record exists but the file is in neither the baseline nor sql_src; remove the record")
            continue
        if r is None:
            status[name] = f"UNAPPROVED {expected}"
            problems.append(f"{name}: {expected} but not recorded in tools\\sql_changes.txt")
            continue
        if r["action"] != expected:
            status[name] = "WRONG RECORD"
            problems.append(f"{name}: record says {r['action']} but the file state is {expected}")
            continue
        want = c if c else "-"
        if r["sha"] != want:
            status[name] = "CHANGED AFTER APPROVAL"
            problems.append(
                f"{name}: file differs from its recorded hash (recorded {r['sha'][:12]}, now {want[:12]}); "
                "update the record"
            )
            continue
        reason = r["reason"]
        if reason.upper().startswith("REASON:") or len(reason) < MIN_REASON:
            status[name] = "REASON MISSING"
            problems.append(f"{name}: write a real reason (at least {MIN_REASON} characters)")
            continue
        status[name] = f"approved {expected}"
    return problems, status


def load_state() -> tuple:
    for f in (BASELINE, CHANGES):
        if not f.is_file():
            raise SystemExit(f"ERROR: missing required file: {f}")
    baseline = parse_manifest(BASELINE.read_text(encoding="utf-8-sig"))
    records, parse_problems = parse_changes(CHANGES.read_text(encoding="utf-8-sig"))
    problems, status = evaluate(baseline, hash_dir(SQL_SRC), records)
    return parse_problems + problems, status, hash_dir(SQL_SRC)


def main(argv: list) -> int:
    if len(argv) == 2 and argv[0] == "--hash":
        p = SQL_SRC / argv[1]
        if not p.is_file():
            print(f"ERROR: not found: {p}")
            return 2
        print(hashlib.sha256(p.read_bytes()).hexdigest())
        return 0
    if argv not in ([], ["--suggest"]):
        print("usage: python tools\\sql_baseline.py [--suggest | --hash NAME]")
        return 2
    problems, status, current = load_state()
    counts = {}
    for s in status.values():
        counts[s] = counts.get(s, 0) + 1
    print("Scripts compared with the original baseline:")
    for label in sorted(counts):
        print(f"  {counts[label]:3d}  {label}")
    for name, s in sorted(status.items()):
        if s != "unchanged":
            print(f"  -> {name}: {s}")
    if argv == ["--suggest"]:
        print("\nPaste into tools\\sql_changes.txt (replace the REASON text):")
        for name, s in sorted(status.items()):
            if s.startswith("UNAPPROVED") or s in ("CHANGED AFTER APPROVAL", "REASON MISSING"):
                act = {"UNAPPROVED CHANGED": "CHANGED", "UNAPPROVED ADDED": "ADDED", "UNAPPROVED REMOVED": "REMOVED"}.get(s, "CHANGED")
                sha = current.get(name, "-")
                print(f"{act} | {name} | {sha} | REASON: describe what changed and why")
    if problems:
        print("\nPROBLEMS:")
        for p in problems:
            print("  -", p)
        return 1
    print("\nOK: sql_src matches the original baseline plus the approved changes.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))