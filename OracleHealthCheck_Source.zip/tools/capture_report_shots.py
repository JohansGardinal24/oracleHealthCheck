"""Run from the project root on a real display (Windows): python tools\\capture_report_shots.py
Writes shots\\reports_{awr,ash,addm}_{light,dark}.png of the Database Reports pages (set OHC_FAKE_ORACLE=healthy first for the simulated data)."""
from pathlib import Path

from PySide6.QtWidgets import QApplication

from ohc.gui.main_window import MainWindow

REPORTS_ROW = 4
app = QApplication([])
win = MainWindow()
win.resize(1583, 900)
win.show()
out = Path("shots")
out.mkdir(exist_ok=True)
for theme in ("light", "dark"):
    win.theme.set_theme(theme)
    for tab, name in enumerate(("awr", "ash", "addm")):
        win._open(REPORTS_ROW, tab)
        app.processEvents()
        app.processEvents()
        win.grab().save(str(out / f"reports_{name}_{theme}.png"))
print("saved to", out.resolve())
