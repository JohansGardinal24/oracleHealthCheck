"""ADDM report logic without Qt (snapshot validation, naming, history). Shared helpers come from ohc.awr.

The report is made by DBMS_ADDM (see ohc.checks.session.addm_variant_sql): a task is analysed for the chosen AWR snapshot range
(ANALYZE_INST for the connected instance, ANALYZE_DB for RAC / all instances) and its report is spooled to the file.
The original ADDM_Report.sql is not changed and not used (it is interactive, text-only, single-instance and has a fixed file name).
"""
from __future__ import annotations

import re
from datetime import datetime

from ohc import awr

INDEX_NAME = "addm_index.json"
MARKER = "ADDM REPORT"                                    # header of DBMS_ADDM.GET_REPORT text ("ADDM Report for Task ...")
DEFAULT_NAME_PREFIX = "ADDM_Report"
REPORT_RE = re.compile(r"^ADDM_Report_(?P<b>\d+)_(?P<e>\d+)_(?P<ts>(?P<d>\d{8})_(?P<t>\d{6}))\.(?P<x>html|txt)$", re.I)


def default_name(begin=None, end=None) -> str:
    """Report Name default (no extension): the legacy pattern ADDM_Report_<begin>_<end>_<timestamp>."""
    return f"{DEFAULT_NAME_PREFIX}_{begin if begin is not None else '<begin>'}_{end if end is not None else '<end>'}_{awr.NAME_TOKEN}"


def task_name(begin: int, end: int, now: datetime) -> str:
    """Advisor task name, same pattern as the legacy script: ADDM_<begin>_<end>_<yyyymmdd_HHMMSS>."""
    return f"ADDM_{int(begin)}_{int(end)}_{now.strftime('%Y%m%d_%H%M%S')}"


def scan_history(report_base, index_dir=None):
    """ADDM reports only: legacy ADDM_Report_<b>_<e>_<yyyymmdd>_<HHMMSS>.txt/.html plus custom-named ones recorded in addm_index.json."""
    return awr.scan_history(report_base, REPORT_RE, INDEX_NAME, index_dir)


def record_report(base, path, db, simulated, begin, end, rac=False, when=None, index_dir=None) -> str:
    return awr.record_report(base, path, db, simulated, begin, end, rac, when, INDEX_NAME, index_dir)
