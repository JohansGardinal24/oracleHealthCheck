"""ADDM report generation for the Database Reports page (no Qt; runs in the GUI's worker thread).

Same plumbing as ohc.awr_service / ohc.ash_service: launcher profile, Oracle Home, DPAPI credentials, SQL*Plus session (login on stdin
only, private temp folder, cancellation) or the fake session when OHC_FAKE_ORACLE is set. Snapshot loading is awr_service.load_snapshots.
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from ohc import addm, awr
from ohc.awr_service import AwrResult, _cleanup, _fail, _msg, _simulated
from ohc.checks import engine, launcher
from ohc.checks.cancel import RunCancelled
from ohc.checks.session import ToolError


FMT = "text"                                              # the only ADDM output: .txt


class AddmError(awr.AwrError):
    """Invalid ADDM input or a failed ADDM run (a readable message)."""


def generate_report(ctx, db_name: str, begin: int, end: int, cancel=None, name=None, rac: bool = False) -> AwrResult:
    """ADDM is TEXT ONLY (.txt, DBMS_ADDM.GET_REPORT). Success only when a valid, non-empty report file exists. Never overwrites; incomplete files are removed again."""
    sim = _simulated()
    target, ours = None, False
    try:
        if not (isinstance(begin, int) and isinstance(end, int) and 0 < begin < end):
            raise AddmError("Begin Snap ID must be lower than End Snap ID.")
        now = datetime.now()
        entry, home, env, th = launcher._prepare(ctx, db_name, False)
        folder = Path(ctx.root) / "reports" / engine.format_dotnet_date(now, env["REPORT_DATE_FORMAT"])
        shown = name if name is not None else addm.default_name(begin, end)
        problem = awr.check_report_name(shown, FMT, folder, now)
        if problem:
            raise AddmError(problem)
        target = folder / (awr.resolve_name(shown, now) + awr.FORMATS[FMT])
        try:
            folder.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise ToolError(f"Cannot create the report folder {folder}: {exc}") from None
        if target.exists():                                   # also covers two runs of a token name within one second
            raise AddmError(f"{target.name} already exists in today's report folder - choose another name.")
        ours = True
        task = addm.task_name(begin, end, now)
        if cancel is not None:
            cancel.check()
        with launcher._open(ctx, entry, home, env, th, cancel) as session:
            simulated = bool(getattr(session, "simulated", False))
            output = session.addm_report(target, rac, begin, end, task)
        if not target.is_file():
            raise AddmError(awr.error_text(output) or "SQL*Plus finished, but no ADDM report file was created.")
        try:
            if target.stat().st_size == 0:
                raise AddmError("Oracle returned an empty ADDM report (no output for that snapshot range).")
            awr.check_report_file(target, FMT, addm.MARKER)
        except AddmError:
            _cleanup([target])
            raise
        except awr.AwrError as exc:
            _cleanup([target])
            raise AddmError(str(exc)) from None
    except RunCancelled:
        if ours and target is not None:
            _cleanup([target])
        return AwrResult("addm", False, True, _msg(sim, "ADDM report generation was cancelled; the incomplete file was removed."), db=db_name, simulated=sim)
    except (awr.AwrError, ToolError) as exc:
        if ours and target is not None:
            _cleanup([target])
        return _fail("addm", db_name, sim, "The ADDM report was not created.", exc)
    except Exception as exc:
        if ours and target is not None:
            _cleanup([target])
        return _fail("addm", db_name, sim, "The ADDM report was not created (unexpected error).", repr(exc))
    note = addm.record_report(Path(ctx.root) / "reports", target, db_name, simulated, begin, end, rac, now, index_dir=awr.index_dir_for(ctx.root))
    return AwrResult("addm", True, message=_msg(simulated, f"ADDM report created: {target.name} (snapshots {begin} to {end}, task {task})"),
                     path=target, db=db_name, simulated=simulated, note=note)
