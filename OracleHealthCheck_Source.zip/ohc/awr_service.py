"""AWR operations for the Database Reports page (no Qt; runs in the GUI's worker thread).

Reuses the existing launcher plumbing: database profile, Oracle Home, DPAPI credentials, the SQL*Plus session (login on
stdin, private temp folder, cancellation) or the fake session when OHC_FAKE_ORACLE is set.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from ohc import awr
from ohc.checks import engine, launcher
from ohc.checks.cancel import RunCancelled
from ohc.checks.session import ToolError
from ohc.config import environment

PREFIX = "SIMULATED DATA - "


@dataclass
class AwrResult:
    kind: str                    # "snapshots" | "report"
    ok: bool
    cancelled: bool = False
    message: str = ""            # one readable line
    detail: str = ""             # ORA-/SP2- lines or the tool problem
    snaps: object = None         # awr.SnapList (kind == "snapshots")
    path: Path | None = None     # generated report (kind == "report")
    db: str = ""
    simulated: bool = False
    note: str = ""               # non-fatal problem (e.g. the history index could not be written)


def _simulated() -> bool:
    try:
        return bool(launcher.fake_scenario())
    except ToolError:
        return False


def _msg(sim: bool, text: str) -> str:
    return PREFIX + text if sim else text


def _fail(kind, db, sim, headline, exc) -> AwrResult:
    return AwrResult(kind, False, message=_msg(sim, headline), detail=str(exc), db=db, simulated=sim)


def load_snapshots(ctx, db_name: str, days, cancel=None) -> AwrResult:
    """Read-only snapshot list. Never raises: every problem becomes a failed AwrResult."""
    sim = _simulated()
    try:
        days = awr.validate_days(days)
        entry, home, env, th = launcher._prepare(ctx, db_name, False)
        if cancel is not None:
            cancel.check()
        with launcher._open(ctx, entry, home, env, th, cancel) as session:
            text = session.awr_snapshots(days)
        found = awr.parse_snapshots(text)
    except RunCancelled:
        return AwrResult("snapshots", False, True, _msg(sim, "Loading snapshots was cancelled."), db=db_name, simulated=sim)
    except awr.AwrError as exc:
        return _fail("snapshots", db_name, sim, "Snapshots could not be loaded.", exc)
    except ToolError as exc:
        return _fail("snapshots", db_name, sim, "Snapshots could not be loaded (tool / configuration problem).", exc)
    except Exception as exc:  # a bug must be shown, not lost
        return _fail("snapshots", db_name, sim, "Snapshots could not be loaded (unexpected error).", repr(exc))
    if not found.snaps:
        return AwrResult("snapshots", True, message=_msg(sim, f"No snapshots were found in the last {days} day(s)."), snaps=found, db=db_name, simulated=sim)
    text = f"Loaded {len(found.snaps)} snapshot(s) from the last {days} day(s)."
    if found.capped:
        text += f" The list is capped at {awr.SNAP_CAP:,}: only the newest {awr.SNAP_CAP:,} are shown - lower Days back to narrow it."
    return AwrResult("snapshots", True, message=_msg(sim, text), snaps=found, db=db_name, simulated=sim)


def _cleanup(files) -> None:
    for f in files:
        try:
            Path(f).unlink()
        except OSError:
            pass


def report_folder(ctx, now=None) -> Path:
    """Today's report folder, exactly as the legacy tool names it (reports\\<REPORT_DATE_FORMAT>)."""
    env = environment.load_environment(ctx.environment_path)
    return Path(ctx.root) / "reports" / engine.format_dotnet_date(now or datetime.now(), env["REPORT_DATE_FORMAT"])


def generate_report(ctx, db_name: str, days, begin: int, end: int, cancel=None, fmt: str = "html", name=None, rac: bool = False) -> AwrResult:
    """HTML + single instance runs the unmodified AWR_Report.sql (a custom name is applied by renaming its file afterwards).
    Text or RAC use the separate variant script (session.awr_report_variant). Success only when a valid report file exists;
    incomplete files are removed; an existing file is never overwritten."""
    sim = _simulated()
    folder, before, target, legacy, ours = None, set(), None, True, False
    try:
        days = awr.validate_days(days)
        if not (isinstance(begin, int) and isinstance(end, int) and 0 < begin < end):
            raise awr.AwrError("Begin Snap ID must be lower than End Snap ID.")
        if fmt not in awr.FORMATS:
            raise awr.AwrError("Report type must be HTML or Text.")
        default = awr.default_name(begin, end)
        custom = name is not None and name != default
        now = datetime.now()
        entry, home, env, th = launcher._prepare(ctx, db_name, False)
        folder = Path(ctx.root) / "reports" / engine.format_dotnet_date(now, env["REPORT_DATE_FORMAT"])
        problem = awr.check_report_name(name if name is not None else default, fmt, folder, now)
        if problem:
            raise awr.AwrError(problem)
        target = folder / (awr.resolve_name(name if name is not None else default, now) + awr.FORMATS[fmt])
        try:
            folder.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise ToolError(f"Cannot create the report folder {folder}: {exc}") from None
        legacy = fmt == "html" and not rac
        if (custom or not legacy) and target.exists():
            raise awr.AwrError(f"{target.name} already exists in today's report folder - choose another name.")
        before = awr.awr_files(folder, begin, end)
        ours = not target.exists()                            # only a file this run creates may be removed again
        if cancel is not None:
            cancel.check()
        with launcher._open(ctx, entry, home, env, th, cancel) as session:
            simulated = bool(getattr(session, "simulated", False))
            if legacy:
                output = session.awr_report(folder, days, begin, end)
            else:
                output = session.awr_report_variant(target, fmt, rac, begin, end)
        new = awr.awr_files(folder, begin, end) - before
        if legacy:
            said = awr.reported_path(output)
            path = said if said is not None and said.is_file() else (max(new, key=lambda p: p.name) if new else None)
        else:
            path = target if target.is_file() else None
        if path is None:
            raise awr.AwrError(awr.error_text(output) or "SQL*Plus finished, but no AWR report file was created.")
        try:
            awr.check_report_file(path, fmt)
        except awr.AwrError:
            _cleanup(new | {path})
            raise
    except RunCancelled:
        _abandon(folder, begin, end, before, target, legacy, ours)
        return AwrResult("report", False, True, _msg(sim, "Report generation was cancelled; the incomplete file was removed."), db=db_name, simulated=sim)
    except (awr.AwrError, ToolError) as exc:
        _abandon(folder, begin, end, before, target, legacy, ours)
        return _fail("report", db_name, sim, "The AWR report was not created.", exc)
    except Exception as exc:
        _abandon(folder, begin, end, before, target, legacy, ours)
        return _fail("report", db_name, sim, "The AWR report was not created (unexpected error).", repr(exc))
    note = ""
    if legacy and custom and path != target:                  # the original script fixes its file name: apply the chosen one
        try:
            path.rename(target)                               # fails (never overwrites) if the target appeared meanwhile
            path = target
        except OSError as exc:
            note = f"The report was kept under its original name {path.name}; it could not be renamed to {target.name}: {exc}"
    note = (note + " " + awr.record_report(Path(ctx.root) / "reports", path, db_name, simulated, begin, end, rac, now, index_dir=awr.index_dir_for(ctx.root))).strip()
    return AwrResult("report", True, message=_msg(simulated, f"AWR report created: {path.name}"), path=path, db=db_name, simulated=simulated, note=note)


def _abandon(folder, begin, end, before, target, legacy, ours) -> None:
    """Remove files this run created (never an earlier report): legacy-named ones and, for the variant script, its own target."""
    if folder is not None:
        _cleanup(awr.awr_files(folder, begin, end) - before)
    if target is not None and not legacy and ours:
        _cleanup([target])
