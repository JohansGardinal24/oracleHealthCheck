import sys

from ohc.app import main

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))