r"""Shared, editable thresholds: <install root>\config\thresholds.json.

Loaded and validated at the start of every run into an immutable snapshot (with the file's SHA-256).
A missing, unreadable or invalid file is an error: defaults are never substituted silently.
Values are substituted into SQL, so numbers must be real integers and the one text value is pattern-checked.

    python -m ohc.config.thresholds --write-default PATH   write a new default file (never overwrites)
    python -m ohc.config.thresholds --check [PATH]         validate a file and print its SHA-256
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping

from ohc import paths

SCHEMA_VERSION = 1
TOP_LEVEL_KEYS = {"schema_version", "thresholds", "descriptions"}
_sleep = time.sleep  # replaced in tests


@dataclass(frozen=True)
class Spec:
    key: str
    default: Any
    description: str
    low: int | None = None
    high: int | None = None
    pattern: str | None = None  # text values only


_PCT = "percent used, 1 to 100"
SPECS = (
    Spec("RETENTION_DAYS", 30, "Days to keep logs and report folders (1 to 3650)", 1, 3650),
    Spec("TBS_WARN", 70, f"Tablespace usage that gives WARNING ({_PCT}); must be below TBS_CRIT", 1, 100),
    Spec("TBS_CRIT", 90, f"Tablespace usage that gives CRITICAL ({_PCT})", 1, 100),
    Spec("FRA_WARN", 70, f"Fast Recovery Area usage that gives WARNING ({_PCT}); must be below FRA_CRIT", 1, 100),
    Spec("FRA_CRIT", 90, f"Fast Recovery Area usage that gives CRITICAL ({_PCT})", 1, 100),
    Spec("DR_LAG_WARN", 120, "Data Guard lag in seconds that gives WARNING; must be below DR_LAG_CRIT", 1, 86400),
    Spec("DR_LAG_CRIT", 600, "Data Guard lag in seconds that gives CRITICAL", 1, 86400),
    Spec("RMAN_LOOKBACK_DAYS", 7, "Days of RMAN history to check (1 to 365)", 1, 365),
    Spec("DISK_WARN", 80, f"Server disk usage that gives WARNING ({_PCT}); must be below DISK_CRIT", 1, 100),
    Spec("DISK_CRIT", 90, f"Server disk usage that gives CRITICAL ({_PCT})", 1, 100),
    Spec("DBFILES_WARN", 70, f"db_files usage that gives WARNING ({_PCT}); must be below DBFILES_CRIT", 1, 100),
    Spec("DBFILES_CRIT", 90, f"db_files usage that gives CRITICAL ({_PCT})", 1, 100),
    Spec("RESOURCE_WARN", 70, f"Resource limit usage that gives WARNING ({_PCT}); must be below RESOURCE_CRIT", 1, 100),
    Spec("RESOURCE_CRIT", 90, f"Resource limit usage that gives CRITICAL ({_PCT})", 1, 100),
    Spec("USER_EXPIRY_WARNING_DAYS", 30, "Days left before a user expires that gives WARNING; must be above USER_EXPIRY_CRITICAL_DAYS", 1, 3650),
    Spec("USER_EXPIRY_CRITICAL_DAYS", 20, "Days left before a user expires that gives CRITICAL", 1, 3650),
    Spec("TEMP_HIST_DAYS", 10, "Days of temp tablespace history to report (1 to 365)", 1, 365),
    Spec("LOCK_WAIT_SEC", 10, "Seconds a session must wait to count as blocked (1 to 86400)", 1, 86400),
    Spec("USER_EXPIRY_LOOKAHEAD_DAYS", 30, "Days ahead to list users that will expire (1 to 3650)", 1, 3650),
    Spec("IMS_SCHEDULER_LOOKAHEAD_DAYS", 90, "Days ahead for the IMS scheduler check (1 to 3650)", 1, 3650),
    Spec("SYS_EXPIRY_CRIT_STATUS", "EXPIRED(GRACE)",
         "Account status that gives CRITICAL for SYS-level users: upper-case letters, digits, _ ( ) and spaces only",
         pattern=r"^[A-Z0-9_() ]{1,40}$"),
    Spec("DATA_MOVEMENT_DBS", "IMS RPP", "Database names for data movement (kept from the original config; currently unused)",
         pattern=r"^[A-Za-z0-9_$#, ]{0,200}$"),
)
KEYS = tuple(s.key for s in SPECS)
_BY_KEY = {s.key: s for s in SPECS}
DEFAULTS: Mapping[str, Any] = MappingProxyType({s.key: s.default for s in SPECS})
DESCRIPTIONS = {s.key: s.description for s in SPECS}

# first must be LOWER than second
ASCENDING_PAIRS = (("TBS_WARN", "TBS_CRIT"), ("FRA_WARN", "FRA_CRIT"), ("DR_LAG_WARN", "DR_LAG_CRIT"),
                   ("DISK_WARN", "DISK_CRIT"), ("DBFILES_WARN", "DBFILES_CRIT"), ("RESOURCE_WARN", "RESOURCE_CRIT"))
# first must be HIGHER than second (warning days left must exceed critical days left)
DESCENDING_PAIRS = (("USER_EXPIRY_WARNING_DAYS", "USER_EXPIRY_CRITICAL_DAYS"),)


class ThresholdsError(RuntimeError):
    def __init__(self, message: str, problems=()):
        super().__init__(message)
        self.problems = list(problems)


class ThresholdsMissingError(ThresholdsError):
    pass


class ThresholdsInvalidError(ThresholdsError):
    pass


@dataclass(frozen=True, eq=False)
class ThresholdsSnapshot:
    """Immutable values used for the whole run, with the SHA-256 of the file they came from."""
    values: Mapping[str, Any]
    sha256: str
    source: str
    loaded_utc: str

    def __getitem__(self, key: str) -> Any:
        return self.values[key]

    def as_dict(self) -> dict:
        return dict(self.values)

    def to_record(self) -> dict:
        return {"source": self.source, "sha256": self.sha256, "loaded_utc": self.loaded_utc, "values": self.as_dict()}


def default_path() -> Path:
    return paths.app_root() / "config" / "thresholds.json"


def _shown(value) -> str:
    text = repr(value)
    return text if len(text) <= 40 else text[:37] + "..."


def validate_values(values: Mapping) -> list:
    """All problems at once, each naming its key. Empty list means valid."""
    problems = []
    for key in sorted(set(values) - set(KEYS)):
        problems.append(f"{key}: unknown key (check the spelling)")
    for spec in SPECS:
        if spec.key not in values:
            problems.append(f"{spec.key}: missing")
            continue
        v = values[spec.key]
        if spec.pattern is None:
            if isinstance(v, bool) or not isinstance(v, int):
                problems.append(f"{spec.key}: must be a whole number between {spec.low} and {spec.high} (found {_shown(v)})")
            elif not spec.low <= v <= spec.high:
                problems.append(f"{spec.key}: must be between {spec.low} and {spec.high} (found {v})")
        elif not isinstance(v, str) or not re.fullmatch(spec.pattern, v):
            problems.append(f"{spec.key}: contains characters or a length that is not allowed (found {_shown(v)})")

    def ok_int(k):
        v = values.get(k)
        return isinstance(v, int) and not isinstance(v, bool) and _BY_KEY[k].low <= v <= _BY_KEY[k].high

    for low, high in ASCENDING_PAIRS:
        if ok_int(low) and ok_int(high) and values[low] >= values[high]:
            problems.append(f"{low} ({values[low]}) must be lower than {high} ({values[high]})")
    for high, low in DESCENDING_PAIRS:
        if ok_int(high) and ok_int(low) and values[high] <= values[low]:
            problems.append(f"{high} ({values[high]}) must be higher than {low} ({values[low]})")
    return problems


def _no_duplicates(pairs):
    seen = {}
    for k, v in pairs:
        if k in seen:
            raise ValueError(f"duplicate key '{k}'")
        seen[k] = v
    return seen


def parse_bytes(raw: bytes) -> tuple:
    """Return (values, problems, is_syntax_error)."""
    try:
        doc = json.loads(raw.decode("utf-8-sig"), object_pairs_hook=_no_duplicates)
    except (UnicodeDecodeError, RecursionError):
        return None, ["the file is not valid UTF-8 JSON"], True
    except ValueError as exc:
        text = str(exc)
        if text.startswith("duplicate key"):
            return None, [f"the file contains a {text}"], False
        return None, [f"the file is not valid JSON ({text})"], True
    if not isinstance(doc, dict):
        return None, ["the top level of the file must be a JSON object"], False
    problems = [f"unknown top-level key '{k}'" for k in sorted(set(doc) - TOP_LEVEL_KEYS)]
    version = doc.get("schema_version")
    if isinstance(version, bool) or not isinstance(version, int):
        problems.append("schema_version: missing or not a whole number")
    elif version > SCHEMA_VERSION:
        problems.append(f"schema_version {version} was written by a newer version of the application")
    elif version < 1:
        problems.append("schema_version: must be 1 or higher")
    values = doc.get("thresholds")
    if not isinstance(values, dict):
        return None, problems + ["'thresholds' is missing or is not an object"], False
    if "descriptions" in doc and not (isinstance(doc["descriptions"], dict)
                                      and all(isinstance(v, str) for v in doc["descriptions"].values())):
        problems.append("'descriptions' must be an object of text values")
    return values, problems + validate_values(values), False


def load_thresholds(path=None) -> ThresholdsSnapshot:
    """Read once, validate, and return an immutable snapshot. Raises ThresholdsError on any problem."""
    path = Path(path) if path is not None else default_path()
    for attempt in (1, 2):
        try:
            raw = path.read_bytes()
        except FileNotFoundError:
            raise ThresholdsMissingError(
                f"The thresholds file was not found: {path}. Create it from the default (nothing is substituted automatically).") from None
        except OSError as exc:
            raise ThresholdsError(f"Cannot read the thresholds file {path}: {exc.strerror or type(exc).__name__}") from None
        values, problems, syntax = parse_bytes(raw)
        if syntax and attempt == 1:  # an editor may still be writing the file: one short retry
            _sleep(0.25)
            continue
        break
    if problems:
        raise ThresholdsInvalidError(
            f"The thresholds file {path.name} is invalid ({len(problems)} problem(s)):\n  - " + "\n  - ".join(problems), problems)
    return ThresholdsSnapshot(
        values=MappingProxyType({k: values[k] for k in KEYS}),
        sha256=hashlib.sha256(raw).hexdigest(),
        source=str(path),
        loaded_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"))


def _document_text(values: Mapping) -> str:
    doc = {"schema_version": SCHEMA_VERSION, "thresholds": {k: values[k] for k in KEYS}, "descriptions": DESCRIPTIONS}
    return json.dumps(doc, indent=2, ensure_ascii=False) + "\n"


def save_thresholds(path, values: Mapping) -> str:
    """Validate, then write atomically (temp file + replace). Returns the SHA-256 of the written file."""
    problems = validate_values(values)
    if problems:
        raise ThresholdsInvalidError("Not saved: " + "; ".join(problems), problems)
    path = Path(path)
    data = _document_text(values).encode("utf-8")
    tmp = path.with_name(f"{path.name}.tmp{os.getpid()}")
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(tmp, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except OSError as exc:
        raise ThresholdsError(f"Cannot write the thresholds file {path}: {exc.strerror or type(exc).__name__}") from None
    finally:
        tmp.unlink(missing_ok=True)
    return hashlib.sha256(data).hexdigest()


def write_default(path) -> str:
    path = Path(path)
    if path.exists():
        raise ThresholdsError(f"{path} already exists and was not overwritten")
    return save_thresholds(path, DEFAULTS)


def main(argv: list) -> int:
    try:
        if len(argv) == 2 and argv[0] == "--write-default":
            print(f"written: {argv[1]}  sha256 {write_default(argv[1])}")
            return 0
        if argv[:1] == ["--check"] and len(argv) <= 2:
            snap = load_thresholds(argv[1] if len(argv) == 2 else None)
            print(f"OK: {len(snap.values)} keys, sha256 {snap.sha256}")
            return 0
    except ThresholdsError as exc:
        print(f"FAILED: {exc}")
        return 1
    print("usage: python -m ohc.config.thresholds --write-default PATH | --check [PATH]")
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))