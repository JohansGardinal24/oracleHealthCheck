"""Oracle Home: syntax check, tool inspection, priority resolution and read-only detection."""
from __future__ import annotations

import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path

EXE = ".exe" if os.name == "nt" else ""
_ALLOWED = re.compile(r"^[A-Za-z0-9 _.()\-~:\\/]+$")
_WIN_ABS = re.compile(r"^[A-Za-z]:[\\/]")
MAX_LEN = 240


@dataclass(frozen=True)
class HomeInfo:
    path: str
    sqlplus: bool
    dgmgrl: bool
    problems: tuple


@dataclass(frozen=True)
class Candidate:
    path: str
    source: str
    sqlplus: bool


def check_home_syntax(text) -> str | None:
    """None if acceptable, else a message. Local absolute paths only (no UNC, no '..', no shell characters)."""
    if not isinstance(text, str) or not text:
        return "Oracle Home is empty"
    if len(text) > MAX_LEN:
        return f"Oracle Home is longer than {MAX_LEN} characters"
    if text != text.strip():
        return "Oracle Home must not start or end with a space"
    if not _ALLOWED.match(text):
        return "Oracle Home contains characters that are not allowed (letters, digits, space and _ . ( ) - : \\ / only)"
    if not (_WIN_ABS.match(text) or (os.name != "nt" and text.startswith("/"))):
        return "Oracle Home must be a local absolute path such as D:\\oracle\\home (no network paths)"
    if ".." in re.split(r"[\\/]", text):
        return "Oracle Home must not contain '..'"
    if ":" in text[2:]:
        return "Oracle Home contains a misplaced ':'"
    return None


def normalize_home(text: str) -> str:
    return text.rstrip("\\/") if len(text) > 3 else text  # like the BAT, drop a trailing backslash


def resolve_oracle_home(db_override: str, shared_default: str) -> tuple:
    """Priority: database override, then the shared default. Returns (path, 'database' | 'default' | 'none')."""
    if db_override and db_override.strip():
        return db_override.strip(), "database"
    if shared_default and shared_default.strip():
        return shared_default.strip(), "default"
    return "", "none"


def inspect_home(text: str) -> HomeInfo:
    problem = check_home_syntax(text)
    if problem:
        return HomeInfo(text, False, False, (problem,))
    path = normalize_home(text)
    home = Path(path)
    problems = [] if home.is_dir() else [f"The folder does not exist: {path}"]
    return HomeInfo(path, (home / "bin" / f"sqlplus{EXE}").is_file(), (home / "bin" / f"dgmgrl{EXE}").is_file(), tuple(problems))


def findings(info: HomeInfo, mode: str) -> tuple:
    """(errors, warnings) for a run mode: 'sql', 'sync', 'all' or 'reports'. DGMGRL is only needed for sync/all."""
    errors = list(info.problems)
    warnings = []
    if not errors and not info.sqlplus:
        errors.append(f"sqlplus.exe was not found in {info.path}\\bin")
    if mode in ("sync", "all") and not errors and not info.dgmgrl:
        warnings.append("dgmgrl.exe was not found: the Data Guard checks will fail (the original tool does not pre-check this)")
    return errors, warnings


def _registry_homes() -> list:  # pragma: no cover - Windows only, read-only
    if sys.platform != "win32":
        return []
    import winreg

    homes = []
    for view in (winreg.KEY_WOW64_64KEY, winreg.KEY_WOW64_32KEY):
        try:
            root = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\ORACLE", 0, winreg.KEY_READ | view)
        except OSError:
            continue
        with root:
            index = 0
            while True:
                try:
                    name = winreg.EnumKey(root, index)
                except OSError:
                    break
                index += 1
                try:
                    with winreg.OpenKey(root, name) as sub:
                        homes.append(str(winreg.QueryValueEx(sub, "ORACLE_HOME")[0]))
                except OSError:
                    continue
    return homes


def detect_oracle_homes(registry_reader=_registry_homes, environ=None) -> list:
    """Read-only: registry, the ORACLE_HOME variable and PATH. Candidates with sqlplus come first."""
    environ = os.environ if environ is None else environ
    found = {}

    def add(path, source):
        path = normalize_home(str(path or "").strip())
        if path and check_home_syntax(path) is None and path.lower() not in found:
            found[path.lower()] = Candidate(path, source, (Path(path) / "bin" / f"sqlplus{EXE}").is_file())

    for p in registry_reader():
        add(p, "registry")
    add(environ.get("ORACLE_HOME"), "ORACLE_HOME variable")
    for entry in environ.get("PATH", "").split(os.pathsep):
        entry = entry.strip().strip('"')
        if entry and Path(entry).name.lower() == "bin" and (Path(entry) / f"sqlplus{EXE}").is_file():
            add(str(Path(entry).parent), "PATH")
    return sorted(found.values(), key=lambda c: (not c.sqlplus, c.path.lower()))
