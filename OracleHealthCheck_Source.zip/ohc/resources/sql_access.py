"""Runtime access to the bundled SQL scripts.

Development and the packaged EXE use exactly the same calls:
    get_sql("v_tbs.sql")  -> bytes (verified against its SHA-256 first)
    list_sql()            -> sorted script names
    verify()              -> list of problems (empty = OK)
"""
from __future__ import annotations

import hashlib
import sys

from ohc.resources import sql_bundle


class SqlNotFoundError(KeyError):
    """The requested script name is not in the bundle."""


class SqlIntegrityError(RuntimeError):
    """A bundled script does not match its recorded SHA-256."""


def _files() -> dict:
    return sql_bundle.SQL_FILES


def list_sql() -> list:
    return sorted(_files())


def get_sql(name: str) -> bytes:
    try:
        sha, data = _files()[name]
    except KeyError:
        raise SqlNotFoundError(f"SQL script is not in the bundle: {name!r}") from None
    if hashlib.sha256(data).hexdigest() != sha:
        raise SqlIntegrityError(f"SQL script failed its integrity check: {name}")
    return data


def bundle_sha256() -> str:
    """Recomputed from the actual bytes (never trusts the stored value)."""
    text = "".join(
        f"{hashlib.sha256(_files()[n][1]).hexdigest()}  {n}\n" for n in sorted(_files())
    )
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def verify() -> list:
    problems = []
    for name in sorted(_files()):
        sha, data = _files()[name]
        if hashlib.sha256(data).hexdigest() != sha:
            problems.append(f"{name}: content does not match its recorded SHA-256")
    if len(_files()) != sql_bundle.FILE_COUNT:
        problems.append(f"script count {len(_files())} != recorded {sql_bundle.FILE_COUNT}")
    if bundle_sha256() != sql_bundle.BUNDLE_SHA256:
        problems.append("bundle SHA-256 does not match the recorded value")
    return problems


def main() -> int:
    problems = verify()
    if problems:
        print("SQL bundle INTEGRITY FAILURE:")
        for p in problems:
            print("  -", p)
        return 1
    print(f"SQL bundle OK: {len(_files())} scripts, sha256 {bundle_sha256()}")
    return 0


if __name__ == "__main__":
    sys.exit(main())