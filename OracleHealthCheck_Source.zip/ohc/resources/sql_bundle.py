# GENERATED FILE - DO NOT EDIT BY HAND.
# Source of truth: sql_src\*.sql (development only; never shipped).
# Regenerate:  python tools\gen_sql_bundle.py
# Verify:      python tools\gen_sql_bundle.py --check

BUNDLE_FORMAT = 1
BUNDLE_SHA256 = "9fd617ca86797d557d249b32ae61a72198e56f2ed1a7dfc0cb689620f779ac62"
FILE_COUNT = 51

SQL_FILES = {
    "ADDM_Report.sql": (
        "c6dc48ccf337c5df86972ed0ee5dbd45fc8ae87167fb964613436ba326f13482",
        (
            b'SET ECHO OFF\n'
            b'SET FEEDBACK OFF\n'
            b'SET HEADING ON\n'
            b'SET PAGESIZE 1000\n'
            b'SET LINESIZE 200\n'
            b'SET VERIFY OFF\n'
            b'SET TERMOUT ON\n'
            b'SET TRIM ON\n'
            b'SET TRIMSPOOL ON\n'
            b'\n'
            b'-- Prompt user for number of days\n'
            b'PROMPT ============================================\n'
            b'PROMPT ADDM Report Generation\n'
            b'PROMPT ============================================\n'
            b'PROMPT \n'
            b"ACCEPT num_days NUMBER PROMPT 'Enter number of days to look back: '\n"
            b'\n'
            b'PROMPT \n'
            b'PROMPT Available Snapshots:\n'
            b'PROMPT ============================================\n'
            b'PROMPT SNAP_ID    BEGIN_INTERVAL_TIME\n'
            b'PROMPT ============================================\n'
            b'\n'
            b'-- Display available snapshots\n'
            b'SELECT snap_id, \n'
            b"       TO_CHAR(begin_interval_time, 'DD-MON-YYYY HH24:MI:SS') AS begin_interval_time\n"
            b'FROM dba_hist_snapshot\n'
            b'WHERE begin_interval_time >= SYSDATE - &num_days\n'
            b'ORDER BY snap_id;\n'
            b'\n'
            b'PROMPT ============================================\n'
            b'PROMPT \n'
            b'\n'
            b'-- Prompt for begin and end snap IDs\n'
            b"ACCEPT begin_snap NUMBER PROMPT 'Enter Beginning Snapshot ID: '\n"
            b"ACCEPT end_snap NUMBER PROMPT 'Enter Ending Snapshot ID: '\n"
            b'\n'
            b'-- Get database ID and instance number\n'
            b'SET TERMOUT OFF\n'
            b'COLUMN dbid NEW_VALUE v_dbid NOPRINT\n'
            b'COLUMN instance_number NEW_VALUE v_inst_num NOPRINT\n'
            b'SELECT dbid FROM v$database;\n'
            b'SELECT instance_number FROM v$instance;\n'
            b'\n'
            b'-- Generate report filename and ADDM task name with timestamp\n'
            b'COLUMN report_name NEW_VALUE v_report_name NOPRINT\n'
            b"SELECT '&rpt_dir\\ADDM_Report_'||TRIM(TO_CHAR(&begin_snap))||'_'||TRIM(TO_CHAR(&end_snap))||'_'||TO_CHAR(SYSDATE,'YYYYMMDD_HH24MISS')||'.txt' AS report_name \n"
            b'FROM dual;\n'
            b'\n'
            b'COLUMN task_name NEW_VALUE v_task_name NOPRINT\n'
            b"SELECT 'ADDM_'||TRIM(TO_CHAR(&begin_snap))||'_'||TRIM(TO_CHAR(&end_snap))||'_'||TO_CHAR(SYSDATE,'YYYYMMDD_HH24MISS') AS task_name \n"
            b'FROM dual;\n'
            b'\n'
            b'SET TERMOUT ON\n'
            b'\n'
            b'PROMPT \n'
            b'PROMPT Running ADDM analysis (this can take a minute)...\n'
            b'PROMPT \n'
            b'\n'
            b'-- Run ADDM analysis for the selected snapshot range (current instance)\n'
            b'VARIABLE v_task VARCHAR2(100)\n'
            b'BEGIN\n'
            b"  :v_task := '&v_task_name';\n"
            b'  DBMS_ADDM.ANALYZE_INST(:v_task, &begin_snap, &end_snap, &v_inst_num, &v_dbid);\n'
            b'END;\n'
            b'/\n'
            b'\n'
            b'-- Set output to file\n'
            b'SET TERMOUT OFF\n'
            b'SET HEADING OFF\n'
            b'SET PAGESIZE 0\n'
            b'SET LINESIZE 1000\n'
            b'SET LONG 100000000\n'
            b'SET LONGCHUNKSIZE 100000000\n'
            b'\n'
            b'SPOOL "&v_report_name"\n'
            b'\n'
            b'-- Generate ADDM report (text)\n'
            b'SELECT DBMS_ADDM.GET_REPORT(:v_task) FROM dual;\n'
            b'\n'
            b'SPOOL OFF\n'
            b'SET TERMOUT ON\n'
            b'\n'
            b'PROMPT Report generated at: &v_report_name\n'
            b'PROMPT ADDM task name     : &v_task_name\n'
            b'PROMPT ============================================\n'
            b'PROMPT \n'
            b'\n'
            b'EXIT\n'
        ),
    ),
    "ASH_Report.sql": (
        "0b82c96af48933b05c37661a99dd3f179d9ef6406ec3474f1fac8d0654181a7b",
        (
            b'SET ECHO OFF\n'
            b'SET FEEDBACK OFF\n'
            b'SET HEADING ON\n'
            b'SET PAGESIZE 1000\n'
            b'SET LINESIZE 200\n'
            b'SET VERIFY OFF\n'
            b'SET TERMOUT ON\n'
            b'SET TRIM ON\n'
            b'SET TRIMSPOOL ON\n'
            b'\n'
            b'PROMPT ============================================\n'
            b'PROMPT ASH Report Generation\n'
            b'PROMPT ============================================\n'
            b'PROMPT \n'
            b'PROMPT Specify the timeframe to generate the ASH report\n'
            b'PROMPT ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n'
            b'PROMPT Enter begin time for report:\n'
            b'PROMPT \n'
            b'PROMPT --    Valid input formats:\n'
            b'PROMPT --       To specify absolute begin time:\n'
            b'PROMPT --          [MM/DD[/YY]] HH24:MI[:SS]\n'
            b'PROMPT --          Examples: 02/23/03 14:30:15\n'
            b'PROMPT --                    02/23 14:30:15\n'
            b'PROMPT --                    14:30:15\n'
            b'PROMPT --                    14:30\n'
            b"PROMPT --       To specify relative begin time: (start with '-' sign)\n"
            b'PROMPT --          -[HH24:]MI\n'
            b'PROMPT --          Examples: -1:15  (SYSDATE - 1 Hr 15 Mins)\n'
            b'PROMPT --                    -25    (SYSDATE - 25 Mins)\n'
            b'PROMPT \n'
            b'PROMPT Defaults to -15 mins\n'
            b"ACCEPT begin_time CHAR DEFAULT '-15' PROMPT 'Enter value for begin_time: '\n"
            b'\n'
            b'PROMPT \n'
            b'PROMPT Enter number of minutes for report duration (default: 15)\n'
            b'PROMPT Note: If you used relative time above (e.g. -20), just press Enter\n'
            b"ACCEPT duration_mins NUMBER DEFAULT '15' PROMPT 'Enter duration in minutes: '\n"
            b'\n'
            b"-- Check if it's relative time (starts with -)\n"
            b'SET TERMOUT OFF\n'
            b'COLUMN is_relative NEW_VALUE v_is_relative NOPRINT\n'
            b"SELECT CASE WHEN SUBSTR('&begin_time',1,1) = '-' THEN 'YES' ELSE 'NO' END AS is_relative FROM dual;\n"
            b'\n'
            b'-- Calculate begin and end times\n'
            b'COLUMN begin_date NEW_VALUE v_begin_date NOPRINT\n'
            b'COLUMN end_date NEW_VALUE v_end_date NOPRINT\n'
            b'\n'
            b'-- For relative time with minutes only (e.g., -20)\n'
            b'-- The duration entered will be ignored\n'
            b'SELECT \n'
            b"    TO_CHAR(SYSDATE - (ABS(TO_NUMBER('&begin_time')) / 1440), 'MM/DD/YY HH24:MI:SS') AS begin_date,\n"
            b"    TO_CHAR(SYSDATE, 'MM/DD/YY HH24:MI:SS') AS end_date\n"
            b'FROM dual\n'
            b"WHERE '&v_is_relative' = 'YES'\n"
            b"  AND INSTR('&begin_time', ':') = 0;\n"
            b'\n'
            b'-- For relative time with hours:minutes (e.g., -1:15)\n'
            b'SELECT \n'
            b"    TO_CHAR(SYSDATE - ((ABS(TO_NUMBER(SUBSTR('&begin_time', 2, INSTR('&begin_time',':')-2))) * 60 + \n"
            b"                        ABS(TO_NUMBER(SUBSTR('&begin_time', INSTR('&begin_time',':')+1)))) / 1440), 'MM/DD/YY HH24:MI:SS') AS begin_date,\n"
            b"    TO_CHAR(SYSDATE, 'MM/DD/YY HH24:MI:SS') AS end_date\n"
            b'FROM dual\n'
            b"WHERE '&v_is_relative' = 'YES'\n"
            b"  AND INSTR('&begin_time', ':') > 0;\n"
            b'\n'
            b'-- For absolute time - use the duration entered\n'
            b'SELECT \n'
            b"    TO_CHAR(TO_DATE('&begin_time', 'MM/DD/YY HH24:MI:SS'), 'MM/DD/YY HH24:MI:SS') AS begin_date,\n"
            b"    TO_CHAR(TO_DATE('&begin_time', 'MM/DD/YY HH24:MI:SS') + (&duration_mins / 1440), 'MM/DD/YY HH24:MI:SS') AS end_date\n"
            b'FROM dual\n'
            b"WHERE '&v_is_relative' = 'NO';\n"
            b'\n'
            b'-- Get database ID and instance number\n'
            b'COLUMN dbid NEW_VALUE v_dbid NOPRINT\n'
            b'COLUMN instance_number NEW_VALUE v_inst_num NOPRINT\n'
            b'SELECT dbid FROM v$database;\n'
            b'SELECT instance_number FROM v$instance;\n'
            b'\n'
            b'-- Generate report filename with timestamp\n'
            b'COLUMN report_name NEW_VALUE v_report_name NOPRINT\n'
            b"SELECT '&rpt_dir\\ASH_Report_'||TO_CHAR(SYSDATE,'YYYYMMDD_HH24MISS')||'.html' AS report_name \n"
            b'FROM dual;\n'
            b'\n'
            b'SET TERMOUT ON\n'
            b'PROMPT \n'
            b'PROMPT Generating ASH report...\n'
            b'PROMPT Report Period: &v_begin_date to &v_end_date\n'
            b'PROMPT \n'
            b'\n'
            b'-- Set output to file\n'
            b'SET TERMOUT OFF\n'
            b'SET PAGESIZE 0\n'
            b'SET LINESIZE 32767\n'
            b'SET LONG 100000000\n'
            b'SET LONGCHUNKSIZE 100000000\n'
            b'\n'
            b'SPOOL "&v_report_name"\n'
            b'\n'
            b'-- Generate ASH report\n'
            b'SELECT output FROM TABLE(DBMS_WORKLOAD_REPOSITORY.ASH_REPORT_HTML(\n'
            b'    &v_dbid,\n'
            b'    &v_inst_num,\n'
            b"    TO_DATE('&v_begin_date','MM/DD/YY HH24:MI:SS'),\n"
            b"    TO_DATE('&v_end_date','MM/DD/YY HH24:MI:SS')\n"
            b'));\n'
            b'\n'
            b'SPOOL OFF\n'
            b'SET TERMOUT ON\n'
            b'\n'
            b'PROMPT ============================================\n'
            b'PROMPT Report generated at: &v_report_name\n'
            b'PROMPT ============================================\n'
            b'PROMPT \n'
            b'\n'
            b'EXIT'
        ),
    ),
    "AWR_Report.sql": (
        "cfad647ea30215c4c7b6645916cec513d56ca92037ae0498dd26a289ec996d8b",
        (
            b'SET ECHO OFF\n'
            b'SET FEEDBACK OFF\n'
            b'SET HEADING ON\n'
            b'SET PAGESIZE 1000\n'
            b'SET LINESIZE 200\n'
            b'SET VERIFY OFF\n'
            b'SET TERMOUT ON\n'
            b'SET TRIM ON\n'
            b'SET TRIMSPOOL ON\n'
            b'\n'
            b'-- Prompt user for number of days\n'
            b'PROMPT ============================================\n'
            b'PROMPT AWR Report Generation\n'
            b'PROMPT ============================================\n'
            b'PROMPT \n'
            b"ACCEPT num_days NUMBER PROMPT 'Enter number of days to look back: '\n"
            b'\n'
            b'PROMPT \n'
            b'PROMPT Available Snapshots:\n'
            b'PROMPT ============================================\n'
            b'PROMPT SNAP_ID    BEGIN_INTERVAL_TIME\n'
            b'PROMPT ============================================\n'
            b'\n'
            b'-- Display available snapshots\n'
            b'SELECT snap_id, \n'
            b"       TO_CHAR(begin_interval_time, 'DD-MON-YYYY HH24:MI:SS') AS begin_interval_time\n"
            b'FROM dba_hist_snapshot\n'
            b'WHERE begin_interval_time >= SYSDATE - &num_days\n'
            b'ORDER BY snap_id;\n'
            b'\n'
            b'PROMPT ============================================\n'
            b'PROMPT \n'
            b'\n'
            b'-- Prompt for begin and end snap IDs\n'
            b"ACCEPT begin_snap NUMBER PROMPT 'Enter Beginning Snapshot ID: '\n"
            b"ACCEPT end_snap NUMBER PROMPT 'Enter Ending Snapshot ID: '\n"
            b'\n'
            b'-- Get database ID and instance number\n'
            b'SET TERMOUT OFF\n'
            b'COLUMN dbid NEW_VALUE v_dbid NOPRINT\n'
            b'COLUMN instance_number NEW_VALUE v_inst_num NOPRINT\n'
            b'SELECT dbid FROM v$database;\n'
            b'SELECT instance_number FROM v$instance;\n'
            b'\n'
            b'-- Generate report filename with timestamp\n'
            b'COLUMN report_name NEW_VALUE v_report_name NOPRINT\n'
            b"SELECT '&rpt_dir\\AWR_Report_'||TRIM(TO_CHAR(&begin_snap))||'_'||TRIM(TO_CHAR(&end_snap))||'_'||TO_CHAR(SYSDATE,'YYYYMMDD_HH24MISS')||'.html' AS report_name \n"
            b'FROM dual;\n'
            b'\n'
            b'SET TERMOUT ON\n'
            b'\n'
            b'PROMPT \n'
            b'PROMPT Generating AWR report...\n'
            b'PROMPT \n'
            b'\n'
            b'-- Set output to file\n'
            b'SET TERMOUT OFF\n'
            b'SET PAGESIZE 0\n'
            b'SET LINESIZE 32767\n'
            b'SET LONG 100000000\n'
            b'SET LONGCHUNKSIZE 100000000\n'
            b'\n'
            b'SPOOL "&v_report_name"\n'
            b'\n'
            b'-- Generate AWR report\n'
            b'SELECT output FROM TABLE(DBMS_WORKLOAD_REPOSITORY.AWR_REPORT_HTML(\n'
            b'    &v_dbid,\n'
            b'    &v_inst_num,\n'
            b'    &begin_snap,\n'
            b'    &end_snap\n'
            b'));\n'
            b'\n'
            b'SPOOL OFF\n'
            b'SET TERMOUT ON\n'
            b'\n'
            b'PROMPT Report generated at: &v_report_name\n'
            b'PROMPT ============================================\n'
            b'PROMPT \n'
            b'\n'
            b'EXIT'
        ),
    ),
    "r_datafile_size.sql": (
        "6a9eda86676683babe12d91afb49703c4d4749df704e997ae0e47e957703da63",
        (
            b'---datafile size\n'
            b'SELECT SUM(bytes)/1024/1024/1024 AS GB FROM dba_data_files;\n'
        ),
    ),
    "r_datafiles.sql": (
        "684840df648f128bb32cec8de9469da806453715b1c3f270928289cf66dbc7ad",
        (
            b'set lines 200\n'
            b'col tablespace_name for a30\n'
            b'col autoext for a8\n'
            b'select tablespace_name, count(*) datafiles,\n'
            b'       round(sum(bytes)/1024/1024/1024,2) size_gb,\n'
            b"       round(sum(case when autoextensible='YES' then greatest(maxbytes,bytes) else bytes end)/1024/1024/1024,2) max_gb,\n"
            b'       max(autoextensible) autoext\n'
            b'from dba_data_files\n'
            b'group by tablespace_name\n'
            b'order by tablespace_name;\n'
        ),
    ),
    "r_db_patch.sql": (
        "872c9a177f719547d0dea3595e5c0cbbf260500f739fe301d9edeb79a23ea874",
        (
            b'set lines 999;\n'
            b'col action_time for a33;\n'
            b'col description for a63;\n'
            b'col STATUS for a20;\n'
            b'select install_id,patch_id,patch_type,action,status,action_time,description from dba_registry_sqlpatch;\n'
        ),
    ),
    "r_db_status.sql": (
        "7d8e312f50026f0c7d731c242c600d1b0b6033b1337cc687848caf1d2362c8a8",
        (
            b'set lines 300\n'
            b'col instance_name for a14\n'
            b'col host_name for a26\n'
            b'col instance_status for a16\n'
            b'col database_status for a16\n'
            b'col startup_time for a17\n'
            b'col db_name for a10\n'
            b'col database_role for a17\n'
            b'col open_mode for a20\n'
            b'col log_mode for a12\n'
            b'select i.instance_name, i.host_name, i.status instance_status, i.database_status,\n'
            b"       to_char(i.startup_time,'YYYY-MM-DD HH24:MI') startup_time,\n"
            b'       d.name db_name, d.database_role, d.open_mode, d.log_mode\n'
            b'from v$instance i, v$database d;\n'
        ),
    ),
    "r_dbfiles.sql": (
        "a49fb5d43fcd127492c3f6ae90e6de5a2f47c3b78567c97ed3fdb55cfbb7155f",
        (
            b'set lines 100\n'
            b'col current_datafiles for 9999999 heading "CURRENT_DATAFILES"\n'
            b'col db_files_limit for 9999999 heading "DB_FILES_LIMIT"\n'
            b'col usage_percent for 999.99 heading "USAGE_PERCENT"\n'
            b'SELECT\n'
            b'    (SELECT COUNT(*) FROM v$datafile) AS current_datafiles,\n'
            b'    TO_NUMBER(value) AS db_files_limit,\n'
            b'    ROUND(\n'
            b'        (SELECT COUNT(*) FROM v$datafile) / TO_NUMBER(value) * 100,\n'
            b'        2\n'
            b'    ) AS usage_percent\n'
            b'FROM v$parameter\n'
            b"WHERE name = 'db_files';\n"
        ),
    ),
    "r_dop_indexes.sql": (
        "86d829adc8814f874318a5df10868a2443e90817d3f5c11942f523b589a94933",
        (
            b'col owner for a20\n'
            b'col index_name for a30\n'
            b'col table_owner for a20\n'
            b'col table_name for a30\n'
            b"SELECT OWNER ,INDEX_NAME ,INDEX_TYPE , DEGREE,TABLE_OWNER ,TABLE_NAME FROM DBA_INDEXES where DEGREE > '1';\n"
        ),
    ),
    "r_dump_job_history.sql": (
        "52e0f371c39ae75ae299041066dabe75990b8cf18de3559f58775a8e0d8eb8d2",
        (
            b'SELECT LOG_DATE,\n'
            b'       STATUS,\n'
            b'       ACTUAL_START_DATE,\n'
            b'       RUN_DURATION\n'
            b'FROM ALL_SCHEDULER_JOB_RUN_DETAILS\n'
            b"WHERE JOB_NAME = 'JOB_IMS_EXP'\n"
            b'  AND ACTUAL_START_DATE >= TRUNC(SYSDATE - 7)\n'
            b"  AND OWNER = 'TRANS'\n"
            b'ORDER BY LOG_DATE DESC;\n'
        ),
    ),
    "r_fra.sql": (
        "5a95ff3bb1b5e961d2a482fad3ddc3e2dc35968732a09a73f1f822c49c4b192e",
        (
            b'set lines 1000\n'
            b'col name for a35\n'
            b'col SPACE_LIMIT for a15\n'
            b'col SPACE_AVAILABLE for a15\n'
            b'col SPACE_USED for a15\n'
            b'col SPACE_RECLAIMABLE for a17\n'
            b"SELECT NAME,TO_CHAR(SPACE_LIMIT/1024/1024/1024,'9999') AS SPACE_LIMIT,TO_CHAR(SPACE_USED/1024/1024/1024,'9999') SPACE_USED,\n"
            b'TO_CHAR(SPACE_LIMIT/1024/1024/1024 - SPACE_USED/1024/1024/1024+ SPACE_RECLAIMABLE/1024/1024/1024,\n'
            b"'9999') AS SPACE_AVAILABLE,TO_CHAR(SPACE_RECLAIMABLE/1024/1024/1024,'9999') SPACE_RECLAIMABLE,NUMBER_OF_FILES,ROUND((SPACE_USED - SPACE_RECLAIMABLE)/SPACE_LIMIT * 100, 1)\n"
            b'AS PERCENT_FULL FROM V$RECOVERY_FILE_DEST;\n'
        ),
    ),
    "r_ims_jobs_config.sql": (
        "dcf6f84c0865a2b604a38cbd01b83e31ff9943639776a90e6b6812783c9e0ca4",
        (
            b'col sch_name for a30\n'
            b"select sch_name,to_char(last_run,'dd-mm-yyyy hh24:mi'),to_char(next_run,'dd-mm-yyyy hh24:mi') from config.schedule_master where sch_name in('Active','Archive') and status='Active';\n"
        ),
    ),
    "r_ims_jobs_mmconfig.sql": (
        "3a31b1f071cf8ed6d569118a4d1c17250f8d88401a1f7a6169aa93745f8acb4d",
        (
            b'col sch_name for a30\n'
            b"select sch_name,to_char(last_run,'dd-mm-yyyy hh24:mi'),to_char(next_run,'dd-mm-yyyy hh24:mi') from mm_config.schedule_master where sch_name in('Active','Archive') and status='Active';\n"
        ),
    ),
    "r_ims_schedulers.sql": (
        "250c333982df78d6a2de06930b6531e97df9fc8b79f83447ae90ec3b3eedaf05",
        (
            b'col sch_name for a30\n'
            b"select sch_id,sch_type,status,sch_name,terminate_on from config.schedule_master where status='Active' and terminate_on < sysdate + &IMS_SCHEDULER_LOOKAHEAD_DAYS;\n"
        ),
    ),
    "r_index_invalid.sql": (
        "950bb8d824f163ccca54d01c6f5249e94637a137c52937ace7d890ee1208e709",
        (
            b'COL owner FOR a20\n'
            b'COL index_name FOR a30\n'
            b"SELECT owner, index_name, status FROM dba_indexes WHERE PARTITIONED='NO' and STATUS <> 'VALID';\n"
        ),
    ),
    "r_index_stale.sql": (
        "86ff9fe45c9609952b34d479d2e954f29a1128ee1e887d6ddf01732d4e2f1e9e",
        (
            b'SELECT MAX(last_analyzed), MIN(last_analyzed)\n'
            b'FROM dba_ind_statistics\n'
            b"WHERE stale_stats='NO' AND table_owner IN (select username from all_users where oracle_maintained = 'N');\n"
        ),
    ),
    "r_index_unusable_parts.sql": (
        "ed519c30438ffd7acc094503459645ffe95dd4e20c1eca0514919ed007fc9a76",
        (
            b'--partition name,index,owner...\n'
            b"select PARTITION_NAME,INDEX_OWNER, index_name, status from dba_ind_subpartitions where status = 'UNUSABLE';\n"
            b"select PARTITION_NAME,INDEX_OWNER, index_name, status from dba_ind_partitions where status = 'UNUSABLE';\n"
        ),
    ),
    "r_locks.sql": (
        "1ed178f11d71b705c2c36c862132a40943f0459ad9b4ac3e362a38c7b6214906",
        (
            b'set lines 100\n'
            b"select ' SID '||\n"
            b"sid||' ,Serial# '||serial#||' user '||username||' is getting blocked by SID '||blocking_session|| ' for last '||seconds_in_wait||' seconds and wait_event '||event||' for SQL_ID '||sql_id\n"
            b'||\' (Locked_Object_ID \'||row_wait_obj#||\' locked_block_id \'||row_wait_block#||\' locked_row_id \'||row_wait_row#||\')\' "Active Locks"\n'
            b'from\n'
            b'   gv$session\n'
            b'where\n'
            b'   lockwait is not null and ROW_WAIT_OBJ#!=-1 and seconds_in_wait>&LOCK_WAIT_SEC\n'
            b'order by\n'
            b'   sid;\n'
        ),
    ),
    "r_open_cursors.sql": (
        "c6727cfb639a71407395850d1a94aeb8a60f329e760258fb22326162d4c25dc4",
        (
            b'col inst_id for 9999\n'
            b'col configured_open_cursors for a10\n'
            b'col current_open_cursors for 9999999\n'
            b'col usage_percent for 999.99\n'
            b'SELECT\n'
            b'    p.inst_id,\n'
            b'    p.value AS configured_open_cursors,\n'
            b'    s.value AS current_open_cursors,\n'
            b'    ROUND((s.value / p.value) * 100, 2) AS usage_percent\n'
            b'FROM gv$parameter p\n'
            b'JOIN gv$sysstat s\n'
            b'    ON p.inst_id = s.inst_id\n'
            b"WHERE p.name = 'open_cursors'\n"
            b"  AND s.name = 'opened cursors current'\n"
            b'ORDER BY p.inst_id;\n'
        ),
    ),
    "r_redo_file.sql": (
        "a38b312488820585ec22d77b1ff7e6d68d323e378f1a6424a7aa9f6c3dc0a268",
        (
            b'set lines 200\n'
            b'col member for a80\n'
            b'col status for a10\n'
            b'col type for a8\n'
            b'select group#, type, status, member from v$logfile order by group#, member;\n'
        ),
    ),
    "r_redo_log.sql": (
        "999ca79100e38c5698b3ed35998018a4c9342a41960ba0616842d6bc65f41d49",
        (
            b'set lines 200\n'
            b'select group#, thread#, sequence#, round(bytes/1024/1024) size_mb, members, archived, status\n'
            b'from v$log order by thread#, group#;\n'
        ),
    ),
    "r_resource_limits.sql": (
        "f733c3cdbaad2ce99b1c98ba6e820d1e2c4d910051fe8610c50dbf9657a66dff",
        (
            b'col resource_name for a20\n'
            b"select resource_name, current_utilization, max_utilization from v$resource_limit where resource_name in ('processes','sessions');\n"
        ),
    ),
    "r_rman.sql": (
        "c6aae337a182675594898a97e2a9e0733186d1e3bd819fa673f250563a0ae414",
        (
            b'SET LINES 1000\n'
            b'SET PAGES 500\n'
            b'COL OPERATION FOR A30\n'
            b'COL STATUS FOR A20\n'
            b'COL START_TIME FOR A20\n'
            b'COL END_TIME FOR A20\n'
            b'COL SID FOR 9999\n'
            b'COL MBYTES_PROCESSED FOR 9999999\n'
            b'SELECT SID,\n'
            b'       RECID,\n'
            b'       STAMP,\n'
            b'       OPERATION,\n'
            b'       OBJECT_TYPE,\n'
            b'       MBYTES_PROCESSED,\n'
            b'       STATUS,\n'
            b"       TO_CHAR(START_TIME,'DD-MM-YY HH24:MI:SS') AS START_TIME,\n"
            b"       TO_CHAR(END_TIME,'DD-MM-YY HH24:MI:SS') AS END_TIME\n"
            b'FROM V$RMAN_STATUS\n'
            b'WHERE START_TIME >= SYSDATE - &RMAN_LOOKBACK_DAYS\n'
            b"  AND OPERATION <> 'LIST'\n"
            b'ORDER BY RECID DESC;\n'
        ),
    ),
    "r_running_jobs.sql": (
        "428d60b943640644219bfbd72a83d7d6adf85b882227f2a45682534ba1a7b358",
        (
            b'set lines 300\n'
            b'set pages 200\n'
            b'col log_id for 9999999999\n'
            b'col owner for a12\n'
            b'col job_name for a25\n'
            b'col job_subname for a20\n'
            b'col session_id for 999999\n'
            b'col running_instance for 9999\n'
            b'col elapsed_time for a20\n'
            b'SELECT\n'
            b'    LOG_ID,\n'
            b'    OWNER,\n'
            b'    JOB_NAME,\n'
            b'    JOB_SUBNAME,\n'
            b'    SESSION_ID,\n'
            b'    RUNNING_INSTANCE,\n'
            b'    ELAPSED_TIME\n'
            b'FROM\n'
            b'    DBA_SCHEDULER_RUNNING_JOBS;\n'
        ),
    ),
    "r_segment_size.sql": (
        "95882f3962db7b1d91380a02dc29c9ff1d4fecf67e9515287c39d3a7a994fbad",
        (
            b'SELECT SUM(bytes)/1024/1024/1024 AS GB FROM dba_segments;\n'
        ),
    ),
    "r_sys_expiry.sql": (
        "2e06b655be3116a3b4f8cdd319913c728b4cb4c7409d06a84b8d72f16a0cf28d",
        (
            b'set lines 200\n'
            b'col username for a15\n'
            b'col profile for a20\n'
            b'SELECT username,\n'
            b'       account_status,\n'
            b'       expiry_date,\n'
            b'       profile\n'
            b'FROM dba_users\n'
            b"WHERE username = 'SYS';\n"
        ),
    ),
    "r_tbs_usage.sql": (
        "1ac3966781bdef476ef0ef1634375e72a1fe2abbac4135cf7732cf7503b5488f",
        (
            b'set lines 200\n'
            b'col tablespace_name for a30\n'
            b'col contents for a10\n'
            b'select m.tablespace_name, t.contents,\n'
            b'       round(m.used_space*t.block_size/1024/1024/1024,2) used_gb,\n'
            b'       round(m.tablespace_size*t.block_size/1024/1024/1024,2) max_gb,\n'
            b'       round(m.used_percent,1) used_pct\n'
            b'from dba_tablespace_usage_metrics m, dba_tablespaces t\n'
            b'where t.tablespace_name = m.tablespace_name\n'
            b'order by m.used_percent desc;\n'
        ),
    ),
    "r_temp_files.sql": (
        "6d35f20585ba2103e5628e52505acdfae4a3904d89095c076e73259791b64428",
        (
            b'set pages 999\n'
            b'set lines 400\n'
            b'col FILE_NAME format a75\n'
            b'select d.TABLESPACE_NAME, d.FILE_NAME, d.BYTES/1024/1024 SIZE_MB, d.AUTOEXTENSIBLE, d.MAXBYTES/1024/1024 MAXSIZE_MB, d.INCREMENT_BY*(v.BLOCK_SIZE/1024)/1024 INCREMENT_BY_MB\n'
            b'from dba_temp_files d,\n'
            b'v$tempfile v\n'
            b'where d.FILE_ID = v.FILE#\n'
            b'order by d.TABLESPACE_NAME, d.FILE_NAME;\n'
        ),
    ),
    "r_temp_history.sql": (
        "333479490267eccefc65946e0a48f7ff988c546df8e37a1a8d955ca4d3ac3832",
        (
            b'set lines 200\n'
            b'col tablespace_name for a20\n'
            b'SELECT\n'
            b'    ts.tablespace_name,\n'
            b'    TRUNC(snap.begin_interval_time) AS usage_date,\n'
            b'    ROUND(AVG(hs.tablespace_usedsize * ts.block_size) / (1024 * 1024), 2) AS avg_used_mb,\n'
            b'    ROUND(AVG(hs.tablespace_size * ts.block_size) / (1024 * 1024), 2) AS avg_allocated_mb,\n'
            b'    ROUND(AVG((hs.tablespace_usedsize / NULLIF(hs.tablespace_size, 0)) * 100), 2) AS avg_pct_used\n'
            b'FROM\n'
            b'    dba_hist_tbspc_space_usage hs\n'
            b'JOIN\n'
            b'    dba_hist_snapshot snap\n'
            b'    ON hs.snap_id = snap.snap_id\n'
            b'   AND hs.dbid = snap.dbid\n'
            b'JOIN\n'
            b'    v$tablespace vts\n'
            b'    ON hs.tablespace_id = vts.ts#\n'
            b'JOIN\n'
            b'    dba_tablespaces ts\n'
            b'    ON vts.name = ts.tablespace_name\n'
            b'WHERE\n'
            b"    ts.contents = 'TEMPORARY'\n"
            b'    AND snap.begin_interval_time >= TRUNC(SYSDATE) - &TEMP_HIST_DAYS\n'
            b'GROUP BY\n'
            b'    ts.tablespace_name,\n'
            b'    TRUNC(snap.begin_interval_time)\n'
            b'ORDER BY\n'
            b'    ts.tablespace_name,\n'
            b'    usage_date DESC;\n'
        ),
    ),
    "r_top_events.sql": (
        "0fc5cc7eaaaf3750b37bd6742fd499da417ccdd448890319aa83c4cc070342f2",
        (
            b'SET LINES 1000\n'
            b'SET PAGES 500\n'
            b'COL EVENT FOR A60\n'
            b'COL TOTAL_WAITS FOR 999999999\n'
            b'COL TIME_WAITED_SEC FOR 999999999.99\n'
            b'COL AVG_WAIT_MS FOR 999999.99\n'
            b'SELECT *\n'
            b'FROM (\n'
            b'    SELECT EVENT,\n'
            b'           TOTAL_WAITS,\n'
            b'           ROUND(TIME_WAITED / 100, 2) AS TIME_WAITED_SEC,\n'
            b'           ROUND((TIME_WAITED / NULLIF(TOTAL_WAITS, 0)) * 10, 2) AS AVG_WAIT_MS\n'
            b'    FROM V$SYSTEM_EVENT\n'
            b"    WHERE WAIT_CLASS <> 'Idle'\n"
            b'    ORDER BY TIME_WAITED DESC\n'
            b')\n'
            b'WHERE ROWNUM <= 5;\n'
        ),
    ),
    "r_user_expiry.sql": (
        "bb22129e6744853f8d63267dcb70eec43cf3e5393e3563ddd6e76154aacfc3a6",
        (
            b'col user_name for a30\n'
            b"select user_id,user_name,status,expires_on from trans.users where status='Active' and expires_on < sysdate + &USER_EXPIRY_LOOKAHEAD_DAYS;\n"
        ),
    ),
    "v_db_info.sql": (
        "1121740c22a59accbe28e6fb77a66a1e4717f0db7d744ddc79de79132afdfa0e",
        (
            b"select i.status||'|'||d.database_role||'|'||d.open_mode||'|'||d.db_unique_name||'|'||d.name from v$instance i, v$database d;\n"
        ),
    ),
    "v_db_patch.sql": (
        "28e12fb360793aa3041a858edc931be96434243eb3f6a9357cb391587d07ad6b",
        (
            b"select 'INFO|'||case when cnt = 0 then 'No records in dba_registry_sqlpatch'\n"
            b"                    else cnt||' patch record(s); latest: patch '||latest_patch||' '||latest_action||' '||latest_status||' at '||to_char(latest_time,'YYYY-MM-DD HH24:MI')\n"
            b'               end\n'
            b'from (select count(*) cnt,\n'
            b'             max(patch_id) keep (dense_rank last order by action_time) latest_patch,\n'
            b'             max(action) keep (dense_rank last order by action_time) latest_action,\n'
            b'             max(status) keep (dense_rank last order by action_time) latest_status,\n'
            b'             max(action_time) latest_time\n'
            b'      from dba_registry_sqlpatch);\n'
        ),
    ),
    "v_dbfiles.sql": (
        "d7993bbf4bc247f0a28909d95691d94b1756a1c565492f8d811435f857f7acfb",
        (
            b"select case when pct >= &DBFILES_CRIT then 'CRITICAL' when pct >= &DBFILES_WARN then 'WARNING' else 'OK' end\n"
            b"       ||'|db_files usage '||to_char(pct,'FM990.00')||'%'\n"
            b"from (select round((select count(*) from v$datafile)/to_number(value)*100,2) pct from v$parameter where name = 'db_files');\n"
        ),
    ),
    "v_dop.sql": (
        "4db7dc1ef032e63629f8c68f964e72d5b53311e45b15778b76b59179127083a2",
        (
            b"select 'INFO|'||count(*)||' index(es) with parallel DEGREE > 1' from dba_indexes where degree > '1';\n"
        ),
    ),
    "v_dump_history.sql": (
        "256f63ae637d1e41dc318590c13d40853f3ac0e5bd8d18dc1c2ed318d194cbfe",
        (
            b"select 'INFO|'||case when cnt = 0 then 'No JOB_IMS_EXP runs found in the last 7 days'\n"
            b"                    else cnt||' run(s) in last 7 days; latest: '||latest_status||' at '||to_char(latest_start,'YYYY-MM-DD HH24:MI')||', duration '||latest_dur\n"
            b'               end\n'
            b'from (select count(*) cnt,\n'
            b'             max(status) keep (dense_rank first order by log_date desc) latest_status,\n'
            b'             max(actual_start_date) keep (dense_rank first order by log_date desc) latest_start,\n'
            b'             max(substr(to_char(run_duration),12,8)) keep (dense_rank first order by log_date desc) latest_dur\n'
            b'      from all_scheduler_job_run_details\n'
            b"      where job_name = 'JOB_IMS_EXP' and actual_start_date >= trunc(sysdate - 7) and owner = 'TRANS');\n"
        ),
    ),
    "v_fra.sql": (
        "99e9f6686d3068d9f0a6f3049e5f822c893eef506b37e37eb754e41dc418cef6",
        (
            b"select case when space_limit is null or space_limit = 0 then 'WARNING|FRA not configured or space limit is 0'\n"
            b"            else case when pct >= &FRA_CRIT then 'CRITICAL' when pct >= &FRA_WARN then 'WARNING' else 'OK' end\n"
            b"                 ||'|FRA '||to_char(pct,'FM990.0')||'% full (used - reclaimable)' end\n"
            b'from (select space_limit, round((space_used - space_reclaimable)/nullif(space_limit,0)*100,1) pct from v$recovery_file_dest);\n'
        ),
    ),
    "v_ims_jobs.sql": (
        "349713561e80180f37e503a469c0b8a1f75aa23903888049d717a01450afa5fd",
        (
            b"select 'INFO|See report for last_run/next_run of Active/Archive jobs (config + mm_config)' from dual;\n"
        ),
    ),
    "v_ims_sched.sql": (
        "6ed11fe0ba2429d66aefbe2dedacec5b8c293926ce8d7252479ec080ba1748e9",
        (
            b"select 'INFO|'||count(*)||' active scheduler(s) found (terminate_on within &IMS_SCHEDULER_LOOKAHEAD_DAYS days)'\n"
            b"from config.schedule_master where status = 'Active' and terminate_on < sysdate + &IMS_SCHEDULER_LOOKAHEAD_DAYS;\n"
        ),
    ),
    "v_index.sql": (
        "3fcefbe52cceba2dcda5c366e920b4ac88f7d80ef246f8a5c2895db7e3b601d4",
        (
            b"select 'INFO|'||(select count(*) from dba_indexes where partitioned = 'NO' and status <> 'VALID')||' invalid/unusable index(es), '\n"
            b"       ||(select count(*) from dba_ind_partitions where status = 'UNUSABLE')||' unusable index partition(s), '\n"
            b"       ||(select count(*) from dba_ind_subpartitions where status = 'UNUSABLE')||' unusable index subpartition(s) (no severity applied, informational only)'\n"
            b'from dual;\n'
        ),
    ),
    "v_locks.sql": (
        "9c566b403c59a3ff2e32b3facee4f8d40150f85f2b91f8d6841008f9923f5c00",
        (
            b"select 'INFO|'||case when count(*) > 0 then count(*)||' blocking session(s) found (waiting > &LOCK_WAIT_SEC s)'\n"
            b"                     else 'No blocking sessions found (waiting > &LOCK_WAIT_SEC s)' end\n"
            b'from gv$session\n'
            b'where lockwait is not null and row_wait_obj# != -1 and seconds_in_wait > &LOCK_WAIT_SEC;\n'
        ),
    ),
    "v_redo.sql": (
        "1ebba487e3cf541d0b422a6e290124407f40d46e8abf8606525dfab8cecded73",
        (
            b"select case when bad > 0 or (total > 0 and act = total) then 'CRITICAL'\n"
            b"            when single_cnt > 0 then 'WARNING' else 'OK' end\n"
            b"       ||'|'||total||' groups, '||act||' ACTIVE, '||bad||' bad member(s), '||single_cnt||' group(s) with single member'\n"
            b"from (select (select count(*) from v$logfile where status in ('INVALID','DELETED')) bad,\n"
            b"             (select count(*) from v$log where status = 'ACTIVE') act,\n"
            b'             (select count(*) from v$log) total,\n'
            b'             (select count(*) from v$log where members < 2) single_cnt\n'
            b'      from dual);\n'
        ),
    ),
    "v_resource.sql": (
        "3005393204f7804547d70f70546959b3ce207c985cef82e4b8dd2a660730902e",
        (
            b'with r as (\n'
            b'  select resource_name name, current_utilization cur,\n'
            b"         case when upper(trim(limit_value)) = 'UNLIMITED' then null else to_number(trim(limit_value)) end lim\n"
            b"  from v$resource_limit where resource_name in ('processes','sessions')\n"
            b'  union all\n'
            b"  select 'open_cursors(inst'||p.inst_id||')', to_number(s.value), to_number(p.value)\n"
            b'  from gv$parameter p join gv$sysstat s on p.inst_id = s.inst_id\n'
            b"  where p.name = 'open_cursors' and s.name = 'opened cursors current')\n"
            b"select case when sum(case when lim > 0 and cur/lim*100 >= &RESOURCE_CRIT then 1 else 0 end) > 0 then 'CRITICAL'\n"
            b"            when sum(case when lim > 0 and cur/lim*100 >= &RESOURCE_WARN then 1 else 0 end) > 0 then 'WARNING'\n"
            b"            else 'OK' end\n"
            b"       ||'|'||listagg(name||' '||cur||'/'||nvl(to_char(lim),'unlimited')||case when lim > 0 then ' ('||round(cur/lim*100,1)||'%)' end,'; ') within group (order by name)\n"
            b'from r;\n'
        ),
    ),
    "v_rman.sql": (
        "569f958389c533cc355a121720c91d937ff68071042346c870bfd63a22bc5ee1",
        (
            b"select case when cnt > 0 then 'CRITICAL|'||cnt||' FAILED job(s) in last &RMAN_LOOKBACK_DAYS d - '||detail\n"
            b"            else 'OK|No FAILED RMAN job(s) in the last &RMAN_LOOKBACK_DAYS day(s)' end\n"
            b'from (select count(*) cnt,\n'
            b"             listagg(operation||' ('||nvl(object_type,'-')||') '||to_char(start_time,'YYYY-MM-DD HH24:MI'),'; ' on overflow truncate '...') within group (order by start_time desc) detail\n"
            b'      from v$rman_status\n'
            b"      where upper(status) like '%FAILED%' and start_time >= sysdate - &RMAN_LOOKBACK_DAYS and operation <> 'LIST');\n"
        ),
    ),
    "v_running.sql": (
        "332c156138572c4d0e0530f8e0cc42578f7f083994db30010a4b4f90eb442856",
        (
            b"select 'INFO|'||count(*)||' job(s) currently running' from dba_scheduler_running_jobs;\n"
        ),
    ),
    "v_segment.sql": (
        "a2382b7412c2cae1e9cb8433aa589ec6c88a1187cc7b8b2b72e3ba424d2e97bc",
        (
            b"select 'INFO|Total segment size: '||round((select sum(bytes) from dba_segments)/1024/1024/1024,2)||' GB, datafile size: '\n"
            b"       ||round((select sum(bytes) from dba_data_files)/1024/1024/1024,2)||' GB'\n"
            b'from dual;\n'
        ),
    ),
    "v_sys.sql": (
        "98860dbac8e1d9d522f5ae42cdcef95e2b84591b3c4f0b85ac601a6f9c237126",
        (
            b"select case when account_status = '&SYS_EXPIRY_CRIT_STATUS' then 'CRITICAL' else 'OK' end\n"
            b"       ||'|SYS account_status = '||account_status\n"
            b"from dba_users where username = 'SYS';\n"
        ),
    ),
    "v_tbs.sql": (
        "051a1156770bd6e415655894a01e27049d4e24acc478dddff536256f99641268",
        (
            b"select case when sum(case when pct >= &TBS_CRIT then 1 else 0 end) > 0 then 'CRITICAL'\n"
            b"            when sum(case when pct >= &TBS_WARN then 1 else 0 end) > 0 then 'WARNING'\n"
            b"            else 'OK' end\n"
            b"       ||'|Highest: '||nvl(max(tablespace_name) keep (dense_rank last order by pct),'n/a')||' '\n"
            b"       ||nvl(to_char(max(pct),'FM990.0'),'0')||'% ('\n"
            b"       ||nvl(sum(case when pct >= &TBS_CRIT then 1 else 0 end),0)||' critical, '\n"
            b'       ||nvl(sum(case when pct >= &TBS_WARN and pct < &TBS_CRIT then 1 else 0 end),0)\n'
            b"       ||' warning; UNDO/TEMP-current not evaluated)'\n"
            b'from (select m.tablespace_name, round(m.used_percent,1) pct\n'
            b'      from dba_tablespace_usage_metrics m, dba_tablespaces t\n'
            b"      where t.tablespace_name = m.tablespace_name and t.contents = 'PERMANENT');\n"
        ),
    ),
    "v_temp_hist.sql": (
        "7035b6a6101ff20fa54e9248da48f42928f32b0d0eebcc2a955279cb1baa3b08",
        (
            b"select case when sum(case when p >= &TBS_CRIT then 1 else 0 end) > 0 then 'CRITICAL'\n"
            b"            when sum(case when p >= &TBS_WARN then 1 else 0 end) > 0 then 'WARNING'\n"
            b"            else 'OK' end\n"
            b"       ||'|TEMP hist (&TEMP_HIST_DAYS d worst): '||nvl(max(tablespace_name) keep (dense_rank last order by p),'n/a')||' '\n"
            b"       ||nvl(to_char(max(p),'FM990.00'),'0')||'% ('\n"
            b"       ||nvl(sum(case when p >= &TBS_CRIT then 1 else 0 end),0)||' critical, '\n"
            b"       ||nvl(sum(case when p >= &TBS_WARN and p < &TBS_CRIT then 1 else 0 end),0)||' warning)'\n"
            b'from (select tablespace_name, max(avg_pct) p\n'
            b'      from (select ts.tablespace_name tablespace_name, trunc(snap.begin_interval_time) usage_date,\n'
            b'                   round(avg((hs.tablespace_usedsize / nullif(hs.tablespace_size,0)) * 100),2) avg_pct\n'
            b'            from dba_hist_tbspc_space_usage hs\n'
            b'            join dba_hist_snapshot snap on hs.snap_id = snap.snap_id and hs.dbid = snap.dbid\n'
            b'            join v$tablespace vts on hs.tablespace_id = vts.ts#\n'
            b'            join dba_tablespaces ts on vts.name = ts.tablespace_name\n'
            b"            where ts.contents = 'TEMPORARY' and snap.begin_interval_time >= trunc(sysdate) - &TEMP_HIST_DAYS\n"
            b'            group by ts.tablespace_name, trunc(snap.begin_interval_time))\n'
            b'      group by tablespace_name);\n'
        ),
    ),
    "v_top_events.sql": (
        "0ac951029e75308de2a7d6467dee4ac350585a6f262a6e2e71d6a56a2c9e228b",
        (
            b"select 'INFO|Top 5 non-idle wait events collected (see report)' from dual;\n"
        ),
    ),
    "v_user_expiry.sql": (
        "42c7df7468bd7d3304f46e95674051730fac0c9466d2d447037ac13f7961ead2",
        (
            b"select case when nvl(c,0) > 0 then 'CRITICAL' when nvl(w,0) > 0 then 'WARNING' else 'OK' end\n"
            b"       ||'|'||case when tot = 0 then 'No active TRANS users expiring within &USER_EXPIRY_LOOKAHEAD_DAYS day(s)'\n"
            b"                   else c||' critical (<=&USER_EXPIRY_CRITICAL_DAYS d), '||w||' warning (<=&USER_EXPIRY_WARNING_DAYS d), '||(tot-c-w)||' further out (within &USER_EXPIRY_LOOKAHEAD_DAYS d)'\n"
            b"                        ||case when c > 0 then '; CRITICAL: '||cl end\n"
            b"                        ||case when w > 0 then '; WARNING: '||wl end\n"
            b'              end\n'
            b'from (select count(*) tot,\n'
            b'             sum(case when d <= &USER_EXPIRY_CRITICAL_DAYS then 1 else 0 end) c,\n'
            b'             sum(case when d > &USER_EXPIRY_CRITICAL_DAYS and d <= &USER_EXPIRY_WARNING_DAYS then 1 else 0 end) w,\n'
            b"             listagg(case when d <= &USER_EXPIRY_CRITICAL_DAYS then user_name||'('||d||'d)' end,'; ' on overflow truncate '...') within group (order by d) cl,\n"
            b"             listagg(case when d > &USER_EXPIRY_CRITICAL_DAYS and d <= &USER_EXPIRY_WARNING_DAYS then user_name||'('||d||'d)' end,'; ' on overflow truncate '...') within group (order by d) wl\n"
            b'      from (select user_name, trunc(expires_on - sysdate) d\n'
            b'            from trans.users\n'
            b"            where status = 'Active' and expires_on < sysdate + &USER_EXPIRY_LOOKAHEAD_DAYS));\n"
        ),
    ),
}
