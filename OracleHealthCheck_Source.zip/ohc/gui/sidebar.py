"""Sidebar navigation: compact icon buttons, section captions, an expandable Database Reports submenu,
and a collapsed icon rail. Only presentation: it reports clicks through `navigate(page_row, tab)` and starts nothing.

Icons are drawn with QPainter (no image files), in the muted colour, accent colour for the open group, white on the selected item.
"""
from __future__ import annotations

import math
from functools import partial

from PySide6.QtCore import QPoint, QPointF, QRectF, QSize, Qt, Signal
from PySide6.QtGui import QColor, QFont, QIcon, QPainter, QPen, QPixmap, QPolygonF
from PySide6.QtWidgets import QButtonGroup, QFrame, QHBoxLayout, QLabel, QMenu, QPushButton, QToolButton, QVBoxLayout, QWidget


WIDTH, COLLAPSED_WIDTH = 216, 60
ICON, SCALE = 17, 3          # logical icon size; drawn at 3x so it stays crisp at any Windows display scaling


def nav_pixmap(kind: str, color: str, size: int = ICON) -> QPixmap:
    """A line icon on a 24 x 24 grid. kinds: dashboard health sync checks reports logs settings database list server folder terminal dot chev_right chev_down."""
    pm = QPixmap(size * SCALE, size * SCALE)
    pm.fill(Qt.GlobalColor.transparent)
    pm.setDevicePixelRatio(SCALE)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.scale(size / 24, size / 24)
    pen = QPen(QColor(color), 1.8, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
    p.setPen(pen)
    p.setBrush(Qt.BrushStyle.NoBrush)
    pts = lambda *xy: [QPointF(x, y) for x, y in xy]  # noqa: E731
    if kind == "dashboard":
        for x, y in ((3.5, 3.5), (13.5, 3.5), (3.5, 13.5), (13.5, 13.5)):
            p.drawRoundedRect(QRectF(x, y, 7, 7), 1.8, 1.8)
    elif kind == "health":      # pulse line
        p.drawPolyline(pts((2.5, 12.5), (7, 12.5), (9.5, 5.5), (13.5, 19), (16, 12.5), (21.5, 12.5)))
    elif kind == "sync":        # two opposite arrows
        p.drawLine(QPointF(4, 8), QPointF(19.5, 8))
        p.drawPolyline(pts((15.5, 4.5), (19.5, 8), (15.5, 11.5)))
        p.drawLine(QPointF(20, 16), QPointF(4.5, 16))
        p.drawPolyline(pts((8.5, 12.5), (4.5, 16), (8.5, 19.5)))
    elif kind == "checks":      # check list
        for y in (6, 12, 18):
            p.drawPolyline(pts((3.5, y), (5.4, y + 1.9), (8.8, y - 1.9)))
            p.drawLine(QPointF(12.5, y), QPointF(21, y))
    elif kind == "reports":     # bar chart
        pen.setWidthF(3.2)
        p.setPen(pen)
        for x, top in ((6, 12), (12, 6), (18, 9.5)):
            p.drawLine(QPointF(x, 19), QPointF(x, top))
    elif kind == "logs":        # document
        p.drawRoundedRect(QRectF(5, 3, 14, 18), 2, 2)
        for y, x2 in ((9, 15.5), (13, 15.5), (17, 12.5)):
            p.drawLine(QPointF(8.5, y), QPointF(x2, y))
    elif kind == "settings":    # gear
        gear = []
        for i in range(8):
            a = math.radians(i * 45)
            for off, r in ((-13, 6.9), (-8, 9.7), (8, 9.7), (13, 6.9)):
                t = a + math.radians(off)
                gear.append(QPointF(12 + r * math.cos(t), 12 + r * math.sin(t)))
        p.drawPolygon(QPolygonF(gear))
        p.drawEllipse(QPointF(12, 12), 3, 3)
    elif kind == "database":    # cylinder
        p.drawEllipse(QRectF(5, 3.5, 14, 5.5))
        p.drawLine(QPointF(5, 6.25), QPointF(5, 17.75))
        p.drawLine(QPointF(19, 6.25), QPointF(19, 17.75))
        p.drawArc(QRectF(5, 9.5, 14, 5.5), 180 * 16, 180 * 16)
        p.drawArc(QRectF(5, 15, 14, 5.5), 180 * 16, 180 * 16)
    elif kind == "list":        # bulleted list
        for y in (6, 12, 18):
            p.drawEllipse(QPointF(4.8, y), 0.9, 0.9)
            p.drawLine(QPointF(9, y), QPointF(21, y))
    elif kind == "server":      # rack with two units
        for y in (4, 13.5):
            p.drawRoundedRect(QRectF(4, y, 16, 6.5), 1.8, 1.8)
            p.drawPoint(QPointF(8, y + 3.25))
            p.drawLine(QPointF(12, y + 3.25), QPointF(16.5, y + 3.25))
    elif kind == "folder":
        p.drawPolygon(QPolygonF([QPointF(3.5, 6), QPointF(9, 6), QPointF(11, 8.5), QPointF(20.5, 8.5), QPointF(20.5, 18.5), QPointF(3.5, 18.5)]))
    elif kind == "terminal":    # prompt: >_
        p.drawPolyline(pts((5, 8), (10.5, 12.5), (5, 17)))
        p.drawLine(QPointF(13, 17.5), QPointF(19.5, 17.5))
    elif kind == "dot":         # submenu bullet
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(color))
        p.drawEllipse(QPointF(12, 12), 3.4, 3.4)
    elif kind == "chev_right":
        pen.setWidthF(2.2)
        p.setPen(pen)
        p.drawPolyline(pts((9, 6), (15, 12), (9, 18)))
    elif kind == "chev_down":
        pen.setWidthF(2.2)
        p.setPen(pen)
        p.drawPolyline(pts((6, 9), (12, 15), (18, 9)))
    p.end()
    return pm


def _repolish(widget: QWidget) -> None:
    widget.style().unpolish(widget)
    widget.style().polish(widget)


class NavButton(QPushButton):
    """One sidebar entry. `sub` entries (AWR / ASH / ADDM) have no icon; `chevron` marks the expandable group."""

    def __init__(self, text: str, icon_kind: str | None = None, sub: bool = False, chevron: bool = False, parent=None):
        super().__init__(self._label(text), parent)
        self.full_text, self.icon_kind, self.active = text, ("dot" if sub else icon_kind), False
        self.setObjectName("navSub" if sub else "navItem")
        self.setCheckable(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setIconSize(QSize(8, 8) if sub else QSize(ICON, ICON))
        self.chev = None
        if chevron:
            self.chev = QLabel(self)
            self.chev.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
            row = QHBoxLayout(self)
            row.setContentsMargins(0, 0, 10, 0)
            row.addStretch(1)
            row.addWidget(self.chev)

    @staticmethod
    def _label(text: str) -> str:
        return text.replace("&", "&&")   # a single & would be read by Qt as a keyboard-shortcut marker ("Reports & Logs")

    def set_icons(self, pal: dict) -> None:
        if self.icon_kind is None:
            return
        icon = QIcon()
        off = pal["accent_text"] if self.active else pal["muted"]
        icon.addPixmap(nav_pixmap(self.icon_kind, off), QIcon.Mode.Normal, QIcon.State.Off)
        icon.addPixmap(nav_pixmap(self.icon_kind, "#FFFFFF"), QIcon.Mode.Normal, QIcon.State.On)
        self.setIcon(icon)

    def set_active(self, active: bool, pal: dict) -> None:
        """`active`: a child page of this group is open (shown in the accent colour while the group is expanded)."""
        self.active = active
        self.setProperty("active", active)
        _repolish(self)
        self.set_icons(pal)


class Sidebar(QFrame):
    """entries: ("item", title, icon, page_row) | ("group", title, icon, page_row, [(child title, tab), ...]) | ("section", caption) | ("stretch",)."""
    navigate = Signal(int, object)          # page row, tab index (None for pages without tabs)

    def __init__(self, entries: list, version: str, pal: dict, parent=None):
        super().__init__(parent)
        self.setObjectName("nav")
        self.setFixedWidth(WIDTH)
        self.pal, self.collapsed, self.expanded = pal, False, False
        self.current = (0, None)
        self.items: dict = {}                # (page_row, tab) -> NavButton
        self.sections: list = []             # (caption, divider)
        self.group_btn = self.group_box = self.group_row = None
        self.group_children: list = []
        self.group = QButtonGroup(self)
        self.group.setExclusive(True)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(6, 0, 6, 8)
        outer.setSpacing(1)

        self.toggle_btn = QToolButton()      # the hamburger (MainWindow connects it and sets its icon)
        self.toggle_btn.setObjectName("navToggle")
        self.toggle_btn.setFixedSize(30, 30)
        self.toggle_btn.setIconSize(QSize(20, 20))
        self.toggle_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.brand = QWidget()               # the application title as text only: "ORACLE" over "Health Check", centred
        self.brand.setAccessibleName("Oracle Health Check")
        title = QVBoxLayout(self.brand)
        title.setContentsMargins(0, 0, 0, 0)
        title.setSpacing(0)
        word = QLabel("ORACLE")
        word.setObjectName("brandWord")
        spaced = word.font()
        spaced.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 1.6)
        word.setFont(spaced)
        name = QLabel("Health Check")
        name.setObjectName("brand")
        for label in (word, name):
            label.setAlignment(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter)
            title.addWidget(label)
        head = QHBoxLayout()
        head.setContentsMargins(0, 6, 0, 12)
        head.setSpacing(6)
        head.addWidget(self.toggle_btn)
        head.addWidget(self.brand, 1)
        outer.addLayout(head)

        for entry in entries:
            kind = entry[0]
            if kind == "section":
                caption = QLabel(entry[1])
                caption.setObjectName("navSection")
                divider = QFrame()
                divider.setObjectName("navDivider")
                divider.setFixedHeight(1)
                divider.hide()
                outer.addWidget(caption)
                outer.addWidget(divider)
                self.sections.append((caption, divider))
            elif kind == "stretch":
                outer.addStretch(1)
            elif kind == "item":
                _k, title, icon, row = entry
                outer.addWidget(self._add(NavButton(title, icon), row, None))
            elif kind == "group":
                _k, title, icon, row, children = entry
                self.group_row = row
                self.group_btn = NavButton(title, icon, chevron=True)
                self.group_btn.clicked.connect(self._group_clicked)
                outer.addWidget(self.group_btn)
                box = QFrame()
                box.setObjectName("navSubBox")
                box_layout = QVBoxLayout(box)
                box_layout.setContentsMargins(0, 0, 0, 0)
                box_layout.setSpacing(2)
                for text, tab in children:
                    box_layout.addWidget(self._add(NavButton(text, sub=True), row, tab))
                    self.group_children.append((text, tab))
                self.group_box = QWidget()
                wrap = QHBoxLayout(self.group_box)
                wrap.setContentsMargins(14, 0, 0, 2)
                wrap.addWidget(box)
                self.group_box.setVisible(False)
                outer.addWidget(self.group_box)

        self.footer = QLabel(f"Version {version}")
        self.footer.setObjectName("navFooter")
        outer.addWidget(self.footer)
        self.refresh_icons(pal)
        self._update_group()

    # ------------------------------------------------------------------ building
    def _add(self, button: NavButton, row: int, tab) -> NavButton:
        button.clicked.connect(partial(self.navigate.emit, row, tab))
        self.group.addButton(button)
        self.items[(row, tab)] = button
        return button

    def _buttons(self):
        return [b for b in self.items.values() if b.objectName() == "navItem"] + ([self.group_btn] if self.group_btn else [])

    # ------------------------------------------------------------------ state
    def set_current(self, row: int, tab=None) -> None:
        """Highlight the entry for this page (and open the group when it is one of the reports). Emits nothing."""
        self.current = (row, tab)
        in_group = row == self.group_row
        button = self.items.get((row, tab if in_group else None))
        if button is not None:
            button.setChecked(True)
        if self.group_btn is not None:
            self.group_btn.set_active(in_group, self.pal)
            if in_group:
                self.expanded = True
        self._update_group()

    def _update_group(self) -> None:
        if self.group_btn is None:
            return
        in_group = self.current[0] == self.group_row
        self.group_box.setVisible(self.expanded and not self.collapsed)
        self.group_btn.setChecked(self.collapsed and in_group)   # collapsed rail: the group button itself shows the selection
        if self.group_btn.chev is not None:
            self.group_btn.chev.setPixmap(nav_pixmap("chev_down" if self.expanded else "chev_right", self.pal["muted"], 14))
            self.group_btn.chev.setVisible(not self.collapsed)

    def _group_clicked(self) -> None:
        if self.collapsed:                   # no room for the submenu on the rail: a small popup instead
            menu = QMenu(self)
            for text, tab in self.group_children:
                menu.addAction(text, partial(self.navigate.emit, self.group_row, tab))
            menu.exec(self.group_btn.mapToGlobal(QPoint(self.group_btn.width(), 0)))
        else:
            self.expanded = not self.expanded
        self._update_group()

    def set_collapsed(self, collapsed: bool) -> None:
        """Collapsed: a narrow icon rail (full names in tooltips). Expanded: as designed."""
        self.collapsed = collapsed
        self.setFixedWidth(COLLAPSED_WIDTH if collapsed else WIDTH)
        self.toggle_btn.setFixedSize(COLLAPSED_WIDTH - 12 if collapsed else 30, 30)
        for widget in (self.brand, self.footer):
            widget.setVisible(not collapsed)
        for caption, divider in self.sections:
            caption.setVisible(not collapsed)
            divider.setVisible(collapsed)
        for button in self._buttons():
            button.setText("" if collapsed else button._label(button.full_text))
            button.setToolTip(button.full_text if collapsed else "")
            button.setProperty("collapsed", collapsed)
            _repolish(button)
        self._update_group()

    def refresh_icons(self, pal: dict) -> None:
        self.pal = pal
        for button in list(self.items.values()) + ([self.group_btn] if self.group_btn else []):
            button.set_icons(pal)
        self._update_group()

    # ------------------------------------------------------------------ row API (the older list-style navigation)
    def setCurrentRow(self, row: int) -> None:
        self.navigate.emit(row, None)

    def currentRow(self) -> int:
        return self.current[0]
