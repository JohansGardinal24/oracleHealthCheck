"""Pages for options 1, 2 and 3: the Oracle Health Check dashboard.

Choose a database, press Run Health Check, watch the checks complete, select a check to see its output and SQL.
Nothing runs until Run is pressed.
"""
from __future__ import annotations

import time
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, QSize, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices, QFont, QFontDatabase, QIcon, QPainter, QPen
from PySide6.QtWidgets import (QAbstractItemView, QComboBox, QDialog, QFrame, QGridLayout, QHBoxLayout, QLabel,
                               QPlainTextEdit, QProgressBar, QPushButton, QStyledItemDelegate, QTableWidgetItem, QTabWidget,
                               QVBoxLayout, QWidget)

from ohc.checks import engine, launcher
from ohc.checks.cancel import CancelToken
from ohc.checks.session import ENC
from ohc.config import environment
from ohc.config import oracle_home as oh
from ohc.gui import outcomes, run_skin
from ohc.gui.runner import JobThread
from ohc.gui.sidebar import nav_pixmap
from ohc.gui.theme import PALETTES
from ohc.gui.widgets import FitTable, WrapLabel
from ohc.resources import sql_access


# status -> (badge colour, text colour, text shown). The words are the legacy tool's (OK / WARNING / CRITICAL / SKIPPED).
BADGES = {
    "OK": ("#16A34A", "#FFFFFF", "OK"), "WARNING": ("#F59E0B", "#1F1300", "WARNING"), "CRITICAL": ("#DC2626", "#FFFFFF", "CRITICAL"),
    "SKIPPED": ("#64748B", "#FFFFFF", "SKIPPED"), "INFO": ("#2563EB", "#FFFFFF", "INFO"),
    "RUNNING": ("#2563EB", "#FFFFFF", "Running"), "PENDING": ("#CBD5E1", "#334155", "Not Run"),
    "UNKNOWN": ("#64748B", "#FFFFFF", "Unknown"),
    "CANCELLED": ("#94A3B8", "#FFFFFF", "Cancelled"),
}
COLS = ("#", "Check Name", "Status", "Result / Summary", "Time")
STATUS_ROLE = Qt.ItemDataRole.UserRole
NO_SQL = "This check does not use a SQL script (it uses DGMGRL or PowerShell)."
SKIN_OPTIONS = ("1", "2", "3")                                    # pages with the redesigned look (one shared wave)
HEAD_ICONS = {"1": "health", "2": "sync", "3": "checks"}         # heading icon = the sidebar icon of the page


def fmt_seconds(value: float) -> str:
    return f"{value:.1f} s" if value < 60 else f"{int(value) // 60:02d}:{int(value) % 60:02d}"


def fmt_elapsed(value: float) -> str:
    value = int(value)
    return f"{value // 3600:02d}:{value // 60 % 60:02d}:{value % 60:02d}"


def fmt_when(moment: datetime) -> str:
    return moment.strftime("%d %b %Y, %H:%M:%S")


def _label(text="", name="muted", wrap=True) -> QLabel:
    label = QLabel(text)
    label.setObjectName(name)
    label.setWordWrap(wrap)
    return label


def _card() -> tuple:
    frame = QFrame()
    frame.setObjectName("card")
    box = QVBoxLayout(frame)
    box.setContentsMargins(14, 12, 14, 12)
    box.setSpacing(8)
    return frame, box


def _mono() -> QPlainTextEdit:
    edit = QPlainTextEdit()
    edit.setReadOnly(True)
    edit.setFont(QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont))
    edit.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
    return edit


def _restyle(widget, name: str) -> None:
    widget.setObjectName(name)
    widget.style().unpolish(widget)
    widget.style().polish(widget)


class BadgeDelegate(QStyledItemDelegate):
    """Paints the Status column as a rounded coloured badge."""

    def paint(self, painter, option, index) -> None:
        fill, ink, text = BADGES.get(index.data(STATUS_ROLE) or "PENDING", BADGES["PENDING"])
        painter.save()
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(option.rect).adjusted(6, 5, -6, -5)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(fill))
        painter.drawRoundedRect(rect, 5, 5)
        painter.setPen(QColor(ink))
        font = QFont(option.font)
        font.setBold(True)
        font.setPointSizeF(max(7.5, font.pointSizeF() - 1.5))
        painter.setFont(font)
        painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, text)
        painter.restore()


class SkinBadgeDelegate(BadgeDelegate):
    """The Status column of the redesigned pages: soft tinted pills (same look as the Dashboard). BadgeDelegate itself is unchanged."""

    def __init__(self, parent, theme_name) -> None:
        super().__init__(parent)
        self._theme_name = theme_name

    def paint(self, painter, option, index) -> None:
        status = index.data(STATUS_ROLE) or "PENDING"
        label = BADGES.get(status, BADGES["PENDING"])[2]
        fill, ink = run_skin.pill(self._theme_name(), status)
        painter.save()
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(option.rect).adjusted(6, 5, -6, -5)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(fill))
        painter.drawRoundedRect(rect, 5, 5)
        painter.setPen(QColor(ink))
        font = QFont(option.font)
        font.setBold(True)
        font.setPointSizeF(max(7.5, font.pointSizeF() - 1.5))
        painter.setFont(font)
        painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, label)
        painter.restore()


class StateIcon(QWidget):
    """Round state symbol of the status card."""
    COLORS = {"idle": "#94A3B8", "running": "#2563EB", "ok": "#16A34A", "warn": "#F59E0B", "bad": "#DC2626", "cancelled": "#94A3B8"}

    def __init__(self, parent=None):
        super().__init__(parent)
        self.state = "idle"
        self.setFixedSize(40, 40)

    def set_state(self, state: str) -> None:
        self.state = state
        self.update()

    def paintEvent(self, _event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.scale(40 / 52, 40 / 52)
        pen = QPen(QColor(self.COLORS[self.state]), 3.5)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
        p.setPen(pen)
        ring = QRectF(4, 4, 44, 44)
        if self.state == "running":
            p.drawArc(ring, 90 * 16, -270 * 16)
        else:
            p.drawEllipse(ring)
        if self.state == "ok":
            p.drawPolyline([QPointF(15, 27), QPointF(23, 35), QPointF(37, 19)])
        elif self.state in ("warn", "bad"):
            p.drawLine(26, 14, 26, 29)
            p.drawPoint(26, 37)
        elif self.state == "cancelled":
            p.drawRect(QRectF(18, 18, 16, 16))
        p.end()


class LogDialog(QDialog):
    """Read-only view of the full run log (the same file the legacy tool writes)."""

    def __init__(self, path: Path, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Full log - {path.name}")
        self.resize(900, 600)
        box = QVBoxLayout(self)
        self.view = _mono()
        try:
            self.view.setPlainText(path.read_text(encoding=ENC, errors="replace"))
        except OSError as exc:
            self.view.setPlainText(f"The log could not be read: {exc}")
        box.addWidget(self.view)


class RunPage(QWidget):
    view_changed = Signal()   # the plan, a row, the run state or the run identity changed (the Dashboard mirrors this page)

    def __init__(self, ctx, option: str, title: str, blurb: str, gate, parent=None, theme=None):
        super().__init__(parent)
        self.setObjectName("pageHost")
        self.ctx, self.option, self.gate = ctx, option, gate
        self.theme = theme                  # ThemeManager (optional); the redesigned pages follow it
        self._skin = option in SKIN_OPTIONS   # 5B: Oracle Health Check, Sync Check and All Checks share the new look
        self._icons: list = []              # (label, icon kind, size) re-drawn when the theme changes
        self.mode = engine.MODES[option]
        self._thread = None
        self._token = None       # CancelToken of the run in progress
        self._cancelling = False
        self._result = None
        self._data: dict = {}      # idx -> {"status", "message", "seconds", "output"}
        self._row: dict = {}       # idx -> table row
        self._total = 0
        self._started = 0.0
        self.run_db = None         # database name / start time / fake flag of the run last started on this page (None: no run yet)
        self.run_started = None
        self.run_fake = False
        self._timer = QTimer(self)
        self._timer.setInterval(500)
        self._timer.timeout.connect(self._tick)

        # ---- top row: database, Oracle Home, actions
        self.db_combo = QComboBox()
        self.home_label = WrapLabel("-")  # long paths wrap; the tooltip holds the full path
        self.home_label.setObjectName("muted")
        self.run_btn = QPushButton("\u25B6  Run Health Check")
        self.run_btn.setObjectName("primary")
        self.cancel_btn = QPushButton("\u25A0  Cancel")
        self.cancel_btn.setEnabled(False)  # enabled only while a run is in progress
        self.cancel_btn.setToolTip("Stop the run safely: no new check starts and the running SQL*Plus/DGMGRL process is ended")
        db_card, db_box = _card()
        self._add_head(db_box, "database", _label("Select Database", "strong", False))
        db_box.addWidget(self.db_combo)
        home_card, home_box = _card()
        self._add_head(home_box, "server", _label("Oracle Home", "strong", False))
        home_box.addWidget(self.home_label)
        act_card, act_box = _card()
        act_row = QHBoxLayout()
        act_row.addWidget(self.run_btn, 3)
        act_row.addWidget(self.cancel_btn, 2)
        act_box.addStretch(1)
        act_box.addLayout(act_row)
        act_box.addStretch(1)
        self.top_grid = QGridLayout()
        self.top_grid.setSpacing(12)
        self.top_cards = (db_card, home_card, act_card)
        self._arrange_top()

        # ---- status card
        self.state_icon = StateIcon()
        self.state_label = _label("Not Started", "stateTitle", False)
        self.status = _label("Click \"Run Health Check\" to start. Nothing runs until you do.")
        if self._skin:       # long failure messages (paths, ORA- errors) wrap fully and the card grows, instead of being clipped
            self.status = WrapLabel(self.status.text())
            self.status.setObjectName("muted")
        self.start_val, self.end_val, self.elapsed_val = (_label("-", "text", False) for _ in range(3))
        self.progress = QProgressBar()
        self.progress.setTextVisible(False)
        self.progress.setFixedHeight(10)
        self.percent_label = _label("0%", "text", False)
        self.count_label = _label("", "muted", False)
        self.state_box, self.times_box, self.prog_box = QWidget(), QWidget(), QWidget()
        state_col = QVBoxLayout(self.state_box)
        state_col.setContentsMargins(0, 0, 0, 0)
        state_col.setSpacing(0)
        state_col.addWidget(self.state_label)
        state_col.addWidget(self.status)
        times = QVBoxLayout(self.times_box)
        times.setContentsMargins(0, 0, 0, 0)
        times.setSpacing(0)
        for caption, value in (("Start Time", self.start_val), ("End Time", self.end_val), ("Elapsed", self.elapsed_val)):
            row = QHBoxLayout()
            cap = _label(caption, "muted", False)
            cap.setFixedWidth(80)
            row.addWidget(cap)
            row.addWidget(value, 1)
            times.addLayout(row)
        prog_row = QHBoxLayout()
        prog_row.addWidget(self.progress, 1)
        prog_row.addWidget(self.percent_label)
        prog = QVBoxLayout(self.prog_box)
        prog.setContentsMargins(0, 0, 0, 0)
        prog.setSpacing(0)
        prog.addWidget(_label("Progress", "muted", False))
        prog.addLayout(prog_row)
        prog.addWidget(self.count_label)
        status_card, status_box = _card()
        status_box.setContentsMargins(*((16, 3, 16, 3) if self._skin else (14, 6, 14, 6)))
        self.status_grid = QGridLayout()
        self.status_grid.setHorizontalSpacing(18)
        self.status_grid.setVerticalSpacing(0)
        status_box.addLayout(self.status_grid)
        self._arrange_status()

        # ---- results table
        self.table = FitTable(0, len(COLS), fixed={0: 46, 2: 100, 4: 60} if self._skin else {0: 36, 2: 96, 4: 64},
                              flex={1: 60, 3: 40} if self._skin else {1: 45, 3: 55}, flex_min=90)       # redesigned page: wider Check Name
        self.table.setHorizontalHeaderLabels(list(COLS))
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setShowGrid(False)
        self.table.setAlternatingRowColors(False)
        self.table.setItemDelegateForColumn(2, SkinBadgeDelegate(self.table, self._theme_name) if self._skin else BadgeDelegate(self.table))
        self.table.horizontalHeader().setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.table.setTextElideMode(Qt.TextElideMode.ElideRight)
        self.table.setMinimumHeight(110)
        self.results_title = _label("", "section", False)
        results_card, results_box = _card()
        self._add_head(results_box, "list", self.results_title)
        results_box.addWidget(self.table, 1)

        # ---- execution log
        # ---- check details
        self.det = {k: (WrapLabel("-") if k in ("name", "sql") else _label("-", "text", False))
                    for k in ("id", "name", "status", "time", "sql")}
        for lab in self.det.values():
            lab.setObjectName("text")
        self.out_view, self.sql_view = _mono(), _mono()
        self.out_view.setPlaceholderText("Select a check from the list to view its output.")
        self.sql_view.setPlaceholderText("Select a check from the list to view its SQL.")
        self.tabs = QTabWidget()
        self.tabs.addTab(self.out_view, "Result Output")
        self.tabs.addTab(self.sql_view, "SQL")
        details_card, details_box = _card()
        details_box.setSpacing(4)
        self._add_head(details_box, "logs", _label("Check Details", "section", False))
        for key, caption in (("id", "Check ID"), ("name", "Check Name"), ("status", "Status"), ("time", "Execution Time"),
                             ("sql", "SQL File")):
            row = QHBoxLayout()
            cap = _label(caption, "muted", False)
            cap.setFixedWidth(110)
            row.addWidget(cap)
            if key == "status":
                row.addWidget(self.det[key], 0, Qt.AlignmentFlag.AlignLeft)
                row.addStretch(1)
            else:
                row.addWidget(self.det[key], 1)
            details_box.addLayout(row)
        self.tabs.setMinimumHeight(150)
        details_box.addWidget(self.tabs, 1)
        self.open_file_btn = QPushButton("Open Output File")
        self.open_dir_btn = QPushButton("Open Report Folder")
        self.view_log_btn = QPushButton("View Full Log")
        actions = QHBoxLayout()
        for b in (self.open_file_btn, self.open_dir_btn, self.view_log_btn):
            b.setObjectName("compact")  # slightly tighter side padding so the three buttons fit the details column
            actions.addWidget(b)
        if self._skin:
            actions.setSpacing(6)
        details_box.addLayout(actions)

        left, right = QVBoxLayout(), QVBoxLayout()
        left.setSpacing(12)
        right.setSpacing(12)
        left.addWidget(results_card, 1)
        right.addWidget(details_card, 1)
        self.middle = QHBoxLayout()
        self.middle.setSpacing(12)
        self.middle.addLayout(left, 3)
        self.middle.addLayout(right, 2)

        inner = QWidget()
        inner.setObjectName("page")
        box = QVBoxLayout(inner)
        box.setContentsMargins(*((30, 6, 30, 18) if self._skin else (32, 4, 32, 16)))
        box.setSpacing(10)
        self._add_heading(box, title, blurb)
        box.addLayout(self.top_grid)
        box.addWidget(status_card)
        box.addLayout(self.middle, 1)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(inner)
        self._inner = inner

        self.run_btn.clicked.connect(self.start)
        self.cancel_btn.clicked.connect(self.cancel)
        self.db_combo.currentIndexChanged.connect(lambda _i: self._refresh_home())
        self.table.itemSelectionChanged.connect(self._selection_changed)
        self.open_file_btn.clicked.connect(self.open_output_file)
        self.open_dir_btn.clicked.connect(self.open_report_folder)
        self.view_log_btn.clicked.connect(self.view_full_log)
        gate.changed.connect(lambda _busy: self._update_enabled())
        self.refresh_databases()
        self._load_plan()
        if self._skin:
            self._init_skin()

    # ------------------------------------------------------------ skin (look only; nothing here starts, stops or reads anything)
    def _theme_name(self) -> str:
        return self.theme.theme if self.theme is not None else "dark"

    def _icon(self, kind: str, size: int) -> QLabel:
        label = QLabel()
        label.setFixedSize(size, size)
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._icons.append((label, kind, size))
        return label

    def _add_head(self, box, kind: str, label: QLabel) -> None:
        """A card heading; on the redesigned pages with a small red icon in front."""
        if not self._skin:
            box.addWidget(label)
            return
        row = QHBoxLayout()
        row.setSpacing(8)
        row.addWidget(self._icon(kind, 18))
        row.addWidget(label, 1)
        box.addLayout(row)

    def _add_heading(self, box, title: str, blurb: str) -> None:
        if not self._skin:
            box.addWidget(_label(title, "title", False))
            box.addWidget(_label(blurb))
            return
        texts = QVBoxLayout()
        texts.setSpacing(0)
        texts.addWidget(_label(title, "title", False))
        texts.addWidget(_label(blurb))
        row = QHBoxLayout()
        row.setSpacing(12)
        row.addWidget(self._icon(HEAD_ICONS.get(self.option, "health"), 32), 0, Qt.AlignmentFlag.AlignTop)
        row.addLayout(texts, 1)
        box.addLayout(row)

    def _init_skin(self) -> None:
        for card in self.top_cards[:2]:              # the two information cards get a faint warm tint
            card.setProperty("tint", "info")
        self.home_label.setObjectName("text")
        self.tabs.setIconSize(QSize(16, 16))
        for button in (self.open_file_btn, self.open_dir_btn, self.view_log_btn):
            button.setIconSize(QSize(14, 14))
        for card in self.top_cards:
            card.setMinimumHeight(100)
        cards = [f for f in self._inner.findChildren(QFrame) if f.objectName() == "card"]
        self._backdrop = run_skin.PageBackdrop(self._inner, cards, self._theme_name, lambda: self.top_cards[0].y())     # faint wave + soft card shadows behind the cards
        if self.theme is not None:
            self.theme.changed.connect(lambda _name: self._apply_skin())
        self._apply_skin()

    def _apply_skin(self) -> None:
        name = self._theme_name()
        pal = PALETTES[name]
        self.setStyleSheet(run_skin.stylesheet(name))
        for label, kind, size in self._icons:
            label.setPixmap(nav_pixmap(kind, pal["accent_text"], size))
        for index, kind in enumerate(("terminal", "logs")):          # tab icons: muted, accent when the tab is selected
            icon = QIcon()
            icon.addPixmap(nav_pixmap(kind, pal["muted"], 16), QIcon.Mode.Normal)
            icon.addPixmap(nav_pixmap(kind, pal["accent_text"], 16), QIcon.Mode.Selected)
            self.tabs.setTabIcon(index, icon)
        for button, kind in ((self.open_file_btn, "folder"), (self.open_dir_btn, "folder"), (self.view_log_btn, "logs")):
            icon = QIcon()
            icon.addPixmap(nav_pixmap(kind, pal["accent_text"], 14), QIcon.Mode.Normal)
            icon.addPixmap(nav_pixmap(kind, pal["muted"], 14), QIcon.Mode.Disabled)
            button.setIcon(icon)
        self.state_icon.COLORS = run_skin.state_colors(name)
        self.state_icon.update()
        self._backdrop.update()
        self.table.viewport().update()
        self._show_details(self._selected())

    # ------------------------------------------------------------ arrangement
    def _arrange_status(self) -> None:
        g = self.status_grid
        if self._skin:       # state | divider | times | progress
            divider = QFrame()
            divider.setObjectName("statusDivider")
            divider.setFixedWidth(1)
            g.addWidget(self.state_icon, 0, 0)
            g.addWidget(self.state_box, 0, 1)
            g.addWidget(divider, 0, 2)
            g.addWidget(self.times_box, 0, 3)
            g.addWidget(self.prog_box, 0, 4)
            for col, stretch in ((1, 3), (3, 2), (4, 3)):
                g.setColumnStretch(col, stretch)
            return
        g.addWidget(self.state_icon, 0, 0)
        g.addWidget(self.state_box, 0, 1)
        g.addWidget(self.times_box, 0, 2)
        g.addWidget(self.prog_box, 0, 3)
        for col, stretch in ((1, 3), (2, 2), (3, 3)):
            g.setColumnStretch(col, stretch)

    def _arrange_top(self) -> None:
        g = self.top_grid
        for col, (card, stretch) in enumerate(zip(self.top_cards, (3, 4, 4))):
            g.addWidget(card, 0, col)
            g.setColumnStretch(col, stretch)

    # ------------------------------------------------------------ database / Oracle Home
    def refresh_databases(self) -> None:
        entries = [(e.name, e.id) for e in self.ctx.databases.entries()]
        if entries and entries == [(self.db_combo.itemText(i), self.db_combo.itemData(i)) for i in range(self.db_combo.count())]:
            self._refresh_home()
            self._update_enabled()
            return  # unchanged: avoids a needless relayout every time the page is shown
        keep = self.db_combo.currentData()
        wanted = self.ctx.settings.get("default_db")
        self.db_combo.blockSignals(True)
        self.db_combo.clear()
        for e in self.ctx.databases.entries():
            self.db_combo.addItem(e.name, e.id)
        index = self.db_combo.findData(keep) if keep is not None else -1
        if index < 0 and wanted:
            index = self.db_combo.findText(wanted)
        self.db_combo.setCurrentIndex(max(0, index))
        self.db_combo.blockSignals(False)
        self._refresh_home()
        self._update_enabled()

    def _refresh_home(self) -> None:
        text = "-"
        entry = self.ctx.databases.get(self.db_combo.currentData())
        if entry is not None:
            try:
                env = environment.load_environment(self.ctx.environment_path)
                path, source = oh.resolve_oracle_home(entry.oracle_home, env["ORACLE_HOME"])
                text = path if source != "none" else "Not configured (set it in Settings)"
            except Exception:  # shown as 'not configured'; the real error is raised when a run starts
                text = "Not configured (set it in Settings)"
        self.home_label.setText(text)
        self.home_label.setToolTip(text)

    def _update_enabled(self) -> None:
        has_db = self.db_combo.count() > 0
        self.db_combo.setEnabled(not self.gate.busy)
        self.run_btn.setEnabled(has_db and not self.gate.busy)
        self.cancel_btn.setEnabled(self._thread is not None and not self._cancelling)
        if not has_db and not self.gate.busy:
            self._set_status("muted", "No databases configured. Add one in Settings.")
        files = self._result is not None
        self.open_file_btn.setEnabled(files and Path(self._result.report_file).is_file())
        self.open_dir_btn.setEnabled(files and Path(self._result.report_file).parent.is_dir())
        self.view_log_btn.setEnabled(files and Path(self._result.log_file).is_file())

    def showEvent(self, event) -> None:
        super().showEvent(event)
        if not self.gate.busy:
            self.refresh_databases()

    def _set_status(self, level: str, text: str) -> None:
        _restyle(self.status, level if level in ("ok", "warn", "bad") else "muted")
        self.status.setText(text)
        if self._skin:       # a longer message needs a taller status card: tell the layout (a text change alone does not re-measure it)
            for widget in (self.status, self.state_box, self.state_icon.parentWidget()):
                widget.updateGeometry()

    # ------------------------------------------------------------ table
    def _load_plan(self, plan=None) -> None:
        """Rows for the checks this option records (all 'Not Run')."""
        plan = plan or [(i, engine.NAMES[i]) for i in engine.plan(self.mode)]
        self._data = {i: {"status": "PENDING", "message": "", "seconds": None, "output": "", "when": None} for i, _ in plan}
        self._row = {}
        self._total = len(plan)
        self.table.setRowCount(0)
        self.table.setRowCount(len(plan))
        for row, (idx, name) in enumerate(plan):
            self._row[idx] = row
            for col, text in enumerate((str(row + 1), name, "", "-", "-")):  # first column: position in this run (1..N); the real check ID stays in the row data / details
                item = QTableWidgetItem(text)
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                self.table.setItem(row, col, item)
            self.table.item(row, 0).setData(Qt.ItemDataRole.UserRole + 1, idx)
            self.table.item(row, 0).setToolTip(f"Check ID {idx + 1}")
            self.table.item(row, 1).setToolTip(name)
            self.table.item(row, 2).setData(STATUS_ROLE, "PENDING")
        self.results_title.setText(f"Check Results ({self._total} checks)")
        self.progress.setRange(0, max(1, self._total))
        self.progress.setValue(0)
        self.percent_label.setText("0%")
        self.count_label.setText(f"0 of {self._total} checks completed")
        self._show_details(None)
        self.view_changed.emit()

    def _set_row(self, idx: int, status: str, message=None, seconds=None, output=None) -> None:
        d = self._data.get(idx)
        row = self._row.get(idx)
        if d is None or row is None:
            return
        d["status"] = status
        if message is not None:
            d["message"] = message
        if seconds is not None:
            d["seconds"] = seconds
        if output is not None:
            d["output"] = output
        if status not in ("PENDING", "RUNNING") and d.get("when") is None:
            d["when"] = datetime.now()   # completion time, shown by the Dashboard
        self.table.item(row, 2).setData(STATUS_ROLE, status)
        self.table.item(row, 3).setText(d["message"] or "-")
        self.table.item(row, 3).setToolTip(d["message"])
        self.table.item(row, 4).setText(fmt_seconds(d["seconds"]) if d["seconds"] is not None else "-")
        self.table.viewport().update()
        if self._selected() == idx:
            self._show_details(idx)
        self.view_changed.emit()

    def _selected(self):
        rows = self.table.selectionModel().selectedRows() if self.table.selectionModel() else []
        return self.table.item(rows[0].row(), 0).data(Qt.ItemDataRole.UserRole + 1) if rows else None

    def _selection_changed(self) -> None:
        self._show_details(self._selected())

    def _show_details(self, idx) -> None:
        d = self._data.get(idx) if idx is not None else None
        if d is None:
            for lab in self.det.values():
                lab.setText("-")
                lab.setStyleSheet("")
                lab.setMaximumWidth(16777215)
                lab.setMinimumWidth(0)
            self.out_view.setPlainText("")
            self.sql_view.setPlainText("")
            return
        fill, ink, text = BADGES[d["status"]]
        if self._skin:
            fill, ink = run_skin.pill(self._theme_name(), d["status"])
        self.det["id"].setText(str(idx + 1))
        self.det["name"].setText(engine.NAMES[idx])
        self.det["status"].setText(text)
        self.det["status"].setFixedWidth(self.det["status"].fontMetrics().horizontalAdvance(text) + 20)
        self.det["status"].setStyleSheet(f"background:{fill}; color:{ink}; border-radius:4px; font-weight:600; padding:1px 4px; qproperty-alignment: AlignCenter;")
        self.det["time"].setText(fmt_seconds(d["seconds"]) if d["seconds"] is not None else "-")
        files = engine.sql_files(idx)
        self.det["sql"].setText((", ".join(files) if len(files) <= 2 else f"{files[0]} +{len(files) - 1} more") if files else "- (DGMGRL / PowerShell)")
        self.det["sql"].setToolTip("\n".join(files))
        self.out_view.setPlainText(d["output"] or {"PENDING": "This check has not run yet.", "RUNNING": "Running ..."}.get(d["status"], "No output."))
        self.sql_view.setPlainText(self._sql_text(files))

    @staticmethod
    def _sql_text(files: list) -> str:
        if not files:
            return NO_SQL
        parts = []
        for name in files:
            try:
                parts.append(f"-- ===== {name} =====\n" + sql_access.get_sql(name).decode("utf-8", errors="replace"))
            except Exception as exc:  # integrity failure or missing script: shown, never hidden
                parts.append(f"-- ===== {name} =====\n-- cannot be shown: {exc}")
        return "\n".join(parts)

    # ------------------------------------------------------------ run
    def start(self) -> None:
        if self.gate.busy:
            return
        entry = self.ctx.databases.get(self.db_combo.currentData())
        if entry is None:
            self._set_status("warn", "Select a database first.")
            return
        text, level = outcomes.fake_status()
        if level == "bad":
            self._set_status("bad", text)
            return
        fake, name, ctx, option = level == "warn", entry.name, self.ctx, self.option
        self._result = None
        self._token = token = CancelToken()
        self._cancelling = False
        self.run_db, self.run_started, self.run_fake = name, datetime.now(), fake
        self._load_plan()
        self.start_val.setText(fmt_when(self.run_started))
        self.end_val.setText("-")
        self.elapsed_val.setText("00:00:00")
        self.state_icon.set_state("running")
        _restyle(self.state_label, "stateTitle")
        self.state_label.setText("Running")
        self._set_status("muted", f"Running on {name} ..." + (" (simulated)" if fake else ""))
        self._started = time.monotonic()
        self._timer.start()

        def job(emit):
            return outcomes.for_run(launcher.run_option(ctx, name, option, emit, cancel=token, on_event=thread.event.emit), fake)

        thread = JobThread(job, fake, self)
        thread.event.connect(self._on_event)
        thread.done.connect(self._done)
        thread.finished.connect(self._finished)
        self._thread = thread
        self.gate.begin()
        thread.start()
        self._update_enabled()
        self.view_changed.emit()

    def cancel(self) -> None:
        """Cancel button: ask the run to stop. The worker thread ends the run itself and reports CANCELLED."""
        if self._thread is None or self._token is None or self._cancelling:
            return
        self._cancelling = True
        self.cancel_btn.setEnabled(False)
        self.state_label.setText("Cancelling")
        self._set_status("warn", "Cancelling - waiting for the running check to stop ...")
        self._token.request()

    def _on_event(self, ev) -> None:
        kind = ev[0]
        if kind == "plan":
            self._load_plan(ev[1])
        elif kind == "start":
            self._set_row(ev[1], "RUNNING", "Running ...")
            row = self._row.get(ev[1])
            if row is not None:
                self.table.scrollToItem(self.table.item(row, 1))
        elif kind == "done":
            r = ev[1]
            self._set_row(r.idx, r.status if r.status in BADGES else "INFO", r.message, r.seconds, r.output)
            self._progress()

    def _progress(self) -> None:
        done = sum(1 for d in self._data.values() if d["status"] not in ("PENDING", "RUNNING"))
        cancelled = 0
        if self.option == "1":       # a cancelled check did not complete (option 1 only: options 2 and 3 keep counting it, as before): it is reported next to the count, not inside it
            cancelled = sum(1 for d in self._data.values() if d["status"] == "CANCELLED")
            done -= cancelled
        self.progress.setValue(done)
        self.percent_label.setText(f"{round(100 * done / max(1, self._total))}%")
        self.count_label.setText(f"{done} of {self._total} checks completed" + (f" \u00B7 {cancelled} cancelled" if cancelled else ""))

    def _tick(self) -> None:
        self.elapsed_val.setText(fmt_elapsed(time.monotonic() - self._started))

    def _done(self, outcome) -> None:
        self._timer.stop()
        self._tick()
        self.end_val.setText(fmt_when(datetime.now()))
        self._result = outcome.result
        if outcome.result is not None:  # make sure every recorded check is shown even if an event was missed
            for r in outcome.result.results:
                if self._data.get(r.idx, {}).get("status") in ("PENDING", "RUNNING"):
                    self._set_row(r.idx, r.status if r.status in BADGES else "INFO", r.message, r.seconds, r.output)
        for idx, d in self._data.items():
            if d["status"] == "RUNNING":  # the check that was in progress when the run stopped
                self._set_row(idx, "CANCELLED" if outcome.cancelled else "PENDING", "Cancelled" if outcome.cancelled else "-")
        self._progress()
        self.state_icon.set_state("cancelled" if outcome.cancelled else {"ok": "ok", "warn": "warn"}.get(outcome.level, "bad"))
        error = outcome.exit_code == 3
        self.state_label.setText("Cancelled" if outcome.cancelled else "Failed" if error else "Completed")
        _restyle(self.state_label, "stateTitle")
        self._set_status(outcome.level, outcome.text() + (f"\n{outcome.detail}" if outcome.detail else ""))
        self._show_details(self._selected())
        self._update_enabled()
        self.view_changed.emit()

    def _finished(self) -> None:
        thread, self._thread = self._thread, None
        self._token, self._cancelling = None, False
        if thread is not None:
            thread.deleteLater()
        self.view_changed.emit()
        self.gate.end()

    # ------------------------------------------------------------ files
    def open_output_file(self) -> None:
        if self._result is not None:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self._result.report_file)))

    def open_report_folder(self) -> None:
        if self._result is not None:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(self._result.report_file).parent)))

    def view_full_log(self) -> None:
        if self._result is not None:
            LogDialog(Path(self._result.log_file), self).exec()
