"""ADDM Report tab of Database Reports (a panel inside DatabaseReportsPage; shell, database selector and tabs belong to that page).

The snapshot-range UI is the AWR one: the selection/hover/mark methods of DatabaseReportsPage are reused as they are (they only need
the widgets and state attributes this panel defines with the same names), so both tabs behave identically. Loading snapshots is
ohc.awr_service.load_snapshots; the report is ohc.addm_service.generate_report; history is ohc.addm.scan_history.
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QEvent, Qt
from PySide6.QtGui import QBrush, QColor
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QFrame, QHBoxLayout, QLineEdit, QPlainTextEdit, QPushButton,
                               QRadioButton, QSpinBox, QTableWidgetItem, QVBoxLayout, QWidget)

from ohc import addm, addm_service, awr, awr_service
from ohc.checks.cancel import CancelToken
from ohc.gui import outcomes
from ohc.gui.awr_page import (ALL_DATES, AMBER, KEY_FOCUS, SNAP_ROW_H, TIME_FORMATS, BackgroundDelegate, DatabaseReportsPage, FittedTable,
                              _card, _label)
from ohc.gui.report_index import format_size
from ohc.gui.runner import JobThread
from ohc.gui.theme import PALETTES
from ohc.gui.widgets import FitTable, WrapLabel

HIST_ROW_H = 30
_P = DatabaseReportsPage


class AddmPanel(QWidget):
    # ---- shared with the AWR tab (same widgets/attributes, same behaviour)
    _set_target, _show_target, _paint_caption = _P._set_target, _P._show_target, _P._paint_caption
    _cell_clicked, _set_hover, _paint_hover, _hover_from_cursor, _sid_at = _P._cell_clicked, _P._set_hover, _P._paint_hover, _P._hover_from_cursor, _P._sid_at
    _pick, _sync_marks, _fill_snapshots, _when, _time_items, _check = _P._pick, _P._sync_marks, _P._fill_snapshots, _P._when, _P._time_items, _P._check
    _cell = _P.__dict__["_cell"]
    reveal, _actions, _exists, open_path, open_folder, copy_path = _P.reveal, _P._actions, _P._exists, _P.open_path, _P.open_folder, _P.copy_path

    def __init__(self, ctx, gate, db_name_fn, page=None):
        super().__init__(page)
        self.ctx, self.gate, self._db_name, self._page = ctx, gate, db_name_fn, page
        self._snaps: list = []
        self._loaded, self._loaded_days = False, 7
        self._cells: dict = {}
        self._marks = (None, None)
        self._hover = None
        self._target = "begin"
        self._time_fmt = TIME_FORMATS[0]
        self._thread = self._token = None
        self._job = ""
        self._cancelling = False
        self._name_custom, self._name_err, self._name_flag = False, "", False
        self._level = "muted"
        self.entries: list = []
        self.last_scan = awr.HistoryScan()
        self._build()
        self.reset_selection(initial=True)
        self.refresh_history()
        gate.changed.connect(lambda _b: self._update_enabled())

    # ------------------------------------------------------------------ construction
    def _build(self) -> None:
        # ---- snapshot panel (same as AWR)
        self.days = QSpinBox()
        self.days.setRange(awr.DAYS_MIN, awr.DAYS_MAX)
        self.days.setValue(7)
        self.days.setKeyboardTracking(False)
        self.days.setFixedWidth(76)
        self.load_btn = QPushButton("Load Snapshots")
        self.caption = _label("")
        days_row = QHBoxLayout()
        days_row.setSpacing(6)
        days_row.addWidget(_label("Days back:"))
        days_row.addWidget(self.days)
        days_row.addWidget(self.load_btn)
        days_row.addStretch(1)
        days_row.addWidget(self.caption)

        self.table = FittedTable(0, 6, fixed={0: 90, 2: 90, 4: 66, 5: 72}, flex={1: 1, 3: 1}, flex_min=60)
        self.table.setHorizontalHeaderLabels(["Snap ID", "Time", "Snap ID", "Time", "Instance", "Duration"])
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(SNAP_ROW_H)
        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.table.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.table.setShowGrid(False)
        self.table.setWordWrap(False)
        self.table.horizontalHeader().setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.table.setMinimumHeight(SNAP_ROW_H * 5 + 2)
        self.table.hint_height = 28 + SNAP_ROW_H * 6
        self.table.fitted.connect(self._refit_times)
        self.table.setMouseTracking(True)
        for col in (1, 3):
            self.table.setItemDelegateForColumn(col, BackgroundDelegate(self.table))
        self._table_vp = self.table.viewport()
        self._table_vp.setMouseTracking(True)
        self._table_vp.installEventFilter(self)
        self.table.cellClicked.connect(self._cell_clicked)

        self.begin_edit, self.end_edit = QLineEdit(), QLineEdit()
        self.begin_edit.setObjectName("awrBegin")
        self.end_edit.setObjectName("awrEnd")
        for edit in (self.begin_edit, self.end_edit):
            edit.setPlaceholderText("Snap ID")
            edit.setMaxLength(18)
            edit.installEventFilter(self)
            edit.textChanged.connect(lambda _t: self._range_changed())
        fields = QHBoxLayout()
        fields.setSpacing(6)
        fields.addWidget(_label("Begin Snap ID:"))
        fields.addWidget(self.begin_edit, 1)
        fields.addSpacing(10)
        fields.addWidget(_label("End Snap ID:"))
        fields.addWidget(self.end_edit, 1)
        self.range_msg = WrapLabel("")
        self.range_msg.setObjectName("muted")
        snap_panel, sbox = _card()
        sbox.setContentsMargins(8, 6, 8, 6)
        sbox.setSpacing(4)
        sbox.addWidget(_label("Select Snapshot Range", "strong"))
        sbox.addLayout(days_row)
        sbox.addWidget(self.table, 1)
        sbox.addLayout(fields)
        sbox.addWidget(self.range_msg)

        # ---- options
        self.name_edit = QLineEdit(addm.default_name())
        self.name_edit.setObjectName("awrName")
        self.name_edit.setMaxLength(awr.NAME_MAX + len(awr.NAME_TOKEN))
        self.name_edit.setToolTip("File name without extension: letters, digits, _ and - only.\n"
                                  f"{awr.NAME_TOKEN} is replaced by the generation time. An existing file is never overwritten.")
        self.ext_label = _label(".txt")                        # ADDM reports are text only
        self.rac_check = QCheckBox("Include RAC Information (if applicable)")
        self.rac_check.setToolTip("Analyses all instances (DBMS_ADDM.ANALYZE_DB). Unchecked: the connected instance only (ANALYZE_INST).")
        self.open_check = QCheckBox("Open report after generation")
        self.generate_btn = QPushButton("\u25B6  Generate ADDM Report")
        self.generate_btn.setObjectName("primary")
        self.cancel_btn = QPushButton("\u25A0  Cancel")
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.setToolTip("Stop safely: the running SQL*Plus process is ended and any incomplete report file is removed.")
        self.status = QPlainTextEdit()
        self.status.setObjectName("awrStatus")
        self.status.setReadOnly(True)
        self.status.setFixedHeight(54)
        self.status.setFrameShape(QFrame.Shape.NoFrame)
        self.status.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        opt_panel, obox = _card()
        obox.setContentsMargins(8, 6, 8, 6)
        obox.setSpacing(3)
        opt_panel.setMinimumWidth(250)
        obox.addWidget(_label("Options", "strong"))
        name_head = QHBoxLayout()
        name_head.addWidget(_label("Report Name"))
        name_head.addStretch(1)
        name_head.addWidget(self.ext_label)
        obox.addLayout(name_head)
        obox.addWidget(self.name_edit)
        obox.addWidget(self.rac_check)
        obox.addWidget(self.open_check)
        obox.addStretch(1)
        obox.addWidget(self.generate_btn)
        obox.addWidget(self.cancel_btn)
        obox.addWidget(self.status)

        body = QHBoxLayout()
        body.setSpacing(10)
        body.addWidget(snap_panel, 7)
        body.addWidget(opt_panel, 3)
        params, pbox = _card()
        pbox.setSpacing(4)
        title = QHBoxLayout()
        title.addWidget(_label("ADDM Report Parameters", "section"))
        title.addWidget(_label("Select an AWR snapshot range to generate ADDM findings."))
        title.addStretch(1)
        pbox.addLayout(title)
        pbox.addLayout(body, 1)

        # ---- history (same shape as AWR)
        self.refresh_btn = QPushButton("\u27F3  Refresh")
        self.date_combo = QComboBox()
        self.date_combo.addItem(ALL_DATES, "")
        self.date_combo.setMinimumWidth(130)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search reports...")
        self.search.setClearButtonEnabled(True)
        self.search.setMaximumWidth(320)
        htitles = QVBoxLayout()
        htitles.setSpacing(0)
        htitles.addWidget(_label("Generated ADDM Reports", "section"))
        htitles.addWidget(_label("Browse and open generated ADDM reports."))
        hhead = QHBoxLayout()
        hhead.addLayout(htitles, 1)
        hhead.addWidget(self.refresh_btn, 0, Qt.AlignmentFlag.AlignTop)
        filters = QHBoxLayout()
        filters.setSpacing(6)
        filters.addWidget(_label("Filter by date:"))
        filters.addWidget(self.date_combo)
        filters.addSpacing(8)
        filters.addWidget(self.search, 1)
        filters.addStretch(1)
        self.hist_note = WrapLabel("")
        self.hist_note.setObjectName("muted")
        self.hist = FittedTable(0, 6, fixed={0: 128, 1: 76, 2: 124, 4: 74, 5: 156}, flex={3: 1}, flex_min=100)
        self.hist.setHorizontalHeaderLabels(["Date & Time", "DB", "Snapshot Range", "File Name", "Size", "Actions"])
        self.hist.verticalHeader().setVisible(False)
        self.hist.verticalHeader().setDefaultSectionSize(HIST_ROW_H)
        self.hist.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.hist.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.hist.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.hist.setShowGrid(False)
        self.hist.setWordWrap(False)
        self.hist.setTextElideMode(Qt.TextElideMode.ElideMiddle)
        self.hist.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.hist.horizontalHeader().setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.hist.setMinimumHeight(HIST_ROW_H * 3 + 28)
        self.hist.hint_height = 28 + HIST_ROW_H * 5
        self.hist.fitted.connect(self._refit_history)
        history, hbox = _card()
        hbox.setSpacing(4)
        hbox.addLayout(hhead)
        hbox.addLayout(filters)
        hbox.addWidget(self.hist_note)
        hbox.addWidget(self.hist, 1)

        box = QVBoxLayout(self)
        box.setContentsMargins(0, 0, 0, 0)
        box.setSpacing(6)
        box.addWidget(params, 1)
        box.addWidget(history, 1)
        self.outer_cards = (params, history)       # the two cards the page's wave backdrop puts shadows under

        self.load_btn.clicked.connect(self.load_snapshots)
        self.generate_btn.clicked.connect(self.generate)
        self.cancel_btn.clicked.connect(self.cancel)
        self.refresh_btn.clicked.connect(self.refresh_history)
        self.name_edit.textEdited.connect(self._name_edited)
        self.name_edit.textChanged.connect(lambda _t: self._validate_name())
        self.date_combo.currentIndexChanged.connect(lambda _i: self._fill_history())
        self.search.textChanged.connect(lambda _t: self._fill_history())

    # ------------------------------------------------------------------ state
    @staticmethod
    def _fmt() -> str:
        return addm_service.FMT                  # ADDM is text only

    def _busy(self) -> bool:
        return self._thread is not None

    def _update_enabled(self) -> None:
        idle = not self.gate.busy
        has_db = bool(self._db_name())
        self.days.setEnabled(has_db and idle)
        self.load_btn.setEnabled(has_db and idle)
        for w in (self.begin_edit, self.end_edit, self.table):
            w.setEnabled(self._loaded and idle)
        for w in (self.open_check, self.name_edit, self.rac_check):
            w.setEnabled(idle)
        self.generate_btn.setEnabled(has_db and idle and self._loaded and self._check().ok and not self._name_err)
        self.cancel_btn.setEnabled(self._busy() and not self._cancelling)

    def _set_status(self, level: str, text: str, detail: str = "") -> None:
        self._level = level if level in ("ok", "warn", "bad") else "muted"
        full = text + (("\n" + detail) if detail else "")
        self.status.setPlainText(full)
        self.status.setToolTip(full)
        self.repaint_status()

    def repaint_status(self) -> None:
        pal = getattr(self._page, "_pal", None) or PALETTES["dark"]
        self.status.setStyleSheet(f"QPlainTextEdit#awrStatus {{ color: {pal.get(self._level, pal['muted'])}; }}")

    def reset_selection(self, initial: bool = False) -> None:
        """Forget loaded snapshots and the selection (database change, failure, empty result, cancellation)."""
        self._snaps, self._loaded, self._cells, self._marks, self._hover = [], False, {}, (None, None), None
        self.table.setRowCount(0)
        for edit in (self.begin_edit, self.end_edit):
            edit.blockSignals(True)
            edit.clear()
            edit.blockSignals(False)
        self._target = "begin"
        self._name_custom = False
        self._show_target()
        self._range_changed()
        if not self._busy():
            name = self._db_name()
            if not name:
                self._set_status("muted", "No databases configured. Add one in Settings.")
            elif initial:
                self._set_status("muted", "Click \"Load Snapshots\" to list the AWR snapshots. Nothing is queried until you do.")
            else:
                self._set_status("muted", f"Click \"Load Snapshots\" to list the snapshots of {name}.")
        self._update_enabled()

    def _range_changed(self) -> None:
        check = self._check()
        if not self._loaded:
            self.range_msg.setText("")
        else:
            self.range_msg.setText(check.message)
            self.range_msg.setObjectName(check.level)
            self.range_msg.style().unpolish(self.range_msg)
            self.range_msg.style().polish(self.range_msg)
        if not self._name_custom:
            self.name_edit.setText(addm.default_name(check.begin, check.end) if check.ok else addm.default_name())
            self.name_edit.setCursorPosition(0)
        self._sync_marks()
        self._update_enabled()

    def _name_edited(self, _text) -> None:
        self._name_custom = True              # from now on the ids no longer rewrite the name, and the typed name is validated
        self._validate_name()

    def _validate_name(self) -> None:
        try:
            folder = awr_service.report_folder(self.ctx)
        except Exception:
            folder = None
        # an automatic name (not typed by the user) is only a preview: the service builds the real one from the ids and the time
        self._name_err = awr.check_report_name(self.name_edit.text(), self._fmt(), folder) if self._name_custom else ""
        self.name_edit.setProperty("invalid", "true" if self._name_err else "false")
        self.name_edit.style().unpolish(self.name_edit)
        self.name_edit.style().polish(self.name_edit)
        if self._name_err and not self._busy():
            self._name_flag = True
            self._set_status("warn", "Report Name: " + self._name_err)
        elif self._name_flag and not self._busy():
            self._name_flag = False
            self._set_status("muted", "Report Name is valid.")
        self._update_enabled()

    def eventFilter(self, obj, event):
        if obj is self._table_vp:                              # hover over a snapshot's time cell
            kind = event.type()
            if kind == QEvent.Type.MouseMove:
                idx = self.table.indexAt(event.position().toPoint())
                sid = self._sid_at(idx.row(), idx.column()) if idx.isValid() else None
                self._table_vp.setCursor(Qt.CursorShape.PointingHandCursor if sid is not None else Qt.CursorShape.ArrowCursor)
                self._set_hover(sid)
            elif kind == QEvent.Type.Leave:
                self._hover_from_cursor()
        elif isinstance(obj, QRadioButton):                    # hover over a snapshot's Snap ID
            if event.type() in (QEvent.Type.Enter, QEvent.Type.MouseMove):
                self._set_hover(int(obj.text()))
            elif event.type() == QEvent.Type.Leave:
                self._hover_from_cursor()
        if obj in (self.begin_edit, self.end_edit) and obj.isEnabled():
            kind = event.type()
            if kind == QEvent.Type.MouseButtonPress or (kind == QEvent.Type.FocusIn and event.reason() in KEY_FOCUS):
                self._set_target("begin" if obj is self.begin_edit else "end")
        return super().eventFilter(obj, event)

    # ------------------------------------------------------------------ jobs
    def _start(self, kind: str, job) -> None:
        self._token, self._cancelling, self._job = CancelToken(), False, kind
        fake = outcomes.fake_status()[1] == "warn"
        token = self._token
        thread = JobThread(lambda emit: job(token), fake, self)
        thread.done.connect(self._done)
        thread.finished.connect(self._finished)
        self._thread = thread
        self.gate.begin()
        thread.start()
        self._update_enabled()

    def load_snapshots(self) -> None:
        if self.gate.busy or self._busy():
            return
        name = self._db_name()
        if not name:
            self._set_status("warn", "Select a database first.")
            return
        try:
            days = awr.validate_days(self.days.value())
        except awr.AwrError as exc:
            self._set_status("bad", str(exc))
            return
        text, level = outcomes.fake_status()
        if level == "bad":
            self._set_status("bad", text)
            return
        self.reset_selection()
        self._loaded_days = days
        self._set_status("muted", f"Loading snapshots from {name} ..." + (" (simulated)" if level == "warn" else ""))
        ctx = self.ctx
        self._start("load", lambda token: awr_service.load_snapshots(ctx, name, days, token))

    def generate(self) -> None:
        if self.gate.busy or self._busy():
            return
        check, name = self._check(), self._db_name()
        if not (name and self._loaded and check.ok) or self._name_err:
            self._set_status("warn", self._name_err and ("Report Name: " + self._name_err) or check.message or "Load snapshots and choose a valid range first.")
            return
        text, level = outcomes.fake_status()
        if level == "bad":
            self._set_status("bad", text)
            return
        b, e, ctx = check.begin, check.end, self.ctx
        rname, rac = self.name_edit.text(), self.rac_check.isChecked()
        self._name_flag = False
        self._set_status("muted", f"Running ADDM and generating the text report{' (RAC, all instances)' if rac else ''} for snapshots "
                         f"{b} to {e} on {name} ... this can take a few minutes." + (" (simulated)" if level == "warn" else ""))
        self._start("generate", lambda token: addm_service.generate_report(ctx, name, b, e, token, rname, rac))

    def cancel(self) -> None:
        if self._thread is None or self._token is None or self._cancelling:
            return
        self._cancelling = True
        self.cancel_btn.setEnabled(False)
        self._set_status("warn", "Cancelling - waiting for SQL*Plus to stop ...")
        self._token.request()

    def _done(self, r) -> None:
        kind = self._job
        if not isinstance(r, awr_service.AwrResult):           # JobThread's safety net for an unexpected exception
            if kind == "load":
                self.reset_selection()
            self._set_status("bad", getattr(r, "headline", "Unexpected error"), getattr(r, "detail", ""))
        elif kind == "load":
            self._load_done(r)
        elif r.cancelled:
            self._set_status("warn", r.message)
        elif not r.ok:
            self._set_status("bad", r.message, r.detail)
        else:
            self._set_status("warn" if r.note else "ok", r.message, r.note)
            self.reveal(r.path)
            if self.open_check.isChecked():
                self.open_path(r.path)

    def _load_done(self, r) -> None:
        if r.cancelled:
            self.reset_selection()
            self._set_status("warn", r.message)
        elif not r.ok:
            self.reset_selection()
            self._set_status("bad", r.message, r.detail)
        elif not r.snaps.snaps:
            self.reset_selection()
            self._set_status("warn", r.message)
        else:
            self._snaps, self._loaded = list(r.snaps.snaps), True
            self._fill_snapshots()
            self._show_target()
            self._range_changed()
            self._set_status("warn" if r.snaps.capped else "ok", r.message)

    def _finished(self) -> None:
        thread, self._thread = self._thread, None
        self._token, self._cancelling, self._job = None, False, ""
        if thread is not None:
            thread.deleteLater()
        self.gate.end()
        self._validate_name()
        self._update_enabled()

    # ------------------------------------------------------------------ tables
    def _refit_times(self) -> None:
        """Same fitting as the AWR table: ID columns from the radio width, times in the longest format that fits."""
        fm = self.table.fontMetrics()
        probe = QRadioButton("0" * 7)
        probe.setStyleSheet(self._page.styleSheet() if self._page is not None else "")
        id_w = probe.sizeHint().width() + 14
        head = lambda text: int(fm.horizontalAdvance(text) * 1.12) + 16
        self.table._fixed.update({0: id_w, 2: id_w, 4: head("Instance"), 5: max(head("Duration"), fm.horizontalAdvance("00h 00m") + 16)})
        FitTable.fit_columns(self.table)
        width = self.table.columnWidth(1)
        sample = datetime(2026, 9, 30, 23, 59, 59)
        fmt = next((f for f in TIME_FORMATS if fm.horizontalAdvance(sample.strftime(f).upper()) + 16 <= width), TIME_FORMATS[-1])
        if fmt != self._time_fmt:
            self._time_fmt = fmt
            for item, snap in self._time_items():
                item.setText(self._when(snap))

    def _refit_history(self) -> None:
        fm = self.hist.fontMetrics()
        probe = QPushButton("Open Report")
        probe.setObjectName("cellBtn")
        probe.setStyleSheet(self._page.styleSheet() if self._page is not None else "")
        text = lambda sample: fm.horizontalAdvance(sample) + 18
        db_w = max([text("PROD_DB_01")] + [text(e.db + (" [SIM]" if e.simulated else "")) for e in self.entries[:200]])
        self.hist._fixed.update({0: text("0000-00-00 00:00"), 1: min(db_w, 170), 2: text("000000 - 000000"), 4: text("000.0 MB"),
                                 5: probe.sizeHint().width() + 28 + 8 + 12})
        self.hist._flex_min = 100
        FitTable.fit_columns(self.hist)

    def refresh_history(self) -> None:
        self.last_scan = addm.scan_history(Path(self.ctx.root) / "reports", index_dir=awr.index_dir_for(self.ctx.root))
        self.entries = self.last_scan.entries
        keep = self.date_combo.currentData() or ""
        self.date_combo.blockSignals(True)
        self.date_combo.clear()
        self.date_combo.addItem(ALL_DATES, "")
        for d in awr.dates_of(self.entries):
            self.date_combo.addItem(d, d)
        self.date_combo.setCurrentIndex(max(0, self.date_combo.findData(keep)))
        self.date_combo.blockSignals(False)
        self._fill_history()

    def _fill_history(self) -> None:
        shown = awr.filter_entries(self.entries, self.date_combo.currentData() or "", self.search.text())
        self.hist.setUpdatesEnabled(False)
        self.hist.setRowCount(0)
        self.hist.setRowCount(len(shown))
        for row, e in enumerate(shown):
            texts = (e.when.strftime("%Y-%m-%d %H:%M"), e.db + (" [SIM]" if e.simulated else ""), e.range_text, e.name, format_size(e.size))
            for col, text in enumerate(texts):
                item = QTableWidgetItem(text)
                item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
                item.setToolTip(str(e.path) if col == 3 else ("Simulated report: no database was contacted." if e.simulated else text))
                self.hist.setItem(row, col, item)
            self.hist.item(row, 3).setData(Qt.ItemDataRole.UserRole, str(e.path))
            self.hist.setCellWidget(row, 5, self._actions(e.path))
        self.hist.setUpdatesEnabled(True)
        scan = self.last_scan
        if not scan.exists:
            note = "The reports folder does not exist yet - it is created when the first report is generated."
        elif not self.entries:
            note = "No ADDM reports have been generated yet."
        elif not shown:
            note = "No reports match the filter."
        else:
            note = ""
        self.hist_note.setText((note + " " + scan.note).strip())
        self.hist_note.setVisible(bool(self.hist_note.text()))

    def showEvent(self, event) -> None:
        super().showEvent(event)
        if not self._busy():
            self.refresh_history()
            self._validate_name()
            self._update_enabled()
