"""4. Database Reports: the AWR Report tab (ASH and ADDM are disabled placeholders until their workstreams).

Nothing touches the database until the user clicks Load Snapshots or Generate AWR Report; both run in a worker thread
(JobThread + CancelToken, like the health-check pages). The report is produced by the original AWR_Report.sql.
"""
from __future__ import annotations

import tempfile
from datetime import datetime
from functools import partial
from pathlib import Path
from string import Template

from PySide6.QtCore import QEvent, QPoint, QPointF, QRectF, QSize, Qt, QUrl, Signal
from PySide6.QtGui import QBrush, QColor, QCursor, QDesktopServices, QGuiApplication, QIcon, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QFrame, QHBoxLayout, QLabel, QLineEdit, QMenu,
                               QPlainTextEdit, QPushButton, QRadioButton, QSpinBox, QStyledItemDelegate, QTableWidgetItem, QTabBar, QToolButton,
                               QVBoxLayout, QWidget)

from ohc import awr, awr_service
from ohc.checks.cancel import CancelToken
from ohc.gui import outcomes
from ohc.gui.report_index import format_size
from ohc.gui.runner import JobThread
from ohc.gui.run_skin import PageBackdrop           # the approved wave + card shadows of the redesigned pages (reused, not changed)
from ohc.gui.theme import PALETTES, _arrow_files
from ohc.gui.widgets import FitTable, WrapLabel

BLUE, AMBER = "#2563EB", "#F59E0B"
ALL_DATES = "All dates"
TIME_FORMATS = ("%d-%b-%Y %H:%M:%S", "%d-%b-%y %H:%M:%S", "%d-%b %H:%M:%S", "%d-%b %H:%M")  # long -> short; the longest that fits is used
TIME_SAMPLE = "30-SEP-2026 23:59:59"
SNAP_ROW_H, HIST_ROW_H = 24, 30
KEY_FOCUS = (Qt.FocusReason.TabFocusReason, Qt.FocusReason.BacktabFocusReason, Qt.FocusReason.ShortcutFocusReason)

_QSS = Template("""
* { font-size: 12px; }
QLabel#pageTitle { font-size: 22px; font-weight: 600; }
QLabel#section { font-size: 15px; font-weight: 600; }
QLineEdit { padding: 3px 8px; }
QComboBox { padding: 3px 26px 3px 8px; }
QComboBox::drop-down { subcontrol-origin: padding; subcontrol-position: center right; width: 22px; border: none; }
QComboBox::down-arrow { image: url($down_arrow); width: 10px; height: 10px; }
QCheckBox { spacing: 8px; padding: 2px 0px; }
QCheckBox::indicator { width: 14px; height: 14px; border: 1px solid $muted; border-radius: 3px; background: $input_bg; }
QCheckBox::indicator:checked { background: $accent; border: 1px solid $accent; image: url($check_img); }
QCheckBox::indicator:disabled { border: 1px solid $border; }
QTimeEdit { background: $input_bg; color: $text; border: 1px solid $border; border-radius: 6px; padding: 2px 24px 2px 8px; }
QTimeEdit:focus { border: 1px solid $accent; }
QTimeEdit:disabled { color: $muted; }
QTimeEdit::up-button { subcontrol-origin: padding; subcontrol-position: top right; width: 22px; height: 12px; border: none; }
QTimeEdit::down-button { subcontrol-origin: padding; subcontrol-position: bottom right; width: 22px; height: 12px; border: none; }
QTimeEdit::up-arrow { image: url($up_arrow); width: 10px; height: 10px; }
QTimeEdit::down-arrow { image: url($down_arrow); width: 10px; height: 10px; }
QLineEdit#awrName[invalid="true"] { border: 1px solid #DC2626; }
QSpinBox { padding: 2px 24px 2px 8px; }
QPushButton { padding: 5px 12px; }
QPushButton#primary { padding: 9px 12px; font-weight: 600; }
QPushButton#cellBtn { padding: 2px 8px; }
QToolButton#cellMenu { background: $button_bg; border: 1px solid $border; border-radius: 6px; padding: 2px 4px; }
QToolButton#cellMenu::menu-indicator { image: none; }
QToolButton#cellMenu:hover { background: $button_hover; }
QTabBar#reportTabs::tab { background: $button_bg; color: $muted; padding: 7px 16px; margin-right: 6px; border: 1px solid $border;
    border-radius: 6px; border-bottom: 1px solid $border; }
QTabBar#reportTabs::tab:selected { background: $accent; color: #FFFFFF; border: 1px solid $accent; }
QTabBar#reportTabs::tab:disabled { color: $muted; }
QRadioButton { padding-left: 4px; spacing: 6px; }
QRadioButton[hover="true"][htarget="begin"] { background: rgba(37, 99, 235, 60); }
QRadioButton[hover="true"][htarget="end"] { background: rgba(245, 158, 11, 70); }
QRadioButton[mark="begin"] { background: rgba(37, 99, 235, 90); }
QRadioButton[mark="end"] { background: rgba(245, 158, 11, 100); }
QLineEdit#awrBegin { border: 1px solid $blue; padding: 3px 8px; }
QLineEdit#awrEnd { border: 1px solid $amber; padding: 3px 8px; }
QLineEdit#awrBegin[active="true"] { border: 2px solid $blue; padding: 2px 7px; background: rgba(37, 99, 235, 40); }
QLineEdit#awrEnd[active="true"] { border: 2px solid $amber; padding: 2px 7px; background: rgba(245, 158, 11, 45); }
QPlainTextEdit#awrStatus { background: transparent; border: none; padding: 0; }
QTableWidget::item { padding: 0px 6px; }
""")

# Redesign (5C): look only - same headings / cards as the redesigned run pages. No sizes, paddings or margins change.
_SKIN_QSS = Template("""
QLabel#pageTitle { font-weight: 700; }
QLabel#section { font-weight: 700; }
QLabel#strong { font-weight: 700; }
QLabel#liveTag { color: $ok; font-weight: 700; }
""")


def _check_file(theme: str) -> str:
    """White check mark for checked boxes (Qt style sheets need an image), drawn once into the temp folder."""
    path = Path(tempfile.gettempdir()) / f"ohc_{theme}_check.png"
    pm = QPixmap(20, 20)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setPen(QPen(QColor("#FFFFFF"), 2.4, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
    p.drawPolyline([QPointF(4.5, 10.5), QPointF(8.5, 14.5), QPointF(15.5, 5.5)])
    p.end()
    pm.save(str(path), "PNG")
    return path.as_posix()


def _label(text="", name="muted") -> QLabel:
    label = QLabel(text)
    label.setObjectName(name)
    return label


def refresh_pixmap(color: str, size: int = 16) -> QPixmap:
    """A circular-arrow line icon drawn with QPainter (no image file), in the line style of the sidebar icons."""
    scale = 3
    pm = QPixmap(size * scale, size * scale)
    pm.fill(Qt.GlobalColor.transparent)
    pm.setDevicePixelRatio(scale)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.scale(size / 24, size / 24)
    p.setPen(QPen(QColor(color), 2.0, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.drawArc(QRectF(4.5, 4.5, 15, 15), 40 * 16, 280 * 16)                     # an open circle ...
    p.drawPolyline([QPointF(19.5, 3.5), QPointF(19.6, 8.6), QPointF(14.6, 8.4)])   # ... with an arrow head at its upper-right end
    p.end()
    return pm


def _card() -> tuple:
    frame = QFrame()
    frame.setObjectName("card")
    box = QVBoxLayout(frame)
    box.setContentsMargins(10, 6, 10, 6)
    box.setSpacing(5)
    return frame, box


class BackgroundDelegate(QStyledItemDelegate):
    """The theme's QTableWidget::item rule hides item backgrounds; paint them (Begin/End/hover colours of the time cells)."""

    def paint(self, painter, option, index) -> None:
        brush = index.data(Qt.ItemDataRole.BackgroundRole)
        if brush is not None and brush.style() != Qt.BrushStyle.NoBrush:
            painter.fillRect(option.rect, brush)
        super().paint(painter, option, index)


class FittedTable(FitTable):
    """FitTable that tells the page when its columns were re-fitted (widths and the timestamp format depend on the font)."""
    fitted = Signal()
    hint_height = 260

    def sizeHint(self) -> QSize:
        return QSize(420, self.hint_height)   # constant (see FitTable.sizeHint); the page decides how many rows are comfortable

    def fit_columns(self) -> None:
        super().fit_columns()
        self.fitted.emit()


class DatabaseReportsPage(QWidget):
    def __init__(self, ctx, gate, theme=None, parent=None):
        super().__init__(parent)
        self.setObjectName("page")
        self.ctx, self.gate, self.theme = ctx, gate, theme
        self._snaps: list = []
        self._loaded, self._loaded_days, self._loaded_db = False, 7, ""
        self._target = "begin"
        self._thread = self._token = None
        self._job = ""            # "load" | "generate" | ""
        self._cancelling = False
        self._cells: dict = {}    # snap_id -> (radio, time item)
        self._hover = None        # snap_id under the mouse
        self._name_custom, self._name_err, self._name_flag = False, "", False
        self._marks = (None, None)
        self._time_fmt = TIME_FORMATS[0]
        self.entries: list = []
        self.last_scan = awr.HistoryScan()
        self._build()
        self._apply_style()
        if theme is not None:
            theme.changed.connect(lambda _n: self._apply_style())
        gate.changed.connect(lambda _busy: self._update_enabled())
        self.refresh_databases()
        self._reset_selection(initial=True)
        self.refresh_history()

    # ------------------------------------------------------------------ construction
    def _build(self) -> None:
        # header: title left, database selector right
        self.db_combo = QComboBox()
        self.db_combo.setMinimumWidth(200)
        self.db_combo.setMaximumWidth(280)
        self.sim_tag = _label("SIMULATED DATA", "warn")
        self.sim_tag.setToolTip("Fake Oracle mode (development): no database is contacted.")
        titles = QVBoxLayout()
        titles.setSpacing(0)
        titles.addWidget(_label("Database Reports", "pageTitle"))
        titles.addWidget(_label("Generate and view Oracle performance reports (AWR, ASH, ADDM)."))
        head = QHBoxLayout()
        head.addLayout(titles, 1)
        head.addWidget(self.sim_tag)
        self.live_tag = _label("\u25CF  Live Database", "liveTag")     # shown only while the app's own state says "real Oracle" (see _refresh_fake)
        self.live_tag.setToolTip("Not simulated: reports run against the selected database. It is only contacted when you load snapshots or generate a report.")
        self.live_tag.setVisible(False)
        head.addWidget(self.live_tag)
        head.addSpacing(8)
        head.addWidget(_label("Database:"))
        head.addWidget(self.db_combo)

        self.tabs = QTabBar()
        self.tabs.setObjectName("reportTabs")
        self.tabs.setDrawBase(False)
        self.tabs.setExpanding(False)
        for text in ("AWR Report", "ASH Report", "ADDM Report"):
            self.tabs.addTab(text)
        self.tabs.setParent(self)    # AWR / ASH / ADDM are chosen in the sidebar submenu; this tab bar stays, hidden, as the page's selector
        self.tabs.hide()             # (MainWindow drives it with tabs.setCurrentIndex and follows tabs.currentChanged)

        # ---- snapshot panel
        self.days = QSpinBox()
        self.days.setRange(awr.DAYS_MIN, awr.DAYS_MAX)
        self.days.setValue(7)
        self.days.setKeyboardTracking(False)
        self.days.setFixedWidth(76)
        self.load_btn = QPushButton("Load Snapshots")
        self.caption = QLabel("")
        days_row = QHBoxLayout()
        days_row.setSpacing(6)
        days_row.addWidget(_label("Days back:"))
        days_row.addWidget(self.days)
        days_row.addWidget(self.load_btn)
        days_row.addStretch(1)
        days_row.addWidget(self.caption)

        self.table = FittedTable(0, 6, fixed={0: 90, 2: 90, 4: 66, 5: 72}, flex={1: 1, 3: 1}, flex_min=60)
        self.table.setHorizontalHeaderLabels(["Snap ID", "Time", "Snap ID", "Time", "Instance", "Duration"])
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(SNAP_ROW_H)
        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.table.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.table.setShowGrid(False)
        self.table.setWordWrap(False)
        self.table.horizontalHeader().setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.table.setMinimumHeight(SNAP_ROW_H * 5 + 2)
        self.table.hint_height = 28 + SNAP_ROW_H * 6
        self.table.fitted.connect(self._refit_times)
        self.table.setMouseTracking(True)
        for col in (1, 3):
            self.table.setItemDelegateForColumn(col, BackgroundDelegate(self.table))
        self.table.viewport().setMouseTracking(True)
        self._table_vp = self.table.viewport()
        self._table_vp.installEventFilter(self)
        self.table.cellClicked.connect(self._cell_clicked)

        self.begin_edit, self.end_edit = QLineEdit(), QLineEdit()
        self.begin_edit.setObjectName("awrBegin")
        self.end_edit.setObjectName("awrEnd")
        for edit in (self.begin_edit, self.end_edit):
            edit.setPlaceholderText("Snap ID")
            edit.setMaxLength(18)
            edit.installEventFilter(self)
            edit.textChanged.connect(self._text_changed)
        fields = QHBoxLayout()
        fields.setSpacing(6)
        fields.addWidget(_label("Begin Snap ID:"))
        fields.addWidget(self.begin_edit, 1)
        fields.addSpacing(10)
        fields.addWidget(_label("End Snap ID:"))
        fields.addWidget(self.end_edit, 1)
        self.range_msg = WrapLabel("")
        self.range_msg.setObjectName("muted")

        snap_panel, sbox = _card()
        sbox.setContentsMargins(8, 6, 8, 6)
        sbox.setSpacing(4)
        sbox.addWidget(_label("Select Snapshot Range", "strong"))
        sbox.addLayout(days_row)
        sbox.addWidget(self.table, 1)
        sbox.addLayout(fields)
        sbox.addWidget(self.range_msg)

        # ---- options panel
        self.type_combo = QComboBox()
        self.type_combo.addItem("HTML", "html")
        self.type_combo.addItem("Text", "text")
        self.type_combo.setCurrentIndex(0)
        self.type_combo.setToolTip("HTML runs the original AWR_Report.sql.\nText uses a separate script (DBMS_WORKLOAD_REPOSITORY.AWR_REPORT_TEXT).")
        self.name_edit = QLineEdit(awr.default_name())
        self.name_edit.setObjectName("awrName")
        self.name_edit.setMaxLength(awr.NAME_MAX + len(awr.NAME_TOKEN))
        self.name_edit.setToolTip("File name without extension: letters, digits, _ and - only.\n"
                                  f"{awr.NAME_TOKEN} is replaced by the generation time. An existing file is never overwritten.")
        self.ext_label = _label(".html")
        self.rac_check = QCheckBox("Include RAC (if applicable)")
        self.rac_check.setToolTip("Reports all instances that have both snapshots (DBMS_WORKLOAD_REPOSITORY.AWR_GLOBAL_REPORT_*, Oracle 11.2+).\n"
                                  "Uses a separate script, not AWR_Report.sql. Unchecked: the connected instance only.")
        self.open_check = QCheckBox("Open report after generation")
        self.open_check.setChecked(False)
        self.generate_btn = QPushButton("\u25B6  Generate AWR Report")
        self.generate_btn.setObjectName("primary")
        self.cancel_btn = QPushButton("\u25A0  Cancel")
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.setToolTip("Stop safely: the running SQL*Plus process is ended and any incomplete report file is removed.")
        self.status = QPlainTextEdit()
        self.status.setObjectName("awrStatus")
        self.status.setReadOnly(True)
        self.status.setFixedHeight(54)
        self.status.setFrameShape(QFrame.Shape.NoFrame)
        self.status.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.status.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._status_level = "muted"

        opt_panel, obox = _card()
        obox.setContentsMargins(8, 6, 8, 6)
        obox.setSpacing(3)
        opt_panel.setMinimumWidth(250)
        obox.addWidget(_label("Options", "strong"))
        obox.addWidget(_label("Report Type"))
        obox.addWidget(self.type_combo)
        name_head = QHBoxLayout()
        name_head.addWidget(_label("Report Name"))
        name_head.addStretch(1)
        name_head.addWidget(self.ext_label)
        obox.addLayout(name_head)
        obox.addWidget(self.name_edit)
        obox.addWidget(self.rac_check)
        obox.addWidget(self.open_check)
        obox.addStretch(1)
        obox.addWidget(self.generate_btn)
        obox.addWidget(self.cancel_btn)
        obox.addWidget(self.status)

        body = QHBoxLayout()
        body.setSpacing(10)
        body.addWidget(snap_panel, 7)
        body.addWidget(opt_panel, 3)
        params, pbox = _card()
        self._opt_panel, self._params_card = opt_panel, params
        pbox.setSpacing(4)
        title_row = QHBoxLayout()
        title_row.addWidget(_label("AWR Report Parameters", "section"))
        title_row.addWidget(_label("Select snapshots and options to generate the AWR report."))
        title_row.addStretch(1)
        pbox.addLayout(title_row)
        pbox.addLayout(body, 1)

        # ---- history
        self.refresh_btn = QPushButton("\u27F3  Refresh")
        self.date_combo = QComboBox()
        self.date_combo.addItem(ALL_DATES, "")
        self.date_combo.setMinimumWidth(130)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search reports...")
        self.search.setClearButtonEnabled(True)
        self.search.setMaximumWidth(320)
        htitles = QVBoxLayout()
        htitles.setSpacing(0)
        htitles.addWidget(_label("Generated AWR Reports", "section"))
        htitles.addWidget(_label("Browse and open generated AWR reports."))
        hhead = QHBoxLayout()
        hhead.addLayout(htitles, 1)
        hhead.addWidget(self.refresh_btn, 0, Qt.AlignmentFlag.AlignTop)
        filters = QHBoxLayout()
        filters.setSpacing(6)
        filters.addWidget(_label("Filter by date:"))
        filters.addWidget(self.date_combo)
        filters.addSpacing(8)
        filters.addWidget(self.search, 1)
        filters.addStretch(1)
        self.hist_note = WrapLabel("")
        self.hist_note.setObjectName("muted")
        self.hist = FittedTable(0, 6, fixed={0: 128, 1: 76, 2: 124, 4: 74, 5: 156}, flex={3: 1}, flex_min=150)
        self.hist.setHorizontalHeaderLabels(["Date & Time", "DB", "Snapshot Range", "File Name", "Size", "Actions"])
        self.hist.verticalHeader().setVisible(False)
        self.hist.verticalHeader().setDefaultSectionSize(HIST_ROW_H)
        self.hist.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.hist.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.hist.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.hist.setShowGrid(False)
        self.hist.setWordWrap(False)
        self.hist.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.hist.setTextElideMode(Qt.TextElideMode.ElideMiddle)
        self.hist.horizontalHeader().setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.hist.setMinimumHeight(HIST_ROW_H * 3 + 28)
        self.hist.hint_height = 28 + HIST_ROW_H * 5
        self.hist.fitted.connect(self._refit_history)
        history, hbox = _card()
        hbox.setSpacing(4)
        hbox.addLayout(hhead)
        hbox.addLayout(filters)
        hbox.addWidget(self.hist_note)
        hbox.addWidget(self.hist, 1)

        box = QVBoxLayout(self)
        box.setContentsMargins(20, 2, 20, 8)
        box.setSpacing(6)
        box.addLayout(head)
        from ohc.gui.addm_page import AddmPanel    # local imports: these panels build on this module's widgets
        from ohc.gui.ash_page import AshPanel
        self.ash = AshPanel(self.ctx, self.gate, self._db_name, self)
        self.addm = AddmPanel(self.ctx, self.gate, self._db_name, self)
        self._awr_cards = (params, history)         # shown for the AWR tab; the ASH panel replaces them (hidden widgets take no space)
        box.addWidget(params, 1)
        box.addWidget(history, 1)
        self._history_card = history
        box.addWidget(self.ash, 1)
        box.addWidget(self.addm, 1)
        self.ash.setVisible(False)
        self.addm.setVisible(False)
        self._backdrop_cards = [params, history, *self.ash.outer_cards, *self.addm.outer_cards]
        self._backdrop = PageBackdrop(self, self._backdrop_cards, self._theme_name, self._cards_top)     # faint wave + soft card shadows behind the cards
        self.tabs.currentChanged.connect(self._tab_changed)

        self.load_btn.clicked.connect(self.load_snapshots)
        self.generate_btn.clicked.connect(self.generate)
        self.cancel_btn.clicked.connect(self.cancel)
        self.refresh_btn.clicked.connect(self.refresh_history)
        self.db_combo.currentIndexChanged.connect(self._database_changed)
        self.type_combo.currentIndexChanged.connect(self._format_changed)
        self.name_edit.textEdited.connect(self._name_edited)
        self.name_edit.textChanged.connect(lambda _t: self._validate_name())
        self.date_combo.currentIndexChanged.connect(lambda _i: self._fill_history())
        self.search.textChanged.connect(lambda _t: self._fill_history())

    def _theme_name(self) -> str:
        return self.theme.theme if self.theme is not None else "dark"

    def _cards_top(self) -> int:
        """y of the first visible card (the wave lives in the strip above it)."""
        tops = [c.mapTo(self, QPoint(0, 0)).y() for c in self._backdrop_cards if c.isVisible()]
        return min(tops) if tops else 64

    def _tab_changed(self, index: int) -> None:
        panels = {0: list(self._awr_cards), 1: [self.ash], 2: [self.addm]}
        if index not in panels:
            return
        # Hide the outgoing content BEFORE showing the incoming one. With two contents visible even for an instant the window's minimum
        # height is their sum (~1190 px); the main window grows to it and never shrinks back (clipped history, huge table).
        for other, widgets in panels.items():
            if other != index:
                for w in widgets:
                    w.setVisible(False)
        for w in panels[index]:
            w.setVisible(True)

    def _apply_style(self) -> None:
        pal = dict(PALETTES[self.theme.theme if self.theme is not None else "dark"])
        self._pal = pal
        theme = self.theme.theme if self.theme is not None else "dark"
        self.setStyleSheet(_QSS.substitute(pal, blue=BLUE, amber=AMBER, down_arrow=_arrow_files(theme, pal["text"])[1], up_arrow=_arrow_files(theme, pal["text"])[0], check_img=_check_file(theme))
                           + _SKIN_QSS.substitute(pal))
        icon = QIcon(refresh_pixmap(pal["text"]))
        self.load_btn.setIcon(icon)
        if hasattr(self, "addm"):
            self.addm.load_btn.setIcon(icon)
        self._paint_status()
        self._paint_caption()
        if hasattr(self, "ash"):
            self.ash.repaint_status()
            self.addm.repaint_status()
        self.ensurePolished()                     # size hints must use this page's font (12 px) even before the page is first shown
        for child in self.findChildren(QWidget):
            child.ensurePolished()

    # ------------------------------------------------------------------ databases
    def refresh_databases(self) -> None:
        entries = [(e.name, e.id) for e in self.ctx.databases.entries()]
        current = [(self.db_combo.itemText(i), self.db_combo.itemData(i)) for i in range(self.db_combo.count())]
        if entries and entries == current:
            return
        keep = self.db_combo.currentData()
        wanted = self.ctx.settings.get("default_db")
        self.db_combo.blockSignals(True)
        self.db_combo.clear()
        for name, ident in entries:
            self.db_combo.addItem(name, ident)
        index = self.db_combo.findData(keep) if keep is not None else -1
        if index < 0 and wanted:
            index = self.db_combo.findText(wanted)
        self.db_combo.setCurrentIndex(max(0, index))
        self.db_combo.blockSignals(False)
        if keep != self.db_combo.currentData():
            self._reset_selection()
            if hasattr(self, "addm"):
                self.addm.reset_selection()
        self._refresh_fake()

    def _database_changed(self, _index) -> None:
        self._reset_selection()
        self.addm.reset_selection()

    def _db_name(self) -> str:
        entry = self.ctx.databases.get(self.db_combo.currentData())
        return entry.name if entry is not None else ""

    # ------------------------------------------------------------------ state
    def _busy(self) -> bool:
        return self._thread is not None

    def _check(self) -> awr.RangeCheck:
        return awr.check_range(self.begin_edit.text(), self.end_edit.text(), self._snaps)

    def _update_enabled(self) -> None:
        idle = not self.gate.busy        # a job on any page (also this one) disables the conflicting controls
        has_db = self.db_combo.count() > 0
        self.db_combo.setEnabled(idle)
        self.days.setEnabled(has_db and idle)
        self.load_btn.setEnabled(has_db and idle)
        for w in (self.begin_edit, self.end_edit, self.table):
            w.setEnabled(self._loaded and idle)
        for w in (self.open_check, self.type_combo, self.name_edit, self.rac_check):
            w.setEnabled(idle)
        self.generate_btn.setEnabled(has_db and idle and self._loaded and self._check().ok and not self._name_err)
        self.cancel_btn.setEnabled(self._busy() and not self._cancelling)

    def _set_status(self, level: str, text: str, detail: str = "") -> None:
        self._status_level = level if level in ("ok", "warn", "bad") else "muted"
        full = text + (("\n" + detail) if detail else "")
        self.status.setPlainText(full)
        self.status.setToolTip(full)
        self._paint_status()

    def _paint_status(self) -> None:
        color = self._pal.get(self._status_level, self._pal["muted"])
        self.status.setStyleSheet(f"QPlainTextEdit#awrStatus {{ color: {color}; }}")

    def _reset_selection(self, initial: bool = False) -> None:
        """Forget the loaded snapshots and the selection (database change, failure, empty result, cancellation)."""
        self._snaps, self._loaded, self._cells, self._marks, self._hover = [], False, {}, (None, None), None
        self.table.setRowCount(0)
        for edit in (self.begin_edit, self.end_edit):
            edit.blockSignals(True)
            edit.clear()
            edit.blockSignals(False)
        self._target = "begin"
        self._name_custom = False
        self._show_target()
        self._refresh_fake()
        self._range_changed()
        if not self._busy():
            name = self._db_name()
            if not name:
                self._set_status("muted", "No databases configured. Add one in Settings.")
            elif initial:
                self._set_status("muted", "Click \"Load Snapshots\" to list the snapshots. Nothing is queried until you do.")
            else:
                self._set_status("muted", f"Click \"Load Snapshots\" to list the snapshots of {name}.")
        self._update_enabled()

    def _refresh_fake(self) -> None:
        _text, level = outcomes.fake_status()
        self.sim_tag.setVisible(level == "warn")
        self.live_tag.setVisible(level == "" and bool(self._db_name()))     # '' = real Oracle (outcomes.fake_status); never shown on a guess

    # ------------------------------------------------------------------ selection
    def eventFilter(self, obj, event):
        if obj is self._table_vp:                              # hover over a snapshot's time cell
            kind = event.type()
            if kind == QEvent.Type.MouseMove:
                idx = self.table.indexAt(event.position().toPoint())
                sid = self._sid_at(idx.row(), idx.column()) if idx.isValid() else None
                self._table_vp.setCursor(Qt.CursorShape.PointingHandCursor if sid is not None else Qt.CursorShape.ArrowCursor)
                self._set_hover(sid)
            elif kind == QEvent.Type.Leave:
                self._hover_from_cursor()
        elif isinstance(obj, QRadioButton):                    # hover over a snapshot's Snap ID
            if event.type() in (QEvent.Type.Enter, QEvent.Type.MouseMove):
                self._set_hover(int(obj.text()))
            elif event.type() == QEvent.Type.Leave:
                self._hover_from_cursor()
        if obj in (self.begin_edit, self.end_edit) and obj.isEnabled():
            kind = event.type()
            # a click or a keyboard move into the field makes it the target; regaining window focus (Alt+Tab, dialogs) must not
            if kind == QEvent.Type.MouseButtonPress or (kind == QEvent.Type.FocusIn and event.reason() in KEY_FOCUS):
                self._set_target("begin" if obj is self.begin_edit else "end")
        return super().eventFilter(obj, event)

    def _set_target(self, target: str) -> None:
        if target != self._target:
            self._target = target
            self._show_target()

    def _show_target(self) -> None:
        for edit, name in ((self.begin_edit, "begin"), (self.end_edit, "end")):
            edit.setProperty("active", "true" if (self._loaded and self._target == name) else "false")
            edit.style().unpolish(edit)
            edit.style().polish(edit)
        self._paint_hover(self._hover, self._hover is not None)
        self._paint_caption()

    def _paint_caption(self) -> None:
        if not self._loaded:
            self.caption.setText("Load snapshots to select a range")
            self.caption.setStyleSheet("")
            return
        begin = self._target == "begin"
        self.caption.setText(f"Now selecting: {'Begin' if begin else 'End'} Snap ID")
        self.caption.setStyleSheet(f"color: {BLUE if begin else AMBER}; font-weight: 600;")

    def _fmt(self) -> str:
        return self.type_combo.currentData() or "html"

    def _format_changed(self, _index) -> None:
        self.ext_label.setText(awr.FORMATS[self._fmt()])
        self._validate_name()

    def _name_edited(self, _text) -> None:
        self._name_custom = True              # from now on the ids no longer rewrite the name

    def _validate_name(self) -> None:
        try:
            folder = awr_service.report_folder(self.ctx)
        except Exception:                     # no environment file yet: the service reports that when generating
            folder = None
        self._name_err = awr.check_report_name(self.name_edit.text(), self._fmt(), folder)
        self.name_edit.setProperty("invalid", "true" if self._name_err else "false")
        self.name_edit.style().unpolish(self.name_edit)
        self.name_edit.style().polish(self.name_edit)
        if self._name_err and not self._busy():
            self._name_flag = True
            self._set_status("warn", "Report Name: " + self._name_err)
        elif self._name_flag and not self._busy():
            self._name_flag = False
            self._set_status("muted", "Report Name is valid.")
        self._update_enabled()

    def _cell_clicked(self, row: int, col: int) -> None:
        """A click on a snapshot's timestamp selects it exactly like its radio button (the Snap ID cell is the radio itself)."""
        item = self.table.item(row, col) if col in (1, 3) else None
        sid = item.data(Qt.ItemDataRole.UserRole) if item is not None else None
        if sid is not None:
            self._pick(sid)

    def _set_hover(self, sid) -> None:
        """Hover highlight on BOTH cells of one snapshot: blue while Begin is the target, amber while End is.
        Selected Begin/End snapshots keep their own colours."""
        old, self._hover = self._hover, sid
        for s in {old, sid} - {None}:
            self._paint_hover(s, s == sid)

    def _paint_hover(self, s, on: bool) -> None:
        cell = self._cells.get(s)
        if cell is None:
            return
        radio, item = cell
        free = s not in self._marks                      # selected snapshots keep their Begin/End colour
        radio.setProperty("hover", "true" if on else "false")
        radio.setProperty("htarget", self._target if (on and free) else "")
        radio.style().unpolish(radio)
        radio.style().polish(radio)
        if free:
            blue = self._target == "begin"
            item.setBackground(QBrush(QColor(37, 99, 235, 70) if blue else QColor(245, 158, 11, 80)) if on else QBrush())

    def _hover_from_cursor(self) -> None:
        """After a Leave event: keep the highlight if the mouse is still over a cell of a snapshot (moving between its two
        cells must not flicker), clear it when the mouse is anywhere else."""
        pos = self._table_vp.mapFromGlobal(QCursor.pos())
        idx = self.table.indexAt(pos)
        sid = self._sid_at(idx.row(), idx.column()) if idx.isValid() and self._table_vp.rect().contains(pos) else None
        self._table_vp.setCursor(Qt.CursorShape.PointingHandCursor if sid is not None else Qt.CursorShape.ArrowCursor)
        self._set_hover(sid)

    def _sid_at(self, row: int, col: int):
        """Snapshot of a Snap ID / Time cell (columns 0-1 left, 2-3 right); None for other cells."""
        radio = self.table.cellWidget(row, 0 if col in (0, 1) else 2) if col in (0, 1, 2, 3) else None
        return int(radio.text()) if radio is not None else None

    def _pick(self, snap_id: int) -> None:
        """A snapshot radio was clicked: fill the active field, then move on to End after Begin."""
        edit = self.begin_edit if self._target == "begin" else self.end_edit
        edit.setText(str(snap_id))
        if self._target == "begin":
            self._set_target("end")
        self._sync_marks()

    def _text_changed(self, _text) -> None:
        self._range_changed()

    def _range_changed(self) -> None:
        check = self._check()
        if not self._loaded:
            self.range_msg.setText("")
        else:
            self.range_msg.setText(check.message)
            self.range_msg.setObjectName(check.level)
            self.range_msg.style().unpolish(self.range_msg)
            self.range_msg.style().polish(self.range_msg)
        if not self._name_custom:
            self.name_edit.setText(awr.default_name(check.begin, check.end) if check.ok else awr.default_name())
            self.name_edit.setCursorPosition(0)       # show the start of the name, not its end
        self._sync_marks()
        self._update_enabled()

    def _sync_marks(self) -> None:
        """Radios and highlights follow the two fields: blue = Begin, amber = End."""
        def ident(edit):
            text = edit.text().strip()
            return int(text) if text.isdigit() else None
        new = (ident(self.begin_edit), ident(self.end_edit))
        for sid in {x for x in (*self._marks, *new) if x is not None}:
            cell = self._cells.get(sid)
            if cell is None:
                continue
            radio, time_item = cell
            mark = "begin" if sid == new[0] else "end" if sid == new[1] else ""
            radio.setChecked(bool(mark))
            radio.setProperty("mark", mark)
            radio.style().unpolish(radio)
            radio.style().polish(radio)
            time_item.setBackground(QBrush(QColor(37, 99, 235, 70) if mark == "begin" else QColor(245, 158, 11, 80) if mark == "end" else QBrush()))
        self._marks = new
        self._paint_hover(self._hover, self._hover is not None)

    # ------------------------------------------------------------------ snapshot table
    def _fill_snapshots(self) -> None:
        rows = awr.pair_rows(self._snaps)
        self._cells, self._hover = {}, None
        self.table.setUpdatesEnabled(False)
        self.table.setRowCount(len(rows))
        for r, (left, right) in enumerate(rows):
            for col, snap in ((0, left), (2, right)):
                if snap is None:
                    for c in (col, col + 1):
                        self.table.setItem(r, c, self._cell(""))
                    continue
                radio = QRadioButton(str(snap.snap_id))
                radio.setAutoExclusive(False)
                radio.setFocusPolicy(Qt.FocusPolicy.NoFocus)
                radio.setCursor(Qt.CursorShape.PointingHandCursor)
                radio.setMouseTracking(True)
                radio.installEventFilter(self)
                radio.clicked.connect(partial(self._pick, snap.snap_id))
                self.table.setItem(r, col, self._cell(""))
                self.table.setCellWidget(r, col, radio)
                item = self._cell(self._when(snap))
                item.setToolTip(snap.begin.strftime(awr.SHOW_FMT).upper() + (f"  (instance restarted {snap.startup:%d-%b-%Y %H:%M})" if snap.startup else ""))
                item.setData(Qt.ItemDataRole.UserRole, snap.snap_id)
                self.table.setItem(r, col + 1, item)
                self._cells[snap.snap_id] = (radio, item)
            self.table.setItem(r, 4, self._cell(str(left.instance)))
            self.table.setItem(r, 5, self._cell(awr.row_duration(left, right)))
        self.table.setUpdatesEnabled(True)
        self._marks = (None, None)
        self._refit_times()

    @staticmethod
    def _cell(text: str) -> QTableWidgetItem:
        item = QTableWidgetItem(text)
        item.setFlags(Qt.ItemFlag.ItemIsEnabled)
        return item

    def _when(self, snap) -> str:
        return snap.begin.strftime(self._time_fmt).upper()

    def _refit_times(self) -> None:
        """Columns fit the text: ID columns from the radio width, times in the longest format that fits (never clipped)."""
        fm = self.table.fontMetrics()
        probe = QRadioButton("0" * 7)
        probe.setStyleSheet(self.styleSheet())
        id_w = probe.sizeHint().width() + 14
        head = lambda text: int(fm.horizontalAdvance(text) * 1.12) + 16     # header text is bold and padded
        self.table._fixed.update({0: id_w, 2: id_w, 4: head("Instance"), 5: max(head("Duration"), fm.horizontalAdvance("00h 00m") + 16)})
        FitTable.fit_columns(self.table)
        width = self.table.columnWidth(1)
        sample = datetime(2026, 9, 30, 23, 59, 59)
        fmt = next((f for f in TIME_FORMATS if fm.horizontalAdvance(sample.strftime(f).upper()) + 16 <= width), TIME_FORMATS[-1])
        if fmt != self._time_fmt:
            self._time_fmt = fmt
            for item, snap in self._time_items():
                item.setText(self._when(snap))

    def _refit_history(self) -> None:
        fm = self.hist.fontMetrics()
        probe = QPushButton("Open Report")
        probe.setObjectName("cellBtn")
        probe.setStyleSheet(self.styleSheet())
        text = lambda sample: fm.horizontalAdvance(sample) + 18
        db_w = max([text("PROD_DB_01")] + [text(e.db + (" [SIM]" if e.simulated else "")) for e in self.entries[:200]])
        self.hist._fixed.update({0: text("0000-00-00 00:00"), 1: min(db_w, 170), 2: text("000000 - 000000"), 4: text("000.0 MB"),
                                 5: probe.sizeHint().width() + 28 + 8 + 12})
        self.hist._flex_min = 100
        FitTable.fit_columns(self.hist)

    def _time_items(self):
        by_id = {s.snap_id: s for s in self._snaps}
        for sid, (_radio, item) in self._cells.items():
            yield item, by_id[sid]

    # ------------------------------------------------------------------ jobs
    def _start(self, kind: str, job) -> None:
        self._token = CancelToken()
        self._cancelling = False
        self._job = kind
        fake = outcomes.fake_status()[1] == "warn"
        token = self._token
        thread = JobThread(lambda emit: job(token), fake, self)
        thread.done.connect(self._done)
        thread.finished.connect(self._finished)
        self._thread = thread
        self.gate.begin()
        thread.start()
        self._update_enabled()

    def load_snapshots(self) -> None:
        if self.gate.busy or self._busy():
            return
        name = self._db_name()
        if not name:
            self._set_status("warn", "Select a database first.")
            return
        try:
            days = awr.validate_days(self.days.value())
        except awr.AwrError as exc:
            self._set_status("bad", str(exc))
            return
        text, level = outcomes.fake_status()
        if level == "bad":
            self._set_status("bad", text)
            return
        self._reset_selection()
        self._loaded_days, self._loaded_db = days, name
        self._set_status("muted", f"Loading snapshots from {name} ..." + (" (simulated)" if level == "warn" else ""))
        ctx = self.ctx
        self._start("load", lambda token: awr_service.load_snapshots(ctx, name, days, token))

    def generate(self) -> None:
        if self.gate.busy or self._busy():
            return
        check = self._check()
        name = self._db_name()
        if not (name and self._loaded and check.ok):
            self._set_status("warn", check.message or "Load snapshots and choose a valid range first.")
            return
        text, level = outcomes.fake_status()
        if level == "bad":
            self._set_status("bad", text)
            return
        b, e, days, ctx = check.begin, check.end, self._loaded_days, self.ctx
        fmt, rname, rac = self._fmt(), self.name_edit.text(), self.rac_check.isChecked()
        self._name_flag = False
        self._set_status("muted", f"Generating the {'Text' if fmt == 'text' else 'HTML'} AWR report{' (RAC, all instances)' if rac else ''} for snapshots "
                         f"{b} to {e} on {name} ... this can take a few minutes." + (" (simulated)" if level == "warn" else ""))
        self._start("generate", lambda token: awr_service.generate_report(ctx, name, days, b, e, token, fmt, rname, rac))

    def cancel(self) -> None:
        if self._thread is None or self._token is None or self._cancelling:
            return
        self._cancelling = True
        self.cancel_btn.setEnabled(False)
        self._set_status("warn", "Cancelling - waiting for SQL*Plus to stop ...")
        self._token.request()

    def _done(self, result) -> None:
        kind = self._job
        if not isinstance(result, awr_service.AwrResult):   # JobThread's safety net for an unexpected exception
            if kind == "load":
                self._reset_selection()
            self._set_status("bad", getattr(result, "headline", "Unexpected error"), getattr(result, "detail", ""))
            return
        if kind == "load":
            self._load_done(result)
        else:
            self._generate_done(result)

    def _load_done(self, r) -> None:
        if r.cancelled:
            self._reset_selection()
            self._set_status("warn", r.message)
        elif not r.ok:
            self._reset_selection()
            self._set_status("bad", r.message, r.detail)
        elif not r.snaps.snaps:
            self._reset_selection()
            self._set_status("warn", r.message)
        else:
            self._snaps, self._loaded = list(r.snaps.snaps), True
            self._fill_snapshots()
            self._show_target()
            self._range_changed()
            self._set_status("warn" if r.snaps.capped else "ok", r.message)

    def _generate_done(self, r) -> None:
        if r.cancelled:
            self._set_status("warn", r.message)
        elif not r.ok:
            self._set_status("bad", r.message, r.detail)
        else:
            self._set_status("warn" if r.note else "ok", r.message, r.note)
            self.reveal(r.path)
            if self.open_check.isChecked():
                self.open_path(r.path)

    def _finished(self) -> None:
        thread, self._thread = self._thread, None
        self._token, self._cancelling, self._job = None, False, ""
        if thread is not None:
            thread.deleteLater()
        self.gate.end()
        self._update_enabled()

    # ------------------------------------------------------------------ history
    def refresh_history(self) -> None:
        self.last_scan = awr.scan_history(Path(self.ctx.root) / "reports", index_dir=awr.index_dir_for(self.ctx.root))
        self.entries = self.last_scan.entries
        keep = self.date_combo.currentData() or ""
        self.date_combo.blockSignals(True)
        self.date_combo.clear()
        self.date_combo.addItem(ALL_DATES, "")
        for d in awr.dates_of(self.entries):
            self.date_combo.addItem(d, d)
        self.date_combo.setCurrentIndex(max(0, self.date_combo.findData(keep)))
        self.date_combo.blockSignals(False)
        self._fill_history()

    def reveal(self, path) -> None:
        """Rescan and make sure the report is visible (filters are cleared if they would hide it)."""
        self.refresh_history()
        shown = awr.filter_entries(self.entries, self.date_combo.currentData() or "", self.search.text())
        if not any(e.path == Path(path) for e in shown):
            self.search.blockSignals(True)
            self.search.clear()
            self.search.blockSignals(False)
            self.date_combo.blockSignals(True)
            self.date_combo.setCurrentIndex(0)
            self.date_combo.blockSignals(False)
            self._fill_history()
        for row in range(self.hist.rowCount()):
            if self.hist.item(row, 3).data(Qt.ItemDataRole.UserRole) == str(path):
                self.hist.selectRow(row)
                self.hist.scrollToItem(self.hist.item(row, 3))
                break

    def _fill_history(self) -> None:
        shown = awr.filter_entries(self.entries, self.date_combo.currentData() or "", self.search.text())
        self.hist.setUpdatesEnabled(False)
        self.hist.setRowCount(0)
        self.hist.setRowCount(len(shown))
        for row, e in enumerate(shown):
            texts = (e.when.strftime("%Y-%m-%d %H:%M"), e.db + (" [SIM]" if e.simulated else ""), e.range_text, e.name, format_size(e.size))
            for col, text in enumerate(texts):
                item = QTableWidgetItem(text)
                item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
                item.setToolTip(str(e.path) if col == 3 else ("Simulated report: no database was contacted." if e.simulated else text))
                self.hist.setItem(row, col, item)
            self.hist.item(row, 3).setData(Qt.ItemDataRole.UserRole, str(e.path))
            self.hist.setCellWidget(row, 5, self._actions(e.path))
        self.hist.setUpdatesEnabled(True)
        scan = self.last_scan
        if not scan.exists:
            note = "The reports folder does not exist yet - it is created when the first report is generated."
        elif not self.entries:
            note = "No AWR reports have been generated yet."
        elif not shown:
            note = "No reports match the filter."
        else:
            note = ""
        self.hist_note.setText((note + " " + scan.note).strip())
        self.hist_note.setVisible(bool(self.hist_note.text()))

    def _actions(self, path: Path) -> QWidget:
        """One Open Report button and one menu per row, bound to THIS row's file (not to a table position)."""
        holder = QWidget()
        lay = QHBoxLayout(holder)
        lay.setContentsMargins(4, 2, 4, 2)
        lay.setSpacing(4)
        open_btn = QPushButton("Open Report")
        open_btn.setObjectName("cellBtn")
        open_btn.clicked.connect(partial(self.open_path, path))
        menu_btn = QToolButton()
        menu_btn.setObjectName("cellMenu")
        menu_btn.setText("\u25BE")
        menu_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        menu = QMenu(menu_btn)
        menu.addAction("Open Report").triggered.connect(partial(self.open_path, path))
        menu.addAction("Open Containing Folder").triggered.connect(partial(self.open_folder, path))
        menu.addAction("Copy File Path").triggered.connect(partial(self.copy_path, path))
        menu_btn.setMenu(menu)
        lay.addWidget(open_btn, 1)
        lay.addWidget(menu_btn)
        holder.open_btn, holder.menu_btn, holder.path = open_btn, menu_btn, path
        return holder

    def _exists(self, path: Path) -> bool:
        if Path(path).is_file():
            return True
        self._set_status("warn", f"The report no longer exists: {Path(path).name}")
        self.refresh_history()
        return False

    def open_path(self, path) -> None:
        if self._exists(Path(path)):
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def open_folder(self, path) -> None:
        if self._exists(Path(path)):
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(path).parent)))

    def copy_path(self, path) -> None:
        QGuiApplication.clipboard().setText(str(path))

    def _reserve_parameters_height(self) -> None:
        """The page layout sizes the parameters card from its height-for-width, which ignores the Options panel's taller content, and splits the
        height equally with the history card. On a short window the card then ends above its content: the Generate button is squeezed (label
        clipped) or the card runs into the Generated Reports section. The two cards always share the same total height, so cap the history
        card at what is left after the parameters card's own need; the history card keeps its normal share whenever there is room."""
        params, hist = self._params_card, self._history_card
        total = params.height() + hist.height()
        cap = max(hist.minimumSizeHint().height(), total - params.layout().minimumSize().height())
        if hist.maximumHeight() != cap:
            hist.setMaximumHeight(cap)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self._reserve_parameters_height()

    def showEvent(self, event) -> None:
        super().showEvent(event)
        self._reserve_parameters_height()
        if not self._busy():
            self.refresh_databases()
            self._refresh_fake()
            self.refresh_history()
            self._update_enabled()
