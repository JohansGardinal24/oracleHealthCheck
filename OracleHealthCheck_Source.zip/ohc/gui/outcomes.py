"""Turns engine results into what the GUI shows (no Qt here, so it is easy to test)."""
from __future__ import annotations

from dataclasses import dataclass

from ohc.checks import launcher
from ohc.checks.cancel import RunCancelled
from ohc.checks.session import ToolError

PREFIX = "SIMULATED DATA - "
LEVELS = {"OK": "ok", "WARNING": "warn", "CRITICAL": "bad"}


@dataclass(frozen=True)
class Outcome:
    level: str            # ok | warn | bad  (label styles)
    headline: str
    exit_code: int | None = None
    detail: str = ""
    result: object = None   # the engine RunResult, when there is one (file paths, completed checks)
    cancelled: bool = False

    def text(self) -> str:
        return self.headline + (f" (exit code {self.exit_code})" if self.exit_code is not None else "")


def fake_status() -> tuple:
    """-> (banner text, level): level 'warn' = fake mode on, 'bad' = OHC_FAKE_ORACLE is invalid, '' = real Oracle."""
    try:
        scenario = launcher.fake_scenario()
    except ToolError as exc:
        return str(exc), "bad"
    if scenario:
        return (f"FAKE / SIMULATED DATA (scenario: {scenario}) - no database is contacted; these results are not real.", "warn")
    return "", ""


def _p(fake: bool, text: str) -> str:
    return PREFIX + text if fake else text


def for_cancelled(result=None, fake: bool = False) -> Outcome:
    """Never 'ok': a cancelled run is reported as CANCELLED (exit code 4, GUI only)."""
    done = len(result.results) if result is not None else 0
    return Outcome("warn", _p(fake, f"CANCELLED - {done} check(s) completed before the run was stopped"), 4,
                   "", result, True)


def for_run(result, fake: bool = False) -> Outcome:
    if getattr(result, "cancelled", False):
        return for_cancelled(result, fake)
    return Outcome(LEVELS.get(result.overall, "bad"), _p(fake, f"OVERALL: {result.overall}"), result.exit_code, "", result)


def for_probe(probe, fake: bool = False) -> Outcome:
    return Outcome("ok" if probe.kind == "OK" else "bad", _p(fake, f"{probe.kind}: {probe.state}"), None, probe.error)


def for_error(exc: BaseException, fake: bool = False) -> Outcome:
    if isinstance(exc, RunCancelled):  # cancelled before the engine produced any result
        return for_cancelled(None, fake)
    detail = str(exc) if isinstance(exc, ToolError) else f"Unexpected error: {exc!r}"
    return Outcome("bad", _p(fake, "TOOL / CONFIGURATION ERROR"), 3, detail)
