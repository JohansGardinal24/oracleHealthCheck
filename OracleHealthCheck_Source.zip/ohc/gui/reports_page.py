"""Reports & Logs page: browse the HTML reports and execution logs that runs already wrote.

Read-only. Reports are opened in the system browser (never rendered here); logs open in the read-only LogDialog.
"""
from __future__ import annotations

from pathlib import Path

from string import Template

from PySide6.QtCore import QPointF, QRectF, Qt, QThread, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices, QFont, QFontMetricsF, QGuiApplication, QPainter, QPen, QPolygonF
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QComboBox, QFrame, QHBoxLayout, QLabel, QLineEdit, QMenu,
                               QMessageBox, QPushButton, QTableWidgetItem, QVBoxLayout, QWidget)

from ohc.gui import report_index as ri
from ohc.gui.run_page import BADGES, STATUS_ROLE, BadgeDelegate, LogDialog
from ohc.gui.run_skin import PageBackdrop, pill         # the approved wave / card shadows / status tints (reused, not changed)
from ohc.gui.sidebar import nav_pixmap
from ohc.gui.theme import PALETTES
from ohc.gui.widgets import FitTable, WrapLabel

ALL_DATES = "All dates"
BIG_LOG = 8 * 1024 * 1024

# Redesign (5D): look only. Same heading sizes as the redesigned run pages.
_SKIN_QSS = Template("""
QLabel#title { font-size: 26px; font-weight: 700; }
QLabel#section { font-size: 15px; font-weight: 700; }
""")
# The status pills of the approved design, per theme and status code: (fill, ink, icon colour, colour of the mark inside the icon).
STATUS_STYLE = {
    "light": {"OK": ("#E0EFDB", "#0F6212", "#16872A", "#FFFFFF"), "WARNING": ("#FDECC9", "#92400E", "#F7960F", "#FFFFFF"),
              "CRITICAL": ("#F8DADA", "#B91C1C", "#D61F1F", "#FFFFFF"), "CANCELLED": ("#E8EAEF", "#12284A", "#647692", "#FFFFFF")},
    "dark": {"OK": ("#1F3326", "#A8D8A8", "#4E9F5A", "#FFFFFF"), "WARNING": ("#3A2F12", "#FBBF24", "#FBBF24", "#1F1300"),
             "CRITICAL": ("#3F1B1E", "#F87171", "#F87171", "#FFFFFF"), "CANCELLED": ("#242B38", "#B6C2D6", "#8A97AD", "#FFFFFF")},
}
STATUS_LABEL = {"OK": "SUCCESS", "WARNING": "WARNING", "CRITICAL": "CRITICAL", "CANCELLED": "CANCELLED"}      # what the pill says; the status code is unchanged


class ReportBadgeDelegate(BadgeDelegate):
    """The Status column of Reports & Logs (both tables): capsule pills with an icon. OK is shown as SUCCESS (check), WARNING (triangle),
    CRITICAL (cross) and CANCELLED (minus); any other status keeps its label in the neutral tint, without an icon.
    Only painting: the status code in STATUS_ROLE is untouched."""

    def __init__(self, parent, theme_name) -> None:
        super().__init__(parent)
        self._theme_name = theme_name

    @staticmethod
    def _icon(painter, status: str, x: float, y: float, d: float, icon: str, mark: str) -> None:
        ic, mk = QColor(icon), QColor(mark)
        round_pen = lambda c, w: QPen(c, w, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)  # noqa: E731
        if status == "CRITICAL":                                       # red ring with a cross
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.setPen(round_pen(ic, 1.6))
            painter.drawEllipse(QRectF(x + 0.8, y + 0.8, d - 1.6, d - 1.6))
            painter.drawLine(QPointF(x + 5.2, y + 5.2), QPointF(x + 10.8, y + 10.8))
            painter.drawLine(QPointF(x + 10.8, y + 5.2), QPointF(x + 5.2, y + 10.8))
        elif status == "WARNING":                                      # filled triangle with an exclamation mark
            painter.setBrush(ic)
            painter.setPen(round_pen(ic, 1.6))
            painter.drawPolygon(QPolygonF([QPointF(x + 8, y + 1.6), QPointF(x + 14.8, y + 13.6), QPointF(x + 1.2, y + 13.6)]))
            painter.setPen(round_pen(mk, 1.5))
            painter.drawLine(QPointF(x + 8, y + 5.8), QPointF(x + 8, y + 9.2))
            painter.drawPoint(QPointF(x + 8, y + 11.4))
        else:                                                          # filled disc: a check (SUCCESS) or a minus (CANCELLED)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(ic)
            painter.drawEllipse(QRectF(x, y, d, d))
            painter.setPen(round_pen(mk, 1.8))
            if status == "OK":
                painter.drawPolyline([QPointF(x + 4.3, y + 8.4), QPointF(x + 7.0, y + 11.0), QPointF(x + 11.8, y + 5.4)])
            else:
                painter.drawLine(QPointF(x + 4.4, y + 8.0), QPointF(x + 11.6, y + 8.0))

    def paint(self, painter, option, index) -> None:
        status = index.data(STATUS_ROLE) or "PENDING"
        theme = self._theme_name()
        painter.save()
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(option.rect).adjusted(6, 6, -6, -6)
        style = STATUS_STYLE[theme].get(status)
        if style is not None:
            fill, ink, icon, mark = style
            label = STATUS_LABEL[status]
        else:
            (fill, ink), icon, mark, label = pill(theme, status), None, None, BADGES.get(status, BADGES["PENDING"])[2]
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(fill))
        painter.drawRoundedRect(rect, rect.height() / 2, rect.height() / 2)
        text_rect = rect
        if icon is not None:
            d = 16.0
            self._icon(painter, status, rect.left() + 8, rect.center().y() - d / 2, d, icon, mark)
            text_rect = rect.adjusted(8 + d + 4, 0, -6, 0)
        painter.setPen(QColor(ink))
        font = QFont(option.font)
        font.setBold(True)
        font.setPointSizeF(max(7.5, font.pointSizeF() - 1.5))
        while QFontMetricsF(font).horizontalAdvance(label) > text_rect.width() and font.pointSizeF() > 6.5:      # a long label (CANCELLED) always fits
            font.setPointSizeF(font.pointSizeF() - 0.25)
        painter.setFont(font)
        painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter, label)
        painter.restore()

class ScanThread(QThread):
    """Looks for files off the GUI thread."""
    done = Signal(object, object)

    def __init__(self, report_base: Path, log_dir: Path, parent=None):
        super().__init__(parent)
        self._report_base, self._log_dir = report_base, log_dir

    def run(self) -> None:
        try:
            self.done.emit(ri.scan_reports(self._report_base, self._log_dir), ri.scan_logs(self._log_dir))
        except Exception as exc:  # never let a scan problem escape the thread
            self.done.emit(ri.Scan(note=f"Scan failed: {exc}", exists=False), ri.Scan(note=f"Scan failed: {exc}", exists=False))


class Section:
    """One card: title, Refresh, date filter, search, table, empty-state text."""

    def __init__(self, title: str, subtitle: str, search_hint: str, columns: tuple, fixed: dict, flex: dict, status_col: int, noun: str):
        self.noun, self.entries = noun, []
        self.card = QFrame()
        self.card.setObjectName("card")
        box = QVBoxLayout(self.card)
        box.setContentsMargins(14, 12, 14, 12)
        box.setSpacing(8)
        self.refresh_btn = QPushButton("\u27F3  Refresh")
        head = QHBoxLayout()
        titles = QVBoxLayout()
        titles.setSpacing(0)
        t = QLabel(title)
        t.setObjectName("section")
        s = QLabel(subtitle)
        s.setObjectName("muted")
        titles.addWidget(t)
        titles.addWidget(s)
        self.titles, self.title_label, self.subtitle_label = titles, t, s
        head.addLayout(titles, 1)
        head.addWidget(self.refresh_btn, 0, Qt.AlignmentFlag.AlignTop)
        box.addLayout(head)
        self.date_combo = QComboBox()
        self.date_combo.addItem(ALL_DATES, "")
        self.search = QLineEdit()
        self.search.setPlaceholderText(search_hint)
        self.search.setClearButtonEnabled(True)
        filters = QHBoxLayout()
        caption = QLabel("Filter by date:")
        caption.setObjectName("muted")
        filters.addWidget(caption)
        filters.addWidget(self.date_combo)
        filters.addSpacing(12)
        self.search.setMaximumWidth(340)  # visibly narrower than the card; the same for both sections
        filters.addWidget(self.search, 1)
        filters.addStretch(1)
        box.addLayout(filters)
        self.table = FitTable(0, len(columns), fixed=fixed, flex=flex, flex_min=120)
        self.table.setHorizontalHeaderLabels(list(columns))
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(42)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setShowGrid(False)
        self.table.setWordWrap(False)
        self.table.setTextElideMode(Qt.TextElideMode.ElideMiddle)
        self.table.horizontalHeader().setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.table.setItemDelegateForColumn(status_col, BadgeDelegate(self.table))
        self.table.setMinimumHeight(110)
        self.empty = WrapLabel("")
        self.empty.setObjectName("muted")
        self.note = WrapLabel("")
        self.note.setObjectName("warn")
        self.note.hide()
        box.addWidget(self.empty)
        box.addWidget(self.table, 1)
        box.addWidget(self.note)

    def selected_date(self) -> str:
        return self.date_combo.currentData() or ""

    def set_dates(self, entries) -> None:
        keep = self.selected_date()
        self.date_combo.blockSignals(True)
        self.date_combo.clear()
        self.date_combo.addItem(ALL_DATES, "")
        for d in ri.dates_of(entries):
            self.date_combo.addItem(d, d)
        index = self.date_combo.findData(keep)
        self.date_combo.setCurrentIndex(max(0, index))
        self.date_combo.blockSignals(False)


class ReportsPage(QWidget):
    def __init__(self, ctx, parent=None, theme=None):
        super().__init__(parent)
        self.setObjectName("page")
        self.ctx = ctx
        self.theme = theme                  # ThemeManager (optional); the page follows it
        self._icons: list = []              # (label, icon kind, size) re-drawn when the theme changes
        self.report_base, self.log_dir = Path(ctx.root) / "reports", Path(ctx.root) / "logs"  # same places the engine writes to
        self.scanning, self._again, self._thread = False, False, None
        self._scans = {}
        self.reports = Section("Reports", "Browse and open generated HTML reports.", "Search reports...",
                               ("Date & Time", "Status", "Checks", "File Name", "Size", "Actions"),
                               {0: 150, 1: 110, 2: 90, 4: 80, 5: 150}, {3: 1}, 1, "reports")
        self.logs = Section("Execution Logs", "Browse and view execution logs.", "Search logs...",
                            ("Date & Time", "Status", "File Name", "Size", "Actions"),
                            {0: 150, 1: 110, 3: 80, 4: 190}, {2: 1}, 1, "logs")
        title = QLabel("Reports & Logs")
        title.setObjectName("title")
        box = QVBoxLayout(self)
        box.setContentsMargins(32, 8, 32, 16)
        box.setSpacing(10)
        heading = QHBoxLayout()
        heading.setSpacing(12)
        heading.addWidget(self._icon("logs", 32), 0, Qt.AlignmentFlag.AlignVCenter)      # the page's own (document) icon from the sidebar
        heading.addWidget(title, 1)
        box.addLayout(heading)
        box.addWidget(self.reports.card, 1)
        box.addWidget(self.logs.card, 1)
        for sec in (self.reports, self.logs):
            row = QHBoxLayout()
            row.setSpacing(8)
            row.addWidget(self._icon("logs", 18))
            sec.titles.removeWidget(sec.title_label)
            row.addWidget(sec.title_label, 1)
            sec.titles.insertLayout(0, row)
            sec.subtitle_label.setContentsMargins(26, 0, 0, 0)          # under the title text (icon 18 + spacing 8)
            sec.table.setItemDelegateForColumn(1, ReportBadgeDelegate(sec.table, self._theme_name))     # column 1 = Status in both tables
        self._backdrop = PageBackdrop(self, [self.reports.card, self.logs.card], self._theme_name, lambda: self.reports.card.y())   # faint wave + soft card shadows
        if self.theme is not None:
            self.theme.changed.connect(lambda _name: self._apply_skin())
        self._apply_skin()
        self.reports_table, self.logs_table = self.reports.table, self.logs.table
        for sec in (self.reports, self.logs):
            sec.refresh_btn.clicked.connect(self.rescan)
            sec.date_combo.currentIndexChanged.connect(lambda _i: self._apply_filters())
            sec.search.textChanged.connect(lambda _t: self._apply_filters())
        app = QApplication.instance()
        if app is not None:
            app.aboutToQuit.connect(self.shutdown)
        self._apply_filters()

    # ------------------------------------------------------------ scanning
    def _theme_name(self) -> str:
        return self.theme.theme if self.theme is not None else "dark"

    def _icon(self, kind: str, size: int) -> QLabel:
        label = QLabel()
        label.setFixedSize(size, size)
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._icons.append((label, kind, size))
        return label

    def _apply_skin(self) -> None:
        name = self._theme_name()
        self.setStyleSheet(_SKIN_QSS.substitute())
        for label, kind, size in self._icons:
            label.setPixmap(nav_pixmap(kind, PALETTES[name]["accent_text"], size))
        for sec in (self.reports, self.logs):
            sec.table.viewport().update()

    def showEvent(self, event) -> None:
        super().showEvent(event)
        self.rescan()

    def rescan(self) -> None:
        if self.scanning:
            self._again = True
            return
        self.scanning, self._again = True, False
        thread = ScanThread(self.report_base, self.log_dir, self)
        thread.done.connect(self._scanned)
        thread.finished.connect(self._scan_finished)
        self._thread = thread
        thread.start()

    def _scanned(self, reports, logs) -> None:
        self._scans = {"reports": reports, "logs": logs}
        self.reports.entries, self.logs.entries = reports.entries, logs.entries
        self.reports.set_dates(reports.entries)
        self.logs.set_dates(logs.entries)
        self._apply_filters()

    def _scan_finished(self) -> None:
        thread, self._thread = self._thread, None
        if thread is not None:
            thread.deleteLater()
        self.scanning = False
        if self._again:
            self.rescan()

    def shutdown(self) -> None:
        if self._thread is not None:
            self._thread.wait(5000)

    # ------------------------------------------------------------ table
    def _apply_filters(self) -> None:
        for sec, kind in ((self.reports, "reports"), (self.logs, "logs")):
            shown = ri.filter_entries(sec.entries, sec.selected_date(), sec.search.text())
            self._fill(sec, shown)
            scan = self._scans.get(kind)
            if shown:
                sec.empty.hide()
            elif scan is None:
                sec.empty.setText(f"Looking for {sec.noun} ...")
                sec.empty.show()
            elif not scan.exists:
                sec.empty.setText(f"No {sec.noun} yet: the folder {scan.folder} does not exist. It is created by the first run.")
                sec.empty.show()
            elif not sec.entries:
                sec.empty.setText(f"No {sec.noun} found in {scan.folder}.")
                sec.empty.show()
            else:
                sec.empty.setText(f"No {sec.noun} match the filter.")
                sec.empty.show()
            sec.table.setVisible(bool(shown))
            note = scan.note if scan else ""
            sec.note.setText(note)
            sec.note.setVisible(bool(note))

    def _fill(self, sec: Section, entries: list) -> None:
        table, is_report = sec.table, sec is self.reports
        table.setRowCount(len(entries))
        for row, e in enumerate(entries):
            cells = [e.when.strftime("%Y-%m-%d  %H:%M"), "", *([e.checks or "-"] if is_report else []), e.display_name, ri.format_size(e.size)]
            for col, text in enumerate(cells):
                item = QTableWidgetItem(text)
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                table.setItem(row, col, item)
            table.item(row, 1).setData(STATUS_ROLE, e.status)
            name_item = table.item(row, 3 if is_report else 2)
            name_item.setToolTip(str(e.path))
            table.setCellWidget(row, 5 if is_report else 4, self._report_actions(e) if is_report else self._log_actions(e))

    def _report_actions(self, e) -> QWidget:
        btn = QPushButton("Open Report")
        btn.setObjectName("cellBtn")
        btn.clicked.connect(lambda _=False, p=e.path: self.open_report(p))
        return self._wrap(btn)

    def _log_actions(self, e) -> QWidget:
        view, more = QPushButton("View Log"), QPushButton("\u25BE")
        view.setObjectName("cellBtn")
        more.setObjectName("cellBtn")
        more.setToolTip("More actions")
        view.clicked.connect(lambda _=False, p=e.path: self.view_log(p))
        more.clicked.connect(lambda _=False, p=e.path, b=more: self._log_menu(p, b))
        return self._wrap(view, more)

    @staticmethod
    def _wrap(*buttons) -> QWidget:
        cell = QWidget()
        row = QHBoxLayout(cell)
        row.setContentsMargins(4, 3, 4, 3)
        row.setSpacing(6)
        for i, b in enumerate(buttons):
            row.addWidget(b, 1 if i == 0 else 0)
        return cell

    def _log_menu(self, path: Path, anchor) -> None:
        menu = QMenu(self)
        menu.addAction("Open in default app", lambda: self.open_log_external(path))
        menu.addAction("Open containing folder", lambda: self.open_log_folder(path))
        menu.addAction("Copy path", lambda: self.copy_log_path(path))
        menu.exec(anchor.mapToGlobal(anchor.rect().bottomLeft()))

    # ------------------------------------------------------------ actions (all validate the file first)
    def _safe(self, path: Path, root: Path, suffixes: tuple, what: str):
        """The resolved path if it is an existing file of the expected kind inside the app's own folder, else None (with a message)."""
        try:
            real = Path(path).resolve()
            real.relative_to(Path(root).resolve())
        except (OSError, ValueError):
            QMessageBox.information(self, "Reports & Logs", f"This {what} is outside the application's {what} folder and will not be opened.")
            return None
        if real.suffix.lower() not in suffixes or not real.is_file():
            QMessageBox.information(self, "Reports & Logs", f"This {what} no longer exists or cannot be read:\n{path}")
            self.rescan()
            return None
        return real

    def open_report(self, path: Path) -> None:
        real = self._safe(path, self.report_base, (".html",), "report")
        if real is not None and not QDesktopServices.openUrl(QUrl.fromLocalFile(str(real))):
            QMessageBox.information(self, "Reports & Logs", "The system could not open the report in a browser.")

    def view_log(self, path: Path) -> None:
        real = self._safe(path, self.log_dir, (".log",), "log")
        if real is None:
            return
        try:
            size = real.stat().st_size
        except OSError:
            size = 0
        if size > BIG_LOG:
            QMessageBox.information(self, "Reports & Logs", "This log is too large to view here. Use \"Open in default app\" from the menu.")
            return
        LogDialog(real, self).exec()

    def open_log_external(self, path: Path) -> None:
        real = self._safe(path, self.log_dir, (".log",), "log")
        if real is not None:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(real)))

    def open_log_folder(self, path: Path) -> None:
        real = self._safe(path, self.log_dir, (".log",), "log")
        if real is not None:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(real.parent)))

    def copy_log_path(self, path: Path) -> None:
        real = self._safe(path, self.log_dir, (".log",), "log")
        if real is not None:
            QGuiApplication.clipboard().setText(str(real))
