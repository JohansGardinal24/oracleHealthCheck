"""Settings page: Oracle Home, databases, retention and theme."""
from __future__ import annotations

from string import Template

from PySide6.QtCore import QPointF, QRectF, QSize, Qt
from PySide6.QtGui import QColor, QIcon, QPainter, QPen, QPixmap, QPolygonF
from PySide6.QtWidgets import (QComboBox, QFileDialog, QFrame, QHBoxLayout, QInputDialog, QLabel, QLineEdit, QMessageBox,
                               QPushButton, QSpinBox, QVBoxLayout, QWidget)

from ohc.config import dbadmin, environment, thresholds
from ohc.config import oracle_home as oh
from ohc.config.jsonio import ConfigFileError
from ohc.checks import launcher
from ohc.gui import outcomes
from ohc.gui.runner import JobGate, JobThread
from ohc.gui.database_dialog import DatabaseDialog
from ohc.gui.run_skin import PageBackdrop            # the approved wave + card shadows of the redesigned pages (reused, not changed)
from ohc.gui.sidebar import nav_pixmap
from ohc.gui.theme import PALETTES
from ohc.gui.widgets import WrapLabel
from ohc.security import credstore


def _label(text="", name="muted", wrap=True) -> QLabel:
    label = WrapLabel(text) if wrap else QLabel(text)  # long paths wrap instead of widening the page
    label.setObjectName(name)
    return label


# Redesign (5E): look only. Same heading sizes as the redesigned run pages; the three value fields read semi-bold.
_SKIN_QSS = Template("""
QLabel#title { font-size: 26px; font-weight: 700; }
QLabel#section { font-size: 16px; font-weight: 700; }
QComboBox[value="bold"], QSpinBox[value="bold"] { font-weight: 600; }
""")


def settings_pixmap(kind: str, color: str, size: int = 18) -> QPixmap:
    """Line icons for this page, drawn with QPainter (no image files) in the style of the sidebar icons; kinds the sidebar already has are reused."""
    if kind in ("settings", "database", "folder"):
        return nav_pixmap(kind, color, size)
    scale = 3
    pm = QPixmap(size * scale, size * scale)
    pm.fill(Qt.GlobalColor.transparent)
    pm.setDevicePixelRatio(scale)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.scale(size / 24, size / 24)
    pen = QPen(QColor(color), 1.8, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
    p.setPen(pen)
    p.setBrush(Qt.BrushStyle.NoBrush)
    pts = lambda *xy: [QPointF(x, y) for x, y in xy]  # noqa: E731
    line = lambda x1, y1, x2, y2: p.drawLine(QPointF(x1, y1), QPointF(x2, y2))  # noqa: E731
    dot = lambda x, y: (pen.setWidthF(2.6), p.setPen(pen), p.drawPoint(QPointF(x, y)), pen.setWidthF(1.8), p.setPen(pen))  # noqa: E731
    if kind == "search":
        p.drawEllipse(QPointF(10.5, 10.5), 6.2, 6.2)
        line(15.2, 15.2, 20.2, 20.2)
    elif kind == "pencil":
        p.drawPolygon(QPolygonF(pts((4, 20), (5, 15.4), (16, 4.4), (19.6, 8), (8.6, 19), (4, 20))))
        line(13.4, 7, 17, 10.6)
    elif kind == "trash":
        line(4.5, 7, 19.5, 7)
        p.drawPolyline(pts((9.5, 7), (9.5, 4.5), (14.5, 4.5), (14.5, 7)))
        p.drawPolyline(pts((6.5, 7), (7.4, 20), (16.6, 20), (17.5, 7)))
        line(10.3, 10.6, 10.3, 16.6)
        line(13.7, 10.6, 13.7, 16.6)
    elif kind == "plus_circle":
        p.drawEllipse(QPointF(12, 12), 8.6, 8.6)
        line(12, 8, 12, 16)
        line(8, 12, 16, 12)
    elif kind == "link":
        for dx in (-1, 1):
            p.save()
            p.translate(12, 12)
            p.rotate(-45)
            p.drawRoundedRect(QRectF(-9.2 if dx < 0 else -0.8, -3.3, 10, 6.6), 3.3, 3.3)
            p.restore()
    elif kind == "calendar":
        p.drawRoundedRect(QRectF(4, 5.5, 16, 14.5), 2.2, 2.2)
        line(4, 10, 20, 10)
        line(8.5, 3.5, 8.5, 7.5)
        line(15.5, 3.5, 15.5, 7.5)
        for x, y in ((8.5, 14), (12, 14), (15.5, 14), (8.5, 17.2), (12, 17.2)):
            dot(x, y)
    elif kind == "palette":
        p.drawEllipse(QRectF(3, 3.4, 18, 17.2))
        for x, y in ((8, 10), (12, 7.6), (16, 10), (8.8, 14.6)):
            dot(x, y)
    elif kind == "check":
        p.drawPolyline(pts((5, 12.5), (10, 17.5), (19, 7)))
    elif kind == "save":
        p.drawRoundedRect(QRectF(4, 4, 16, 16), 2.4, 2.4)
        p.drawPolyline(pts((8, 4), (8, 9), (16, 9), (16, 4)))
        p.drawRoundedRect(QRectF(7.6, 13.2, 8.8, 6.8), 1, 1)
    elif kind == "check_circle":                         # filled disc with a white check (the Oracle Home "found" mark)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(color))
        p.drawEllipse(QPointF(12, 12), 10, 10)
        pen.setColor(QColor("#FFFFFF"))
        pen.setWidthF(2.2)
        p.setPen(pen)
        p.drawPolyline(pts((7, 12.4), (10.6, 16), (17, 8.4)))
    p.end()
    return pm


class SettingsPage(QWidget):
    def __init__(self, ctx, theme, parent=None, gate=None):
        super().__init__(parent)
        self.setObjectName("page")
        self.ctx, self.theme = ctx, theme
        self._icons: list = []               # (label, icon kind, size) re-drawn when the theme changes
        self._button_icons: list = []        # (button, icon kind)
        self._cards: list = []               # the section cards the wave backdrop puts shadows under
        self.gate = gate or JobGate(self)
        self._test_thread = None
        self.env_values, self.env_ok = dict(environment.DEFAULTS), True
        self.th_values, self.th_state = dict(thresholds.DEFAULTS), "ok"  # ok | missing | invalid

        title = _label("Settings", "title", False)
        # --- Oracle Home
        self.home_edit = QLineEdit()
        self.browse_btn, self.detect_btn = QPushButton("Browse"), QPushButton("Detect")
        self.home_status = _label()
        home_row = QHBoxLayout()
        for w, s in ((self.home_edit, 1), (self.browse_btn, 0), (self.detect_btn, 0)):
            home_row.addWidget(w, s)
        # --- Databases
        self.db_combo = QComboBox()
        self.add_btn, self.edit_btn, self.delete_btn = QPushButton("Add Database"), QPushButton("Edit"), QPushButton("Delete")
        self.add_btn.setObjectName("primary")
        self.db_details = _label()
        card = QFrame()
        card.setObjectName("card")
        QVBoxLayout(card).addWidget(self.db_details)
        db_row = QHBoxLayout()
        db_row.addWidget(self.db_combo, 1)
        for b in (self.add_btn, self.edit_btn, self.delete_btn):
            db_row.addWidget(b)
        self.test_btn = QPushButton("Test Connection")
        self.test_btn.setEnabled(False)
        self.test_btn.setToolTip("Connect with the stored login and report the database state.")
        # --- Retention, theme
        self.retention = QSpinBox()
        self.retention.setRange(1, 3650)
        self.retention.setFixedWidth(120)
        self.theme_combo = QComboBox()
        self.theme_combo.addItem("Dark", "dark")
        self.theme_combo.addItem("Light", "light")
        self.theme_combo.setFixedWidth(160)
        self.validate_btn, self.save_btn = QPushButton("Validate"), QPushButton("Save")
        self.save_btn.setObjectName("primary")
        self.shared_note = _label()
        self.status = _label()
        buttons = QHBoxLayout()
        buttons.addWidget(self.validate_btn)
        buttons.addWidget(self.save_btn)
        buttons.addStretch(1)
        # --- Redesign (5E): the widgets above are the original ones, wired as before; they are only placed into cards here.
        for field in (self.db_combo, self.theme_combo, self.retention):
            field.setProperty("value", "bold")
        indent = 30                                             # card icon 22 + spacing 8: the controls line up under the card title
        self.home_ok_icon = self._icon("check_circle", 16)       # shown while the Oracle Home check says "ok" (see _update_home_status)
        self.home_ok_icon.setVisible(False)
        status_row = QHBoxLayout()
        status_row.setContentsMargins(indent, 0, 0, 0)
        status_row.setSpacing(6)
        status_row.addWidget(self.home_ok_icon, 0, Qt.AlignmentFlag.AlignTop)
        status_row.addWidget(self.home_status, 1)
        home_row.setContentsMargins(indent, 0, 0, 0)
        for button, kind in ((self.browse_btn, "folder"), (self.detect_btn, "search"), (self.add_btn, "plus_circle"), (self.edit_btn, "pencil"),
                             (self.delete_btn, "trash"), (self.test_btn, "link"), (self.validate_btn, "check"), (self.save_btn, "save")):
            button.setIconSize(QSize(18, 18))
            self._button_icons.append((button, kind))

        home_card, home_body = self._card("database", "Oracle Home", "Oracle Home (default for all databases)")
        home_body.addLayout(home_row)
        home_body.addLayout(status_row)
        db_card, db_body = self._card("database", "Databases")
        db_body.addLayout(db_row)
        db_body.addWidget(card)
        db_body.addWidget(self.test_btn)
        retention_card, retention_body = self._card("calendar", "Report/Log Retention", "Number of days to keep generated reports and log files.")
        retention_row = QHBoxLayout()
        retention_row.setContentsMargins(indent, 0, 0, 0)
        retention_row.addWidget(self.retention)
        retention_row.addStretch(1)
        retention_body.addLayout(retention_row)
        theme_card, theme_body = self._card("palette", "Theme", "Application appearance theme.")
        theme_row = QHBoxLayout()
        theme_row.setContentsMargins(indent, 0, 0, 0)
        theme_row.addWidget(self.theme_combo)
        theme_row.addStretch(1)
        theme_body.addLayout(theme_row)
        small_cards = QHBoxLayout()
        small_cards.setSpacing(10)
        small_cards.addWidget(retention_card, 1)
        small_cards.addWidget(theme_card, 1)

        texts = QVBoxLayout()
        texts.setSpacing(0)
        texts.addWidget(title)
        texts.addWidget(_label("Configure Oracle connection, databases, report retention and application theme."))
        heading = QHBoxLayout()
        heading.setSpacing(12)
        heading.addWidget(self._icon("settings", 32), 0, Qt.AlignmentFlag.AlignTop)
        heading.addLayout(texts, 1)

        box = QVBoxLayout(self)
        box.setContentsMargins(32, 8, 32, 16)
        box.setSpacing(10)
        box.addLayout(heading)
        box.addWidget(home_card)
        box.addWidget(db_card)
        box.addLayout(small_cards)
        box.addLayout(buttons)
        box.addWidget(self.shared_note)
        box.addWidget(self.status)
        box.addStretch(1)
        self._backdrop = PageBackdrop(self, self._cards, self._theme_name, lambda: self._cards[0].y())      # faint wave + soft card shadows

        self.browse_btn.clicked.connect(self.browse)
        self.detect_btn.clicked.connect(self.detect)
        self.home_edit.editingFinished.connect(self._update_home_status)
        self.add_btn.clicked.connect(self.add_database)
        self.edit_btn.clicked.connect(self.edit_database)
        self.delete_btn.clicked.connect(self.delete_database)
        self.db_combo.currentIndexChanged.connect(lambda _i: self._update_db_details())
        self.validate_btn.clicked.connect(self.run_validate)
        self.save_btn.clicked.connect(self.save)
        self.test_btn.clicked.connect(self.test_connection)
        self.gate.changed.connect(lambda _busy: self._update_test_btn())
        self._sync_theme_combo(theme.theme)
        self.theme_combo.currentIndexChanged.connect(lambda _i: self.theme.set_theme(self.theme_combo.currentData()))
        theme.changed.connect(self._sync_theme_combo)
        theme.changed.connect(lambda _name: self._apply_skin())
        self._apply_skin()
        self.load_shared()
        self.refresh_databases()

    # ---------------------------------------------------------------- look (5E)
    def _theme_name(self) -> str:
        return self.theme.theme

    def _icon(self, kind: str, size: int) -> QLabel:
        label = QLabel()
        label.setFixedSize(size, size)
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._icons.append((label, kind, size))
        return label

    def _card(self, kind: str, title: str, subtitle: str | None = None) -> tuple:
        """A section card: icon + title (+ subtitle) on top; returns (frame, body layout)."""
        frame = QFrame()
        frame.setObjectName("card")
        body = QVBoxLayout(frame)
        body.setContentsMargins(14, 12, 14, 12)
        body.setSpacing(8)
        texts = QVBoxLayout()
        texts.setSpacing(0)
        texts.addWidget(_label(title, "section", False))
        if subtitle:
            texts.addWidget(_label(subtitle))
        head = QHBoxLayout()
        head.setSpacing(8)
        head.addWidget(self._icon(kind, 22), 0, Qt.AlignmentFlag.AlignTop)
        head.addLayout(texts, 1)
        body.addLayout(head)
        self._cards.append(frame)
        return frame, body

    def _apply_skin(self) -> None:
        pal = PALETTES[self.theme.theme]
        self.setStyleSheet(_SKIN_QSS.substitute())
        for label, kind, size in self._icons:
            label.setPixmap(settings_pixmap(kind, pal["ok"] if kind == "check_circle" else pal["accent_text"], size))
        for button, kind in self._button_icons:
            button.setIcon(QIcon(settings_pixmap(kind, "#FFFFFF" if button.objectName() == "primary" else pal["text"], 18)))

    # ---------------------------------------------------------------- helpers
    @staticmethod
    def _set(label: QLabel, kind: str, text: str) -> None:
        label.setObjectName(kind)
        label.setText(text)
        label.style().unpolish(label)
        label.style().polish(label)

    def _sync_theme_combo(self, name: str) -> None:
        self.theme_combo.blockSignals(True)
        self.theme_combo.setCurrentIndex(self.theme_combo.findData(name))
        self.theme_combo.blockSignals(False)

    def _confirm(self, text: str) -> bool:
        return QMessageBox.question(self, "Oracle Health Check", text) == QMessageBox.StandardButton.Yes

    def _ask_create_thresholds(self) -> bool:
        return self._confirm("thresholds.json was not found. Create it with the default values and this retention?")

    # ---------------------------------------------------------------- shared configuration
    def load_shared(self) -> None:
        notes = []
        try:
            self.env_values, self.env_ok = dict(environment.load_environment(self.ctx.environment_path).values), True
        except environment.EnvConfigMissingError:
            self.env_values, self.env_ok = dict(environment.DEFAULTS), True
            notes.append("environment.json was not found; saving will create it.")
        except ConfigFileError as exc:
            self.env_ok = False
            notes.append(str(exc))
        try:
            self.th_values, self.th_state = thresholds.load_thresholds(self.ctx.thresholds_path).as_dict(), "ok"
        except thresholds.ThresholdsMissingError:
            self.th_values, self.th_state = dict(thresholds.DEFAULTS), "missing"
            notes.append("thresholds.json was not found; saving will offer to create it.")
        except thresholds.ThresholdsError as exc:
            self.th_state = "invalid"
            notes.append(str(exc))
        self.home_edit.setText(self.env_values["ORACLE_HOME"] if self.env_ok else "")
        self.retention.setValue(self.th_values["RETENTION_DAYS"])
        for w in (self.home_edit, self.browse_btn, self.detect_btn):
            w.setEnabled(self.env_ok)
        self.retention.setEnabled(self.th_state != "invalid")
        self.save_btn.setEnabled(self.env_ok and self.th_state != "invalid")
        self._set(self.shared_note, "warn" if notes else "muted", "\n".join(notes))
        self._update_home_status()

    def _update_home_status(self) -> None:
        self._update_home_status_text()
        self.home_ok_icon.setVisible(self.home_status.objectName() == "ok")      # the green check only while the check says "found"

    def _update_home_status_text(self) -> None:
        text = self.home_edit.text().strip()
        if not text:
            self._set(self.home_status, "warn", "Oracle Home is not configured. Use Browse or Detect, or set an Oracle Home per database.")
            return
        errors, warnings = oh.findings(oh.inspect_home(text), "all")
        if errors:
            self._set(self.home_status, "bad", "; ".join(errors))
        elif warnings:
            self._set(self.home_status, "warn", "sqlplus.exe found. " + " ".join(warnings))
        else:
            self._set(self.home_status, "ok", "sqlplus.exe and dgmgrl.exe found")

    def browse(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Select the Oracle Home")
        if folder:
            self.home_edit.setText(folder.replace("/", "\\"))
            self._update_home_status()

    def _choose_home(self, found: list) -> str:
        items = [f"{c.path}  ({c.source}{'' if c.sqlplus else ', no sqlplus.exe'})" for c in found]
        item, ok = QInputDialog.getItem(self, "Detect Oracle Home", "Oracle Homes found:", items, 0, False)
        return found[items.index(item)].path if ok else ""

    def detect(self) -> None:
        found = oh.detect_oracle_homes()
        if not found:
            self._set(self.status, "warn", "No Oracle client was found in the registry, the ORACLE_HOME variable or PATH.")
            return
        chosen = found[0].path if len(found) == 1 else self._choose_home(found)
        if chosen:
            self.home_edit.setText(chosen)
            self._update_home_status()

    def validate(self) -> tuple:
        errors, warnings = [], []
        text = self.home_edit.text().strip()
        if not text:
            warnings.append("Oracle Home (default) is not configured")
        elif msg := oh.check_home_syntax(text):
            errors.append(msg)
        else:
            e, w = oh.findings(oh.inspect_home(text), "all")
            warnings += e + w
        return errors, warnings

    def run_validate(self) -> tuple:
        errors, warnings = self.validate()
        if errors:
            self._set(self.status, "bad", "Invalid: " + "; ".join(errors))
        elif warnings:
            self._set(self.status, "warn", "Valid, with warnings: " + "; ".join(warnings))
        else:
            self._set(self.status, "ok", "Settings are valid.")
        return errors, warnings

    def save(self) -> bool:
        errors, _warnings = self.validate()
        if errors:
            self._set(self.status, "bad", "Not saved: " + "; ".join(errors))
            return False
        saved = []
        try:
            if self.env_ok:
                typed = self.home_edit.text().strip()
                environment.save_environment(self.ctx.environment_path, {**self.env_values, "ORACLE_HOME": typed})
                on_disk = environment.load_environment(self.ctx.environment_path).values["ORACLE_HOME"]     # read back the file the launcher reads
                if on_disk != (oh.normalize_home(typed) if typed else ""):
                    raise ConfigFileError(f"{self.ctx.environment_path} was written but does not contain the new Oracle Home")
                saved.append(f"environment.json ({self.ctx.environment_path})")
            days = self.retention.value()
            if self.th_state == "missing":
                if self._ask_create_thresholds():
                    thresholds.save_thresholds(self.ctx.thresholds_path, {**thresholds.DEFAULTS, "RETENTION_DAYS": days})
                    saved.append("thresholds.json (created)")
            elif self.th_state == "ok" and days != self.th_values["RETENTION_DAYS"]:
                current = thresholds.load_thresholds(self.ctx.thresholds_path).as_dict()  # re-read: keep other people's edits
                thresholds.save_thresholds(self.ctx.thresholds_path, {**current, "RETENTION_DAYS": days})
                saved.append("thresholds.json")
        except (ConfigFileError, thresholds.ThresholdsError) as exc:
            self._set(self.status, "bad", f"Not saved: {exc}")
            return False
        self.load_shared()
        if self.th_state == "missing":
            self.retention.setValue(days)  # keep what the user typed when thresholds.json was not created
        self._set(self.status, "ok", "Saved: " + ", ".join(saved) if saved else "Nothing to save.")
        return True

    # ---------------------------------------------------------------- databases
    def _db_enabled(self) -> bool:
        return not self.ctx.databases_error and self.ctx.credentials_dir is not None

    def current_entry(self):
        return self.ctx.databases.get(self.db_combo.currentData()) if self._db_enabled() else None

    def _update_test_btn(self, enabled=None, entry=None) -> None:
        if enabled is None:
            enabled, entry = self._db_enabled(), self.current_entry()
        self.test_btn.setEnabled(bool(enabled and entry is not None and not self.gate.busy))

    def test_connection(self) -> None:
        entry = self.current_entry()
        if entry is None or self.gate.busy:
            return
        text, level = outcomes.fake_status()
        if level == "bad":
            self._set(self.status, "bad", text)
            return
        if level != "warn" and not entry.oracle_home.strip() and self.home_edit.text().strip() != getattr(self, "env_values", {}).get("ORACLE_HOME", ""):
            self._set(self.status, "warn", "The Oracle Home shown above has not been saved yet. Click Save first, then Test Connection "
                                           f"(the connection test uses the saved value in {self.ctx.environment_path}).")
            return
        fake, name, ctx = level == "warn", entry.name, self.ctx
        self._set(self.status, "muted", f"Testing the connection to {name} ..." + (" (simulated)" if fake else ""))
        holder, self._test_db_id = {}, entry.id

        def job(emit):
            holder["probe"] = launcher.test_connection(ctx, name)
            return outcomes.for_probe(holder["probe"], fake)
        self._test_probe = holder
        thread = JobThread(job, fake, self)
        thread.done.connect(self._test_done)
        thread.finished.connect(self._test_finished)
        self._test_thread = thread
        self.gate.begin()
        thread.start()

    def _test_done(self, outcome) -> None:
        level, extra = outcome.level, self._save_run_mode(getattr(self, "_test_probe", {}).get("probe"))
        if extra and level == "ok" and extra.startswith("Run mode could not"):
            level = "warn"
        self._set(self.status, level, outcome.text() + (f"\n{outcome.detail}" if outcome.detail else "") + (f"\n{extra}" if extra else ""))

    def _save_run_mode(self, probe) -> str:
        """Test Connection classifies the database once (SWITCHOVER_STATUS) and saves it for the Dashboard Run button."""
        mode = getattr(probe, "mode", None)
        if probe is None or probe.kind != "OK" or mode is None:
            return ""                                   # not connected: keep whatever was saved
        try:
            dbadmin.set_run_mode(self.ctx.databases, self._test_db_id, mode.mode, mode.status)
        except Exception as exc:                        # DatabasesError etc.: the connection test itself still succeeded
            return f"Run mode could not be saved: {exc}"
        if not mode.mode:
            return f"Run mode could not be determined ({mode.error}). Dashboard Run will run All Checks; run Test Connection again."
        label = "Standard database - Dashboard Run uses 1. Oracle Health Check" if mode.mode == "standard" else "Data Guard related database - Dashboard Run uses 3. All Checks"
        return f"Run mode: {label} (SWITCHOVER_STATUS = {mode.status})"

    def _test_finished(self) -> None:
        thread, self._test_thread = self._test_thread, None
        if thread is not None:
            thread.deleteLater()
        self.gate.end()

    def refresh_databases(self, select_id=None) -> None:
        self.db_combo.blockSignals(True)
        self.db_combo.clear()
        for e in self.ctx.databases.entries():
            self.db_combo.addItem(e.name, e.id)
        if select_id is not None:
            self.db_combo.setCurrentIndex(max(0, self.db_combo.findData(select_id)))
        self.db_combo.blockSignals(False)
        self._update_db_details()

    def _update_db_details(self) -> None:
        enabled, entry = self._db_enabled(), self.current_entry()
        self._update_test_btn(enabled, entry)
        self.add_btn.setEnabled(enabled)
        self.edit_btn.setEnabled(entry is not None)
        self.delete_btn.setEnabled(entry is not None)
        if not enabled:
            self._set(self.db_details, "bad", self.ctx.databases_error or "Databases cannot be edited (no per-user folder).")
        elif entry is None:
            self._set(self.db_details, "muted", "No databases configured. Click Add Database.")
        else:
            login = "stored (encrypted)" if credstore.has_credentials(self.ctx.credentials_dir, entry.id) else "NOT stored: edit the database to enter it"
            self._set(self.db_details, "muted", f"SID: {entry.effective_sid}\nData Guard service: {entry.dg_service or '-'}\n"
                      f"Oracle Home: {entry.oracle_home or 'default (shared)'}\nLogin: {login}")

    def add_database(self) -> None:
        dialog = DatabaseDialog(self.ctx, parent=self)
        if dialog.exec():
            self.refresh_databases(dialog.result_entry.id)

    def edit_database(self) -> None:
        entry = self.current_entry()
        if entry is None:
            return
        dialog = DatabaseDialog(self.ctx, entry, parent=self)
        if dialog.exec():
            self.refresh_databases(entry.id)

    def delete_database(self) -> None:
        entry = self.current_entry()
        if entry is None or not self._confirm(f"Delete database '{entry.name}' and its stored login?"):
            return
        try:
            dbadmin.delete_database(self.ctx.databases, self.ctx.credentials_dir, entry.id)
            if self.ctx.settings.get("default_db") == entry.id:
                self.ctx.settings.set("default_db", "")
        except (ConfigFileError, OSError) as exc:
            self._set(self.status, "bad", f"Not deleted: {exc}")
        self.refresh_databases()
