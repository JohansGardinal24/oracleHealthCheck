"""Background execution for the GUI: one job at a time, never on the GUI thread."""
from __future__ import annotations

from PySide6.QtCore import QObject, QThread, Signal

from ohc.gui import outcomes


class JobGate(QObject):
    """Shared 'a job is running' flag; every Run / Test Connection button follows it."""
    changed = Signal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.busy = False

    def begin(self) -> None:
        self.busy = True
        self.changed.emit(True)

    def end(self) -> None:
        self.busy = False
        self.changed.emit(False)


class JobThread(QThread):
    """Runs job(emit_line) -> Outcome. 'line' and 'done' are delivered to the GUI thread; 'finished' follows 'done'."""
    line = Signal(str)
    done = Signal(object)
    event = Signal(object)  # engine progress events ('plan' / 'start' / 'done'), delivered to the GUI thread

    def __init__(self, job, fake: bool = False, parent=None):
        super().__init__(parent)
        self._job, self._fake = job, fake

    def run(self) -> None:
        try:
            outcome = self._job(self.line.emit)
        except Exception as exc:  # a tool/configuration error or a bug: shown, never silently lost
            outcome = outcomes.for_error(exc, self._fake)
        self.done.emit(outcome)
