"""ASH Report tab of Database Reports (a panel inside DatabaseReportsPage; the shell, database selector and tabs belong to that page).

Begin time (relative or specific) + duration + options -> one worker-thread job (JobThread + CancelToken) that runs
ohc.ash_service.generate_report. History comes from ohc.ash.scan_history.
"""
from __future__ import annotations

from datetime import datetime, timedelta
from functools import partial
from pathlib import Path

from PySide6.QtCore import QDate, QTime, Qt, QUrl
from PySide6.QtGui import QBrush, QColor, QDesktopServices, QGuiApplication
from PySide6.QtWidgets import (QAbstractItemView, QButtonGroup, QCheckBox, QComboBox, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit,
                               QMenu, QPlainTextEdit, QPushButton, QRadioButton, QSpinBox, QTableWidgetItem, QTimeEdit, QToolButton,
                               QVBoxLayout, QWidget)

from ohc import ash, ash_service, awr
from ohc.checks.cancel import CancelToken
from ohc.gui import outcomes
from ohc.gui.awr_page import ALL_DATES, AMBER, FittedTable, _card, _label
from ohc.gui.report_index import format_size
from ohc.gui.runner import JobThread
from ohc.gui.theme import PALETTES
from ohc.gui.widgets import WrapLabel

TIME_FORMATS = ("%d-%b-%Y %H:%M:%S", "%d-%b-%y %H:%M:%S", "%d-%b %H:%M:%S", "%d-%b %H:%M")
HIST_ROW_H = 30
UNIT_ITEMS = (("minutes before now", "minutes"), ("hours before now", "hours"), ("days before now", "days"))
UNIT_LIMIT = {"minutes": 10080, "hours": 168, "days": 7}      # 7 days at most, in each unit

_QSS = """
QLabel#infoBox { background: rgba(37, 99, 235, 45); border-radius: 4px; padding: 3px 8px; }
QFrame#group { }
"""


class AshPanel(QWidget):
    def __init__(self, ctx, gate, db_name_fn, page=None):
        super().__init__(page)
        self.ctx, self.gate, self._db_name, self._page = ctx, gate, db_name_fn, page
        self._thread = self._token = None
        self._cancelling = False
        self._err = self._name_err = ""
        self._name_flag = False
        self._level = "muted"
        self._abs_touched = False
        self._fmt_idx = 0
        self.entries: list = []
        self.last_scan = ash.HistoryScan()
        self._build()
        self.setStyleSheet(_QSS)
        gate.changed.connect(lambda _b: self._update_enabled())
        self._set_abs_to_default()
        self._recompute()
        self.refresh_history()

    # ------------------------------------------------------------------ construction
    def _build(self) -> None:
        # ---- Begin Time
        self.rel_radio = QRadioButton("Relative time (from now)")
        self.abs_radio = QRadioButton("Specific date and time")
        self.mode_group = QButtonGroup(self)
        self.mode_group.addButton(self.rel_radio)
        self.mode_group.addButton(self.abs_radio)
        self.rel_radio.setChecked(True)
        self.rel_spin = QSpinBox()
        self.rel_spin.setRange(-UNIT_LIMIT["minutes"], -1)
        self.rel_spin.setValue(-15)
        self.rel_spin.setKeyboardTracking(False)
        self.rel_spin.setFixedWidth(88)
        self.unit_combo = QComboBox()
        for text, key in UNIT_ITEMS:
            self.unit_combo.addItem(text, key)
        rel_row = QHBoxLayout()
        rel_row.setSpacing(6)
        rel_row.addSpacing(22)
        rel_row.addWidget(self.rel_spin)
        rel_row.addWidget(self.unit_combo, 1)
        self.rel_help = _label("Negative values count back from now. Default: the last 15 minutes.")
        self.rel_help.setWordWrap(True)
        self.summary = WrapLabel("")
        self.summary.setObjectName("infoBox")
        self.month = QComboBox()
        self.month.addItems([str(i) for i in range(1, 13)])
        self.day = QComboBox()
        self.day.addItems([str(i) for i in range(1, 32)])
        year = datetime.now().year
        self.year = QComboBox()
        self.year.addItems([str(year - 1), str(year)])
        self.time_edit = QTimeEdit()
        self.time_edit.setDisplayFormat("HH:mm:ss")
        self.time_edit.setTime(QTime(0, 0, 0))
        grid = QGridLayout()
        grid.setHorizontalSpacing(6)
        grid.setVerticalSpacing(1)
        for col, (text, widget) in enumerate((("Month", self.month), ("Day", self.day), ("Year", self.year), ("Time (HH:MM:SS)", self.time_edit))):
            grid.addWidget(_label(text), 0, col)
            grid.addWidget(widget, 1, col)
        grid.setColumnStretch(3, 1)
        begin, bbox = _card()
        bbox.setContentsMargins(10, 6, 10, 6)
        bbox.setSpacing(3)
        bbox.addWidget(_label("Begin Time", "strong"))
        bbox.addWidget(self.rel_radio)
        bbox.addLayout(rel_row)
        bbox.addWidget(self.rel_help)
        bbox.addWidget(self.summary)
        bbox.addWidget(self.abs_radio)
        bbox.addLayout(grid)
        bbox.addStretch(1)

        # ---- Duration
        self.duration = QSpinBox()
        self.duration.setRange(ash.DUR_MIN, ash.DUR_MAX)
        self.duration.setValue(15)
        self.duration.setKeyboardTracking(False)
        self.dur_help = _label(f"Used for a specific date/time (end = begin + duration, {ash.DUR_MIN}-{ash.DUR_MAX} minutes). "
                               "Ignored for relative time: the window then ends now.")
        self.dur_help.setWordWrap(True)
        dur, dbox = _card()
        dbox.setContentsMargins(10, 6, 10, 6)
        dbox.setSpacing(3)
        dbox.addWidget(_label("Duration", "strong"))
        dbox.addWidget(_label("Duration (minutes):"))
        dbox.addWidget(self.duration)
        dbox.addWidget(self.dur_help)
        dbox.addStretch(1)

        # ---- Options
        self.type_combo = QComboBox()
        self.type_combo.addItem("HTML (Default)", "html")
        self.type_combo.addItem("Text", "text")
        self.type_combo.setToolTip("HTML: ASH_REPORT_HTML / ASH_GLOBAL_REPORT_HTML.  Text: ASH_REPORT_TEXT / ASH_GLOBAL_REPORT_TEXT.")
        self.name_edit = QLineEdit(ash.DEFAULT_NAME)
        self.name_edit.setObjectName("awrName")
        self.name_edit.setMaxLength(awr.NAME_MAX + len(awr.NAME_TOKEN))
        self.name_edit.setToolTip("File name without extension: letters, digits, _ and - only.\n"
                                  f"{awr.NAME_TOKEN} is replaced by the generation time. An existing file is never overwritten.")
        self.name_label = _label("Report Name (.html)")
        self.rac_check = QCheckBox("Include RAC Information (if applicable)")
        self.rac_check.setToolTip("Reports all open instances (DBMS_WORKLOAD_REPOSITORY.ASH_GLOBAL_REPORT_*). Unchecked: the connected instance only.")
        self.open_check = QCheckBox("Open report after generation")
        self.generate_btn = QPushButton("\u25B6  Generate ASH Report")
        self.generate_btn.setObjectName("primary")
        self.cancel_btn = QPushButton("\u25A0  Cancel")
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.setToolTip("Stop safely: the running SQL*Plus process is ended and any incomplete report file is removed.")
        self.status = QPlainTextEdit()
        self.status.setObjectName("awrStatus")
        self.status.setReadOnly(True)
        self.status.setFixedHeight(46)
        self.status.setFrameShape(QFrame.Shape.NoFrame)
        self.status.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        opt, obox = _card()
        obox.setContentsMargins(10, 6, 10, 6)
        obox.setSpacing(3)
        obox.addWidget(_label("Options", "strong"))
        obox.addWidget(_label("Report Type"))
        obox.addWidget(self.type_combo)
        obox.addWidget(self.name_label)
        obox.addWidget(self.name_edit)
        obox.addWidget(self.rac_check)
        obox.addWidget(self.open_check)
        obox.addStretch(1)
        btns = QHBoxLayout()
        btns.setSpacing(6)
        btns.addWidget(self.generate_btn, 3)
        btns.addWidget(self.cancel_btn, 1)
        obox.addLayout(btns)
        obox.addWidget(self.status)
        opt.setMinimumWidth(250)

        body = QHBoxLayout()
        body.setSpacing(10)
        body.addWidget(begin, 4)
        body.addWidget(dur, 2)
        body.addWidget(opt, 4)
        params, pbox = _card()
        pbox.setSpacing(4)
        title = QHBoxLayout()
        title.addWidget(_label("ASH Report Parameters", "section"))
        title.addWidget(_label("Select the begin time and duration to generate the ASH report."))
        title.addStretch(1)
        pbox.addLayout(title)
        pbox.addLayout(body, 1)

        # ---- history
        self.refresh_btn = QPushButton("\u27F3  Refresh")
        self.date_combo = QComboBox()
        self.date_combo.addItem(ALL_DATES, "")
        self.date_combo.setMinimumWidth(130)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search reports...")
        self.search.setClearButtonEnabled(True)
        self.search.setMaximumWidth(320)
        htitles = QVBoxLayout()
        htitles.setSpacing(0)
        htitles.addWidget(_label("Generated ASH Reports", "section"))
        htitles.addWidget(_label("Browse and open generated ASH reports."))
        hhead = QHBoxLayout()
        hhead.addLayout(htitles, 1)
        hhead.addWidget(self.refresh_btn, 0, Qt.AlignmentFlag.AlignTop)
        filters = QHBoxLayout()
        filters.setSpacing(6)
        filters.addWidget(_label("Filter by date:"))
        filters.addWidget(self.date_combo)
        filters.addSpacing(8)
        filters.addWidget(self.search, 1)
        filters.addStretch(1)
        self.hist_note = WrapLabel("")
        self.hist_note.setObjectName("muted")
        self.hist = FittedTable(0, 8, fixed={0: 120, 1: 66, 2: 130, 3: 130, 4: 70, 6: 70, 7: 150}, flex={5: 1}, flex_min=100)
        self.hist.setHorizontalHeaderLabels(["Date & Time", "DB", "Begin Time", "End Time", "Duration", "File Name", "Size", "Actions"])
        self.hist.verticalHeader().setVisible(False)
        self.hist.verticalHeader().setDefaultSectionSize(HIST_ROW_H)
        self.hist.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.hist.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.hist.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.hist.setShowGrid(False)
        self.hist.setWordWrap(False)
        self.hist.setTextElideMode(Qt.TextElideMode.ElideMiddle)
        self.hist.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.hist.horizontalHeader().setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.hist.setMinimumHeight(HIST_ROW_H * 3 + 28)
        self.hist.hint_height = 28 + HIST_ROW_H * 5
        self.hist.fitted.connect(self._refit_history)
        history, hbox = _card()
        hbox.setSpacing(4)
        hbox.addLayout(hhead)
        hbox.addLayout(filters)
        hbox.addWidget(self.hist_note)
        hbox.addWidget(self.hist, 1)

        box = QVBoxLayout(self)
        box.setContentsMargins(0, 0, 0, 0)
        box.setSpacing(6)
        box.addWidget(params, 0)
        box.addWidget(history, 1)
        self.outer_cards = (params, history)       # the two cards the page's wave backdrop puts shadows under

        for sig in (self.rel_radio.toggled, self.abs_radio.toggled):
            sig.connect(lambda _c: self._mode_changed())
        self.unit_combo.currentIndexChanged.connect(self._unit_changed)
        for w in (self.rel_spin, self.duration):
            w.valueChanged.connect(lambda _v: self._recompute())
        for w in (self.month, self.day, self.year):
            w.currentIndexChanged.connect(lambda _i: self._abs_edited())
        self.time_edit.timeChanged.connect(lambda _t: self._abs_edited())
        self.type_combo.currentIndexChanged.connect(self._format_changed)
        self.name_edit.textChanged.connect(lambda _t: self._validate_name())
        self.generate_btn.clicked.connect(self.generate)
        self.cancel_btn.clicked.connect(self.cancel)
        self.refresh_btn.clicked.connect(self.refresh_history)
        self.date_combo.currentIndexChanged.connect(lambda _i: self._fill_history())
        self.search.textChanged.connect(lambda _t: self._fill_history())

    # ------------------------------------------------------------------ parameters
    def is_relative(self) -> bool:
        return self.rel_radio.isChecked()

    def _set_abs_to_default(self) -> None:
        """Specific time defaults to 15 minutes ago (minute precision) so it is valid out of the box."""
        t = (datetime.now() - timedelta(minutes=15)).replace(second=0, microsecond=0)
        for combo, value in ((self.year, str(t.year)), (self.month, str(t.month)), (self.day, str(t.day))):
            combo.blockSignals(True)
            idx = combo.findText(value)
            combo.setCurrentIndex(max(0, idx))
            combo.blockSignals(False)
        self.time_edit.blockSignals(True)
        self.time_edit.setTime(QTime(t.hour, t.minute, 0))
        self.time_edit.blockSignals(False)

    def _unit_changed(self, _i) -> None:
        unit = self.unit_combo.currentData()
        self.rel_spin.setRange(-UNIT_LIMIT[unit], -1)        # clamps the value into the 7-day limit
        self._recompute()

    def _abs_edited(self) -> None:
        self._abs_touched = True
        self._recompute()

    def _mode_changed(self) -> None:
        if not self.is_relative() and not self._abs_touched:
            self._set_abs_to_default()
        self._recompute()

    def window(self):
        """(Window, '') or (None, reason) for the current inputs."""
        try:
            if self.is_relative():
                return ash.relative_window(self.rel_spin.value(), self.unit_combo.currentData()), ""
            t = self.time_edit.time()
            return ash.absolute_window(self.year.currentText(), self.month.currentText(), self.day.currentText(),
                                       t.hour(), t.minute(), t.second(), self.duration.value()), ""
        except ash.AshError as exc:
            return None, str(exc)

    def _recompute(self) -> None:
        rel = self.is_relative()
        self.rel_spin.setEnabled(rel and not self.gate.busy)
        self.unit_combo.setEnabled(rel and not self.gate.busy)
        for w in (self.month, self.day, self.year, self.time_edit):
            w.setEnabled((not rel) and not self.gate.busy)
        win, err = self.window()
        self._err = err
        if win is not None:
            self.summary.setText("Window: " + win.describe())
        else:
            self.summary.setText(err)
        if err and not self._busy():
            self._set_status("warn", err)
        self._update_enabled()

    def _format_changed(self, _i) -> None:
        self.name_label.setText(f"Report Name ({awr.FORMATS[self._fmt()]})")
        self._validate_name()

    def _fmt(self) -> str:
        return self.type_combo.currentData() or "html"

    def _validate_name(self) -> None:
        try:
            folder = awr_report_folder(self.ctx)
        except Exception:
            folder = None
        self._name_err = awr.check_report_name(self.name_edit.text(), self._fmt(), folder)
        self.name_edit.setProperty("invalid", "true" if self._name_err else "false")
        self.name_edit.style().unpolish(self.name_edit)
        self.name_edit.style().polish(self.name_edit)
        if self._name_err and not self._busy():
            self._name_flag = True
            self._set_status("warn", "Report Name: " + self._name_err)
        elif self._name_flag and not self._busy():
            self._name_flag = False
            self._set_status("muted", "Report Name is valid." if not self._err else self._err)
        self._update_enabled()

    # ------------------------------------------------------------------ state
    def _busy(self) -> bool:
        return self._thread is not None

    def _update_enabled(self) -> None:
        idle = not self.gate.busy
        rel = self.is_relative()
        self.rel_radio.setEnabled(idle)
        self.abs_radio.setEnabled(idle)
        self.rel_spin.setEnabled(idle and rel)
        self.unit_combo.setEnabled(idle and rel)
        for w in (self.month, self.day, self.year, self.time_edit):
            w.setEnabled(idle and not rel)
        for w in (self.duration, self.type_combo, self.name_edit, self.rac_check, self.open_check):
            w.setEnabled(idle)
        self.generate_btn.setEnabled(idle and bool(self._db_name()) and not self._err and not self._name_err)
        self.cancel_btn.setEnabled(self._busy() and not self._cancelling)

    def _set_status(self, level: str, text: str, detail: str = "") -> None:
        self._level = level if level in ("ok", "warn", "bad") else "muted"
        full = text + (("\n" + detail) if detail else "")
        self.status.setPlainText(full)
        self.status.setToolTip(full)
        self.repaint_status()

    def repaint_status(self) -> None:
        pal = getattr(self._page, "_pal", None) or PALETTES["dark"]
        self.status.setStyleSheet(f"QPlainTextEdit#awrStatus {{ color: {pal.get(self._level, pal['muted'])}; }}")

    # ------------------------------------------------------------------ job
    def generate(self) -> None:
        if self.gate.busy or self._busy():
            return
        name = self._db_name()
        win, err = self.window()
        if not name:
            self._set_status("warn", "Select a database first.")
            return
        if win is None or self._name_err:
            self._set_status("warn", err or ("Report Name: " + self._name_err))
            return
        text, level = outcomes.fake_status()
        if level == "bad":
            self._set_status("bad", text)
            return
        fmt, rname, rac, ctx = self._fmt(), self.name_edit.text(), self.rac_check.isChecked(), self.ctx
        self._name_flag = False
        self._set_status("muted", f"Generating the {'Text' if fmt == 'text' else 'HTML'} ASH report{' (RAC, all instances)' if rac else ''} on {name}: "
                         f"{win.describe()} ..." + (" (simulated)" if level == "warn" else ""))
        self._token, self._cancelling = CancelToken(), False
        token = self._token
        thread = JobThread(lambda emit: ash_service.generate_report(ctx, name, win, token, fmt, rname, rac), level == "warn", self)
        thread.done.connect(self._done)
        thread.finished.connect(self._finished)
        self._thread = thread
        self.gate.begin()
        thread.start()
        self._update_enabled()

    def cancel(self) -> None:
        if self._thread is None or self._token is None or self._cancelling:
            return
        self._cancelling = True
        self.cancel_btn.setEnabled(False)
        self._set_status("warn", "Cancelling - waiting for SQL*Plus to stop ...")
        self._token.request()

    def _done(self, r) -> None:
        if not isinstance(r, ash_service.AwrResult):        # JobThread's safety net for an unexpected exception
            self._set_status("bad", getattr(r, "headline", "Unexpected error"), getattr(r, "detail", ""))
        elif r.cancelled:
            self._set_status("warn", r.message)
        elif not r.ok:
            self._set_status("bad", r.message, r.detail)
        else:
            self._set_status("warn" if r.note else "ok", r.message, r.note)
            self.reveal(r.path)
            if self.open_check.isChecked():
                self.open_path(r.path)

    def _finished(self) -> None:
        thread, self._thread = self._thread, None
        self._token, self._cancelling = None, False
        if thread is not None:
            thread.deleteLater()
        self.gate.end()
        self._validate_name()          # the name may now exist
        self._update_enabled()

    # ------------------------------------------------------------------ history
    def refresh_history(self) -> None:
        self.last_scan = ash.scan_history(Path(self.ctx.root) / "reports", index_dir=awr.index_dir_for(self.ctx.root))
        self.entries = self.last_scan.entries
        keep = self.date_combo.currentData() or ""
        self.date_combo.blockSignals(True)
        self.date_combo.clear()
        self.date_combo.addItem(ALL_DATES, "")
        for d in awr.dates_of(self.entries):
            self.date_combo.addItem(d, d)
        self.date_combo.setCurrentIndex(max(0, self.date_combo.findData(keep)))
        self.date_combo.blockSignals(False)
        self._fill_history()

    def reveal(self, path) -> None:
        self.refresh_history()
        shown = awr.filter_entries(self.entries, self.date_combo.currentData() or "", self.search.text())
        if not any(e.path == Path(path) for e in shown):
            self.search.blockSignals(True)
            self.search.clear()
            self.search.blockSignals(False)
            self.date_combo.blockSignals(True)
            self.date_combo.setCurrentIndex(0)
            self.date_combo.blockSignals(False)
            self._fill_history()
        for row in range(self.hist.rowCount()):
            if self.hist.item(row, 5).data(Qt.ItemDataRole.UserRole) == str(path):
                self.hist.selectRow(row)
                self.hist.scrollToItem(self.hist.item(row, 5))
                break

    def _stamp(self, dt, fmt) -> str:
        return dt.strftime(fmt).upper() if dt else "-"

    def _fill_history(self) -> None:
        shown = awr.filter_entries(self.entries, self.date_combo.currentData() or "", self.search.text())
        fmt = getattr(self, "_hfmt", TIME_FORMATS[0])
        self.hist.setUpdatesEnabled(False)
        self.hist.setRowCount(0)
        self.hist.setRowCount(len(shown))
        for row, e in enumerate(shown):
            texts = (e.when.strftime("%Y-%m-%d %H:%M"), e.db + (" [SIM]" if e.simulated else ""), self._stamp(e.begin, fmt), self._stamp(e.end, fmt),
                     e.duration_text, e.name, format_size(e.size))
            for col, text in enumerate(texts):
                item = QTableWidgetItem(text)
                item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
                item.setToolTip(str(e.path) if col == 5 else ("Simulated report: no database was contacted." if e.simulated and col == 1 else text))
                if col in (2, 3) and e.begin:
                    item.setToolTip((e.begin if col == 2 else e.end).strftime(awr.SHOW_FMT).upper())
                self.hist.setItem(row, col, item)
            self.hist.item(row, 5).setData(Qt.ItemDataRole.UserRole, str(e.path))
            self.hist.item(row, 2).setData(Qt.ItemDataRole.UserRole, e.begin)
            self.hist.item(row, 3).setData(Qt.ItemDataRole.UserRole, e.end)
            self.hist.setCellWidget(row, 7, self._actions(e.path))
        self.hist.setUpdatesEnabled(True)
        if not self.last_scan.exists:
            note = "The reports folder does not exist yet - it is created when the first report is generated."
        elif not self.entries:
            note = "No ASH reports have been generated yet."
        elif not shown:
            note = "No reports match the filter."
        else:
            note = ""
        self.hist_note.setText((note + " " + self.last_scan.note).strip())
        self.hist_note.setVisible(bool(self.hist_note.text()))

    def _refit_history(self) -> None:
        """Fixed columns from the font; Begin/End use the longest timestamp format that fits (never clipped)."""
        fm = self.hist.fontMetrics()
        probe = QPushButton("Open Report")
        probe.setObjectName("cellBtn")
        probe.setStyleSheet(self.styleSheet() + (self._page.styleSheet() if self._page is not None else ""))
        text = lambda sample: fm.horizontalAdvance(sample) + 22
        db_w = max([text("PROD_DB_01")] + [text(e.db + (" [SIM]" if e.simulated else "")) for e in self.entries[:200]])
        sample = datetime(2026, 9, 30, 23, 59, 59)
        total = self.hist.viewport().width()
        fixed = {0: text("0000-00-00 00:00"), 1: min(db_w, 80), 4: text("000 mins"), 6: text("000.0 MB"), 7: probe.sizeHint().width() + 28 + 8 + 12}
        name_w = fm.horizontalAdvance("ASH_Report_00000000_000000.html") + 16
        left = total - sum(fixed.values()) - name_w
        fmt = next((f for f in TIME_FORMATS if (fm.horizontalAdvance(sample.strftime(f).upper()) + 22) * 2 <= left), TIME_FORMATS[-1])
        per = fm.horizontalAdvance(sample.strftime(fmt).upper()) + 22
        fixed.update({2: per, 3: per})
        self.hist._fixed.update(fixed)
        self.hist._flex_min = 100
        from ohc.gui.widgets import FitTable
        FitTable.fit_columns(self.hist)
        if fmt != getattr(self, "_hfmt", TIME_FORMATS[0]):
            self._hfmt = fmt
            for row in range(self.hist.rowCount()):
                for col in (2, 3):
                    self.hist.item(row, col).setText(self._stamp(self.hist.item(row, col).data(Qt.ItemDataRole.UserRole), fmt))

    def _actions(self, path: Path) -> QWidget:
        """One Open Report button and one menu per row, bound to THIS row's file."""
        holder = QWidget()
        lay = QHBoxLayout(holder)
        lay.setContentsMargins(4, 2, 4, 2)
        lay.setSpacing(4)
        open_btn = QPushButton("Open Report")
        open_btn.setObjectName("cellBtn")
        open_btn.clicked.connect(partial(self.open_path, path))
        menu_btn = QToolButton()
        menu_btn.setObjectName("cellMenu")
        menu_btn.setText("\u25BE")
        menu_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        menu = QMenu(menu_btn)
        menu.addAction("Open Report").triggered.connect(partial(self.open_path, path))
        menu.addAction("Open Containing Folder").triggered.connect(partial(self.open_folder, path))
        menu.addAction("Copy File Path").triggered.connect(partial(QGuiApplication.clipboard().setText, str(path)))
        menu_btn.setMenu(menu)
        lay.addWidget(open_btn, 1)
        lay.addWidget(menu_btn)
        holder.open_btn, holder.menu_btn, holder.path = open_btn, menu_btn, path
        return holder

    def _exists(self, path: Path) -> bool:
        if Path(path).is_file():
            return True
        self._set_status("warn", f"The report no longer exists: {Path(path).name}")
        self.refresh_history()
        return False

    def open_path(self, path) -> None:
        if self._exists(Path(path)):
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def open_folder(self, path) -> None:
        if self._exists(Path(path)):
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(path).parent)))

    def showEvent(self, event) -> None:
        super().showEvent(event)
        if not self._busy():
            self.refresh_history()
            self._validate_name()
            self._update_enabled()


def awr_report_folder(ctx):
    from ohc import awr_service
    return awr_service.report_folder(ctx)
