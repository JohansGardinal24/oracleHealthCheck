"""Light and dark themes: one palette per theme, one stylesheet template, programmatic sun/moon icons.

Oracle red accent on a charcoal (dark) or white / light-grey (light) base."""
from __future__ import annotations

import math
import tempfile
from pathlib import Path
from string import Template

from PySide6.QtCore import QObject, QPointF, Qt, Signal
from PySide6.QtGui import QColor, QGuiApplication, QIcon, QPainter, QPainterPath, QPen, QPixmap, QPolygonF
from PySide6.QtWidgets import QApplication

from ohc.config.jsonio import ConfigFileError
from ohc.config.settings import THEMES

FONT_FAMILIES = ["Segoe UI Variable Text", "Segoe UI", "Inter", "Arial"]

# Oracle red is the accent (primary buttons, selected navigation, focus, active tab). Status colours stay green / amber / red.
# Every key of the previous palette is kept (other pages substitute them into their own style sheets); new keys are only added.
PALETTES = {
    "dark": dict(bg="#0F1218", sidebar="#0B0E13", sidebar_text="#E6EAF2", sidebar_hover="#171C26", sidebar_border="#1C222D",
                 card="#161B24", input_bg="#0F131A", border="#262D3A", text="#E6EAF2", muted="#8B95A7",
                 accent="#C74634", accent_hover="#B13C2C", accent_text="#F2705E", accent_tint="#3A2427",
                 button_bg="#1C222D", button_hover="#252D3B", header_bg="#1A202B", row_hover="#1B2230",
                 ok="#4ADE80", bad="#F87171", warn="#FBBF24", toggle_hover="#1C222D", icon="#F6C453"),
    "light": dict(bg="#F4F5F7", sidebar="#F5F3F2", sidebar_text="#1F2530", sidebar_hover="#EAE6E3", sidebar_border="#E2DDDA",
                  card="#FFFFFF", input_bg="#FFFFFF", border="#E1E4EA", text="#1A1F29", muted="#667085",
                  accent="#C74634", accent_hover="#B13C2C", accent_text="#B63D2D", accent_tint="#FAEEEC",
                  button_bg="#F1F3F6", button_hover="#E6E9EE", header_bg="#F6F7F9", row_hover="#F5F6F8",
                  ok="#15803D", bad="#DC2626", warn="#B45309", toggle_hover="#E9ECF1", icon="#1A1F29"),
}

_QSS = Template("""
QWidget { color: $text; font-size: 13px; }
QMainWindow, QDialog, QMessageBox, QWidget#content, QWidget#page, QWidget#pageHost { background: $bg; }

/* ---- sidebar (ohc/gui/sidebar.py): compact */
QFrame#nav { background: $sidebar; border: none; border-right: 1px solid $sidebar_border; }
QLabel#brandWord { color: $accent_text; font-size: 16px; font-weight: 700; }
QLabel#brand { color: $sidebar_text; font-size: 13px; font-weight: 700; }
QLabel#navSection { color: $muted; font-size: 10px; font-weight: 700; padding: 20px 10px 6px 10px; }
QFrame#navDivider { background: $sidebar_border; border: none; margin: 5px 6px; }
QLabel#navFooter { color: $muted; font-size: 10px; padding: 6px 10px 0 10px; }
QPushButton#navItem, QPushButton#navSub { background: transparent; border: none; border-radius: 6px; padding: 8px 10px;
    text-align: left; color: $sidebar_text; font-size: 12px; font-weight: 500; }
QPushButton#navSub { padding: 7px 8px; }
QPushButton#navItem:hover, QPushButton#navSub:hover { background: $sidebar_hover; }
QPushButton#navItem[active="true"] { color: $accent_text; font-weight: 600; }
QPushButton#navItem:checked, QPushButton#navSub:checked { background: $accent; color: #FFFFFF; font-weight: 600; }
QPushButton#navItem[collapsed="true"] { text-align: center; padding: 9px 0; }
QFrame#navSubBox { background: transparent; border: none; }
QToolButton#themeToggle { background: transparent; border: 1px solid transparent; border-radius: 18px; padding: 4px; }
QToolButton#themeToggle:hover { background: $toggle_hover; border: 1px solid $border; }
QToolButton#navToggle { background: transparent; border: 1px solid transparent; border-radius: 8px; padding: 4px; }
QToolButton#navToggle:hover { background: $sidebar_hover; }

/* ---- top bar */
QFrame#header { background: $bg; border: none; border-bottom: 1px solid $border; }
QLabel#crumb { font-size: 14px; font-weight: 600; }

/* ---- text */
QLabel { background: transparent; }
QLabel#title { font-size: 24px; font-weight: 600; }
QLabel#section { font-size: 16px; font-weight: 600; }
QLabel#stateTitle { font-size: 18px; font-weight: 600; }
QLabel#strong { font-weight: 600; }
QLabel#text { color: $text; }
QLabel#muted { color: $muted; }
QLabel#ok { color: $ok; }
QLabel#bad { color: $bad; }
QLabel#warn { color: $warn; }

/* ---- cards */
QFrame#card { background: $card; border: 1px solid $border; border-radius: 10px; }
QFrame#separator { background: $border; max-height: 1px; min-height: 1px; border: none; }
QScrollArea { background: transparent; border: none; }

/* ---- inputs */
QLineEdit, QSpinBox, QComboBox, QPlainTextEdit, QTextEdit { background: $input_bg; border: 1px solid $border; border-radius: 6px;
    padding: 6px 10px; selection-background-color: $accent; selection-color: #FFFFFF; }
QLineEdit:hover, QSpinBox:hover, QComboBox:hover { border: 1px solid $muted; }
QLineEdit:focus, QSpinBox:focus, QComboBox:focus, QPlainTextEdit:focus, QTextEdit:focus { border: 1px solid $accent; }
QLineEdit:disabled, QSpinBox:disabled, QComboBox:disabled { color: $muted; background: $button_bg; }
QComboBox { padding: 6px 28px 6px 10px; }
QComboBox::drop-down { subcontrol-origin: padding; subcontrol-position: center right; width: 24px; border: none; }
QComboBox::down-arrow { image: url($down_arrow); width: 10px; height: 10px; }
QComboBox QAbstractItemView { background: $card; color: $text; border: 1px solid $border; outline: none;
    selection-background-color: $accent; selection-color: #FFFFFF; }
QSpinBox { padding: 4px 26px 4px 10px; }
QSpinBox::up-button { subcontrol-origin: padding; subcontrol-position: top right; width: 22px; height: 14px;
    border: none; border-left: 1px solid $border; border-top-right-radius: 5px; background: $button_bg; }
QSpinBox::down-button { subcontrol-origin: padding; subcontrol-position: bottom right; width: 22px; height: 14px;
    border: none; border-left: 1px solid $border; border-top: 1px solid $border; border-bottom-right-radius: 5px; background: $button_bg; }
QSpinBox::up-button:hover, QSpinBox::down-button:hover { background: $button_hover; }
QSpinBox::up-arrow { image: url($up_arrow); width: 10px; height: 10px; }
QSpinBox::down-arrow { image: url($down_arrow); width: 10px; height: 10px; }
QCheckBox { spacing: 8px; }
QCheckBox::indicator { width: 14px; height: 14px; border: 1px solid $muted; border-radius: 3px; background: $input_bg; }
QCheckBox::indicator:hover { border: 1px solid $accent; }
QCheckBox::indicator:checked { background: $accent; border: 1px solid $accent; image: url($check_img); }
QCheckBox::indicator:disabled { border: 1px solid $border; }
QRadioButton { spacing: 8px; }
QRadioButton::indicator { width: 14px; height: 14px; border: 1px solid $muted; border-radius: 8px; background: $input_bg; }
QRadioButton::indicator:hover { border: 1px solid $accent; }
QRadioButton::indicator:checked { border: 1px solid $accent; background: qradialgradient(cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5,
    stop:0 $accent, stop:0.45 $accent, stop:0.55 $input_bg, stop:1 $input_bg); }

/* ---- buttons */
QPushButton { background: $button_bg; border: 1px solid $border; border-radius: 6px; padding: 7px 16px; }
QPushButton#compact { padding: 7px 8px; }
QPushButton#cellBtn { padding: 3px 8px; }  /* buttons inside table rows: the row is shorter than a normal button */
QPushButton:hover { background: $button_hover; }
QPushButton:pressed { background: $border; }
QPushButton:disabled { background: $bg; color: $muted; border: 1px solid $border; }
QPushButton#primary { background: $accent; border: 1px solid $accent; color: #FFFFFF; font-weight: 600; }
QPushButton#primary:hover { background: $accent_hover; border: 1px solid $accent_hover; }
QPushButton#primary:disabled { background: $button_bg; border: 1px solid $border; color: $muted; }

/* ---- tables */
QTableWidget { background: $card; border: 1px solid $border; border-radius: 6px; outline: none; gridline-color: $border; }
QTableWidget::item { padding: 2px 8px; border-bottom: 1px solid $border; }
QTableWidget::item:hover { background: $row_hover; }
QTableWidget::item:selected { background: $accent_tint; color: $text; }
QHeaderView::section { background: $header_bg; color: $muted; border: none; border-bottom: 1px solid $border; padding: 8px 8px; font-weight: 600; }
QTableCornerButton::section { background: $header_bg; border: none; }

/* ---- tabs, progress */
QTabWidget::pane { border: 1px solid $border; border-radius: 6px; background: $card; top: -1px; }
QTabBar { qproperty-drawBase: 0; }
QTabBar::tab { background: transparent; color: $muted; padding: 8px 16px; margin-right: 4px; border-bottom: 2px solid transparent; }
QTabBar::tab:hover { color: $text; }
QTabBar::tab:selected { color: $accent_text; border-bottom: 2px solid $accent; font-weight: 600; }
QProgressBar { background: $border; border: none; border-radius: 5px; }
QProgressBar::chunk { background: $ok; border-radius: 5px; }

/* ---- scrollbars, menus, tooltips, message boxes */
QScrollBar:vertical { background: transparent; width: 12px; margin: 0; }
QScrollBar::handle:vertical { background: $border; border-radius: 5px; min-height: 28px; margin: 1px 2px; }
QScrollBar::handle:vertical:hover { background: $muted; }
QScrollBar:horizontal { background: transparent; height: 12px; margin: 0; }
QScrollBar::handle:horizontal { background: $border; border-radius: 5px; min-width: 28px; margin: 2px 1px; }
QScrollBar::handle:horizontal:hover { background: $muted; }
QScrollBar::add-line, QScrollBar::sub-line { width: 0; height: 0; }
QScrollBar::add-page, QScrollBar::sub-page { background: transparent; }
QMenu { background: $card; color: $text; border: 1px solid $border; border-radius: 6px; padding: 4px; }
QMenu::item { background: transparent; color: $text; padding: 7px 24px; border-radius: 4px; }
QMenu::item:selected { background: $accent_tint; color: $text; }
QMenu::item:disabled { color: $muted; }
QMenu::separator { height: 1px; background: $border; margin: 4px 6px; }
QToolTip { background: $card; color: $text; border: 1px solid $border; padding: 4px 6px; }
QMessageBox QPushButton { min-width: 72px; }
""")


def _check_file(theme: str) -> str:
    """White check mark for checked boxes (Qt style sheets need an image); the same file awr_page writes, so both agree."""
    path = Path(tempfile.gettempdir()) / f"ohc_{theme}_check.png"
    if QGuiApplication.instance() is not None:
        pm = QPixmap(20, 20)
        pm.fill(Qt.GlobalColor.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(QPen(QColor("#FFFFFF"), 2.4, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        p.drawPolyline([QPointF(4.5, 10.5), QPointF(8.5, 14.5), QPointF(15.5, 5.5)])
        p.end()
        pm.save(str(path), "PNG")
    return path.as_posix()


def _arrow_files(theme: str, color: str) -> tuple[str, str]:
    """Spin-box arrows drawn with QPainter and saved as small PNGs in the temp folder (Qt styles need an image)."""
    folder = Path(tempfile.gettempdir())
    paths = {k: folder / f"ohc_{theme}_{k}.png" for k in ("up", "down")}
    if QGuiApplication.instance() is not None:
        pts = {"up": [(4, 12), (10, 5), (16, 12)], "down": [(4, 8), (10, 15), (16, 8)]}
        for kind, path in paths.items():
            pm = QPixmap(20, 20)
            pm.fill(Qt.GlobalColor.transparent)
            p = QPainter(pm)
            p.setRenderHint(QPainter.RenderHint.Antialiasing)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(color))
            p.drawPolygon(QPolygonF([QPointF(x, y) for x, y in pts[kind]]))
            p.end()
            pm.save(str(path), "PNG")
    return paths["up"].as_posix(), paths["down"].as_posix()


def stylesheet(theme: str) -> str:
    pal = PALETTES[theme]
    up, down = _arrow_files(theme, pal["text"])
    return _QSS.substitute(pal, up_arrow=up, down_arrow=down, check_img=_check_file(theme))


def make_icon(kind: str, color: str) -> QIcon:
    """'sun' or 'moon', drawn with QPainter (no image files)."""
    size, scale = 24, 2
    pixmap = QPixmap(size * scale, size * scale)
    pixmap.fill(Qt.GlobalColor.transparent)
    pixmap.setDevicePixelRatio(scale)
    p = QPainter(pixmap)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    c = QColor(color)
    if kind == "sun":
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(c)
        p.drawEllipse(QPointF(12, 12), 4.5, 4.5)
        pen = QPen(c, 2)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        p.setPen(pen)
        for i in range(8):
            a = i * math.pi / 4
            p.drawLine(QPointF(12 + 7.5 * math.cos(a), 12 + 7.5 * math.sin(a)),
                       QPointF(12 + 10 * math.cos(a), 12 + 10 * math.sin(a)))
    elif kind == "menu":
        pen = QPen(c, 2.2)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        p.setPen(pen)
        for y in (6.5, 12, 17.5):
            p.drawLine(QPointF(4.5, y), QPointF(19.5, y))
    else:
        disc, cut = QPainterPath(), QPainterPath()
        disc.addEllipse(QPointF(12, 12), 8, 8)
        cut.addEllipse(QPointF(16, 9.5), 7, 7)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(c)
        p.drawPath(disc.subtracted(cut))
    p.end()
    return QIcon(pixmap)


class ThemeManager(QObject):
    """Holds the current theme, applies it to the whole application and saves it in the user's settings."""
    changed = Signal(str)

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self._settings = settings
        self.last_error = ""
        name = settings.get("theme")
        self._theme = name if name in THEMES else "dark"

    @property
    def theme(self) -> str:
        return self._theme

    def palette(self) -> dict:
        return PALETTES[self._theme]

    def apply(self) -> None:
        app = QApplication.instance()
        if app is not None:
            font = app.font()
            font.setFamilies(FONT_FAMILIES)  # Segoe UI on Windows; widgets that set their own font (the monospace output box) keep it
            app.setFont(font)
            app.setStyleSheet(stylesheet(self._theme))

    def set_theme(self, name: str) -> None:
        if name not in THEMES:
            raise ValueError(f"unknown theme: {name!r}")
        if name == self._theme:
            return
        self._theme = name
        try:
            self._settings.set("theme", name)
            self.last_error = ""
        except ConfigFileError as exc:  # keep working; the choice just could not be saved
            self.last_error = str(exc)
        self.apply()
        self.changed.emit(name)

    def toggle(self) -> None:
        self.set_theme("light" if self._theme == "dark" else "dark")
