"""Layout helpers: a label that wraps instead of forcing its page wider, and a table that fits its columns."""
from __future__ import annotations

from PySide6.QtCore import QPointF, QSize, Qt
from PySide6.QtGui import QPainter, QTextLayout, QTextOption
from PySide6.QtWidgets import QLabel, QSizePolicy, QTableWidget


class WrapLabel(QLabel):
    """A QLabel that never forces its page wider: long unbreakable text (paths, hashes) wraps at any character.

    The text is not modified (text() returns it unchanged). Use a tooltip when the full text matters."""

    def __init__(self, text: str = "", parent=None):
        super().__init__(text, parent)
        self.setWordWrap(True)
        self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        policy = self.sizePolicy()
        policy.setHeightForWidth(True)
        self.setSizePolicy(policy)

    def _layout(self, width: int) -> tuple:
        """Lay the text out: wrap at spaces where possible, anywhere inside a word only when the word is wider than the label."""
        layout = QTextLayout(self.text().replace("\n", "\u2028"), self.font())
        option = QTextOption(Qt.AlignmentFlag.AlignLeft)
        option.setWrapMode(QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere)
        layout.setTextOption(option)
        height = 0.0
        layout.beginLayout()
        while True:
            line = layout.createLine()
            if not line.isValid():
                break
            line.setLineWidth(max(1, width))
            line.setPosition(QPointF(0, height))
            height += line.height()
        layout.endLayout()
        return layout, height

    def _text_height(self, width: int) -> int:
        m = self.contentsMargins()
        return int(self._layout(width - m.left() - m.right())[1] + 0.999) + m.top() + m.bottom()

    def hasHeightForWidth(self) -> bool:
        return True

    def heightForWidth(self, width: int) -> int:
        return self._text_height(width)

    def minimumSizeHint(self) -> QSize:
        m = self.contentsMargins()
        return QSize(40 + m.left() + m.right(), self.fontMetrics().height() + m.top() + m.bottom())

    def sizeHint(self) -> QSize:
        m = self.contentsMargins()
        width = min(520, max(self.fontMetrics().horizontalAdvance(line) for line in self.text().split("\n") or [""]) + m.left() + m.right() + 2)
        return QSize(width, self._text_height(width))

    def paintEvent(self, _event) -> None:
        rect = self.contentsRect()
        layout, _height = self._layout(rect.width())
        painter = QPainter(self)
        color = self.palette().color(self.foregroundRole())
        if not self.isEnabled():
            color = self.palette().color(self.palette().ColorGroup.Disabled, self.foregroundRole())
        painter.setPen(color)
        layout.draw(painter, QPointF(rect.left(), rect.top()))
        painter.end()


class FitTable(QTableWidget):
    """Fixed columns keep their width; the 'flex' columns share what is left (and scroll sideways only below their minimum)."""

    def __init__(self, rows: int, cols: int, fixed: dict, flex: dict, flex_min: int = 110, parent=None):
        super().__init__(rows, cols, parent)
        self._fixed, self._flex, self._flex_min = fixed, flex, flex_min
        self.horizontalHeader().setStretchLastSection(False)
        for col in range(cols):
            self.horizontalHeader().setSectionResizeMode(col, self.horizontalHeader().ResizeMode.Fixed)
        self.horizontalHeader().setMinimumSectionSize(30)

    def sizeHint(self) -> QSize:
        # constant: the default hint follows the column widths, which follow the viewport width, which follows the
        # scrollbar - a feedback loop that made small tables (Sync Check, 4 rows) jump
        return QSize(420, 260)

    def minimumSizeHint(self) -> QSize:
        return QSize(150, 110)

    def fit_columns(self) -> None:
        free = self.viewport().width() - sum(self._fixed.values())
        total = sum(self._flex.values())
        widths = {c: max(self._flex_min, int(free * w / total)) for c, w in self._flex.items()}
        for col, width in {**self._fixed, **widths}.items():
            self.setColumnWidth(col, width)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self.fit_columns()

    def showEvent(self, event) -> None:
        super().showEvent(event)
        self.fit_columns()
