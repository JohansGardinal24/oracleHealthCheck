"""Dashboard: health counts, health check results, status chart, database card, recent reports and quick actions.

The health counts, chart and Health Check Results table start empty and mirror the '3. All Checks' RunPage of THIS session (its
view_changed signal): progressively while the run executes, then its final result. Old run logs are never shown as current results (they
stay on disk and in Reports & Logs). Recent Reports still come from the shared reports folder via ohc.dashboard_data. The page never
contacts a database. The top Run button starts the existing RunPage (same engine, validation, background job, cancellation and result
handling); Cancel stops whichever RunPage is running. The quick-action cards only navigate.
"""
from __future__ import annotations

from datetime import datetime
from string import Template
from functools import partial
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, QSize, Qt, QTimer, QUrl
from PySide6.QtGui import QBrush, QColor, QDesktopServices, QFont, QFontMetricsF, QLinearGradient, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import (QAbstractItemView, QComboBox, QFrame, QGridLayout, QHBoxLayout, QLabel, QPushButton, QSizePolicy,
                               QTableWidgetItem, QVBoxLayout, QWidget)

from ohc import __version__, awr, dashboard_data as dd, paths
from ohc.checks import engine
from ohc.gui import outcomes
from ohc.gui.awr_page import FittedTable, _card, _label
from ohc.gui.reports_page import STATUS_STYLE, ReportBadgeDelegate       # the approved status pill colours / icons (also used by Reports & Logs)
from ohc.gui.run_page import BADGES, STATUS_ROLE, BadgeDelegate
from ohc.gui.run_skin import PageBackdrop                 # the approved wave + card shadows (reused, not changed)
from ohc.gui.sidebar import nav_pixmap
from ohc.gui.theme import PALETTES, _arrow_files
from ohc.gui.widgets import FitTable, WrapLabel
from ohc.resources import sql_access

GREEN, AMBER, RED, GREY = "#16A34A", "#F59E0B", "#DC2626", "#94A3B8"
DB_BLUE = "#2563EB"                # the Database card (information, not a health status)
ROW_H = 28
DONUT, DONUT_MAX = 128, 172        # status ring: minimum and maximum size (was a fixed 96)
MAX_ROWS = 8                       # rows the results card is sized for (layout); all 21 results are shown, the table scrolls
PLACEHOLDER = "-"
# every text the connection label can show: its width is reserved so the Run / Cancel buttons never move while the text changes
STATUS_TEXTS = ("Running ... 21 of 21 checks completed", "Connected (simulated)", "Not connected (simulated)", "Not checked yet", "No database")
OPEN_TEXT = "Open Report"
CLEAN_NOTE = "Run All Checks to view results."

# Dashboard-only colours (the shared palette is in theme.py). Status tints are solid colours: quiet, no glow, no gradients.
DASH = {
    "dark": dict(ok_bg="#16241F", ok_edge="#1F3A2E", warn_bg="#262114", warn_edge="#3D3418", bad_bg="#291719", bad_edge="#442024",
                 db_bg="#141C2B", db_edge="#22304A", quick_bg="#161B24", quick_hover="#211B1F", alert_bg="#2A1B1D", alert_edge="#4A2427",
                 badges={"OK": ("#173A2A", "#4ADE80"), "WARNING": ("#3A2F12", "#FBBF24"), "CRITICAL": ("#3F1B1E", "#F87171"),
                         "RUNNING": ("#3A2427", "#F2705E"), "NEUTRAL": ("#242B38", "#9AA5B8")}, wave=(38, 56)),
    "light": dict(ok_bg="#EAF5EE", ok_edge="#CFE6D7", warn_bg="#FDF3E1", warn_edge="#F2DDB0", bad_bg="#FCEBEA", bad_edge="#F3CDCA",
                  db_bg="#EBF1FD", db_edge="#CCD9F5", quick_bg="#FFFFFF", quick_hover="#FBF1EF", alert_bg="#FCEBEA", alert_edge="#F3CDCA",
                  badges={"OK": ("#DDF1E4", "#15803D"), "WARNING": ("#FBEBC8", "#9A5B07"), "CRITICAL": ("#FADAD7", "#B42318"),
                          "RUNNING": ("#FAE2DE", "#B63D2D"), "NEUTRAL": ("#E8EAEE", "#5B6577")}, wave=(32, 50)),
}
_KIND = {"OK": "OK", "WARNING": "WARNING", "CRITICAL": "CRITICAL", "RUNNING": "RUNNING"}     # every other status is drawn neutral

_QSS = Template("""
* { font-size: 12px; }
QComboBox { padding: 4px 26px 4px 8px; }
QComboBox::drop-down { subcontrol-origin: padding; subcontrol-position: center right; width: 22px; border: none; }
QComboBox::down-arrow { image: url($down_arrow); width: 10px; height: 10px; }
QLabel#pageTitle { font-size: 24px; font-weight: 700; }
QLabel#section { font-size: 14px; font-weight: 600; }
QLabel#legendValue { font-weight: 600; }
QLabel#bigNumber { font-size: 26px; font-weight: 700; }
QLabel#statTitle { font-size: 13px; font-weight: 600; }
QLabel#quickTitle { font-size: 13px; font-weight: 600; }
QPushButton#quickBtn { background: $quick_bg; border: 1px solid $border; border-radius: 10px; padding: 0; }
QPushButton#quickBtn:hover { background: $quick_hover; border: 1px solid $accent; }
QPushButton#quickBtn:pressed { background: $accent_tint; border: 1px solid $accent; }
QPushButton#quickBtn:disabled { background: $bg; border: 1px solid $border; }
QPushButton#quickBtn QLabel { background: transparent; border: none; }
QLabel#linkLabel { color: $accent_text; }
QPushButton#linkBtn { border: none; background: transparent; color: $accent_text; padding: 2px 4px; font-weight: 600; }
QPushButton#linkBtn:hover { background: transparent; text-decoration: underline; }
QPushButton { padding: 5px 12px; }
QPushButton#primary { padding: 7px 16px; font-weight: 600; }
QPushButton#cellBtn { padding: 2px 8px; background: transparent; border: 1px solid $accent; color: $accent_text; font-weight: 600; }
QPushButton#cellBtn:hover { background: $accent_tint; }
QFrame#statOk { background: $ok_bg; border: 1px solid $ok_edge; border-radius: 10px; }
QFrame#statWarn { background: $warn_bg; border: 1px solid $warn_edge; border-radius: 10px; }
QFrame#statBad { background: $bad_bg; border: 1px solid $bad_edge; border-radius: 10px; }
QFrame#statDb { background: $db_bg; border: 1px solid $db_edge; border-radius: 10px; }
QFrame#statOk QLabel, QFrame#statWarn QLabel, QFrame#statBad QLabel, QFrame#statDb QLabel { background: transparent; border: none; }
QFrame#noteBox { background: transparent; border: none; }
QFrame#noteBox[alert="true"] { background: $alert_bg; border: 1px solid $alert_edge; border-left: 3px solid $accent; border-radius: 6px; }
QFrame#noteBox[alert="true"] QLabel { color: $text; }
QTableWidget { background: transparent; border: none; }
QTableWidget::item { padding: 0px 6px; }
""")



class StatIcon(QWidget):
    """Round coloured badge with a white symbol (check, exclamation, cross, database), drawn as vectors so it never depends on a font."""

    def __init__(self, glyph: str, color: str, parent=None):
        super().__init__(parent)
        self.glyph, self.color = glyph, color
        self.setFixedSize(40, 40)

    def paintEvent(self, _event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(self.color))
        p.drawEllipse(self.rect().adjusted(1, 1, -1, -1))
        pen = QPen(QColor("#FFFFFF"), 3.2, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
        p.setPen(pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        if self.glyph == "\u2713":
            p.drawPolyline([QPointF(11.5, 20.5), QPointF(17.5, 26.5), QPointF(28.5, 14)])
        elif self.glyph == "!":                  # a warning triangle with an exclamation mark
            pen.setWidthF(2.6)
            p.setPen(pen)
            p.drawPolygon([QPointF(20, 10.5), QPointF(30, 28.5), QPointF(10, 28.5)])
            pen.setWidthF(2.4)
            p.setPen(pen)
            p.drawLine(QPointF(20, 17.6), QPointF(20, 22.4))
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor("#FFFFFF"))
            p.drawEllipse(QPointF(20, 25.4), 1.4, 1.4)
        elif self.glyph == "\u2715":
            p.drawLine(QPointF(13.5, 13.5), QPointF(26.5, 26.5))
            p.drawLine(QPointF(26.5, 13.5), QPointF(13.5, 26.5))
        else:                                    # database
            p.drawPixmap(QPointF(9, 9), nav_pixmap("database", "#FFFFFF", 22))


class StatCard(QFrame):
    """A KPI card with two soft waves in its status colour at the bottom right. Purely decorative: painted, no data behind it."""

    def __init__(self, color: str, theme_name, parent=None) -> None:
        super().__init__(parent)
        self._color, self._theme_name = QColor(color), theme_name

    def paintEvent(self, event) -> None:
        super().paintEvent(event)                    # the card's own background and border (style sheet)
        w, h = float(self.width()), float(self.height())
        back, front = DASH[self._theme_name()]["wave"]
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(Qt.PenStyle.NoPen)
        clip = QPainterPath()
        clip.addRoundedRect(QRectF(self.rect()).adjusted(1, 1, -1, -1), 9, 9)
        p.setClipPath(clip)                          # stay inside the border
        waves = ((back, ((0.42, 1.0), (0.56, 0.74), (0.66, 1.02), (0.79, 0.72), (0.88, 0.56), (0.95, 0.60), (1.0, 0.50))),
                 (front, ((0.54, 1.0), (0.66, 0.86), (0.75, 1.04), (0.86, 0.80), (0.92, 0.72), (0.97, 0.70), (1.0, 0.66))))
        for alpha, (start, c1, c2, mid, c3, c4, end) in waves:
            path = QPainterPath(QPointF(start[0] * w, start[1] * h))
            path.cubicTo(QPointF(c1[0] * w, c1[1] * h), QPointF(c2[0] * w, c2[1] * h), QPointF(mid[0] * w, mid[1] * h))
            path.cubicTo(QPointF(c3[0] * w, c3[1] * h), QPointF(c4[0] * w, c4[1] * h), QPointF(end[0] * w, end[1] * h))
            path.lineTo(w, h)
            path.closeSubpath()
            grad = QLinearGradient(0, h * 0.45, 0, h)       # a very gentle fade, not a strong gradient
            top, bottom = QColor(self._color), QColor(self._color)
            top.setAlpha(alpha)
            bottom.setAlpha(round(alpha * 0.35))
            grad.setColorAt(0.0, top)
            grad.setColorAt(1.0, bottom)
            p.setBrush(QBrush(grad))
            p.drawPath(path)


class StatusBadgeDelegate(BadgeDelegate):
    """The Dashboard's status pills: capsules in the approved tints with an icon (Passed = check, Warning = triangle, Critical = cross); every other
    status keeps its label in the quiet tint, without an icon. Display only: the status code in STATUS_ROLE is untouched. run_page's BadgeDelegate
    (used by the other pages) is untouched."""
    LABELS = {"OK": "Passed", "WARNING": "Warning", "CRITICAL": "Critical"}

    def __init__(self, parent, theme_name) -> None:
        super().__init__(parent)
        self._theme_name = theme_name

    def paint(self, painter, option, index) -> None:
        status = index.data(STATUS_ROLE) or "PENDING"
        theme = self._theme_name()
        style = STATUS_STYLE[theme].get(status)
        painter.save()
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(option.rect).adjusted(6, 4, -6, -4)
        if style is not None:
            fill, ink, icon, mark = style
            label = self.LABELS[status]
        else:
            (fill, ink), icon, mark, label = DASH[theme]["badges"][_KIND.get(status, "NEUTRAL")], None, None, BADGES.get(status, BADGES["PENDING"])[2]
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(fill))
        painter.drawRoundedRect(rect, rect.height() / 2, rect.height() / 2)
        text_rect, d = rect, rect.height() - 6
        if icon is not None:
            painter.save()
            painter.translate(rect.left() + 7, rect.center().y() - d / 2)
            painter.scale(d / 16.0, d / 16.0)
            ReportBadgeDelegate._icon(painter, status, 0, 0, 16.0, icon, mark)
            painter.restore()
            text_rect = rect.adjusted(7 + d + 3, 0, -4, 0)
        painter.setPen(QColor(ink))
        font = QFont(option.font)
        font.setBold(True)
        font.setPointSizeF(max(7.5, font.pointSizeF() - 1.5))
        while QFontMetricsF(font).horizontalAdvance(label) > text_rect.width() and font.pointSizeF() > 6.5:        # a long label always fits
            font.setPointSizeF(font.pointSizeF() - 0.25)
        painter.setFont(font)
        painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter, label)
        painter.restore()


class ElidedLabel(QLabel):
    """A label that gives way when the toolbar is narrow (shown with "..."), instead of widening the page. text() is the full text."""

    def __init__(self, text: str = "", parent=None) -> None:
        super().__init__(text, parent)
        self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)

    def minimumSizeHint(self) -> QSize:
        return QSize(0, super().minimumSizeHint().height())

    def paintEvent(self, _event) -> None:
        p = QPainter(self)
        p.setPen(self.palette().color(self.foregroundRole()))
        p.drawText(self.rect(), int(self.alignment()), self.fontMetrics().elidedText(self.text(), Qt.TextElideMode.ElideRight, self.width()))


class Donut(QWidget):
    """Status ring: segments for healthy / warnings / critical / other, total in the middle."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.values = (0, 0, 0, 0)
        self.setMinimumSize(DONUT - 4, DONUT - 4)
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        self.center_pen = QColor("#64748B")

    def sizeHint(self) -> QSize:
        return QSize(DONUT + 20, DONUT + 20)

    def set_values(self, healthy: int, warnings: int, critical: int, other: int, text_color: str) -> None:
        self.values, self.center_pen = (healthy, warnings, critical, other), QColor(text_color)
        self.update()

    def paintEvent(self, _event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        side = min(self.width(), self.height()) - 12
        rect = QRectF((self.width() - side) / 2, (self.height() - side) / 2, side, side)
        total = sum(self.values)
        width = side * 0.16
        ring = rect.adjusted(width / 2, width / 2, -width / 2, -width / 2)
        if total == 0:
            track = QColor(self.center_pen)          # the ring's empty track: the text colour, very faint (works in both themes)
            track.setAlpha(34)
            p.setPen(QPen(track, width))
            p.drawEllipse(ring)
        else:
            start = 90 * 16
            for value, color in zip(self.values, (GREEN, AMBER, RED, GREY)):
                if value:
                    span = -round(360 * 16 * value / total)
                    p.setPen(QPen(QColor(color), width, Qt.PenStyle.SolidLine, Qt.PenCapStyle.FlatCap))
                    p.drawArc(ring, start, span)
                    start += span
        p.setPen(self.center_pen)
        big = QFont(self.font())
        big.setPixelSize(max(22, round(side * 0.2)))
        big.setBold(True)
        p.setFont(big)
        p.drawText(QRectF(rect.x(), rect.y() + side * 0.22, side, side * 0.3), Qt.AlignmentFlag.AlignCenter, str(total))
        small = QFont(self.font())
        small.setPixelSize(max(10, round(side * 0.095)))
        p.setFont(small)
        muted = QColor(self.center_pen)
        muted.setAlpha(170)
        p.setPen(muted)
        p.drawText(QRectF(rect.x(), rect.y() + side * 0.5, side, side * 0.2), Qt.AlignmentFlag.AlignCenter, "Total Checks")


def _link(text: str) -> QPushButton:
    btn = QPushButton(text)
    btn.setObjectName("linkBtn")
    btn.setCursor(Qt.CursorShape.PointingHandCursor)
    btn.setFlat(True)
    return btn


class DashboardPage(QWidget):
    """goto(row, tab=None) switches the main window's page (and the Database Reports tab); run_pages = {row: RunPage}."""

    def __init__(self, ctx, gate, run_pages: dict, goto, theme=None, parent=None):
        super().__init__(parent)
        self.setObjectName("page")
        self.ctx, self.gate, self.run_pages, self.goto, self.theme = ctx, gate, run_pages, goto, theme
        self.all_page = run_pages[3]       # menu 3: All Checks (Data Guard related or not yet classified databases)
        self.health_page = run_pages[1]    # menu 1: Oracle Health Check (databases classified as standard by Test Connection)
        self.summary = dd.RunSummary()
        self.display_rows: list = []     # (check_id, name, status, message, completed-at) for every row of the Health Check Results table
        self._scrolled_idx = None
        self.reports: list = []
        self._when_fmt = "%d %b %Y %H:%M"
        self._icons: list = []           # (label, icon kind, size): re-drawn in the accent colour whenever the theme changes
        self._stat_frames: list = []     # the four KPI cards (the wave backdrop puts soft shadows under them)
        self._build()
        self._apply_style()
        self._poll = QTimer(self)
        self._poll.setInterval(500)
        self._poll.timeout.connect(self._poll_run)
        gate.changed.connect(self._gate_changed)
        self.all_page.view_changed.connect(self._live_changed)
        self.health_page.view_changed.connect(self._live_changed)
        if theme is not None:
            theme.changed.connect(lambda _n: (self._apply_style(), self._paint_chart(), self._conn_state()))
        self._reserve_status_width()
        self.refresh_databases()
        self.refresh()

    def _reserve_status_width(self) -> None:
        """A fixed-width status area (the widest status text) keeps Run and Cancel at the same place for the whole run."""
        fm = self.conn_label.fontMetrics()
        self.conn_label.setFixedWidth(max(fm.horizontalAdvance(t) for t in STATUS_TEXTS) + 12)

    # ------------------------------------------------------------------ construction
    def _build(self) -> None:
        # ---- toolbar: database, connection status, Run, Cancel
        self.db_combo = QComboBox()
        self.db_combo.setMinimumWidth(180)
        self.db_combo.setMaximumWidth(260)
        self.dot = QLabel("\u25CF")
        self.conn_label = QLabel("")
        self.run_btn = QPushButton("\u25B6  Run")
        self.run_btn.setObjectName("primary")
        self.run_btn.setToolTip("Runs the Oracle Health Checks and the Data Guard Sync Checks (menu 3: All Checks) on the selected database")
        self.cancel_btn = QPushButton("\u25A0  Cancel")
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.setToolTip("Stop the run in progress safely (no new check starts and the running SQL*Plus/DGMGRL process is ended)")
        tool = QHBoxLayout()
        tool.setSpacing(8)
        tool.addWidget(_label("Database:"))
        tool.addWidget(self.db_combo)
        tool.addSpacing(6)
        tool.addWidget(self.dot)
        tool.addWidget(self.conn_label)
        tool.addSpacing(10)
        tool.addWidget(self.run_btn)
        tool.addWidget(self.cancel_btn)
        tool.addStretch(1)
        self.updated = ElidedLabel("")
        self.updated.setObjectName("muted")
        self.updated.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.refresh_btn = QPushButton("\u27F3  Refresh")
        tool.addWidget(self.updated, 1)
        tool.addSpacing(4)
        tool.addWidget(self.refresh_btn)

        # ---- title row
        self.sim_tag = _label("SIMULATED DATA", "warn")
        self.sim_tag.setToolTip("Fake Oracle mode (development): no database is contacted and these results are not real.")
        titles = QVBoxLayout()
        titles.setSpacing(0)
        titles.addWidget(_label("Dashboard", "pageTitle"))
        titles.addWidget(_label("Overview of database health, recent checks and reports"))
        title = QHBoxLayout()
        title.setSpacing(10)
        title.addWidget(self._icon("dashboard", 32))
        title.addLayout(titles, 1)
        title.addWidget(self.sim_tag)

        # ---- stat cards
        self.healthy_n, self.healthy_sub = QLabel("0"), _label("checks passed")
        self.warn_n, self.warn_sub = QLabel("0"), _label("checks with warnings")
        self.crit_n, self.crit_sub = QLabel("0"), _label("checks failed")
        self.db_name, self.db_sub = QLabel("-"), _label("")
        for lab in (self.healthy_n, self.warn_n, self.crit_n, self.db_name):
            lab.setObjectName("bigNumber")
        stats = QHBoxLayout()
        stats.setSpacing(10)
        for name, glyph, color, title_text, big, sub in (("statOk", "\u2713", GREEN, "Healthy", self.healthy_n, self.healthy_sub),
                                                         ("statWarn", "!", AMBER, "Warnings", self.warn_n, self.warn_sub),
                                                         ("statBad", "\u2715", RED, "Critical", self.crit_n, self.crit_sub),
                                                         ("statDb", "\u26C1", DB_BLUE, "Database", self.db_name, self.db_sub)):
            frame = StatCard(color, self._theme_name)
            frame.setObjectName(name)
            self._stat_frames.append(frame)
            row = QHBoxLayout(frame)
            row.setContentsMargins(16, 6, 16, 6)
            row.setSpacing(14)
            row.addWidget(StatIcon(glyph, color))
            col = QVBoxLayout()
            col.setSpacing(0)
            head = QLabel(title_text)
            head.setObjectName("statTitle")
            col.addWidget(head)
            col.addWidget(big)
            col.addWidget(sub)
            row.addLayout(col, 1)
            stats.addWidget(frame, 1)

        # ---- health check results
        self.results = FittedTable(0, 5, fixed={0: 70, 2: 90, 4: 74}, flex={1: 3, 3: 4}, flex_min=60)
        self.results.setHorizontalHeaderLabels(["Check ID", "Check Name", "Status", "Message", "Time"])
        self.results.setItemDelegateForColumn(2, StatusBadgeDelegate(self.results, self._theme_name))
        self.view_results = _link("View All")
        self.results_note = WrapLabel("")
        self.results_note.setObjectName("muted")
        self.note_box = QFrame()           # WrapLabel paints only text: this frame gives a failure message its alert-strip background
        self.note_box.setObjectName("noteBox")
        note_layout = QVBoxLayout(self.note_box)
        note_layout.setContentsMargins(0, 0, 0, 0)
        note_layout.addWidget(self.results_note)
        res_card, rbox = _card()
        head = QHBoxLayout()
        head.setSpacing(8)
        head.addWidget(self._icon("list", 18))
        head.addWidget(_label("Health Check Results", "section"))
        head.addStretch(1)
        head.addWidget(self.view_results)
        rbox.addLayout(head)
        rbox.addWidget(self.note_box)
        rbox.addWidget(self.results, 1)

        # ---- status summary
        self.donut = Donut()
        self.donut.setMinimumSize(DONUT, DONUT)                    # grows (up to DONUT_MAX) with the height the summary card has to spare
        self.donut.setMaximumSize(DONUT_MAX, DONUT_MAX)
        self.legend = {}
        self.legend_pct = {}             # key -> "n %" label (share of the completed checks, computed from the real counts)
        legend = QGridLayout()
        legend.setHorizontalSpacing(8)
        legend.setVerticalSpacing(4)
        self.legend_seps: list = []      # thin lines between the legend rows (as in the approved reference)
        for i, (key, text, color) in enumerate((("healthy", "Passed", GREEN), ("warnings", "Warnings", AMBER), ("critical", "Failed", RED),
                                                ("other", "Other", GREY))):
            dot = QLabel("\u25CF")
            dot.setStyleSheet(f"color: {color}; font-size: 15px;")
            value = QLabel("0")
            value.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            value.setMinimumWidth(32)
            value.setObjectName("legendValue")
            caption = QLabel(text)
            caption.setMinimumWidth(78)
            pct = QLabel("0%")
            pct.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            pct.setMinimumWidth(44)
            for w in (dot, caption, value, pct):
                w.setMinimumHeight(30)              # rows about 40 px apart together with their separators, as in the reference
            row = 2 * i                             # content rows 0, 2, 4, 6; separators in between
            legend.addWidget(dot, row, 0)
            legend.addWidget(caption, row, 1)
            legend.addWidget(value, row, 2)
            legend.addWidget(pct, row, 3)
            if i < 3:
                sep = QFrame()
                sep.setObjectName("separator")
                sep.setFixedHeight(1)
                legend.addWidget(sep, row + 1, 0, 1, 4)
                self.legend_seps.append(sep)
            self.legend_pct[key] = pct
            self.legend[key] = (dot, value, caption)
        legend.setColumnStretch(3, 1)          # the counts sit right next to their labels; the percentages take the spare width on the right
        sum_card, sbox = _card()
        sbox.setContentsMargins(10, 4, 10, 4)          # compact vertical padding: the right column sets the minimum height of the page
        sbox.setSpacing(2)
        sum_head = QHBoxLayout()
        sum_head.setSpacing(8)
        sum_head.addWidget(self._icon("dashboard", 18))
        sum_head.addWidget(_label("Check Status Summary", "section"))
        sum_head.addStretch(1)
        sum_head.addWidget(self._icon("reports", 18))
        sbox.addLayout(sum_head)
        srow = QHBoxLayout()
        ring = QHBoxLayout()                     # the ring is centred in the left ~45 % of the card, the legend takes the right ~55 % (as in the reference)
        ring.addStretch(1)
        ring.addWidget(self.donut)
        ring.addStretch(1)
        srow.addLayout(ring, 9)
        legend_box = QVBoxLayout()               # the rows sit together, centred beside the ring; the lines and the percentages reach the card's right edge
        legend_box.setContentsMargins(0, 0, 4, 0)
        legend_box.addStretch(1)
        legend_box.addLayout(legend)
        legend_box.addStretch(1)
        srow.addLayout(legend_box, 11)
        sbox.addStretch(1)
        sbox.addLayout(srow)
        sbox.addStretch(1)

        # ---- recent reports
        self.reports_table = FittedTable(0, 4, fixed={0: 52, 2: 124, 3: 112}, flex={1: 1}, flex_min=60)
        self.reports_table.setHorizontalHeaderLabels(["Type", "Report Name", "Created", "Action"])
        self.reports_table.fitted.connect(self._refit_reports)
        self.reports_table.fitted.connect(self._size_reports)
        self.view_reports = _link("View All")
        self.reports_note = WrapLabel("")
        self.reports_note.setObjectName("muted")
        rep_card, pbox = _card()
        pbox.setContentsMargins(10, 4, 10, 4)
        pbox.setSpacing(3)
        head = QHBoxLayout()
        head.setSpacing(8)
        head.addWidget(self._icon("logs", 18))
        head.addWidget(_label("Recent Reports", "section"))
        head.addStretch(1)
        head.addWidget(self.view_reports)
        pbox.addLayout(head)
        pbox.addWidget(self.reports_note)
        pbox.addWidget(self.reports_table, 1)
        for table, rows in ((self.results, MAX_ROWS), (self.reports_table, dd.MAX_RECENT_REPORTS)):
            table.verticalHeader().setVisible(False)
            table.verticalHeader().setDefaultSectionSize(ROW_H)
            table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
            table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
            table.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            table.setShowGrid(False)
            table.setWordWrap(False)
            table.setTextElideMode(Qt.TextElideMode.ElideRight)
            table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            table.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            table.horizontalHeader().setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
            table.hint_height = 28 + ROW_H * rows
            if table is self.results:
                table.fitted.connect(partial(self._min_rows, table, 3))
        # all 21 results: the results table scrolls vertically when it needs to (its columns are re-fitted when the scrollbar appears/disappears)
        self.results.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.results.verticalScrollBar().rangeChanged.connect(lambda *_: QTimer.singleShot(0, self.results.fit_columns))
        right = QVBoxLayout()
        right.setSpacing(8)
        right.addWidget(sum_card, 1)
        right.addWidget(rep_card)
        middle = QHBoxLayout()
        middle.setSpacing(10)
        middle.addWidget(res_card, 5)
        middle.addLayout(right, 4)

        # ---- quick actions (navigation only)
        quick = QHBoxLayout()
        quick.setSpacing(10)
        self.quick = {}
        n_sql, n_dg = len(engine.plan("SQL")), len(engine.plan("DG"))
        for key, kind, title_text, text in (
                ("health", "health", "Run Health Check", f"Open the page that runs the {n_sql} Oracle checks"),
                ("sync", "sync", "Data Guard Sync Check", f"Open the page that runs the {n_dg} Data Guard checks"),
                ("awr", "logs", "Generate AWR Report", "Create an AWR report for a snapshot range"),
                ("ash", "reports", "Generate ASH Report", "Create an ASH report (HTML or Text)"),
                ("addm", "database", "Generate ADDM Report", "Create an ADDM report (Text only)")):
            button = QPushButton("")                    # the whole card is the button: same object, same clicked signal as before
            button.setObjectName("quickBtn")
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setToolTip(f"{title_text}\n{text}")
            cbox = QVBoxLayout(button)
            cbox.setContentsMargins(8, 10, 8, 10)
            cbox.setSpacing(6)
            icon = self._icon(kind, 30)
            icon.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
            name = QLabel(title_text)
            name.setObjectName("quickTitle")
            name.setAlignment(Qt.AlignmentFlag.AlignCenter)
            name.setWordWrap(True)
            name.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
            name.setMinimumHeight(2 * name.fontMetrics().lineSpacing())      # a title may wrap on a narrow window: reserve its 2nd line
            cbox.addWidget(icon, 0, Qt.AlignmentFlag.AlignHCenter)
            cbox.addWidget(name)
            button.setMinimumHeight(cbox.sizeHint().height())              # a QPushButton ignores its layout when asked for a size
            button.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
            quick.addWidget(button, 1)
            self.quick[key] = button
        foot = QHBoxLayout()
        self.footer = QLabel("")
        self.footer.setObjectName("muted")
        self.footer.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)       # never wraps, never widens the page
        foot.addWidget(self.footer, 1)

        box = QVBoxLayout(self)
        box.setContentsMargins(24, 4, 24, 6)
        box.setSpacing(8)
        box.addLayout(title)
        box.addLayout(tool)
        box.addLayout(stats)
        box.addLayout(middle, 1)
        box.addLayout(quick)
        box.addLayout(foot)

        self._backdrop = PageBackdrop(self, [*self._stat_frames, res_card, sum_card, rep_card, *self.quick.values()],
                                      self._theme_name, lambda: self._stat_frames[0].y())          # faint wave + soft card shadows
        self.run_btn.clicked.connect(self.run_all)
        self.cancel_btn.clicked.connect(self.cancel_run)
        self.refresh_btn.clicked.connect(self.refresh)
        self.db_combo.currentIndexChanged.connect(lambda _i: self.refresh())
        self.view_results.clicked.connect(lambda: self.goto(5, None))
        self.view_reports.clicked.connect(self.view_all_reports)
        for key, (row, tab) in {"health": (1, None), "sync": (2, None), "awr": (4, 0), "ash": (4, 1), "addm": (4, 2)}.items():
            self.quick[key].clicked.connect(partial(self.goto, row, tab))

    def _theme_name(self) -> str:
        return self.theme.theme if self.theme is not None else "dark"

    def _icon(self, kind: str, size: int) -> QLabel:
        """A small line icon in the accent colour (drawn in code); registered so _apply_style re-colours it for the theme."""
        label = QLabel()
        label.setFixedSize(size, size)
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._icons.append((label, kind, size))
        return label

    def _apply_style(self) -> None:
        name = self._theme_name()
        pal = PALETTES[name]
        self.setStyleSheet(_QSS.substitute({**pal, **DASH[name]}, down_arrow=_arrow_files(name, pal["text"])[1]))
        for label, kind, size in self._icons:
            label.setPixmap(nav_pixmap(kind, pal["accent_text"], size))
        self.results.viewport().update()                      # the status pills follow the theme

    def _style_note(self, alert: bool) -> None:
        """Failure text goes in a subtle Oracle-red alert strip; the text itself is unchanged."""
        if self.note_box.property("alert") == alert:
            return
        self.note_box.setProperty("alert", alert)
        self.note_box.layout().setContentsMargins(*((10, 6, 8, 6) if alert else (0, 0, 0, 0)))     # (a style-sheet padding would not move the label)
        for widget in (self.note_box, self.results_note):
            widget.style().unpolish(widget)
            widget.style().polish(widget)
        self.note_box.updateGeometry()

    # ------------------------------------------------------------------ data
    def refresh_databases(self) -> None:
        entries = [(e.name, e.id) for e in self.ctx.databases.entries()]
        current = [(self.db_combo.itemText(i), self.db_combo.itemData(i)) for i in range(self.db_combo.count())]
        if entries and entries == current:
            return
        keep, wanted = self.db_combo.currentData(), self.ctx.settings.get("default_db")
        self.db_combo.blockSignals(True)
        self.db_combo.clear()
        for name, ident in entries:
            self.db_combo.addItem(name, ident)
        idx = self.db_combo.findData(keep) if keep is not None else -1
        if idx < 0 and wanted:
            idx = self.db_combo.findText(wanted)
        self.db_combo.setCurrentIndex(max(0, idx))
        self.db_combo.blockSignals(False)

    def _db(self):
        return self.ctx.databases.get(self.db_combo.currentData())

    def _session_page(self):
        """The page (menu 1 or menu 3) that made the latest run of the selected database in this session, else None (clean state)."""
        entry = self._db()
        if entry is None:
            return None
        runs = [p for p in (self.all_page, self.health_page) if p.run_db is not None and p.run_db.lower() == entry.name.lower()]
        return max(runs, key=lambda p: p.run_started) if runs else None

    def _run_page_for(self, entry):
        """Dashboard Run = menu 1 for a database Test Connection classified as standard (SWITCHOVER_STATUS = NOT ALLOWED), else menu 3."""
        return self.health_page if entry is not None and entry.run_mode == "standard" else self.all_page

    def _build_summary(self) -> None:
        """summary (completed checks only: counts, chart, connection) and display_rows (every check of the run) from the All Checks page."""
        page = self._session_page()
        if page is None:       # clean state: all 21 checks of All Checks as "Not Run" (nothing is read from old logs)
            self.summary = dd.RunSummary()
            mode = "SQL" if (self._db() is not None and self._db().run_mode == "standard") else "ALL"   # the checks Run will execute
            self.display_rows = [(f"CHK_{i + 1:02d}", engine.NAMES[i], "PENDING", "", None) for i in engine.plan(mode)]
            return
        rows = [(f"CHK_{idx + 1:02d}", engine.NAMES[idx], d["status"], d["message"] or "", d.get("when"))
                for idx, d in ((i, page._data[i]) for i in sorted(page._row, key=page._row.get))]
        done = [dd.CheckRow(cid, name, status, msg) for cid, name, status, msg, _w in rows if status not in ("PENDING", "RUNNING")]
        self.summary = dd.RunSummary(db=page.run_db, when=page.run_started, simulated=page.run_fake, rows=done)
        self.display_rows = sorted(rows, key=lambda r: r[0])     # always ascending check ID (CHK_01, CHK_02, ...), whatever the status

    def _apply_summary(self) -> None:
        self._build_summary()
        entry = self._db()
        self.run_btn.setToolTip({
            "standard": "Runs 1. Oracle Health Check on the selected database (standard database: SWITCHOVER_STATUS = NOT ALLOWED)",
            "dataguard": "Runs 3. All Checks on the selected database (Data Guard related: SWITCHOVER_STATUS = %s)" % (entry.switchover_status if entry else ""),
        }.get(entry.run_mode if entry else "", "Runs 3. All Checks (Oracle Health Checks + Data Guard Sync Checks). The database type is not known yet: "
                                                 "use Test Connection in Settings to let Run choose the right checks"))
        s, started = self.summary, self._session_page() is not None
        for lab, value in ((self.healthy_n, s.healthy), (self.warn_n, s.warnings), (self.crit_n, s.critical)):
            lab.setText(str(value) if started else PLACEHOLDER)
        idle = "waiting for results" if started and s.total == 0 else None
        for sub, text in ((self.healthy_sub, "checks passed"), (self.warn_sub, "checks with warnings"), (self.crit_sub, "checks failed")):
            sub.setText("no run yet" if not started else idle or text)
        self._paint_chart()
        self._fill_results()
        self._conn_state()

    def _live_changed(self) -> None:
        """The All Checks page changed (plan, a check started/finished, run ended): mirror it. No second engine, no file reads."""
        self._apply_summary()
        page = self._session_page()
        if page is not None and page._thread is not None:
            running = next((i for i, d in page._data.items() if d["status"] == "RUNNING"), None)
            if running is not None and running != self._scrolled_idx and page._row.get(running) is not None:
                self._scrolled_idx = running
                row = next((r for r, x in enumerate(self.display_rows) if x[0] == f"CHK_{running + 1:02d}"), None)
                if row is not None and self.results.item(row, 1) is not None:
                    self.results.scrollToItem(self.results.item(row, 1))
        elif page is None or page._thread is None:
            if self._scrolled_idx is not None:       # the run just ended: the problems-first order starts at the top
                self.results.scrollToTop()
            self._scrolled_idx = None
        self._update_enabled()

    def refresh(self) -> None:
        """Re-read the reports folder and re-apply the current session's results (file reads: reports only; old run logs are not shown)."""
        entry = self._db()
        root = Path(self.ctx.root)
        self.reports = dd.recent_reports(root / "reports", root / "logs", index_dir=awr.index_dir_for(root))
        self.sim_tag.setVisible(outcomes.fake_status()[1] == "warn")
        self.updated.setText("Last Updated: " + datetime.now().strftime("%d %b %Y %H:%M:%S"))
        self.db_name.setText(entry.name if entry is not None else "-")
        self.db_sub.setText(("SID " + entry.effective_sid) if entry is not None else "No database configured")
        self._apply_summary()
        self._fill_reports()
        self._footer()
        self._update_enabled()

    def _paint_chart(self) -> None:
        s = self.summary
        pal = PALETTES[self.theme.theme if self.theme is not None else "dark"]
        self.donut.set_values(s.healthy, s.warnings, s.critical, s.other, pal["text"])
        for key, value in (("healthy", s.healthy), ("warnings", s.warnings), ("critical", s.critical), ("other", s.other)):
            self.legend[key][1].setText(str(value))
            self.legend_pct[key].setText(f"{int(100 * value / s.total + 0.5)}%" if s.total else "0%")      # from the real counts (0% while nothing has run)
            for w in (*self.legend[key], self.legend_pct[key]):
                w.setVisible(key != "other" or s.other > 0)
        self.legend_seps[2].setVisible(s.other > 0)          # a line under "Failed" only while the "Other" row follows

    def _fill_results(self) -> None:
        rows, s, page = self.display_rows, self.summary, self._session_page()
        self.results.setRowCount(len(rows))
        for r, (cid, name, status, message, when) in enumerate(rows):
            stamp = when.strftime("%H:%M:%S") if when else "-"
            for col, text in ((0, cid), (1, name), (3, message or "-"), (4, stamp)):
                item = QTableWidgetItem(text)
                item.setFlags(Qt.ItemFlag.ItemIsEnabled)
                item.setToolTip(text if col in (1, 3) else (f"Completed {when:%d %b %Y %H:%M:%S}" if col == 4 and when else ""))
                self.results.setItem(r, col, item)
            badge = QTableWidgetItem("")
            badge.setFlags(Qt.ItemFlag.ItemIsEnabled)
            badge.setData(STATUS_ROLE, status)
            self.results.setItem(r, 2, badge)
        if page is None:
            entry = self._db()
            note = "Run Health Check to view results." if entry is not None and entry.run_mode == "standard" else CLEAN_NOTE
        elif page._thread is not None:
            note = f"Running on {s.db}{' (simulated)' if s.simulated else ''} - {s.total} of {page._total} checks completed"
        else:
            state = page.state_label.text()
            note = f"{state} run of {s.db}: {s.when:%d %b %Y %H:%M:%S}" + (" - SIMULATED DATA" if s.simulated else "")
            if state == "Failed":
                note += f" - {page.status.text()}"
            elif s.total < page._total:
                note += f" - {s.total} of {page._total} checks completed"
        self.results_note.setText(note)
        self._style_note(page is not None and page._thread is None and page.state_label.text() == "Failed")

    def _fill_reports(self) -> None:
        rows = self.reports
        self.reports_table.setRowCount(len(rows))
        for r, rep in enumerate(rows):
            texts = (rep.kind, rep.name, rep.when.strftime(self._when_fmt))
            for col, text in enumerate(texts):
                item = QTableWidgetItem(text)
                item.setFlags(Qt.ItemFlag.ItemIsEnabled)
                item.setToolTip((str(rep.path) if col == 1 else text) + ("\nSimulated report: no database was contacted." if rep.simulated else ""))
                self.reports_table.setItem(r, col, item)
            self.reports_table.item(r, 1).setData(Qt.ItemDataRole.UserRole, str(rep.path))
            btn = QPushButton("Open Report")
            btn.setObjectName("cellBtn")
            btn.setMinimumWidth(self._open_btn_width(btn.fontMetrics()))        # never narrower than its text + padding: no clipped "O"
            btn.clicked.connect(partial(self.open_report, rep.path))
            holder = QWidget()
            lay = QHBoxLayout(holder)
            lay.setContentsMargins(4, 2, 4, 2)
            lay.addWidget(btn)
            holder.open_btn, holder.path = btn, rep.path
            self.reports_table.setCellWidget(r, 3, holder)
        self.reports_note.setText("" if rows else "No reports have been generated yet.")
        self.reports_note.setVisible(not rows)
        self._size_reports()

    @staticmethod
    def _min_rows(table, rows: int) -> None:
        """Minimum height = the ACTUAL header + frame + `rows` rows (the header is taller than 28 px with some fonts/DPI settings, which used
        to leave the viewport only two rows high at 1200x760)."""
        need = max(table.horizontalHeader().height(), table.horizontalHeader().sizeHint().height()) + ROW_H * rows + 2 * table.frameWidth() + 2
        if table.minimumHeight() != need:
            table.setMinimumHeight(need)

    def _size_reports(self) -> None:
        """The Recent Reports table is exactly as tall as its header and its real rows: no empty row below the last report."""
        table, n = self.reports_table, self.reports_table.rowCount()
        table.setVisible(n > 0)
        need = max(table.horizontalHeader().height(), table.horizontalHeader().sizeHint().height()) + ROW_H * n + 2 * table.frameWidth() + 2
        if table.minimumHeight() != need or table.maximumHeight() != need:
            table.setFixedHeight(need)

    @staticmethod
    def _open_btn_width(fm) -> int:
        return fm.horizontalAdvance(OPEN_TEXT) + 16 + 2 + 8          # text + 2 x 8 px padding + border + slack (a font-based floor: not tied to style polish)

    def _refit_reports(self) -> None:
        """Type/Created/Action columns from the font; Created drops the year when the report name would get too little room."""
        fm = self.reports_table.fontMetrics()
        probe = QPushButton("Open Report")
        probe.setObjectName("cellBtn")
        probe.setStyleSheet(self.styleSheet())
        sample = datetime(2026, 9, 30, 23, 59)
        btn_w = max(probe.sizeHint().width(), self._open_btn_width(probe.fontMetrics()))
        fixed = {0: fm.horizontalAdvance("Health") + 22, 3: btn_w + 8 + 8}        # button + the cell's 2 x 4 px margins + slack
        total = self.reports_table.viewport().width()
        fmt = "%d %b %Y %H:%M"
        if total - sum(fixed.values()) - (fm.horizontalAdvance(sample.strftime(fmt)) + 22) < 150:
            fmt = "%d %b %H:%M"
        fixed[2] = fm.horizontalAdvance(sample.strftime(fmt).upper()) + 22
        self.reports_table._fixed.update(fixed)
        FitTable.fit_columns(self.reports_table)
        if fmt != self._when_fmt:
            self._when_fmt = fmt
            for row, rep in enumerate(self.reports):
                item = self.reports_table.item(row, 2)
                if item is not None:
                    item.setText(rep.when.strftime(fmt))

    def _conn_state(self) -> None:
        pal = PALETTES[self.theme.theme if self.theme is not None else "dark"]
        s = self.summary
        running = self._running_page() is not None
        if running:
            text, color, tip = "Running ...", pal["accent"], "A run is in progress."
        elif self._db() is None:
            text, color, tip = "No database", GREY, "Add a database in Settings."
        elif s.db_reachable is None:
            text, color, tip = "Not checked yet", GREY, "No run has been made for this database yet."
        elif s.db_reachable:
            text, color, tip = "Connected", GREEN, f"The database answered in the latest run ({s.when:%d %b %Y %H:%M:%S})."
        else:
            text, color, tip = "Not connected", RED, f"The database did not answer in the latest run ({s.when:%d %b %Y %H:%M:%S})."
        if s.simulated and not running and s.db_reachable is not None:
            text += " (simulated)"
        self.dot.setStyleSheet(f"color: {color};")
        self.conn_label.setText(text)
        self.conn_label.setToolTip(tip)
        self.dot.setToolTip(tip)

    def _footer(self) -> None:
        problems = sql_access.verify()
        sql = "SQL bundle: INTEGRITY FAILURE - " + "; ".join(problems) if problems else f"SQL bundle: OK ({len(sql_access.list_sql())} scripts)"
        text = f"Version {__version__}  |  Mode: {'packaged EXE' if paths.is_frozen() else 'development'}  |  {sql}  |  Application root: {paths.app_root()}"
        self.footer.setText(text)
        self.footer.setToolTip(text)

    # ------------------------------------------------------------------ run / cancel (delegated to the existing RunPages)
    def _running_page(self):
        return next((p for p in self.run_pages.values() if p._thread is not None), None)

    def _update_enabled(self) -> None:
        busy = self.gate.busy
        self.db_combo.setEnabled(not busy)
        self.run_btn.setEnabled(not busy and self._db() is not None)
        page = self._running_page()
        self.cancel_btn.setEnabled(page is not None and page.cancel_btn.isEnabled())

    def run_all(self) -> None:
        """Run = menu 1 (standard database) or menu 3 (Data Guard related / not classified yet) for the selected database: the RunPage does
        the validation, background job, progress and results."""
        if self.gate.busy or self._db() is None:
            return
        page = self._run_page_for(self._db())
        page.refresh_databases()          # menu 1 / 3 only refresh their database list when shown: pick up databases added, edited or removed since
        idx = page.db_combo.findData(self.db_combo.currentData())
        if idx < 0:                       # never run another database than the selected one
            self._start_problem("The selected database is not available for the run. Open Settings and check the database list.")
            return
        page.db_combo.setCurrentIndex(idx)
        page.start()
        if page._thread is None:          # start() refused (validation / simulated-mode error): say why here, not only on a page that is not shown
            self._start_problem(page.status.text() or "The run could not be started.")
        self._update_enabled()
        self._conn_state()

    def _start_problem(self, text: str) -> None:
        self.results_note.setText(text)
        self._style_note(True)
        self.conn_label.setToolTip(text)

    def cancel_run(self) -> None:
        page = self._running_page()
        if page is not None:
            page.cancel()
        self._update_enabled()

    def _gate_changed(self, busy: bool) -> None:
        if busy:
            self._poll.start()
        else:
            self._poll.stop()
            try:
                self.refresh()           # the run finished: show its results
            finally:                     # whatever happens while refreshing, Run / Cancel must follow the gate again
                self._update_enabled()
                self._conn_state()
            return
        self._update_enabled()
        self._conn_state()

    def _poll_run(self) -> None:
        page = self._running_page()
        if page is not None:
            self.conn_label.setText(f"Running ... {page.count_label.text()}")
        self._update_enabled()

    # ------------------------------------------------------------------ reports
    def open_report(self, path) -> None:
        path = Path(path)
        if path.is_file():
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
        else:
            self.reports_note.setText(f"The report no longer exists: {path.name}")
            self.reports_note.setVisible(True)
            QTimer.singleShot(0, self._refresh_keep_note)

    def _refresh_keep_note(self) -> None:
        note = self.reports_note.text()
        self.refresh()
        if note.startswith("The report no longer exists"):
            self.reports_note.setText(note)
            self.reports_note.setVisible(True)

    def view_all_reports(self) -> None:
        """Health reports are browsed in Reports & Logs; AWR/ASH/ADDM reports on their Database Reports tab."""
        kind = self.reports[0].kind if self.reports else "Health"
        row, tab = {"Health": (5, None), "AWR": (4, 0), "ASH": (4, 1), "ADDM": (4, 2)}[kind]
        self.goto(row, tab)

    def showEvent(self, event) -> None:
        super().showEvent(event)
        self.refresh_databases()
        self.refresh()
