
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QHBoxLayout, QPushButton, QSpinBox, QVBoxLayout, QWidget
)


class RetentionSpinner(QWidget):
    """Retention days input with vertically stacked arrow buttons."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("retentionSpinner")

        self._spin = QSpinBox()
        self._spin.setObjectName("retentionValue")
        self._spin.setRange(1, 3650)
        self._spin.setButtonSymbols(QSpinBox.ButtonSymbols.NoButtons)
        self._spin.setKeyboardTracking(True)
        self._spin.setFixedWidth(88)

        self._up = QPushButton("▲")
        self._down = QPushButton("▼")

        for button in (self._up, self._down):
            button.setObjectName("spinnerButton")
            button.setFixedSize(24, 15)
            button.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        arrows = QVBoxLayout()
        arrows.setContentsMargins(0, 0, 0, 0)
        arrows.setSpacing(0)
        arrows.addWidget(self._up)
        arrows.addWidget(self._down)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self._spin)
        layout.addLayout(arrows)

        self.setFixedSize(112, 30)
        self._up.clicked.connect(self._spin.stepUp)
        self._down.clicked.connect(self._spin.stepDown)

    def setRange(self, minimum: int, maximum: int) -> None:
        self._spin.setRange(minimum, maximum)

    def setValue(self, value: int) -> None:
        self._spin.setValue(value)

    def value(self) -> int:
        return self._spin.value()

    def setEnabled(self, enabled: bool) -> None:
        super().setEnabled(enabled)
        self._spin.setEnabled(enabled)
        self._up.setEnabled(enabled)
        self._down.setEnabled(enabled)
