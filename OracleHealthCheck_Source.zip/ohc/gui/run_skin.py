"""Visual skin of the run pages (Oracle-red design system, light + dark): colours, style sheet and status pills. No behaviour.

Used by ohc/gui/run_page.py for the pages that have been redesigned (5A: option 1, Oracle Health Check)."""
from __future__ import annotations

from string import Template

from PySide6.QtCore import QEvent, QPoint, QPointF, QRectF, Qt
from PySide6.QtGui import QBrush, QColor, QImage, QLinearGradient, QPainter, QPainterPath
from PySide6.QtWidgets import QWidget

from ohc.gui.theme import PALETTES

# The status pills are the same quiet tints as the Dashboard (solid colours, no glow): status -> (fill, ink)
SKIN = {
    "dark": dict(info_bg="#1A191F", info_edge="#2C2529",
                 pills={"OK": ("#173A2A", "#4ADE80"), "WARNING": ("#3A2F12", "#FBBF24"), "CRITICAL": ("#3F1B1E", "#F87171"),
                        "RUNNING": ("#3A2427", "#F2705E"), "CANCELLED": ("#322A12", "#E3B341"), "NEUTRAL": ("#242B38", "#9AA5B8")}),
    "light": dict(info_bg="#FFF8F6", info_edge="#F1DDD8",
                  pills={"OK": ("#DDF1E4", "#15803D"), "WARNING": ("#FBEBC8", "#9A5B07"), "CRITICAL": ("#FADAD7", "#B42318"),
                         "RUNNING": ("#FAE2DE", "#B63D2D"), "CANCELLED": ("#FFF4CF", "#8A5700"), "NEUTRAL": ("#E8EAEE", "#5B6577")}),
}


def pill(theme: str, status: str) -> tuple:
    """(fill, ink) of a status pill; every status without its own colour (Not Run, Skipped, Info, Cancelled, ...) is neutral grey."""
    pills = SKIN[theme]["pills"]
    return pills.get(status, pills["NEUTRAL"])


def state_colors(theme: str) -> dict:
    """Colours of the round state symbol in the status card."""
    pal = PALETTES[theme]
    return {"idle": pal["muted"], "running": pal["accent"], "ok": "#16A34A", "warn": "#F59E0B", "bad": "#DC2626", "cancelled": pal["muted"]}


_QSS = Template("""
QLabel#title { font-size: 26px; font-weight: 700; }
QLabel#strong { font-size: 14px; font-weight: 700; }
QLabel#section { font-size: 15px; font-weight: 700; }
QLabel#stateTitle { font-size: 20px; font-weight: 700; }
QFrame#card[tint="info"] { background: $info_bg; border: 1px solid $info_edge; }
QFrame#statusDivider { background: $border; border: none; }
QComboBox { padding: 7px 28px 7px 10px; }
QPushButton#primary { padding: 9px 16px; font-size: 14px; }
QPushButton#compact { background: transparent; border: 1px solid $accent; color: $accent_text; font-weight: 600; font-size: 12px; padding: 6px 4px; }
QPushButton#compact:hover { background: $accent_tint; }
QPushButton#compact:disabled { background: transparent; border: 1px solid $border; color: $muted; }
QProgressBar { background: $border; border: none; border-radius: 5px; }
QProgressBar::chunk { background: $accent; border-radius: 5px; }
QTabWidget::pane { border: none; background: transparent; top: 0px; }
QTabBar::tab { padding: 8px 14px; }
QPlainTextEdit { background: $input_bg; border: 1px solid $border; border-radius: 8px; padding: 8px; }
QTableWidget { background: transparent; border: none; }
QTableWidget::item { padding: 0px 8px; }
""")


def stylesheet(theme: str) -> str:
    return _QSS.substitute({**PALETTES[theme], **SKIN[theme]})


class PageBackdrop(QWidget):
    """Lies behind everything on a redesigned page: a faint wave in the upper-right corner and soft shadows under the cards.
    Painted here (no graphics effects), so the text on the cards stays sharp. Never takes the mouse; changes no layout."""

    def __init__(self, page: QWidget, cards, theme_name, header_bottom=None) -> None:
        super().__init__(page)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self._cards, self._theme_name = list(cards), theme_name
        self._header_bottom = header_bottom or (lambda: 64)        # y where the first cards start: the wave lives in the strip above them
        page.installEventFilter(self)
        for card in self._cards:
            card.installEventFilter(self)
        self.setGeometry(page.rect())
        self.lower()

    def eventFilter(self, obj, event) -> bool:
        kind = event.type()
        if obj is self.parent():
            if kind == QEvent.Type.Resize:
                self.setGeometry(obj.rect())
                self.lower()
                self.update()
        elif kind in (QEvent.Type.Move, QEvent.Type.Resize, QEvent.Type.Show, QEvent.Type.Hide):
            self.update()
        return False

    def paintEvent(self, _event) -> None:
        dark = self._theme_name() == "dark"
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(Qt.PenStyle.NoPen)
        self._wave(p, dark)
        shadow = QColor(0, 0, 0) if dark else QColor(26, 31, 41)
        for card in self._cards:
            if not card.isVisible():
                continue
            rect = QRectF(card.mapTo(self.parentWidget(), QPoint(0, 0)), card.size())
            for i in range(6, 0, -1):                 # six faint layers, largest first: darkest right at the card edge
                shadow.setAlpha((14 if dark else 8) * 1)
                p.setBrush(shadow)
                p.drawRoundedRect(rect.adjusted(-i, -i + 2, i, i + 2), 10 + i, 10 + i)

    # (start point, bezier segments (c1, c2, end), alpha at the top of the strip, alpha at its bottom) in fractions of width / strip height.
    # The shared wave of the redesigned pages (options 1, 2, 3): two overlapping crests with straight diagonal flanks, traced from the reference design.
    _WAVE_LAYERS = (
        ((0.563, 1.0), (((0.678, 0.67), (0.802, -0.004), (0.85, -0.007)), ((0.885, -0.058), (0.944, 0.018), (1.0, 0.312))), 30, 1),
        ((0.733, 1.0), (((0.774, 0.604), (0.938, -0.0), (0.987, -0.009)), ((0.997, 0.098), (1.007, -0.082), (1.0, 0.128))), 27, 2),
    )
    _WAVE_BOTTOM_KEEP = 0.43        # how much of the wave is left at the bottom of the strip (it dissolves instead of ending in an edge)

    def _wave(self, p: QPainter, dark: bool) -> None:
        """Two very soft, overlapping crests in the strip above the cards: strongest under their upper edge, dissolving downwards and into the page."""
        w, hb = float(self.width()), max(60.0, float(self._header_bottom()) + 14)       # hb: a little behind the first cards
        accent = QColor(PALETTES["dark" if dark else "light"]["accent"])
        ratio = self.devicePixelRatioF()
        layer = QImage(int(w * ratio) + 1, int(hb * ratio) + 1, QImage.Format.Format_ARGB32_Premultiplied)
        layer.setDevicePixelRatio(ratio)
        layer.fill(0)
        lp = QPainter(layer)
        lp.setRenderHint(QPainter.RenderHint.Antialiasing)
        lp.setPen(Qt.PenStyle.NoPen)
        for (sx, sy), segments, alpha, end_alpha in self._WAVE_LAYERS:
            path = QPainterPath(QPointF(w * sx, hb * sy))
            for c1, c2, end in segments:
                path.cubicTo(QPointF(w * c1[0], hb * c1[1]), QPointF(w * c2[0], hb * c2[1]), QPointF(w * end[0], hb * end[1]))
            path.lineTo(w, hb)
            path.closeSubpath()
            grad = QLinearGradient(QPointF(0, 0), QPointF(0, hb))       # strongest right under the crest line, fading straight down
            strong, faint = QColor(accent), QColor(accent)
            strong.setAlpha(round(alpha * (0.85 if dark else 1.0)))
            faint.setAlpha(round(end_alpha * (0.85 if dark else 1.0)))
            grad.setColorAt(0.0, strong)
            grad.setColorAt(1.0, faint)
            lp.setBrush(QBrush(grad))
            lp.drawPath(path)
        lp.setCompositionMode(QPainter.CompositionMode.CompositionMode_DestinationIn)       # soft lower edge
        fade = QLinearGradient(0, 0, 0, hb)
        fade.setColorAt(0.0, QColor(0, 0, 0, 255))
        fade.setColorAt(1.0, QColor(0, 0, 0, round(255 * self._WAVE_BOTTOM_KEEP)))
        lp.fillRect(QRectF(0, 0, w, hb), QBrush(fade))
        lp.end()
        p.drawImage(QPointF(0, 0), layer)
