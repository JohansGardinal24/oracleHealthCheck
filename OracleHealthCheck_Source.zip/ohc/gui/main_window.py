"""Main window: left navigation (with the Database Reports submenu), breadcrumb and theme toggle in the header, and the pages."""
from __future__ import annotations

from PySide6.QtCore import QSize, Qt
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel, QMainWindow, QStackedWidget,
                               QToolButton, QVBoxLayout, QWidget)

from ohc import __version__, paths
from ohc.gui.context import AppContext
from PySide6.QtWidgets import QMessageBox
from ohc.gui import outcomes
from ohc.gui.app_icon import app_icon, set_windows_app_id
from ohc.gui.awr_page import DatabaseReportsPage
from ohc.gui.dashboard_page import DashboardPage
from ohc.gui.reports_page import ReportsPage
from ohc.gui.run_page import RunPage
from ohc.gui.runner import JobGate
from ohc.gui.settings_page import SettingsPage
from ohc.gui.sidebar import COLLAPSED_WIDTH, WIDTH as SIDEBAR_WIDTH, Sidebar  # the two widths stay importable from here
from ohc.gui.theme import PALETTES, ThemeManager, make_icon
from ohc.gui.widgets import WrapLabel
from ohc.resources import sql_access

PAGES = [
    ("Dashboard", ""),
    ("1. Oracle Health Check", "SQL checks run here (later phase)."),
    ("2. Sync Check", "Data Guard / sync checks run here (later phase)."),
    ("3. All Checks", "All 21 checks run here (later phase)."),
    ("4. Database Reports", "AWR / ASH / ADDM reports (later phase)."),
    ("Reports & Logs", "Browse reports and logs (later phase)."),
    ("Settings", ""),
]


REPORTS_ROW = 4                                     # "4. Database Reports": its AWR / ASH / ADDM tabs are the sidebar submenu
REPORT_TABS = ("AWR", "ASH", "ADDM")                # tab order of DatabaseReportsPage
# sidebar layout; the numbers are the row of the page in PAGES
NAV = [
    ("item", "Dashboard", "dashboard", 0),
    ("section", "HEALTH CHECKS"),
    ("item", "1. Oracle Health Check", "health", 1),
    ("item", "2. Sync Check", "sync", 2),
    ("item", "3. All Checks", "checks", 3),
    ("section", "REPORTS"),
    ("group", "Database Reports", "reports", REPORTS_ROW, [(name, i) for i, name in enumerate(REPORT_TABS)]),
    ("item", "Reports & Logs", "logs", 5),
    ("stretch",),
    ("item", "Settings", "settings", 6),
]

RUN_PAGES = {
    "1. Oracle Health Check": ("1", "Runs the Oracle checks (database status, tablespaces, locks, indexes, jobs, patches ...). Read-only."),
    "2. Sync Check": ("2", "Data Guard synchronization (DGMGRL), FRA utilization, redo log status and RMAN backup status."),
    "3. All Checks": ("3", "Runs option 1 and option 2 together: all 21 checks."),
}


class MainWindow(QMainWindow):
    def __init__(self, context: AppContext | None = None) -> None:
        super().__init__()
        set_windows_app_id()                 # own taskbar identity, so the taskbar shows this icon (before the window is shown)
        icon = app_icon()
        self.setWindowIcon(icon)
        if QApplication.instance() is not None:
            QApplication.instance().setWindowIcon(icon)   # dialogs and message boxes inherit it
        self.ctx = context or AppContext.ephemeral()
        self.theme = ThemeManager(self.ctx.settings, self)
        self.setWindowTitle("Oracle Health Check")
        self.resize(1360, 860)
        # no fixed minimum size: Qt keeps the window no smaller than its content needs, so nothing is ever clipped

        root = QWidget()
        root.setObjectName("content")
        self.setCentralWidget(root)
        layout = QHBoxLayout(root)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.sidebar = Sidebar(NAV, __version__, PALETTES[self.theme.theme])
        self.nav = self.sidebar              # setCurrentRow(page row) / currentRow() still work on it
        self.nav_box, self.nav_toggle, self.brand = self.sidebar, self.sidebar.toggle_btn, self.sidebar.brand
        self.sidebar_collapsed = False
        self.nav_toggle.clicked.connect(self.toggle_sidebar)
        self.sidebar.navigate.connect(self._open)

        self.gate = JobGate(self)
        self.pages = QStackedWidget()
        built = {}
        for title, note in PAGES:
            if title in RUN_PAGES:
                page = RunPage(self.ctx, RUN_PAGES[title][0], title, RUN_PAGES[title][1], self.gate, theme=self.theme)
            elif title == "4. Database Reports":
                page = DatabaseReportsPage(self.ctx, self.gate, self.theme)
            elif title == "Reports & Logs":
                page = ReportsPage(self.ctx, theme=self.theme)
            elif title == "Settings":
                page = SettingsPage(self.ctx, self.theme, gate=self.gate)
                self.settings_page = page
            elif title == "Dashboard":
                continue                     # built below: it needs the run pages
            else:
                page = self._simple_page(title, note)
            built[title] = page
        run_pages = {row: built[title] for row, (title, _n) in enumerate(PAGES) if title in RUN_PAGES}
        built["Dashboard"] = DashboardPage(self.ctx, self.gate, run_pages, self._goto, self.theme)
        for title, _note in PAGES:
            self.pages.addWidget(built[title])
        built["4. Database Reports"].tabs.currentChanged.connect(self._reports_tab_changed)  # keep the submenu in step with the page's own tabs

        header = QFrame()
        header.setObjectName("header")
        header.setMinimumHeight(52)
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(24, 6, 16, 6)
        self.crumb = QLabel("")              # where you are: "Dashboard", "Database Reports  \u203A  AWR", ...
        self.crumb.setObjectName("crumb")
        header_layout.addWidget(self.crumb)
        header_layout.addSpacing(16)
        banner_text, banner_level = outcomes.fake_status()
        self.fake_banner = QLabel(banner_text)
        self.fake_banner.setObjectName("bad" if banner_level == "bad" else "warn")
        banner_font = self.fake_banner.font()
        banner_font.setBold(True)
        self.fake_banner.setFont(banner_font)
        self.fake_banner.setWordWrap(True)  # wraps in a narrow window instead of widening it
        self.fake_banner.setVisible(bool(banner_text))
        header_layout.addWidget(self.fake_banner, 1)
        header_layout.addStretch(0)
        self.toggle = QToolButton()
        self.toggle.setObjectName("themeToggle")
        self.toggle.setFixedSize(36, 36)
        self.toggle.setIconSize(QSize(22, 22))
        self.toggle.setCursor(Qt.CursorShape.PointingHandCursor)
        self.toggle.clicked.connect(self.theme.toggle)
        header_layout.addWidget(self.toggle, 0, Qt.AlignmentFlag.AlignRight)

        right = QWidget()
        right.setObjectName("content")
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(0)
        right_layout.addWidget(header)
        right_layout.addWidget(self.pages, 1)
        layout.addWidget(self.sidebar)
        layout.addWidget(right, 1)

        self.theme.changed.connect(lambda _name: self._update_toggle())
        self.theme.apply()
        self._update_toggle()
        self._open(0)

    def toggle_sidebar(self) -> None:
        self.set_sidebar_collapsed(not self.sidebar_collapsed)

    def set_sidebar_collapsed(self, collapsed: bool) -> None:
        """Collapsed: a narrow icon rail (full names in tooltips). Expanded: as designed."""
        self.sidebar_collapsed = collapsed
        self.sidebar.set_collapsed(collapsed)
        self.nav_toggle.setToolTip("Expand the sidebar" if collapsed else "Collapse the sidebar")

    def closeEvent(self, event) -> None:
        if self.gate.busy:  # a worker thread must not be destroyed while it runs
            QMessageBox.information(self, "Oracle Health Check", "A run is still in progress. Click Cancel and wait for it to stop (or wait for it to finish), then close the window.")
            event.ignore()
            return
        super().closeEvent(event)

    def _update_toggle(self) -> None:
        """The icon shows the theme a click switches TO: sun while dark, moon while light."""
        current = self.theme.theme
        kind = "sun" if current == "dark" else "moon"
        self.toggle.setIcon(make_icon(kind, PALETTES[current]["icon"]))
        self.toggle.setToolTip(f"Switch to {'Light' if current == 'dark' else 'Dark'} mode")
        self.toggle.setProperty("icon_kind", kind)
        self.nav_toggle.setIcon(make_icon("menu", PALETTES[current]["sidebar_text"]))
        self.sidebar.refresh_icons(PALETTES[current])
        self.nav_toggle.setToolTip("Expand the sidebar" if self.sidebar_collapsed else "Collapse the sidebar")

    @staticmethod
    def _page_shell(title: str) -> tuple:
        page = QWidget()
        page.setObjectName("page")
        box = QVBoxLayout(page)
        box.setContentsMargins(40, 8, 40, 36)
        box.setSpacing(10)
        heading = QLabel(title)
        heading.setObjectName("title")
        box.addWidget(heading)
        return page, box

    def _simple_page(self, title: str, note: str) -> QWidget:
        page, box = self._page_shell(title)
        label = QLabel(note)
        label.setObjectName("muted")
        box.addWidget(label)
        box.addStretch(1)
        return page

    def _open(self, row: int, tab: int | None = None) -> None:
        """Show a page (and, for Database Reports, its AWR / ASH / ADDM tab); the sidebar and breadcrumb follow. Nothing is started."""
        if tab is not None:
            self.pages.widget(row).tabs.setCurrentIndex(tab)
        self.pages.setCurrentIndex(row)
        self._follow(row)

    def _follow(self, row: int) -> None:
        tab = self.pages.widget(row).tabs.currentIndex() if row == REPORTS_ROW else None  # the page's real tab (a disabled tab refuses a switch)
        self.sidebar.set_current(row, tab)
        name = "Overview" if row == 0 else PAGES[row][0].split(". ", 1)[-1]     # the Dashboard page carries its own "Dashboard" heading
        self.crumb.setText(f"{name}  \u203A  {REPORT_TABS[tab]}" if tab is not None else name)

    def _reports_tab_changed(self, _index: int) -> None:
        if self.pages.currentIndex() == REPORTS_ROW:
            self._follow(REPORTS_ROW)

    def _goto(self, row: int, tab: int | None = None) -> None:
        """Dashboard navigation: open a page (and, for Database Reports, its AWR / ASH / ADDM tab). Nothing is started."""
        self._open(row, tab)
