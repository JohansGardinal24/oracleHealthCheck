"""Finds the reports and logs the health check already wrote (read-only; nothing is created, changed or deleted).

Names (see engine.run_checks):  logs\\ohc_<db>_<yyyymmdd_HHMMSS>.log   reports\\<date folder>\\<db>_health_<yyyymmdd_HHMMSS>.html
The run time is taken from the timestamp in the file name (the date folder name is configurable, so it is not used).
Status and check counts come from the files' own text: the log's ' OVERALL: X' line / summary lines, the report's
Overall badge / summary table. Anything that cannot be read reliably is reported as UNKNOWN, never guessed.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path


LOG_RE = re.compile(r"^ohc_(?P<db>.+)_(?P<ts>(?P<d>\d{8})_(?P<t>\d{6}))\.log$", re.I)
REPORT_RE = re.compile(r"^(?P<db>.+)_health_(?P<ts>(?P<d>\d{8})_(?P<t>\d{6}))\.html$", re.I)
SIMULATED = "FAKE / SIMULATED DATA"
KNOWN = ("OK", "WARNING", "CRITICAL", "CANCELLED")
MAX_ENTRIES = 1000
LOG_TAIL, LOG_HEAD, REPORT_HEAD = 65536, 4096, 32768

_OVERALL = re.compile(r"^ OVERALL: (\w+)", re.M)
_SUMMARY = re.compile(r"^\[\d+\] .+ : (?:OK|WARNING|CRITICAL|INFO|SKIPPED)\s+-", re.M)
_CANCELLED = re.compile(r"RUN CANCELLED BY THE USER - (\d+) of (\d+) checks completed")
_BADGE = re.compile(r'<td>Overall</td><td><span class="badge (\w+)"')
_ROWS = re.compile(r'href="#chk\d+"')


@dataclass(frozen=True)
class Entry:
    kind: str            # "report" or "log"
    path: Path
    name: str
    db: str
    when: datetime
    status: str          # OK / WARNING / CRITICAL / CANCELLED / UNKNOWN
    checks: str          # "" when unknown, "17", or "12 of 21" (cancelled runs whose log says the total)
    size: int
    simulated: bool

    @property
    def date_key(self) -> str:
        return self.when.strftime("%Y-%m-%d")

    @property
    def display_name(self) -> str:
        return ("[SIMULATED] " if self.simulated else "") + self.name


@dataclass
class Scan:
    entries: list = field(default_factory=list)
    folder: Path | None = None
    exists: bool = True
    note: str = ""       # e.g. "1 file(s) could not be read"


def format_size(n: int) -> str:
    if n < 1024:
        return f"{n} B"
    if n < 1024 * 1024:
        return f"{max(1, round(n / 1024))} KB"
    return f"{n / (1024 * 1024):.1f} MB"


def _when(m) -> datetime | None:
    try:
        return datetime.strptime(m.group("d") + m.group("t"), "%Y%m%d%H%M%S")
    except ValueError:
        return None


def _head(path: Path, n: int) -> str:
    with open(path, "rb") as f:
        return f.read(n).decode("utf-8", errors="replace")


def _tail(path: Path, n: int) -> str:
    with open(path, "rb") as f:
        f.seek(max(0, os.path.getsize(path) - n))
        return f.read().decode("utf-8", errors="replace")


def parse_log(path: Path) -> tuple:
    """(status, completed, total or None, simulated). Raises OSError when the file cannot be read."""
    tail = _tail(path, LOG_TAIL)
    found = _OVERALL.findall(tail)
    status = found[-1].upper() if found and found[-1].upper() in KNOWN else "UNKNOWN"
    completed, total = len(_SUMMARY.findall(tail)), None
    cancelled = _CANCELLED.search(tail)
    if cancelled:
        completed, total = int(cancelled.group(1)), int(cancelled.group(2))
    return status, completed, total, SIMULATED in _head(path, LOG_HEAD)


def parse_report(path: Path) -> tuple:
    """(status, completed, simulated) from the start of the report only. Raises OSError when unreadable."""
    head = _head(path, REPORT_HEAD)
    badge = _BADGE.search(head)
    status = badge.group(1).upper() if badge and badge.group(1).upper() in KNOWN else "UNKNOWN"
    return status, len(_ROWS.findall(head)), SIMULATED in head


def _checks_text(status: str, completed: int, total) -> str:
    if status == "CANCELLED" and total:
        return f"{completed} of {total}"
    return str(completed) if completed else ""


def _candidates(files, rx) -> list:
    out = []
    for path in files:
        m = rx.match(path.name)
        when = _when(m) if m else None
        if when is not None:
            out.append((when, path, m.group("db"), m.group("ts")))
    out.sort(key=lambda c: (c[0], c[1].name), reverse=True)
    return out[:MAX_ENTRIES]


def _size(path: Path) -> int:
    try:
        return path.stat().st_size
    except OSError:
        return 0


def scan_logs(log_dir: Path) -> Scan:
    log_dir = Path(log_dir)
    scan = Scan(folder=log_dir, exists=log_dir.is_dir())
    if not scan.exists:
        return scan
    try:
        files = [Path(e.path) for e in os.scandir(log_dir) if e.is_file()]
    except OSError as exc:
        scan.exists, scan.note = False, f"The folder cannot be read: {exc}"
        return scan
    unreadable = 0
    for when, path, db, _ts in _candidates(files, LOG_RE):
        try:
            status, completed, total, sim = parse_log(path)
            checks = _checks_text(status, completed, total)
        except OSError:
            status, checks, sim, unreadable = "UNKNOWN", "", False, unreadable + 1
        scan.entries.append(Entry("log", path, path.name, db, when, status, checks, _size(path), sim))
    scan.note = f"{unreadable} file(s) could not be read" if unreadable else ""
    return scan


def _paired_total(log_dir: Path, db: str, ts: str):
    """Total checks of a cancelled run, from the log of the same database and timestamp (None if there is no reliable match)."""
    log = Path(log_dir) / f"ohc_{db}_{ts}.log"
    try:
        if log.is_file():
            status, _completed, total, _sim = parse_log(log)
            return total if status == "CANCELLED" else None
    except OSError:
        pass
    return None


def scan_reports(report_base: Path, log_dir: Path) -> Scan:
    base = Path(report_base)
    scan = Scan(folder=base, exists=base.is_dir())
    if not scan.exists:
        return scan
    files = []
    try:
        for top in os.scandir(base):
            if top.is_dir():
                files += [Path(e.path) for e in os.scandir(top.path) if e.is_file()]
            elif top.is_file():
                files.append(Path(top.path))
    except OSError as exc:
        scan.note = f"Some folders could not be read: {exc}"
    unreadable = 0
    for when, path, db, ts in _candidates(files, REPORT_RE):
        try:
            status, completed, sim = parse_report(path)
            total = _paired_total(log_dir, db, ts) if status == "CANCELLED" else None
            checks = _checks_text(status, completed, total)
        except OSError:
            status, checks, sim, unreadable = "UNKNOWN", "", False, unreadable + 1
        scan.entries.append(Entry("report", path, path.name, db, when, status, checks, _size(path), sim))
    if unreadable:
        scan.note = (scan.note + "; " if scan.note else "") + f"{unreadable} file(s) could not be read"
    return scan


def dates_of(entries) -> list:
    return sorted({e.date_key for e in entries}, reverse=True)


def filter_entries(entries, date: str = "", text: str = "") -> list:
    """date: 'YYYY-MM-DD' or '' for all. text: case-insensitive match on name, database, status and date."""
    needle = text.strip().lower()
    out = []
    for e in entries:
        if date and e.date_key != date:
            continue
        if needle and needle not in " ".join((e.name, e.db, e.status, e.date_key, e.when.strftime("%H:%M"))).lower():
            continue
        out.append(e)
    return out
