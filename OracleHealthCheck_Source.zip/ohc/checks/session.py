"""One run's access to Oracle: SQL*Plus, DGMGRL, server-spec helper and the Windows service query.

Credentials never appear in a command line and are never written to a file: they are sent on the
standard input of SQL*Plus / DGMGRL. The bundled SQL is written verbatim to a private per-run folder
that is removed when the session closes. The SQL itself holds no secrets.
"""
from __future__ import annotations

import re
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

from ohc.checks.serverspec import SERVER_SPEC_PS
from ohc.resources import sql_access

ENC = "mbcs" if os.name == "nt" else "utf-8"  # SQL*Plus / dgmgrl / PowerShell write the ANSI code page
EXE = ".exe" if os.name == "nt" else ""
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


AWR_SNAP_SQL = """select 'SNAP|'||snap_id||'|'||to_char(bt,'YYYY-MM-DD HH24:MI:SS')||'|'||to_char(et,'YYYY-MM-DD HH24:MI:SS')||'|'||inst||'|'||nvl(to_char(st,'YYYY-MM-DD HH24:MI:SS'),'')
from (select s.snap_id snap_id, s.begin_interval_time bt, s.end_interval_time et, s.instance_number inst, s.startup_time st
      from dba_hist_snapshot s
      where s.dbid = (select dbid from v$database)
        and s.instance_number = (select instance_number from v$instance)
        and s.begin_interval_time >= sysdate - &awr_days
      order by s.snap_id desc)
where rownum <= 2001;
select 'SNAPDONE' from dual;
"""


SWITCHOVER_SQL = ("set pagesize 0 linesize 200 trimspool on feedback off heading off verify off echo off\n"
                  "select 'SWITCHOVER_STATUS|'||switchover_status from v$database;\nexit\n")


def awr_variant_sql(fmt: str, rac: bool) -> str:
    """Separate script for what the original AWR_Report.sql cannot do (Text output, all RAC instances, a chosen file name).
    Same approach as the original: SQL*Plus spools the DBMS_WORKLOAD_REPOSITORY output into the report file."""
    kind = "TEXT" if fmt == "text" else "HTML"
    if rac:
        call = f"DBMS_WORKLOAD_REPOSITORY.AWR_GLOBAL_REPORT_{kind}(&v_dbid, '&v_insts', &v_begin, &v_end)"
        insts = ("COLUMN insts NEW_VALUE v_insts NOPRINT\n"
                 "SELECT LISTAGG(instance_number, ',') WITHIN GROUP (ORDER BY instance_number) insts FROM (SELECT instance_number\n"
                 "  FROM dba_hist_snapshot WHERE dbid = &v_dbid AND snap_id IN (&v_begin, &v_end)\n"
                 "  GROUP BY instance_number HAVING COUNT(DISTINCT snap_id) = 2);\n")
    else:
        call = f"DBMS_WORKLOAD_REPOSITORY.AWR_REPORT_{kind}(&v_dbid, &v_inst, &v_begin, &v_end)"
        insts = "COLUMN inst NEW_VALUE v_inst NOPRINT\nSELECT instance_number inst FROM v$instance;\n"
    return ("SET ECHO OFF FEEDBACK OFF HEADING OFF PAGESIZE 0 LINESIZE 32767 LONG 100000000 LONGCHUNKSIZE 100000000 VERIFY OFF\n"
            "SET TRIMSPOOL ON TERMOUT OFF\n"
            "COLUMN dbid NEW_VALUE v_dbid NOPRINT\nSELECT dbid FROM v$database;\n" + insts +
            'SPOOL "&v_file" CREATE\n'
            f"SELECT output FROM TABLE({call});\n"
            "SPOOL OFF\nSET TERMOUT ON\nPROMPT Report generated at: &v_file\nEXIT\n")


def ash_variant_sql(fmt: str, rac: bool, relative: bool) -> str:
    """ASH report script (separate from the original ASH_Report.sql, which is interactive, HTML-only and single-instance).
    DBMS_WORKLOAD_REPOSITORY.ASH_REPORT_HTML/_TEXT(dbid, inst_num, begin DATE, end DATE) for one instance;
    ASH_GLOBAL_REPORT_HTML/_TEXT(dbid, inst_num VARCHAR2 list, begin DATE, end DATE) for RAC (every open instance of gv$instance)."""
    kind = "TEXT" if fmt == "text" else "HTML"
    if rac:
        call = f"DBMS_WORKLOAD_REPOSITORY.ASH_GLOBAL_REPORT_{kind}(&v_dbid, '&v_insts', TO_DATE('&v_bdate', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('&v_edate', 'YYYY-MM-DD HH24:MI:SS'))"
        inst = ("COLUMN insts NEW_VALUE v_insts NOPRINT\n"
                "SELECT LISTAGG(inst_id, ',') WITHIN GROUP (ORDER BY inst_id) insts FROM gv$instance;\n")
    else:
        call = f"DBMS_WORKLOAD_REPOSITORY.ASH_REPORT_{kind}(&v_dbid, &v_inst, TO_DATE('&v_bdate', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('&v_edate', 'YYYY-MM-DD HH24:MI:SS'))"
        inst = "COLUMN inst NEW_VALUE v_inst NOPRINT\nSELECT instance_number inst FROM v$instance;\n"
    if relative:
        window = "SELECT TO_CHAR(SYSDATE - &v_minutes / 1440, 'YYYY-MM-DD HH24:MI:SS') bdate, TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') edate FROM dual;\n"
    else:
        window = ("SELECT '&v_begin_ts' bdate, TO_CHAR(TO_DATE('&v_begin_ts', 'YYYY-MM-DD HH24:MI:SS') + &v_dur / 1440, 'YYYY-MM-DD HH24:MI:SS') edate FROM dual;\n")
    return ("SET ECHO OFF FEEDBACK OFF HEADING OFF PAGESIZE 0 LINESIZE 32767 LONG 100000000 LONGCHUNKSIZE 100000000 VERIFY OFF\n"
            "SET TRIMSPOOL ON TERMOUT OFF\n"
            "COLUMN dbid NEW_VALUE v_dbid NOPRINT\nSELECT dbid FROM v$database;\n" + inst +
            "COLUMN bdate NEW_VALUE v_bdate NOPRINT\nCOLUMN edate NEW_VALUE v_edate NOPRINT\n" + window +
            'SPOOL "&v_file" CREATE\n'
            f"SELECT output FROM TABLE({call});\n"
            "SPOOL OFF\nSET TERMOUT ON\nPROMPT ASH_PERIOD|&v_bdate|&v_edate\nPROMPT Report generated at: &v_file\nEXIT\n")


def addm_variant_sql(rac: bool) -> str:
    """ADDM report script (separate from the original ADDM_Report.sql, which is interactive, single-instance and has a fixed file name).
    TEXT ONLY, like the original: the report is DBMS_ADDM.GET_REPORT(task). Analysis: DBMS_ADDM.ANALYZE_INST(task, begin_snap, end_snap,
    instance, dbid) for the connected instance (as the original script), DBMS_ADDM.ANALYZE_DB(task, begin_snap, end_snap, dbid) for RAC
    (all instances). The task is left in the advisor repository like the original script does. WHENEVER SQLERROR EXIT stops before any
    spooling, so a failed analysis never leaves a file."""
    if rac:
        inst, analyze = "", "DBMS_ADDM.ANALYZE_DB(:v_task, &v_begin, &v_end, &v_dbid);"
    else:
        inst = "COLUMN inst NEW_VALUE v_inst NOPRINT\nSELECT instance_number inst FROM v$instance;\n"
        analyze = "DBMS_ADDM.ANALYZE_INST(:v_task, &v_begin, &v_end, &v_inst, &v_dbid);"
    return ("SET ECHO OFF FEEDBACK OFF HEADING OFF PAGESIZE 0 LINESIZE 32767 LONG 100000000 LONGCHUNKSIZE 100000000 VERIFY OFF TRIMSPOOL ON\n"
            "WHENEVER SQLERROR EXIT FAILURE\n"
            "COLUMN dbid NEW_VALUE v_dbid NOPRINT\nSELECT dbid FROM v$database;\n" + inst +
            "VARIABLE v_task VARCHAR2(100)\n"
            "BEGIN\n  :v_task := '&v_task_name';\n  " + analyze + "\nEND;\n/\n"
            "SET TERMOUT OFF\n"
            'SPOOL "&v_file" CREATE\n'
            "SELECT DBMS_ADDM.GET_REPORT(:v_task) FROM dual;\n"
            "SPOOL OFF\nSET TERMOUT ON\nPROMPT ADDM_TASK|&v_task_name\nPROMPT Report generated at: &v_file\nEXIT\n")


class ToolError(RuntimeError):
    """Tool or configuration problem (exit code 3) - not a database health result."""


class QueryTimeout(ToolError):
    """One SQL*Plus / DGMGRL call did not finish in time (reported by the engine as that check failing)."""


def _clean(value: bytes, what: str) -> bytes:
    if not value or any(b in value for b in (b"\r", b"\n", b"\x00", b'"')):
        raise ToolError(f"The stored {what} is empty or contains a character that cannot be used in a connect string.")
    return value


class OracleSession:
    def __init__(self, oracle_home, sid, credentials, defines=(), dg_service="", nls_lang="", timeout=900, popen=subprocess.Popen, cancel=None):
        self.home, self.sid, self.dg_service, self.timeout = str(oracle_home), sid, dg_service, timeout
        self._user = _clean(bytes(credentials.username), "user name")
        self._pw = _clean(bytes(credentials.password), "password")
        self._defs = [f"define {k}={v}" for k, v in defines]
        self._popen = popen
        self.cancel = cancel
        self.env = dict(os.environ, ORACLE_HOME=self.home, ORACLE_SID=sid)
        self.env["PATH"] = str(Path(self.home) / "bin") + os.pathsep + self.env.get("PATH", "")
        if nls_lang:
            self.env["NLS_LANG"] = nls_lang
        self.run_dir = Path(tempfile.mkdtemp(prefix="ohc_"))
        self._restrict(self.run_dir)
        self._scripts: dict = {}

    def __enter__(self):
        return self

    def __exit__(self, *exc_info) -> None:
        self.close()

    def close(self) -> None:
        self._user = self._pw = b""
        shutil.rmtree(self.run_dir, ignore_errors=True)

    @staticmethod
    def _restrict(folder: Path) -> None:  # best effort, like the BAT: only the current user may use the folder
        if os.name == "nt" and os.environ.get("USERNAME"):
            subprocess.run(["icacls", str(folder), "/inheritance:r", "/grant:r", f"{os.environ['USERNAME']}:(OI)(CI)F"],
                           capture_output=True, creationflags=_NO_WINDOW, check=False)

    def _exe(self, name: str) -> str:
        exe = Path(self.home) / "bin" / f"{name}{EXE}"
        if not exe.is_file():
            raise ToolError(f"{name}{EXE} was not found in {Path(self.home) / 'bin'}")
        return str(exe)

    def _script(self, name: str) -> Path:
        if name not in self._scripts:
            path = self.run_dir / name
            path.write_bytes(sql_access.get_sql(name))  # verified against its SHA-256 first
            self._scripts[name] = path
        return self._scripts[name]

    def _run(self, argv, stdin: bytearray, cwd=None) -> str:
        if self.cancel is not None:
            self.cancel.check()
        try:
            proc = self._popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               env=self.env, cwd=str(cwd or self.run_dir), creationflags=_NO_WINDOW)
        except OSError as exc:
            raise ToolError(f"Cannot start {Path(argv[0]).name}: {exc}") from None
        if self.cancel is not None:
            self.cancel.register(proc)
        try:
            out, _ = proc.communicate(bytes(stdin), timeout=self.timeout)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.communicate()
            raise QueryTimeout(f"{Path(argv[0]).name} did not finish within {self.timeout} seconds") from None
        finally:
            if self.cancel is not None:
                self.cancel.unregister(proc)
            for i in range(len(stdin)):
                stdin[i] = 0
        if self.cancel is not None:
            self.cancel.check()  # a killed process returns partial output: never interpret it as a result
        return out.decode(ENC, errors="replace")

    def sql(self, mode: str, name: str) -> str:
        """mode 'report' or 'value' - the same SQL*Plus settings as the BAT's :sql helper."""
        script = self._script(name)
        enc = lambda text: text.encode(ENC, errors="replace")
        pre = bytearray(b"set define off\nconnect " + self._user + b'/"' + self._pw + b'" as sysdba\nset define on\n')
        lines = list(self._defs) + ["set sqlblanklines on"]
        lines.append("set pagesize 0 linesize 1000 trimspool on feedback off heading off verify off echo off" if mode == "value"
                     else "set pagesize 200 linesize 1000 trimspool on timing on feedback on heading on verify off")
        lines += [f'@"{script}"', "exit"]
        pre += enc("\n".join(lines) + "\n")
        return self._run([self._exe("sqlplus"), "-s", "/nolog"], pre)

    # ---- AWR (Database Reports page). Same credential path as sql(): the login goes to SQL*Plus on stdin only.
    def _connect_lines(self) -> bytearray:
        return bytearray(b"set define off\nconnect " + self._user + b'/"' + self._pw + b'" as sysdba\nset define on\n')

    def awr_snapshots(self, days: int) -> str:
        """Read-only snapshot list of THIS database and instance (DBID from v$database, instance from v$instance)."""
        script = self.run_dir / "awr_snapshots.sql"
        script.write_text(AWR_SNAP_SQL, encoding="ascii")
        pre = self._connect_lines()
        pre += f'define awr_days={int(days)}\nset sqlblanklines on\nset pagesize 0 linesize 400 trimspool on feedback off heading off verify off echo off\n@"{script}"\nexit\n'.encode(ENC, errors="replace")
        return self._run([self._exe("sqlplus"), "-s", "/nolog"], pre)

    def switchover_status(self) -> str:
        """One read-only line 'SWITCHOVER_STATUS|<value>' from v$database (used once, by Test Connection, to classify the database)."""
        script = self.run_dir / "switchover_status.sql"
        script.write_text(SWITCHOVER_SQL, encoding="ascii")
        pre = self._connect_lines()
        pre += f'@"{script}"\nexit\n'.encode(ENC, errors="replace")
        return self._run([self._exe("sqlplus"), "-s", "/nolog"], pre)

    def awr_report(self, report_dir, days: int, begin: int, end: int) -> str:
        """Runs the ORIGINAL AWR_Report.sql unchanged; its three ACCEPT prompts are answered from stdin (days, begin, end)."""
        folder = str(report_dir)
        if any(c in folder for c in ("'", "&", '"', "\r", "\n", "\x00")):
            raise ToolError("The report folder path contains a character (' & \") that SQL*Plus cannot use in the report file name.")
        script = self._script("AWR_Report.sql")
        pre = self._connect_lines()
        pre += f"define rpt_dir='{folder}'\n@\"{script}\"\n{int(days)}\n{int(begin)}\n{int(end)}\nexit\n".encode(ENC, errors="replace")
        return self._run([self._exe("sqlplus"), "-s", "/nolog"], pre, cwd=self.run_dir)

    def awr_report_variant(self, report_file, fmt: str, rac: bool, begin: int, end: int) -> str:
        """Text / RAC / custom-name report: awr_variant_sql() instead of the original script. SPOOL ... CREATE never overwrites."""
        target = str(report_file)
        if any(c in target for c in ("'", "&", '"', "\r", "\n", "\x00")):
            raise ToolError("The report path contains a character (' & \") that SQL*Plus cannot use in the report file name.")
        script = self.run_dir / "awr_variant.sql"
        script.write_text(awr_variant_sql(fmt, rac), encoding="ascii")
        pre = self._connect_lines()
        pre += f"define v_begin={int(begin)}\ndefine v_end={int(end)}\ndefine v_file='{target}'\n@\"{script}\"\nexit\n".encode(ENC, errors="replace")
        return self._run([self._exe("sqlplus"), "-s", "/nolog"], pre, cwd=self.run_dir)

    def ash_report(self, report_file, fmt: str, rac: bool, window) -> str:
        """ASH report (HTML/Text, single instance or RAC) for an ohc.ash.Window; SPOOL ... CREATE never overwrites."""
        target = str(report_file)
        if any(c in target for c in ("'", "&", '"', "\r", "\n", "\x00")):
            raise ToolError("The report path contains a character (' & \") that SQL*Plus cannot use in the report file name.")
        relative = window.mode == "relative"
        script = self.run_dir / "ash_report.sql"
        script.write_text(ash_variant_sql(fmt, rac, relative), encoding="ascii")
        pre = self._connect_lines()
        if relative:
            pre += f"define v_minutes={int(window.minutes_back)}\n".encode()
        else:
            pre += f"define v_begin_ts='{window.begin.strftime('%Y-%m-%d %H:%M:%S')}'\ndefine v_dur={int(window.duration)}\n".encode()
        pre += f"define v_file='{target}'\n@\"{script}\"\nexit\n".encode(ENC, errors="replace")
        return self._run([self._exe("sqlplus"), "-s", "/nolog"], pre, cwd=self.run_dir)

    def addm_report(self, report_file, rac: bool, begin: int, end: int, task: str) -> str:
        """ADDM text report for an AWR snapshot range (connected instance or RAC); SPOOL ... CREATE never overwrites."""
        target = str(report_file)
        if any(c in target for c in ("'", "&", '"', "\r", "\n", "\x00")):
            raise ToolError("The report path contains a character (' & \") that SQL*Plus cannot use in the report file name.")
        if not re.fullmatch(r"ADDM_\d{1,18}_\d{1,18}_\d{8}_\d{6}", task):
            raise ToolError("Invalid ADDM task name.")
        script = self.run_dir / "addm_report.sql"
        script.write_text(addm_variant_sql(rac), encoding="ascii")
        pre = self._connect_lines()
        pre += f"define v_begin={int(begin)}\ndefine v_end={int(end)}\ndefine v_task_name={task}\n".encode()
        pre += f"define v_file='{target}'\n@\"{script}\"\nexit\n".encode(ENC, errors="replace")
        return self._run([self._exe("sqlplus"), "-s", "/nolog"], pre, cwd=self.run_dir)

    def dgmgrl(self, commands) -> str:
        conn = bytearray(b'connect ' + self._user + b'/"' + self._pw + b'"')
        if self.dg_service:
            conn += b"@" + self.dg_service.encode("ascii")
        conn += b"\r\n" + "\r\n".join(commands).encode(ENC, errors="replace") + b"\r\n"
        return self._run([self._exe("dgmgrl"), "-silent"], conn)

    def server_spec(self, disk_warn: int, disk_crit: int) -> tuple:
        """-> (raw text, status line). Same read-only CIM queries as the BAT's PowerShell helper."""
        ps, out = self.run_dir / "serverspec.ps1", self.run_dir / "serverspec.txt"
        ps.write_text(SERVER_SPEC_PS, encoding="utf-8-sig")
        text = self._run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(ps), "-OutFile", str(out),
                          "-DiskWarn", str(int(disk_warn)), "-DiskCrit", str(int(disk_crit))], bytearray())
        lines = [x for x in text.splitlines() if x.strip()]
        raw = out.read_text(encoding=ENC, errors="replace") if out.is_file() else ""
        return raw, (lines[-1] if lines else "")

    def service_query(self, sid: str) -> str:
        """Output of 'sc query OracleService<SID>' ('' where sc does not exist)."""
        if self.cancel is not None:
            self.cancel.check()
        try:
            done = subprocess.run(["sc", "query", f"OracleService{sid}"], capture_output=True, creationflags=_NO_WINDOW, timeout=60)
        except (OSError, subprocess.TimeoutExpired):
            return ""
        return (done.stdout + done.stderr).decode(ENC, errors="replace")
