"""DEVELOPMENT ONLY: a stand-in for OracleSession so the GUI and the engine can be tried on a machine without Oracle.

Enabled by the environment variable OHC_FAKE_ORACLE=healthy|warning|critical|down, and never in the packaged EXE.
Every message it produces starts with [FAKE]; nothing here contacts a database or starts SQL*Plus / DGMGRL.
"""
from __future__ import annotations

import os
import time
from datetime import datetime, timedelta
from pathlib import Path

from ohc.checks.cancel import RunCancelled

SCENARIOS = ("healthy", "warning", "critical", "down")
_WARN = {"v_tbs.sql": "Highest: USERS 75%", "v_rman.sql": "last backup 3 days ago"}
# the original verdict scripts of these checks always answer INFO (never OK/WARNING), so the fake backend does too
_INFO = ("v_top_events.sql", "v_locks.sql", "v_index.sql", "v_segment.sql", "v_ims_sched.sql", "v_ims_jobs.sql", "v_dop.sql",
         "v_running.sql", "v_dump_history.sql", "v_db_patch.sql")
_CRIT = {"v_fra.sql": "FRA 93% used"}
AWR_MODES = ("", "empty", "fail", "capped", "restart", "badreport")  # OHC_FAKE_AWR (development only), see FakeOracleSession.awr_*
ASH_MODES = ("", "badreport", "empty", "fail", "norac")  # OHC_FAKE_ASH (development only), see FakeOracleSession.ash_report
ADDM_MODES = ("", "badreport", "empty", "fail", "norac")  # OHC_FAKE_ADDM (development only), see FakeOracleSession.addm_report
_AWR_FIRST_ID, _AWR_HOURS = 9001, 61
_TAG = "[FAKE / SIMULATED] Data Guard output - no broker or database was contacted\n"
_CFG = _TAG + "Configuration - fake_dg\n\n  Members:\n  prim - Primary database\n    stby - Physical standby database\n\nConfiguration Status:\nSUCCESS\n"
_DB = _TAG + "Database - stby\n  Transport Lag:      0 seconds\n  Apply Lag:          {lag}\nDatabase Status:\n{status}\n"


class FakeOracleSession:
    simulated = True  # the engine labels every summary it records from this session as [FAKE]

    def __init__(self, scenario: str, sid: str, dg_service: str = "", delay: float = 0.0, cancel=None):
        if scenario not in SCENARIOS:
            raise ValueError(f"unknown scenario {scenario!r}")
        self.scenario, self.sid, self.dg_service, self.delay, self.cancel = scenario, sid, dg_service, delay, cancel

    def _pause(self) -> None:
        """Optional OHC_FAKE_DELAY: makes the run slow enough to watch the progress and to try Cancel."""
        if self.cancel is not None:
            self.cancel.check()
        if self.delay > 0:
            if self.cancel is not None:
                if self.cancel.wait(self.delay):
                    raise RunCancelled("Run cancelled by the user")
            else:
                time.sleep(self.delay)

    def __enter__(self):
        return self

    def __exit__(self, *exc_info) -> None:
        pass

    def close(self) -> None:
        pass

    def service_query(self, sid: str) -> str:
        self._pause()
        return "STATE              : 1  STOPPED" if self.scenario == "down" else "STATE              : 4  RUNNING"

    def sql(self, mode: str, name: str) -> str:
        self._pause()
        if name == "v_db_info.sql":
            return f"OPEN|PRIMARY|READ WRITE|{self.sid}|{self.sid}\n"
        if mode == "report":
            return f"[FAKE] sample output of {name} - no database was contacted\n"
        if name in _INFO:
            return f"INFO|[FAKE] {name} informational result\n"
        if self.scenario == "warning" and name in _WARN:
            return f"WARNING|[FAKE] {_WARN[name]}\n"
        if self.scenario == "critical" and name in _CRIT:
            return f"CRITICAL|[FAKE] {_CRIT[name]}\n"
        return f"OK|[FAKE] {name} healthy\n"

    def dgmgrl(self, commands) -> str:
        self._pause()
        if commands[0] == "show configuration":
            return _CFG
        if self.scenario == "critical":
            return _DB.format(lag="2 minutes", status="ERROR")
        return _DB.format(lag="3 minutes" if self.scenario == "warning" else "5 seconds", status="SUCCESS")

    def server_spec(self, disk_warn: int, disk_crit: int) -> tuple:
        self._pause()
        return ("== DISK ==\n[FAKE] no server was queried", "OK|[FAKE] Disk: highest 40% at C: (0 critical, 0 warning)")

    # ---- AWR (Database Reports page). Same text formats as the real SQL*Plus session, so the real parsers are exercised.
    @staticmethod
    def awr_mode() -> str:
        mode = os.environ.get("OHC_FAKE_AWR", "").strip().lower()
        return mode if mode in AWR_MODES else ""

    def _awr_rows(self, now=None) -> list:
        """[(snap_id, begin, end, instance, startup)] hourly, newest last; the snapshot ids are 9001, 9002, ..."""
        now = now or datetime.now()
        last = now.replace(minute=0, second=7, microsecond=0)
        mode, rows = self.awr_mode(), []
        count = 2001 if mode == "capped" else _AWR_HOURS
        step = timedelta(minutes=3) if mode == "capped" else timedelta(hours=1)   # capped: 2001 snapshots inside one week
        startup0 = last.replace(hour=0, minute=0, second=3) - timedelta(days=30)   # one instance startup for the whole list
        for i in range(count):
            begin = last - step * (count - 1 - i)
            startup = startup0       # (it used to follow each row's calendar day: ranges across midnight looked like a restart)
            if mode == "restart" and i >= count // 2:
                startup = last - timedelta(hours=count // 2 + 1)
            rows.append((_AWR_FIRST_ID + i, begin, begin + step, 1, startup))
        return rows

    def switchover_status(self) -> str:
        """OHC_FAKE_SWITCHOVER = a SWITCHOVER_STATUS value (default TO STANDBY = Data Guard) or ERROR to simulate a failing query."""
        self._pause()
        if self.scenario == "down":
            return "ERROR:\nORA-01034: ORACLE not available\n"
        value = os.environ.get("OHC_FAKE_SWITCHOVER", "TO STANDBY").strip()
        if value.upper() == "ERROR":
            return "ERROR at line 1:\nORA-00942: table or view does not exist\n"
        return f"SWITCHOVER_STATUS|{value.upper()}\n"

    def awr_snapshots(self, days: int) -> str:
        self._pause()
        if self.scenario == "down":
            return "ERROR:\nORA-01034: ORACLE not available\nORA-27101: shared memory realm does not exist\n"
        mode = self.awr_mode()
        if mode == "fail":
            return "ERROR at line 5:\nORA-00942: table or view does not exist\n"
        if mode == "empty":
            return "SNAPDONE\n"
        cutoff = datetime.now() - timedelta(days=int(days))
        rows = [r for r in self._awr_rows() if r[1] >= cutoff]
        rows.reverse()   # the real query returns the newest first
        fmt = "%Y-%m-%d %H:%M:%S"
        lines = [f"SNAP|{i}|{b.strftime(fmt)}|{e.strftime(fmt)}|{n}|{u.strftime(fmt)}" for i, b, e, n, u in rows[:2001]]
        return "\n".join(lines + ["SNAPDONE", ""])

    def awr_report(self, report_dir, days: int, begin: int, end: int) -> str:
        """Writes a clearly marked simulated report with the legacy file name; nothing is contacted."""
        self._pause()
        folder = Path(report_dir)
        if self.scenario == "down":
            return "ERROR:\nORA-01034: ORACLE not available\n"
        ids = {r[0] for r in self._awr_rows()}
        name = f"AWR_Report_{begin}_{end}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
        path = folder / name
        folder.mkdir(parents=True, exist_ok=True)
        path.write_text("<html><body>partial output (simulated)", encoding="utf-8")  # like a spool file that exists while SQL*Plus runs
        self._pause()   # a cancel here leaves the partial file behind, exactly what the service must clean up
        if self.awr_mode() == "badreport" or begin not in ids or end not in ids:
            path.write_text("ORA-20019: Invalid snapshot IDs (simulated)\nORA-06512: at \"SYS.DBMS_WORKLOAD_REPOSITORY\", line 1\n", encoding="utf-8")
        else:
            path.write_text("<!DOCTYPE html><html><head><title>AWR Report (SIMULATED)</title></head><body>"
                            f"<h1>FAKE / SIMULATED DATA - AWR report for snapshots {begin} to {end}</h1>"
                            "<p>No database was contacted; this is not a real AWR report.</p></body></html>\n", encoding="utf-8")
        return f"Generating AWR report...\nReport generated at: {path}\n"

    def awr_report_variant(self, report_file, fmt: str, rac: bool, begin: int, end: int) -> str:
        """Simulated Text / RAC / custom-name report written to exactly report_file (never overwrites, like SPOOL ... CREATE)."""
        self._pause()
        path = Path(report_file)
        if self.scenario == "down":
            return "ERROR:\nORA-01034: ORACLE not available\n"
        if path.exists():
            return "SP2-0749: Unable to create file (simulated)\n"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("partial output (simulated)", encoding="utf-8")
        self._pause()   # a cancel here leaves a partial file for the service to remove
        ids = {r[0] for r in self._awr_rows()}
        scope = "RAC (all instances: 1,2)" if rac else "single instance (1)"
        if self.awr_mode() == "badreport" or begin not in ids or end not in ids:
            path.write_text("ORA-20019: Invalid snapshot IDs (simulated)\n", encoding="utf-8")
        elif fmt == "text":
            path.write_text(f"WORKLOAD REPOSITORY report (SIMULATED)\nFAKE / SIMULATED DATA - {scope}, snapshots {begin} to {end}\n"
                            "No database was contacted; this is not a real AWR report.\n", encoding="utf-8")
        else:
            path.write_text("<!DOCTYPE html><html><head><title>AWR Report (SIMULATED)</title></head><body>"
                            f"<h1>FAKE / SIMULATED DATA - {scope}, snapshots {begin} to {end}</h1></body></html>\n", encoding="utf-8")
        return f"Report generated at: {path}\n"

    # ---- ASH (Database Reports page)
    @staticmethod
    def ash_mode() -> str:
        mode = os.environ.get("OHC_FAKE_ASH", "").strip().lower()
        return mode if mode in ASH_MODES else ""

    def ash_report(self, report_file, fmt: str, rac: bool, window) -> str:
        """Simulated ASH report written to exactly report_file (never overwrites, like SPOOL ... CREATE)."""
        self._pause()
        path = Path(report_file)
        if self.scenario == "down":
            return "ERROR:\nORA-01034: ORACLE not available\n"
        mode = self.ash_mode()
        if mode == "fail":
            return "ERROR at line 1:\nORA-13616: The current user has not been granted the ADVISOR privilege (simulated)\n"
        if path.exists():
            return "SP2-0749: Unable to create file (simulated)\n"
        begin, end = window.span()
        period = f"ASH_PERIOD|{begin.strftime('%Y-%m-%d %H:%M:%S')}|{end.strftime('%Y-%m-%d %H:%M:%S')}\n"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("partial output (simulated)", encoding="utf-8")
        self._pause()   # a cancel here leaves a partial file for the service to remove
        scope = "RAC (all instances: 1,2)" if rac else "single instance (1)"
        if mode == "norac" and rac:
            path.write_text("PLS-00302: component 'ASH_GLOBAL_REPORT_HTML' must be declared (simulated)\n", encoding="utf-8")
        elif mode == "badreport":
            path.write_text("ORA-20019: Invalid time window (simulated)\n", encoding="utf-8")
        elif mode == "empty":
            path.write_text("", encoding="utf-8")
        elif fmt == "text":
            path.write_text(f"ASH Report For SIMULATED\nFAKE / SIMULATED DATA - {scope}, {begin} to {end}\n"
                            "No database was contacted; this is not a real ASH report.\n" + "x" * 600 + "\n", encoding="utf-8")
        else:
            path.write_text("<!DOCTYPE html><html><head><title>ASH Report (SIMULATED)</title></head><body>"
                            f"<h1>FAKE / SIMULATED DATA - {scope}, {begin} to {end}</h1></body></html>\n", encoding="utf-8")
        return period + f"Report generated at: {path}\n"

    # ---- ADDM (Database Reports page)
    @staticmethod
    def addm_mode() -> str:
        mode = os.environ.get("OHC_FAKE_ADDM", "").strip().lower()
        return mode if mode in ADDM_MODES else ""

    def addm_report(self, report_file, rac: bool, begin: int, end: int, task: str) -> str:
        """Simulated ADDM text report written to exactly report_file (never overwrites, like SPOOL ... CREATE)."""
        self._pause()
        path = Path(report_file)
        if self.scenario == "down":
            return "ERROR:\nORA-01034: ORACLE not available\n"
        mode = self.addm_mode()
        if mode == "fail":
            return "ERROR at line 1:\nORA-13516: SWRF Operation failed: Invalid snapshot range (simulated)\nORA-06512: at \"SYS.DBMS_ADDM\"\n"
        if path.exists():
            return "SP2-0749: Unable to create file (simulated)\n"
        ids = {r[0] for r in self._awr_rows()}
        if begin not in ids or end not in ids:
            return "ERROR at line 1:\nORA-13516: SWRF Operation failed: Snapshot does not exist (simulated)\n"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("partial output (simulated)", encoding="utf-8")
        self._pause()   # a cancel here leaves a partial file for the service to remove
        scope = "RAC (all instances: 1,2)" if rac else "single instance (1)"
        if mode == "norac" and rac:
            path.write_text("PLS-00302: component 'ANALYZE_DB' must be declared (simulated)\n", encoding="utf-8")
        elif mode == "badreport":
            path.write_text("ORA-20019: Invalid ADDM task (simulated)\n", encoding="utf-8")
        elif mode == "empty":
            path.write_text("", encoding="utf-8")
        else:
            path.write_text(f"          ADDM Report for Task '{task}'\nFAKE / SIMULATED DATA - {scope}, snapshots {begin} to {end}\n"
                            "No database was contacted; this is not a real ADDM report.\n" + "x" * 600 + "\n", encoding="utf-8")
        return f"ADDM_TASK|{task}\nReport generated at: {path}\n"
