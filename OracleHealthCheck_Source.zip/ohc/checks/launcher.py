"""Glue between the GUI/CLI context (profiles, DPAPI credentials, environment.json, thresholds.json) and the check engine."""
from __future__ import annotations

import os
from pathlib import Path

from ohc import paths
from ohc.checks import engine, fake
from ohc.checks.session import OracleSession, ToolError
from ohc.config import environment, thresholds
from ohc.config import oracle_home as oh
from ohc.config.jsonio import ConfigFileError
from ohc.security import credstore


def fake_scenario() -> str:
    """Development only: the OHC_FAKE_ORACLE scenario, or '' (always '' in the packaged EXE)."""
    value = os.environ.get("OHC_FAKE_ORACLE", "").strip().lower()
    if not value or paths.is_frozen():
        return ""
    if value not in fake.SCENARIOS:
        raise ToolError(f"OHC_FAKE_ORACLE must be one of: {', '.join(fake.SCENARIOS)}")
    return value


def fake_banner(scenario: str) -> str:
    return f"*** FAKE ORACLE ({scenario}): development data - no database is contacted ***"


def _prepare(ctx, db_name: str, need_dg: bool):
    entry = ctx.databases.find_by_name(db_name)
    if entry is None:
        raise ToolError(f"There is no database profile named {db_name!r}.")
    try:
        env = environment.load_environment(ctx.environment_path)
        th = thresholds.load_thresholds(ctx.thresholds_path)
    except (ConfigFileError, thresholds.ThresholdsError) as exc:
        raise ToolError(str(exc)) from None
    if fake_scenario():  # no Oracle on this machine: skip the Oracle Home checks
        return entry, "", env, th
    path, source = oh.resolve_oracle_home(entry.oracle_home, env["ORACLE_HOME"])
    if source == "none":
        raise ToolError("Oracle Home is not configured. Set it in Settings (shared default or per database) and click Save. "
                        f"Looked in {ctx.environment_path} (ORACLE_HOME is blank there) and database {entry.name} has no Oracle Home override.")
    info = oh.inspect_home(path)
    if info.problems:
        raise ToolError("; ".join(info.problems))
    if not info.sqlplus:
        raise ToolError(f"sqlplus was not found in {Path(info.path) / 'bin'}")
    if need_dg and not info.dgmgrl:
        raise ToolError(f"dgmgrl was not found in {Path(info.path) / 'bin'} (needed for the Data Guard check)")
    return entry, info.path, env, th


def fake_delay() -> float:
    """Development only: OHC_FAKE_DELAY seconds per simulated Oracle call (default 0). Ignored unless fake mode is on."""
    try:
        return max(0.0, min(5.0, float(os.environ.get("OHC_FAKE_DELAY", "0") or 0)))
    except ValueError:
        return 0.0


def _open(ctx, entry, home, env, th, cancel=None) -> OracleSession:
    if ctx.credentials_dir is None:
        raise ToolError("No per-user folder is available, so stored credentials cannot be read.")
    try:
        creds = credstore.load_credentials(ctx.credentials_dir, entry.id, backend=ctx.backend)
    except credstore.CredentialError as exc:
        raise ToolError(f"Cannot read the stored login for {entry.name}: {exc}") from None
    try:
        if scenario := fake_scenario():
            return fake.FakeOracleSession(scenario, entry.effective_sid, entry.dg_service, fake_delay(), cancel)
        return OracleSession(home, entry.effective_sid, creds, engine.defines(th), entry.dg_service, env["NLS_LANG"], cancel=cancel)
    finally:
        creds.wipe()


def run_option(ctx, db_name: str, option: str, emit=print, cancel=None, on_event=None) -> engine.RunResult:
    """option '1', '2' or '3' (BAT menu). Raises ToolError for tool/configuration problems (exit code 3).

    cancel: optional CancelToken (GUI). on_event: optional callback for progress events (see engine.run_checks)."""
    mode = engine.MODES.get(str(option))
    if mode is None:
        raise ToolError(f"Unknown option: {option!r}")
    entry, home, env, th = _prepare(ctx, db_name, mode in ("DG", "ALL"))
    if scenario := fake_scenario():
        emit(fake_banner(scenario))
    if cancel is not None:
        cancel.check()
    with _open(ctx, entry, home, env, th, cancel) as session:
        return engine.run_checks(mode, entry.name, entry.effective_sid, session, th, log_dir=ctx.root / "logs",
                                 report_base=ctx.root / "reports", date_format=env["REPORT_DATE_FORMAT"], emit=emit,
                                 cancel=cancel, on_event=on_event)


def test_connection(ctx, db_name: str) -> engine.ProbeResult:
    entry, home, env, th = _prepare(ctx, db_name, False)
    with _open(ctx, entry, home, env, th) as session:
        probe = engine.probe_database(session, entry.effective_sid)
        if probe.kind == "OK":                      # same connected session: one extra read-only query to classify the database
            probe.mode = engine.classify_run_mode(session)
        return probe


def cli(args: list) -> int:
    from ohc.gui.context import AppContext
    opts = {"--db": None, "--root": None}
    action, rest, option = args[0], args[1:], None
    if action == "--run":
        if not rest:
            print("usage: --run 1|2|3 --db NAME")
            return 3
        option, rest = rest[0], rest[1:]
    while rest:
        if rest[0] in opts and len(rest) > 1:
            opts[rest[0]], rest = rest[1], rest[2:]
        else:
            print(f"Unknown or incomplete argument: {rest[0]}")
            return 3
    if not opts["--db"]:
        print("--db NAME is required")
        return 3
    try:
        ctx = AppContext.for_current_user(Path(opts["--root"]) if opts["--root"] else None)
        if action == "--run":
            return run_option(ctx, opts["--db"], option).exit_code
        if scenario := fake_scenario():
            print(fake_banner(scenario))
        probe = test_connection(ctx, opts["--db"])
        print(f"{probe.kind}: {probe.state}" + (f"\n{probe.error}" if probe.error else ""))
        return 0 if probe.kind == "OK" else 1
    except Exception as exc:  # tool/configuration problem, identity/user-folder problem, ...
        print(f"ERROR: {exc}")
        return 3
