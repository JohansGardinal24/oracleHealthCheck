"""Execution of the legacy checks (BAT options 1-3): SQL*Plus, DGMGRL, server spec, logs, HTML report, cleanup."""
