"""The ServerSpec PowerShell from the legacy BAT (read-only CIM queries), kept as it was; only the parameter block is reduced."""

SERVER_SPEC_PS = r"""param([string]$OutFile, [int]$DiskWarn = 80, [int]$DiskCrit = 90)
$ErrorActionPreference = 'Continue'
function Rank([string]$s) { switch ($s) { 'CRITICAL' { 2 } 'WARNING' { 1 } default { 0 } } }
function Worse([string]$a, [string]$b) { if ((Rank $b) -gt (Rank $a)) { $b } else { $a } }
try {
  $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
  $cpus = @(Get-CimInstance Win32_Processor -ErrorAction Stop)
  $cores = 0; $load = 0.0
  foreach ($c in $cpus) { $cores += [int]$c.NumberOfLogicalProcessors; $load += [double]$c.LoadPercentage }
  if ($cpus.Count -gt 0) { $load = [math]::Round($load / $cpus.Count, 0) }
  $totKB = [double]$os.TotalVisibleMemorySize; $freeKB = [double]$os.FreePhysicalMemory
  $memTot = [math]::Round($totKB / 1MB, 2); $memUsed = [math]::Round(($totKB - $freeKB) / 1MB, 2)
  $swTot = 0.0; $swUsed = 0.0
  foreach ($pf in @(Get-CimInstance Win32_PageFileUsage -ErrorAction SilentlyContinue)) { $swTot += [double]$pf.AllocatedBaseSize; $swUsed += [double]$pf.CurrentUsage }
  $r = New-Object System.Collections.Generic.List[string]
  $r.Add('== CPU ==')
  $r.Add("Logical CPU cores: $cores")
  $r.Add("CPU load (average): $load %")
  $r.Add("Uptime since: $($os.LastBootUpTime)")
  $r.Add('')
  $r.Add('== MEMORY + PAGEFILE ==')
  $r.Add("Physical memory: $memUsed GB used of $memTot GB")
  $r.Add(("Pagefile: {0:N1} GB used of {1:N1} GB" -f ($swUsed / 1024), ($swTot / 1024)))
  $r.Add('')
  $r.Add('== DISK ==')
  $r.Add(('{0,-8} {1,10} {2,10} {3,8}' -f 'Drive', 'Size_GB', 'Free_GB', 'Used%'))
  $st = 'OK'; $ncrit = 0; $nwarn = 0; $worstPct = 0; $worstDrv = ''
  foreach ($d in @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' -ErrorAction Stop)) {
    if ([double]$d.Size -le 0) { continue }
    $pct = [int][math]::Round((([double]$d.Size - [double]$d.FreeSpace) / [double]$d.Size) * 100, 0)
    $r.Add(('{0,-8} {1,10:N1} {2,10:N1} {3,7}%' -f $d.DeviceID, ([double]$d.Size / 1GB), ([double]$d.FreeSpace / 1GB), $pct))
    if ($pct -ge $worstPct) { $worstPct = $pct; $worstDrv = $d.DeviceID }
    if ($pct -ge $DiskCrit) { $st = 'CRITICAL'; $ncrit++ }
    elseif ($pct -ge $DiskWarn) { $st = Worse $st 'WARNING'; $nwarn++ }
  }
  Set-Content -LiteralPath $OutFile -Value ($r -join "`r`n")
  Write-Output ("$st|Disk: highest ${worstPct}% at $worstDrv ($ncrit critical, $nwarn warning); CPU load ${load}%; Mem $memUsed/$memTot GB used; Pagefile {0:N1}/{1:N1} GB used" -f ($swUsed / 1024), ($swTot / 1024))
}
catch { Write-Output ("CRITICAL|PowerShell error: " + $_.Exception.Message) }
"""
