"""Cooperative cancellation for one run (GUI 'Cancel').

The worker thread is never killed. Cancelling (1) sets a flag that the engine checks before it starts the next check
and (2) kills the SQL*Plus / DGMGRL / PowerShell child processes that are running right now, so the blocked call returns
immediately and raises RunCancelled in the worker thread, which then ends the run cleanly.
"""
from __future__ import annotations

import subprocess
import sys
import threading


class RunCancelled(Exception):
    """The user cancelled the run. Deliberately NOT a ToolError: it is not a tool/configuration problem."""


class CancelToken:
    def __init__(self) -> None:
        self._event = threading.Event()
        self._lock = threading.Lock()
        self._procs: set = set()

    @property
    def requested(self) -> bool:
        return self._event.is_set()

    def check(self) -> None:
        if self._event.is_set():
            raise RunCancelled("Run cancelled by the user")

    def wait(self, seconds: float) -> bool:
        """Sleep up to 'seconds'; True when cancellation was requested meanwhile."""
        return self._event.wait(seconds)

    def register(self, proc) -> None:
        with self._lock:
            self._procs.add(proc)
            kill_now = self._event.is_set()
        if kill_now:  # cancelled between starting the process and registering it
            self._kill(proc)

    def unregister(self, proc) -> None:
        with self._lock:
            self._procs.discard(proc)

    def request(self) -> None:
        """Safe to call from any thread, more than once."""
        with self._lock:
            self._event.set()
            procs = list(self._procs)
        for proc in procs:
            self._kill(proc)

    @staticmethod
    def _kill(proc) -> None:
        """End the child process (on Windows with everything it started, e.g. a PowerShell helper); never raises."""
        pid = getattr(proc, "pid", None)
        if sys.platform == "win32" and isinstance(pid, int):
            try:  # taskkill /T ends the process tree; /F is needed because these are console programs without a window
                subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               timeout=15, creationflags=0x08000000)
            except Exception:
                pass  # fall through to the plain kill below
        try:
            proc.kill()
        except Exception:  # already finished, or not killable: the worker still stops at the next check
            pass
