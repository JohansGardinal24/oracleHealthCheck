"""Data Guard sync check - a port of the BAT's PowerShell 'DrSync' mode (PowerShell -match is case-insensitive, so is this)."""
from __future__ import annotations

import re

from ohc.checks.session import ToolError

I = re.IGNORECASE
_RANK = {"CRITICAL": 2, "WARNING": 1}


def _worse(a: str, b: str) -> str:
    return b if _RANK.get(b, 0) > _RANK.get(a, 0) else a


def get_next(text: str, label: str) -> str:
    """First word of the first non-empty line after the line containing label."""
    lines = re.split(r"\r?\n", text)
    for i, line in enumerate(lines):
        if re.search(re.escape(label), line, I):
            for nxt in lines[i + 1:]:
                if nxt.strip():
                    return nxt.strip().split()[0]
    return ""


def lag_seconds(text: str) -> int:
    if not text or re.search("unknown", text, I):
        return -1
    found = re.findall(r"(\d+)\s*(day|hour|minute|second)", text, I)
    if not found:
        return -1
    scale = {"day": 86400, "hour": 3600, "minute": 60, "second": 1}
    return sum(int(n) * scale[unit.lower()] for n, unit in found)


def dr_sync(dgmgrl, lag_warn: int, lag_crit: int) -> tuple:
    """dgmgrl(list_of_commands) -> output text. Returns (raw text, 'STATUS|message')."""
    try:
        cfg = dgmgrl(["show configuration", "exit"])
    except ToolError as exc:
        return "", f"CRITICAL|Cannot run dgmgrl: {exc}"
    raw = ["DGMGRL> show configuration", cfg]
    cfgstat = get_next(cfg, "Configuration Status:")
    if not cfgstat:
        if re.search("ORA-16532|ORA-16525|ORA-16501", cfg, I):
            return "\n".join(raw), "WARNING|Data Guard broker configuration not found / broker not running"
        err = next((x for x in re.split(r"\r?\n", cfg) if re.search("ORA-|DGM-", x, I)), "")
        return "\n".join(raw), f"CRITICAL|Cannot read broker status: {err}"
    members = [x.strip().split()[0] for x in re.split(r"\r?\n", cfg) if re.search("standby database", x, I)]
    st, parts = "OK", ""
    if cfgstat.upper() != "SUCCESS":
        st = "CRITICAL"
    for m in members:
        try:
            sd = dgmgrl([f"show database {m}", "exit"])
        except ToolError as exc:
            sd = f"Cannot run dgmgrl: {exc}"
        raw += ["", f"DGMGRL> show database {m}", sd]
        dbst = get_next(sd, "Database Status:")
        tl = al = ""
        if mt := re.search(r"Transport Lag:\s*([^\r\n(]*)", sd, I):
            tl = mt.group(1).strip()
        if ma := re.search(r"Apply Lag:\s*([^\r\n(]*)", sd, I):
            al = ma.group(1).strip()
        tls, als = lag_seconds(tl), lag_seconds(al)
        parts += f"{m}: transport {'unknown' if tls < 0 else f'{tls}s'}, apply {'unknown' if als < 0 else f'{als}s'}; "
        if dbst.upper() != "SUCCESS":
            st = "CRITICAL"
        for v in (tls, als):
            if v < 0:
                st = _worse(st, "WARNING")
            elif v > lag_crit:
                st = _worse(st, "CRITICAL")
            elif v > lag_warn:
                st = _worse(st, "WARNING")
    if not members:
        return "\n".join(raw), f"WARNING|Config status {cfgstat}, but no standby database listed"
    return "\n".join(raw), f"{st}|Config {cfgstat}; " + parts.rstrip(" ;")
