"""Option 1/2/3 of the legacy BAT: same checks, order, skip rules, status handling, log, HTML report, cleanup and exit codes.

The engine only talks to a 'session' (see ohc.checks.session.OracleSession), so tests can supply a fake one.
"""
from __future__ import annotations

import html
import os
import re
import socket
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path

from ohc.checks import dg
from ohc.checks.cancel import RunCancelled
from ohc.checks.session import ENC, QueryTimeout, ToolError

NAMES = {
    0: "DB STATUS", 1: "DR SYNC", 2: "SERVER SPEC (CPU / MEM+PAGEFILE / DISK)", 3: "TABLESPACE / DATAFILE",
    4: "FRA UTILIZATION", 5: "REDO LOG STATUS", 6: "SYS PASSWORD EXPIRY", 7: "DB_FILES USAGE", 8: "RMAN BACKUP STATUS",
    9: "TOP 5 WAIT EVENTS", 10: "ACTIVE LOCKS / BLOCKING SESSIONS", 11: "INDEX STATISTICS", 12: "SEGMENT SIZE",
    13: "RESOURCE LIMITS (processes/sessions/cursors)", 14: "USER EXPIRY (TRANS.USERS)", 15: "IMS SCHEDULERS",
    16: "IMS SCHEDULE JOBS", 17: "PARALLEL DEGREE INDEXES", 18: "SCHEDULER RUNNING JOBS",
    19: "DAILY DUMP JOB HISTORY (JOB_IMS_EXP)", 20: "DB PATCH DETAILS",
}
# idx -> (sections [(title, report sql)], status sql, status used when the status query fails)
SIMPLE = {
    4: ([("Flash recovery area", "r_fra.sql")], "v_fra.sql", None),
    5: ([("Redo log groups (v$log)", "r_redo_log.sql"), ("Redo log members (v$logfile)", "r_redo_file.sql")], "v_redo.sql", None),
    6: ([("SYS account", "r_sys_expiry.sql")], "v_sys.sql", "WARNING"),
    7: ([("db_files usage", "r_dbfiles.sql")], "v_dbfiles.sql", None),
    8: ([("RMAN status", "r_rman.sql")], "v_rman.sql", None),
    9: ([("Top 5 wait events", "r_top_events.sql")], "v_top_events.sql", "WARNING"),
    10: ([("Active locks", "r_locks.sql")], "v_locks.sql", "WARNING"),
    11: ([("Most recent non-stale stats (all non-Oracle-maintained schemas)", "r_index_stale.sql"),
          ("Invalid / unusable indexes (non-partitioned)", "r_index_invalid.sql"),
          ("Unusable index subpartitions / partitions", "r_index_unusable_parts.sql")], "v_index.sql", "WARNING"),
    12: ([("Segment size (dba_segments)", "r_segment_size.sql"), ("Datafile size (dba_data_files)", "r_datafile_size.sql")], "v_segment.sql", "WARNING"),
    13: ([("processes / sessions (v$resource_limit)", "r_resource_limits.sql"),
          ("open_cursors (gv$parameter / gv$sysstat, per instance)", "r_open_cursors.sql")], "v_resource.sql", None),
    14: ([("TRANS.USERS expiring", "r_user_expiry.sql")], "v_user_expiry.sql", None),
    15: ([("config.schedule_master", "r_ims_schedulers.sql")], "v_ims_sched.sql", "WARNING"),
    16: ([("config.schedule_master (Active/Archive, status Active)", "r_ims_jobs_config.sql"),
          ("mm_config.schedule_master (Active/Archive, status Active)", "r_ims_jobs_mmconfig.sql")], "v_ims_jobs.sql", "WARNING"),
    17: ([("Indexes with parallel DEGREE greater than 1", "r_dop_indexes.sql")], "v_dop.sql", "WARNING"),
    18: ([("Scheduler running jobs", "r_running_jobs.sql")], "v_running.sql", "WARNING"),
    19: ([("JOB_IMS_EXP run history - last 7 days (owner TRANS)", "r_dump_job_history.sql")], "v_dump_history.sql", "WARNING"),
    20: ([("dba_registry_sqlpatch", "r_db_patch.sql")], "v_db_patch.sql", "WARNING"),
}
# order of the thresholds written as 'define NAME=value' (the BAT's :build_defs)
DEFINE_KEYS = ("TBS_WARN", "TBS_CRIT", "FRA_WARN", "FRA_CRIT", "DBFILES_WARN", "DBFILES_CRIT", "RESOURCE_WARN", "RESOURCE_CRIT",
               "USER_EXPIRY_WARNING_DAYS", "USER_EXPIRY_CRITICAL_DAYS", "USER_EXPIRY_LOOKAHEAD_DAYS", "IMS_SCHEDULER_LOOKAHEAD_DAYS",
               "TEMP_HIST_DAYS", "LOCK_WAIT_SEC", "RMAN_LOOKBACK_DAYS", "SYS_EXPIRY_CRIT_STATUS")
MODES = {"1": "SQL", "2": "DG", "3": "ALL"}
MODE_NAMES = {"SQL": "ORACLE health check", "DG": "Sync check", "ALL": "ALL"}
VALID = ("OK", "WARNING", "CRITICAL", "INFO")
RANK = {"WARNING": 1, "CRITICAL": 2}
_ERR = re.compile(r"ORA-[0-9]|SP2-[0-9]|TNS-[0-9]")


def defines(thresholds) -> list:
    return [(k, thresholds[k]) for k in DEFINE_KEYS]


def rank(status: str) -> int:
    return RANK.get(status.upper(), 0)


def plan(mode: str) -> list:
    """The check numbers (0-20) a mode records, in display order (the same rules as _Run.go)."""
    do_sql, do_dg = mode in ("SQL", "ALL"), mode in ("DG", "ALL")
    ids = {0, 2, 3, *range(4, 21)} if do_sql else set()
    if do_dg:
        ids.add(1)
        ids |= {4, 5, 8}
    elif do_sql:
        ids -= {4, 5, 8}
    return sorted(ids)


TBS_SQL = ("r_tbs_usage.sql", "r_datafiles.sql", "r_temp_files.sql", "r_temp_history.sql", "v_tbs.sql", "v_temp_hist.sql")


def sql_files(idx: int) -> list:
    """The bundled SQL scripts a check uses (empty for the DGMGRL and PowerShell checks)."""
    if idx == 0:
        return ["v_db_info.sql", "r_db_status.sql"]
    if idx == 3:
        return list(TBS_SQL)
    if idx in SIMPLE:
        sections, vfile, _ = SIMPLE[idx]
        return [name for _, name in sections] + [vfile]
    return []


def format_dotnet_date(now: datetime, fmt: str) -> str:
    """The .NET custom date format used by REPORT_DATE_FORMAT (letters y, M, d plus . _ - and space)."""
    months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]

    def one(m):
        tok = m.group(0)
        c, n = tok[0], len(tok)
        if c == "y":
            return str(now.year % 100) if n == 1 else f"{now.year % 100:02d}" if n == 2 else f"{now.year:0{n}d}"
        if c == "M":
            return str(now.month) if n == 1 else f"{now.month:02d}" if n == 2 else months[now.month - 1][:3] if n == 3 else months[now.month - 1]
        return str(now.day) if n == 1 else f"{now.day:02d}"
    return re.sub(r"y+|M+|d+", one, fmt)


@dataclass
class CheckResult:
    idx: int
    name: str
    status: str
    message: str
    seconds: float = 0.0
    output: str = ""


@dataclass
class RunResult:
    mode: str
    db: str
    overall: str
    exit_code: int
    results: list
    log_file: Path
    report_file: Path
    run_time: str
    problems: list = field(default_factory=list)
    cancelled: bool = False  # GUI only: the run was stopped by the user (exit_code 4); results holds the completed checks


class _Run:
    def __init__(self, mode, db, sid, session, th, emit, log, hostname, cancel=None, on_event=None):
        self.mode, self.db, self.sid, self.s, self.th, self.emit, self.log = mode, db, sid, session, th, emit, log
        self.cancel, self.on_event = cancel, on_event
        self.simulated = bool(getattr(session, "simulated", False))
        self.t0 = time.monotonic()
        self.host = hostname
        self.do_sql, self.do_dg = mode in ("SQL", "ALL"), mode in ("DG", "ALL")
        self.res: list = []
        self.raws: dict = {}
        self.ovr = 0
        self.role = self.open_mode = self.dbuniq = ""
        self.usable, self.mounted = True, False
        self.idx, self.failst = 0, "CRITICAL"

    # ---- output ----
    def out(self, line: str = "") -> None:
        self.emit(line)
        self.log.write(line + "\n")
        self.log.flush()

    def begin(self, idx: int) -> None:
        if self.cancel is not None:
            self.cancel.check()  # stop scheduling new checks once cancellation was requested
        self.idx, self.failst = idx, "CRITICAL"
        self.t0 = time.monotonic()
        if self.on_event:
            self.on_event(("start", idx, NAMES[idx]))
        self.raws[idx] = []
        self.out("")
        self.out(f"----- [{idx + 1}] {NAMES[idx]} -----")

    def add(self, *lines: str) -> None:
        for chunk in lines:
            self.raws[self.idx].append(chunk)

    def show_raw(self) -> None:
        for line in "\n".join(self.raws[self.idx]).splitlines():
            self.out(line)

    def record(self, st: str, m: str) -> None:
        name = NAMES[self.idx]
        if self.simulated and not m.startswith("[FAKE]"):
            m = f"[FAKE] {m}"  # every simulated summary says so, whoever built it
        self.out(f">> [{self.idx + 1}] {name} : {st}  -  {m}")
        result = CheckResult(self.idx, name, st, m, time.monotonic() - self.t0, "\n".join(self.raws.get(self.idx, [])))
        self.res.append(result)
        self.ovr = max(self.ovr, rank(st))
        if self.on_event:
            self.on_event(("done", result))

    def skip(self, idx: int, why: str) -> None:
        self.begin(idx)
        self.add(f"Skipped: {why}")
        self.show_raw()
        self.record("SKIPPED", why)

    # ---- SQL helpers ----
    def query(self, mode: str, name: str) -> str:
        try:
            return self.s.sql(mode, name)
        except QueryTimeout as exc:
            return f"Query timed out: {exc}\n"

    def sec(self, title: str, name: str) -> None:
        self.add("", f"== {title} ==", self.query("report", name))

    def val(self, name: str) -> tuple:
        """-> (first non-empty output line or '', full output)."""
        text = self.query("value", name)
        first = next((x.strip() for x in text.splitlines() if x.strip() and not x.startswith(";")), "")
        return first, text

    @staticmethod
    def first_err(v1: str, text: str) -> str:
        return next((x.strip() for x in text.splitlines() if _ERR.search(x)), v1)

    @staticmethod
    def parse(v1: str) -> tuple:
        if not v1:
            return "", "", False
        st, _, m = v1.partition("|")
        return st, m, st.upper() in VALID

    def rec_line(self, v1: str) -> None:
        st, m, ok = self.parse(v1)
        if not ok:
            st, m = self.failst, ("No output from query" if not v1 else f"Query failed: {v1}")
        self.record(st, m)

    def rec_val(self, idx: int, name: str, failst=None) -> None:
        self.idx = idx
        if failst:
            self.failst = failst
        v1, text = self.val(name)
        if not self.parse(v1)[2]:
            v1 = self.first_err(v1, text)
        self.rec_line(v1)

    # ---- checks ----
    def simple(self, idx: int) -> None:
        sections, vfile, failst = SIMPLE[idx]
        self.begin(idx)
        for title, name in sections:
            self.sec(title, name)
        self.show_raw()
        self.rec_val(idx, vfile, failst)

    def chk_db_status(self) -> None:
        self.begin(0)
        self.usable = self.mounted = False
        svc = self.s.service_query(self.sid)
        state = "STOPPED" if "STOPPED" in svc else "RUNNING" if "RUNNING" in svc else "UNKNOWN"
        if state == "STOPPED":
            self.add(f"Instance {self.sid} is NOT running - Windows service OracleService{self.sid} is stopped.")
            self.show_raw()
            return self.record("CRITICAL", "Instance not running")
        v1, text = self.val("v_db_info.sql")
        parts = v1.split("|") if v1 else []
        if len(parts) < 5 or not parts[4].strip():
            self.add("Cannot connect / query the instance:", text)
            self.show_raw()
            self.role = self.open_mode = self.dbuniq = ""
            return self.record("CRITICAL", f"Cannot connect: {self.first_err(v1, text)}")
        inst, self.role, self.open_mode, self.dbuniq = parts[0], parts[1], parts[2], parts[3]
        self.add(self.query("report", "r_db_status.sql"))
        self.show_raw()
        self.usable, self.mounted = True, self.open_mode == "MOUNTED"
        st = "WARNING"
        if self.role == "PRIMARY":
            st = "OK" if inst == "OPEN" and self.open_mode == "READ WRITE" else "CRITICAL"
        elif self.role in ("PHYSICAL STANDBY", "LOGICAL STANDBY"):
            st = "OK" if self.open_mode in ("MOUNTED", "READ ONLY", "READ ONLY WITH APPLY") else "CRITICAL"
        self.record(st, f"{self.role}, instance {inst}, open mode {self.open_mode}")

    def chk_dr(self) -> None:
        self.begin(1)
        raw, v1 = dg.dr_sync(self.s.dgmgrl, self.th["DR_LAG_WARN"], self.th["DR_LAG_CRIT"])
        self.add(raw)
        self.show_raw()
        self.rec_line(v1)

    def chk_server_spec(self) -> None:
        self.begin(2)
        try:
            raw, v1 = self.s.server_spec(self.th["DISK_WARN"], self.th["DISK_CRIT"])
        except QueryTimeout as exc:
            raw, v1 = "", f"CRITICAL|PowerShell error: {exc}"
        self.add(raw)
        self.show_raw()
        self.rec_line(v1)

    def chk_tablespace(self) -> None:
        self.begin(3)
        if self.mounted:
            self.add("Database is only MOUNTED - dba_ views are not available.")
            self.show_raw()
            return self.record("SKIPPED", "DB not open")
        for title, name in (("Tablespace usage - against max size", "r_tbs_usage.sql"), ("Datafile summary per tablespace", "r_datafiles.sql"),
                            ("Temp tablespace files", "r_temp_files.sql"), ("Temp tablespace usage history", "r_temp_history.sql")):
            self.sec(title, name)
        self.show_raw()
        v1, text = self.val("v_tbs.sql")
        st, m, ok = self.parse(v1)
        if not ok:
            return self.rec_line(self.first_err(v1, text))
        v2, _ = self.val("v_temp_hist.sql")
        st2, m2, ok2 = self.parse(v2)
        if ok2:
            if rank(st2) > rank(st):
                st = st2
            m = f"{m}; {m2}"
        self.record(st, m)

    # ---- flow (BAT :run_db / :dg_part / :sql_part) ----
    def go(self) -> None:
        if self.do_sql:
            self.chk_db_status()
        if self.do_dg:
            if not self.usable:
                self.skip(1, "Database not reachable")
            else:
                self.chk_dr()
            if not self.do_sql:
                for i in (4, 5, 8):
                    self.simple(i)
        if self.do_sql:
            self.chk_server_spec()
            if not self.usable:
                for i in range(3, 21):
                    if i in (4, 5, 8) and not self.do_dg:
                        continue
                    self.skip(i, "Database not reachable")
                return
            self.chk_tablespace()
            for i in range(4, 21):
                if i in (4, 5, 8) and not self.do_dg:
                    continue
                self.simple(i)


def run_checks(mode: str, db: str, sid: str, session, thresholds, *, log_dir, report_base, date_format="yyyy-MM-dd",
               emit=print, now=None, hostname=None, cancel=None, on_event=None) -> RunResult:
    """mode: 'SQL' (option 1), 'DG' (option 2) or 'ALL' (option 3). Raises ToolError for tool/configuration problems."""
    if mode not in MODE_NAMES:
        raise ToolError(f"Unknown mode: {mode!r}")
    now = now or datetime.now()
    host = hostname or os.environ.get("COMPUTERNAME") or socket.gethostname()
    ts, run_time = now.strftime("%Y%m%d_%H%M%S"), now.strftime("%Y-%m-%d %H:%M:%S")
    log_dir, report_dir = Path(log_dir), Path(report_base) / format_dotnet_date(now, date_format)
    log_file, report_file = log_dir / f"ohc_{db}_{ts}.log", report_dir / f"{db}_health_{ts}.html"
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
        report_dir.mkdir(parents=True, exist_ok=True)
        log = open(log_file, "w", encoding=ENC, errors="replace", newline="")
    except OSError as exc:
        raise ToolError(f"Cannot create the log or report folder: {exc}") from None
    with log:
        log.write("")
        run = _Run(mode, db, sid, session, thresholds, emit, _CRLF(log), host, cancel, on_event)
        bar = "=" * 50
        run.out(bar)
        run.out(f" ORACLE HEALTH CHECK   DB: {db}   Host: {host}   {run_time}")
        run.out(bar)
        if run.simulated:
            run.out(" *** FAKE / SIMULATED DATA - development only, not a real database result ***")
        if on_event:
            on_event(("plan", [(i, NAMES[i]) for i in plan(mode)]))
        cancelled = False
        try:
            run.go()
        except RunCancelled:  # completed checks are kept; the check that was running is dropped
            cancelled = True
            run.out("")
            run.out(f"*** RUN CANCELLED BY THE USER - {len(run.res)} of {len(plan(mode))} checks completed ***")
        overall = "CANCELLED" if cancelled else {1: "WARNING", 2: "CRITICAL"}.get(run.ovr, "OK")
        try:
            report_file.write_text(build_html(run, overall, run_time), encoding="utf-8", newline="")
        except OSError as exc:
            raise ToolError(f"Cannot write the report {report_file}: {exc}") from None
        run.out("")
        run.out(bar)
        run.out(f" SUMMARY   DB: {db}")
        run.out(bar)
        rows = sorted(run.res, key=lambda r: r.idx)
        for r in run.res:  # the BAT writes the summary to the log in recorded order, to the console sorted
            run.log.write(f"[{r.idx + 1}] {r.name} : {r.status}  -  {r.message}\n")
        run.log.write("-" * 50 + "\n")
        run.log.write(f" OVERALL: {overall}\n")
        for r in rows:
            emit(f"[{r.idx + 1}] {r.name} : {r.status}  -  {r.message}")
        emit("-" * 50)
        emit(f" OVERALL: {overall}")
        run.out(f" Log   : {log_file}")
        run.out(f" Report: {report_file}")
        run.out("")
    problems = cleanup(log_dir, report_base, int(thresholds["RETENTION_DAYS"]), now)
    return RunResult(mode, db, overall, 4 if cancelled else run.ovr, run.res, log_file, report_file, run_time, problems, cancelled)


class _CRLF:
    """Writes the log with Windows line endings (the BAT's echo) on every platform."""
    def __init__(self, fh):
        self.fh = fh

    def write(self, text: str) -> None:
        self.fh.write(text.replace("\n", "\r\n"))

    def flush(self) -> None:
        self.fh.flush()


CSS = """html{scroll-behavior:smooth}
body{font-family:Segoe UI,Arial,sans-serif;margin:0;background:#f4f6f8;color:#222}
.wrap{max-width:1100px;margin:0 auto;padding:24px}
header{background:#1f3a5f;color:#fff;padding:20px 24px;border-radius:8px}
header h1{margin:0 0 8px 0;font-size:22px}
header table td{padding:2px 18px 2px 0;font-size:14px}
h2{font-size:17px;margin:28px 0 8px 0}
table.sum{width:100%;border-collapse:collapse;background:#fff;margin-top:18px}
table.sum th,table.sum td{border:1px solid #d5dbe1;padding:8px 10px;text-align:left;font-size:14px}
table.sum th{background:#e8edf2}
table.sum a{color:#1f3a5f;text-decoration:none;border-bottom:1px dotted #1f3a5f}
.badge{display:inline-block;padding:2px 10px;border-radius:10px;color:#fff;font-weight:600;font-size:13px}
.OK{background:#2e9e4f}.WARNING{background:#e0a100}.CRITICAL{background:#d33b3b}.SKIPPED{background:#7a8794}.INFO{background:#3a6ea5}
pre{background:#fff;border:1px solid #d5dbe1;border-radius:6px;padding:12px;overflow-x:auto;font-family:Consolas,Menlo,monospace;font-size:12.5px;line-height:1.35}
.failrow{background:#fdecea;color:#a30000;font-weight:700;display:block;margin:0 -12px;padding:0 12px}
footer{margin-top:28px;font-size:12px;color:#667}"""


def _e(text) -> str:
    return html.escape(str(text), quote=True).replace("&#x27;", "&#39;")


def build_html(run: _Run, overall: str, run_time: str) -> str:
    uniq = f", unique name {run.dbuniq}" if run.dbuniq else ""
    rows = sorted(run.res, key=lambda r: r.idx)
    cancelled = overall == "CANCELLED"
    css = CSS + (".CANCELLED{background:#7a8794}" if cancelled else "") + \
        (".note{background:#fff3cd;border:1px solid #e0a100;border-radius:6px;padding:10px 12px;margin-top:18px}" if cancelled or run.simulated else "")
    out = ["<!DOCTYPE html>", '<html lang="en"><head><meta charset="utf-8">',
           f"<title>Oracle Health Report - {_e(run.db)} - {run_time}</title>", f"<style>{css}</style></head><body><div class=\"wrap\">",
           f"<header><h1>Oracle Health Report &mdash; {_e(run.db)}</h1><table>",
           f"<tr><td>Database</td><td><b>{_e(run.db)}</b> (SID {_e(run.sid)}{_e(uniq)})</td></tr>",
           f"<tr><td>Host</td><td>{_e(run.host)}</td></tr>",
           f"<tr><td>Role / open mode</td><td>{_e(run.role or 'n/a')} / {_e(run.open_mode or 'n/a')}</td></tr>",
           f"<tr><td>Run time</td><td>{_e(run_time)}</td></tr>",
           f'<tr><td>Overall</td><td><span class="badge {overall}">{overall}</span></td></tr>', "</table></header>",
           '<table class="sum"><tr><th>#</th><th>Check</th><th>Status</th><th>Details</th></tr>']
    if cancelled:
        out.insert(-1, f'<p class="note"><b>RUN CANCELLED BY THE USER.</b> Only the {len(rows)} completed check(s) are listed; the others did not run.</p>')
    if run.simulated:
        out.insert(-1, '<p class="note"><b>FAKE / SIMULATED DATA.</b> Development output only - no database was contacted and these are not real results.</p>')
    for r in rows:
        n = r.idx + 1
        out.append(f'<tr><td>{n}</td><td><a href="#chk{n}">{_e(r.name)}</a></td><td><span class="badge {_e(r.status)}">{_e(r.status)}</span></td><td>{_e(r.message)}</td></tr>')
    out.append("</table>")
    for r in rows:
        n = r.idx + 1
        out.append(f'<h2 id="chk{n}">[{n}] {_e(r.name)} &nbsp;<span class="badge {_e(r.status)}">{_e(r.status)}</span></h2>')
        body = []
        for line in "\n".join(run.raws.get(r.idx, [])).splitlines():
            if r.name == "RMAN BACKUP STATUS" and re.search("failed", line, re.I):
                body.append(f'<span class="failrow">{_e(line)}</span>')
            else:
                body.append(_e(line))
        out.append("<pre>" + "".join(x + "\n" for x in body) + "</pre>")
    out.append(f"<footer>Generated by Oracle Health Check &middot; {_e(run_time)} &middot; read-only checks</footer></div></body></html>")
    return "\n".join(out) + "\n"


def cleanup(log_dir, report_base, days: int, now=None) -> list:
    """ohc_*.log files and dated report folders whose last-write time is older than the retention (the BAT's Cleanup mode)."""
    cut = ((now or datetime.now()) - timedelta(days=days)).timestamp()
    problems = []
    import shutil
    log_dir, report_base = Path(log_dir), Path(report_base)
    if log_dir.is_dir():
        for f in log_dir.glob("ohc_*.log"):
            try:
                if f.is_file() and f.stat().st_mtime < cut:
                    f.unlink()
            except OSError as exc:
                problems.append(f"Could not delete {f}: {exc}")
    if report_base.is_dir():
        for d in report_base.iterdir():
            try:
                if d.is_dir() and not d.is_symlink() and d.stat().st_mtime < cut:
                    shutil.rmtree(d)
            except OSError as exc:
                problems.append(f"Could not delete {d}: {exc}")
    return problems


# every value Oracle documents for V$DATABASE.SWITCHOVER_STATUS; NOT ALLOWED = a normal (non-Data-Guard) database, any other = Data Guard related
SWITCHOVER_VALUES = frozenset({
    "NOT ALLOWED", "SESSIONS ACTIVE", "SWITCHOVER PENDING", "SWITCHOVER LATENT", "TO PRIMARY", "TO STANDBY", "RECOVERY NEEDED",
    "PREPARING SWITCHOVER", "PREPARING DICTIONARY", "TO LOGICAL STANDBY", "FAILED DESTINATION", "RESOLVABLE GAP", "LOG SWITCH GAP"})


@dataclass
class ModeResult:
    mode: str = ""        # "standard" (menu 1) | "dataguard" (menu 3) | "" = could not be determined
    status: str = ""      # the SWITCHOVER_STATUS value read
    error: str = ""       # why mode is ""


def classify_run_mode(session) -> ModeResult:
    """One query on the already-open Test Connection session. A failed or unrecognised answer is reported, never guessed."""
    try:
        text = session.switchover_status()
    except ToolError as exc:
        return ModeResult(error=str(exc))
    m = re.search(r"^\s*SWITCHOVER_STATUS\|(.*?)\s*$", text or "", re.M)
    if not m:
        return ModeResult(error=_Run.first_err("", text or "") or "SWITCHOVER_STATUS could not be read")
    status = m.group(1).strip().upper()
    if status not in SWITCHOVER_VALUES:
        return ModeResult(status=status, error=f"unexpected SWITCHOVER_STATUS value '{status}'")
    return ModeResult("standard" if status == "NOT ALLOWED" else "dataguard", status)


@dataclass
class ProbeResult:
    kind: str  # OK / NOTFOUND / DOWN / LOGIN / OTHER
    state: str
    error: str = ""
    mode: object = None   # ModeResult, set by launcher.test_connection after a successful connection


def probe_database(session, sid: str) -> ProbeResult:
    """The BAT's :probe_db - used for 'Test Connection'."""
    svc = session.service_query(sid)
    if "FAILED 1060" in svc:
        return ProbeResult("NOTFOUND", "NOT FOUND - no such database on this server")
    if "STOPPED" in svc:
        return ProbeResult("DOWN", "INSTANCE NOT RUNNING - Windows service is stopped")
    try:
        text = session.sql("value", "v_db_info.sql")
    except QueryTimeout as exc:
        return ProbeResult("OTHER", "NOT REACHABLE - check credentials / listener / ORACLE_SID", str(exc))
    first = next((x.strip() for x in text.splitlines() if x.strip()), "")
    parts = first.split("|")
    if len(parts) >= 5 and parts[4].strip():
        return ProbeResult("OK", f"CONNECTED  -  {parts[1]}, instance {parts[0]}, {parts[2]}")
    err = _Run.first_err(first, text)
    if re.search("ORA-01034|ORA-27101|ORA-01033", text):
        return ProbeResult("DOWN", "INSTANCE NOT RUNNING - cannot connect", err)
    if re.search("ORA-01017|ORA-28000|ORA-01031", text):
        return ProbeResult("LOGIN", "LOGIN FAILED - check the stored user name and password", err)
    return ProbeResult("OTHER", "NOT REACHABLE - check credentials / listener / ORACLE_SID", err)
