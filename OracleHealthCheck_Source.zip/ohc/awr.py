"""AWR report logic without Qt: validation, snapshot parsing and pairing, report-file discovery, error extraction.

The report itself is still produced by the original, unmodified AWR_Report.sql (SQL*Plus, DBMS_WORKLOAD_REPOSITORY.AWR_REPORT_HTML).
Its file name is fixed by that script:  <reports>\\<date folder>\\AWR_Report_<begin>_<end>_<yyyymmdd_HHMMSS>.html
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

SCRIPT = "AWR_Report.sql"
FORMATS = {"html": ".html", "text": ".txt"}      # report type -> extension
NAME_TOKEN = "<yyyymmdd_HHMMSS>"                   # replaced by the generation time (the legacy name pattern)
NAME_RE = re.compile(r"^[A-Za-z0-9_-]+$")
NAME_MAX = 100
RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}
SNAP_CAP = 2000                 # snapshots shown at most; the query asks for one more to detect the cap
DAYS_MIN, DAYS_MAX = 1, 365
MAX_ENTRIES = 1000
INDEX_NAME = "awr_index.json"   # app-owned side file in the reports folder: which database a report belongs to (the legacy name has none)
REPORT_RE = re.compile(r"^AWR_Report_(?P<b>\d+)_(?P<e>\d+)_(?P<ts>(?P<d>\d{8})_(?P<t>\d{6}))\.(?P<x>html|txt)$", re.I)
ERROR_RE = re.compile(r"\b(ORA-\d{4,5}|SP2-\d{4}|TNS-\d{5}|PLS-\d{5}|ERROR at line \d+)", re.I)
GENERATED_RE = re.compile(r"^Report generated at:\s*(.+?)\s*$", re.M)
TS_FMT = "%Y-%m-%d %H:%M:%S"
SHOW_FMT = "%d-%b-%Y %H:%M:%S"


class AwrError(RuntimeError):
    """A readable AWR problem (SQL*Plus / Oracle message, invalid input, missing report file)."""


@dataclass(frozen=True)
class Snap:
    snap_id: int
    begin: datetime
    end: datetime | None
    instance: int
    startup: datetime | None = None

    @property
    def shown(self) -> str:
        return self.begin.strftime(SHOW_FMT).upper()


@dataclass(frozen=True)
class SnapList:
    snaps: list
    capped: bool = False


# ------------------------------------------------------------------ validation
def validate_days(value) -> int:
    """Days back as an integer 1..365; raises AwrError otherwise."""
    text = str(value).strip()
    if not re.fullmatch(r"\d{1,4}", text):
        raise AwrError(f"Days back must be a whole number from {DAYS_MIN} to {DAYS_MAX}.")
    days = int(text)
    if not DAYS_MIN <= days <= DAYS_MAX:
        raise AwrError(f"Days back must be from {DAYS_MIN} to {DAYS_MAX}.")
    return days


def parse_snap_id(text: str, label: str) -> int:
    text = (text or "").strip()
    if not text:
        raise AwrError(f"{label} is empty.")
    if not re.fullmatch(r"\d{1,18}", text):
        raise AwrError(f"{label} must be a whole number (digits only).")
    return int(text)


@dataclass
class RangeCheck:
    ok: bool
    level: str = "muted"     # muted | warn | bad
    message: str = ""
    begin: int | None = None
    end: int | None = None


def check_range(begin_text: str, end_text: str, loaded=()) -> RangeCheck:
    """Validate the typed range. Empty / non-numeric / Begin >= End are errors; IDs outside the loaded list and a probable
    instance restart between two loaded snapshots are warnings (the range is still allowed)."""
    b_blank, e_blank = not (begin_text or "").strip(), not (end_text or "").strip()
    if b_blank and e_blank:
        return RangeCheck(False, "muted", "Select a Begin and an End snapshot (or type the snapshot IDs).")
    if b_blank or e_blank:
        return RangeCheck(False, "muted", f"{'Begin' if b_blank else 'End'} Snap ID is empty - select a snapshot or type its ID.")
    try:
        b = parse_snap_id(begin_text, "Begin Snap ID")
        e = parse_snap_id(end_text, "End Snap ID")
    except AwrError as exc:
        return RangeCheck(False, "bad", str(exc))
    if b >= e:
        return RangeCheck(False, "bad", "Begin Snap ID must be lower than End Snap ID.", b, e)
    by_id = {s.snap_id: s for s in loaded}
    notes = []
    missing = [name for name, v in (("Begin", b), ("End", e)) if by_id and v not in by_id]
    if missing:
        notes.append(f"{' and '.join(missing)} Snap ID {'is' if len(missing) == 1 else 'are'} not in the loaded list - Oracle will reject it if it does not exist.")
    elif not by_id:
        notes.append("No snapshot list is loaded - the IDs cannot be checked here.")
    sb, se = by_id.get(b), by_id.get(e)
    if sb and se and sb.startup and se.startup and sb.startup != se.startup:
        notes.append("The instance was restarted between these snapshots; Oracle cannot report across a restart.")
    if notes:
        return RangeCheck(True, "warn", " ".join(notes), b, e)
    return RangeCheck(True, "muted", f"Range {b} to {e} is valid.", b, e)


# ------------------------------------------------------------------ snapshot list
def format_duration(minutes: float) -> str:
    m = int(round(minutes))
    if m < 180:
        return f"{m} mins"
    h, r = divmod(m, 60)
    return f"{h}h {r:02d}m"


def pair_rows(snaps) -> list:
    """Sequential pairs without repeats: [(s1, s2), (s3, s4), ...]; an odd last snapshot is (sN, None)."""
    snaps = list(snaps)
    return [(snaps[i], snaps[i + 1] if i + 1 < len(snaps) else None) for i in range(0, len(snaps), 2)]


def row_duration(left: Snap, right: Snap | None) -> str:
    """Span covered by one table row: from the left snapshot's time to the right one's ('-' when there is no right one)."""
    if right is None:
        return "-"
    return format_duration((right.begin - left.begin).total_seconds() / 60)


def _ts(text: str):
    text = text.strip()
    return datetime.strptime(text, TS_FMT) if text else None


def parse_snapshots(text: str) -> SnapList:
    """Parse the output of the snapshot query (see session.AWR_SNAP_SQL). Raises AwrError for errors or a missing end marker."""
    rows, done = [], False
    for line in text.splitlines():
        line = line.strip()
        if line == "SNAPDONE":
            done = True
        elif line.startswith("SNAP|"):
            parts = line.split("|")
            try:
                rows.append(Snap(int(parts[1]), _ts(parts[2]), _ts(parts[3]), int(parts[4]), _ts(parts[5]) if len(parts) > 5 else None))
            except (ValueError, IndexError):
                raise AwrError(f"Unexpected snapshot row: {line[:120]}") from None
    if not done:
        raise AwrError(error_text(text) or "The snapshot query did not complete (no result marker was returned).")
    rows.sort(key=lambda s: s.snap_id)
    capped = len(rows) > SNAP_CAP
    if capped:
        rows = rows[-SNAP_CAP:]    # the query returns the most recent first, so the newest 2000 are kept
    return SnapList(rows, capped)


# ------------------------------------------------------------------ errors
def error_lines(text: str, limit: int = 6) -> list:
    lines = []
    for raw in (text or "").splitlines():
        line = raw.strip()
        if line and ERROR_RE.search(line) and line not in lines:
            lines.append(line)
    return lines[:limit]


def error_text(text: str) -> str:
    return "\n".join(error_lines(text))


# ------------------------------------------------------------------ report files
def report_name_pattern(begin=None, end=None) -> str:
    return f"AWR_Report_{begin if begin is not None else '<begin>'}_{end if end is not None else '<end>'}_<yyyymmdd_HHMMSS>.html"


def default_name(begin=None, end=None) -> str:
    """Initial Report Name (no extension): the legacy pattern AWR_Report_<begin>_<end>_<timestamp>."""
    return f"AWR_Report_{begin if begin is not None else '<begin>'}_{end if end is not None else '<end>'}_{NAME_TOKEN}"


def resolve_name(name: str, now) -> str:
    return name.replace(NAME_TOKEN, now.strftime("%Y%m%d_%H%M%S"))


def check_report_name(name: str, fmt: str = "html", folder=None, now=None) -> str:
    """'' when the name is acceptable, else a readable reason. Letters, digits, _ and - only (plus the timestamp token): no
    path, drive, dots/extension, spaces or SQL*Plus-special characters; Windows device names are refused; an existing file in
    today's report folder is never overwritten."""
    from datetime import datetime
    if fmt not in FORMATS:
        return "Unknown report type."
    if not name:
        return "Report Name is empty."
    if name.count(NAME_TOKEN) > 1:
        return f"{NAME_TOKEN} may appear only once."
    stem = name.replace(NAME_TOKEN, "")
    if any(c in stem for c in "/\\:") or ".." in stem:
        return "Report Name must be a plain file name: no folders, drive or '..'."
    if "." in stem:
        return f"Do not type an extension or dots; {FORMATS[fmt]} is added automatically."
    if stem and not NAME_RE.match(stem):
        return "Use only letters, digits, '_' and '-' (no spaces or other characters)."
    resolved = resolve_name(name, now or datetime.now())
    if len(resolved) > NAME_MAX:
        return f"Report Name is too long (maximum {NAME_MAX} characters)."
    if resolved.upper() in RESERVED:
        return f"'{resolved}' is a reserved Windows device name."
    if folder is not None and NAME_TOKEN not in name and (Path(folder) / (resolved + FORMATS[fmt])).exists():   # token names: the services check at run time
        return f"{resolved}{FORMATS[fmt]} already exists in today's report folder - choose another name."
    return ""


def reported_path(output: str):
    """Path from the script's final 'Report generated at: <path>' line (None when absent)."""
    found = GENERATED_RE.findall(output or "")
    return Path(found[-1]) if found else None


def awr_files(folder: Path, b=None, e=None) -> set:
    """AWR report files directly inside one folder (optionally only for one snapshot range)."""
    out = set()
    try:
        for entry in os.scandir(folder):
            m = REPORT_RE.match(entry.name)
            if m and entry.is_file() and (b is None or (int(m["b"]), int(m["e"])) == (b, e)):
                out.add(Path(entry.path))
    except OSError:
        pass
    return out


def check_report_file(path: Path, fmt: str = "html", marker: str = "WORKLOAD REPOSITORY") -> None:
    """Raise AwrError unless the file looks like a real AWR report of that type (SQL*Plus spools errors into the file too)."""
    try:
        size = path.stat().st_size
        with open(path, "rb") as fh:
            head = fh.read(8192).decode("utf-8", errors="replace")
            small = fh.read(60000).decode("utf-8", errors="replace") if size < 65536 else ""
    except OSError as exc:
        raise AwrError(f"The report file cannot be read: {exc}") from None
    if fmt == "text":
        if marker.upper() not in head.upper():
            raise AwrError(error_text(head) or "The report file does not contain an AWR text report (Oracle returned no report output).")
        if size < 2048 and error_lines(head):
            raise AwrError(error_text(head))
        return
    if "<html" not in head.lower():
        raise AwrError(error_text(head) or "The report file does not contain an HTML report (Oracle returned no report output).")
    if size < 4096 and error_lines(head + small):
        raise AwrError(error_text(head + small))


# ------------------------------------------------------------------ history
@dataclass(frozen=True)
class ReportEntry:
    path: Path
    name: str
    db: str
    when: datetime
    begin: int
    end: int
    size: int
    simulated: bool

    @property
    def date_key(self) -> str:
        return self.when.strftime("%Y-%m-%d")

    @property
    def range_text(self) -> str:
        return f"{self.begin} - {self.end}"


@dataclass
class HistoryScan:
    entries: list = field(default_factory=list)
    exists: bool = True
    note: str = ""


def _key(base: Path, path: Path) -> str:
    try:
        return path.relative_to(base).as_posix()
    except ValueError:
        return path.name


def index_dir_for(root) -> Path:
    """Where the AWR/ASH/ADDM history indexes live: the shared <root>\\config folder (the reports themselves stay in <root>\\reports)."""
    return Path(root) / "config"


def _read_index(folder: Path, name: str) -> dict:
    try:
        data = json.loads((Path(folder) / name).read_text(encoding="utf-8"))
        reports = data.get("reports", {}) if isinstance(data, dict) else {}
        return {k: v for k, v in reports.items() if isinstance(k, str) and isinstance(v, dict)}
    except (OSError, ValueError):
        return {}


def load_index(base: Path, name: str = INDEX_NAME, index_dir=None) -> dict:
    """Entries keyed by path relative to `base` (the reports folder). Stored in index_dir (default: base itself).
    An index left in the reports folder by an earlier version is still read (entries in index_dir win), so no history is lost."""
    folder = Path(index_dir) if index_dir is not None else Path(base)
    if folder == Path(base):
        return _read_index(base, name)
    return {**_read_index(base, name), **_read_index(folder, name)}


def _write_index(base: Path, name: str, reports: dict, index_dir=None) -> None:
    """Atomic write to index_dir (created if needed); an old index in the reports folder is removed only after the new one is safely written."""
    folder = Path(index_dir) if index_dir is not None else Path(base)
    folder.mkdir(parents=True, exist_ok=True)
    tmp = folder / (name + ".tmp")
    tmp.write_text(json.dumps({"version": 1, "reports": reports}, indent=1), encoding="utf-8")
    os.replace(tmp, folder / name)
    if folder != Path(base):
        try:
            (Path(base) / name).unlink()
        except OSError:
            pass                                 # missing or locked: harmless, the copy in the index folder is the one that counts


def record_report(base: Path, path: Path, db: str, simulated: bool, begin=None, end=None, rac: bool = False, when=None, index_name: str = INDEX_NAME,
                  index_dir=None) -> str:
    """Remember what we know about a report we generated (its file name may be custom). Returns '' or a problem text."""
    base = Path(base)
    try:
        reports = load_index(base, index_name, index_dir)
        meta = {"db": db, "simulated": bool(simulated), "rac": bool(rac)}
        if begin is not None and end is not None:
            meta.update(begin=int(begin), end=int(end))
        if when is not None:
            meta["when"] = when.strftime(TS_FMT)
        reports[_key(base, Path(path))] = meta
        _write_index(base, index_name, reports, index_dir)
        return ""
    except OSError as exc:
        return f"The report was created, but its details could not be saved: {exc}"


def scan_history(report_base: Path, regex=None, index_name: str = INDEX_NAME, index_dir=None) -> HistoryScan:
    """All AWR reports under reports\\<any folder>\\ (and directly in reports\\). Names come from the file name only."""
    base = Path(report_base)
    scan = HistoryScan(exists=base.is_dir())
    if not scan.exists:
        return scan
    regex = regex or REPORT_RE                     # AWR_Report_<b>_<e>_<ts>; ADDM passes its own pattern and index file
    index = load_index(base, index_name, index_dir)
    files = []
    try:
        for top in os.scandir(base):
            if top.is_dir():
                try:
                    files += [Path(e.path) for e in os.scandir(top.path) if e.is_file()]
                except OSError:
                    scan.note = "Some report folders could not be read."
            elif top.is_file():
                files.append(Path(top.path))
    except OSError as exc:
        scan.note = f"The reports folder cannot be read: {exc}"
    found = []
    for path in files:
        meta = index.get(_key(base, path), {})
        m = regex.match(path.name)
        try:
            if m:                                    # legacy name: range and time come from the name itself
                found.append((datetime.strptime(m["d"] + m["t"], "%Y%m%d%H%M%S"), path, int(m["b"]), int(m["e"])))
            elif "begin" in meta and "end" in meta and path.suffix.lower() in (".html", ".txt"):   # custom name we generated
                try:
                    when = datetime.strptime(meta["when"], TS_FMT)
                except (KeyError, ValueError, TypeError):
                    when = datetime.fromtimestamp(path.stat().st_mtime)
                found.append((when, path, int(meta["begin"]), int(meta["end"])))
        except (ValueError, OSError, TypeError):
            continue
    found.sort(key=lambda c: (c[0], c[1].name), reverse=True)
    for when, path, b, e in found[:MAX_ENTRIES]:
        meta = index.get(_key(base, path), {})
        try:
            size = path.stat().st_size
        except OSError:
            continue
        scan.entries.append(ReportEntry(path, path.name, str(meta.get("db") or "-"), when, b, e, size, bool(meta.get("simulated"))))
    return scan


def dates_of(entries) -> list:
    return sorted({e.date_key for e in entries}, reverse=True)


def filter_entries(entries, date: str = "", text: str = "") -> list:
    needle = text.strip().lower()
    out = []
    for e in entries:
        if date and e.date_key != date:
            continue
        hay = " ".join((e.name, e.db, e.range_text, e.date_key, e.when.strftime("%H:%M"))).lower()
        if needle and needle not in hay:
            continue
        out.append(e)
    return out
