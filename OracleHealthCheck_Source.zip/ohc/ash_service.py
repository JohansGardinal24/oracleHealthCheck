"""ASH report generation for the Database Reports page (no Qt; runs in the GUI's worker thread).

Same plumbing as ohc.awr_service: launcher profile/Oracle Home/credentials, SQL*Plus session (login on stdin only, private temp
folder, cancellation) or the fake session when OHC_FAKE_ORACLE is set.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from ohc import ash, awr
from ohc.awr_service import AwrResult, _cleanup, _fail, _msg, _simulated
from ohc.checks import engine, launcher
from ohc.checks.cancel import RunCancelled
from ohc.checks.session import ToolError


@dataclass
class AshResult(AwrResult):
    period: tuple | None = None      # (begin, end) the report really covers


def generate_report(ctx, db_name: str, window: ash.Window, cancel=None, fmt: str = "html", name=None, rac: bool = False) -> AshResult:
    """Success only when a valid, non-empty report file exists. Never overwrites; incomplete files are removed again."""
    sim = _simulated()
    target, ours = None, False

    def failed(headline, exc):
        r = _fail("ash", db_name, sim, headline, exc)
        return AshResult(**{**r.__dict__})

    try:
        if not isinstance(window, ash.Window):
            raise ash.AshError("No valid time window was supplied.")
        if fmt not in awr.FORMATS:
            raise ash.AshError("Report type must be HTML or Text.")
        if window.mode == "absolute":
            ash.absolute_window(window.begin.year, window.begin.month, window.begin.day, window.begin.hour, window.begin.minute,
                                window.begin.second, window.duration)          # re-check against the clock at run time
        else:
            ash.relative_window(-window.minutes_back)
        now = datetime.now()
        entry, home, env, th = launcher._prepare(ctx, db_name, False)
        folder = Path(ctx.root) / "reports" / engine.format_dotnet_date(now, env["REPORT_DATE_FORMAT"])
        shown = name if name is not None else ash.DEFAULT_NAME
        problem = awr.check_report_name(shown, fmt, folder, now)
        if problem:
            raise ash.AshError(problem)
        target = folder / (awr.resolve_name(shown, now) + awr.FORMATS[fmt])
        try:
            folder.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise ToolError(f"Cannot create the report folder {folder}: {exc}") from None
        if target.exists():                                   # also covers two runs of a token name within one second
            raise ash.AshError(f"{target.name} already exists in today's report folder - choose another name.")
        ours = True
        if cancel is not None:
            cancel.check()
        with launcher._open(ctx, entry, home, env, th, cancel) as session:
            simulated = bool(getattr(session, "simulated", False))
            output = session.ash_report(target, fmt, rac, window)
        if not target.is_file():
            raise ash.AshError(awr.error_text(output) or "SQL*Plus finished, but no ASH report file was created.")
        try:
            if target.stat().st_size == 0:
                raise ash.AshError("Oracle returned an empty ASH report (no ASH data for that time window, or no output).")
            awr.check_report_file(target, fmt, ash.MARKER)
        except ash.AshError:
            _cleanup([target])
            raise
        except awr.AwrError as exc:
            _cleanup([target])
            raise ash.AshError(str(exc)) from None
    except RunCancelled:
        if ours and target is not None:
            _cleanup([target])
        return AshResult("ash", False, True, _msg(sim, "ASH report generation was cancelled; the incomplete file was removed."), db=db_name, simulated=sim)
    except (awr.AwrError, ToolError) as exc:
        if ours and target is not None:
            _cleanup([target])
        return failed("The ASH report was not created.", exc)
    except Exception as exc:
        if ours and target is not None:
            _cleanup([target])
        return failed("The ASH report was not created (unexpected error).", repr(exc))
    period = ash.period_from_output(output) or window.span(now)
    note = ash.record_report(Path(ctx.root) / "reports", target, db_name, simulated, period[0], period[1], rac, now, index_dir=awr.index_dir_for(ctx.root))
    text = f"ASH report created: {target.name} ({period[0]:%d-%b-%Y %H:%M:%S} to {period[1]:%d-%b-%Y %H:%M:%S})"
    return AshResult("ash", True, message=_msg(simulated, text), path=target, db=db_name, simulated=simulated, note=note, period=period)
