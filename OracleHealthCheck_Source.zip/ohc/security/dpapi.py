"""Windows DPAPI (CurrentUser scope) through ctypes. No PowerShell, no subprocess.

    protect(data, entropy)   -> bytes      encrypted blob (safe to store)
    unprotect(blob, entropy) -> bytearray  decrypted data; the caller must wipe() it after use

Errors carry only the operation name and the Win32 error code, never data.
"""
from __future__ import annotations

import ctypes
import sys

DESCRIPTION = "OracleHealthCheck credential"
_UI_FORBIDDEN = 0x1  # CRYPTPROTECT_UI_FORBIDDEN. The machine-wide flag is deliberately never used.


class DpapiError(RuntimeError):
    def __init__(self, operation: str, code: int):
        super().__init__(f"DPAPI {operation} failed (Win32 error {code})")
        self.operation = operation
        self.code = code


class DpapiUnavailableError(RuntimeError):
    """Windows DPAPI is not available on this platform."""


def wipe(buffer: bytearray) -> None:
    """Overwrite a bytearray with zeros in place (best effort)."""
    buffer[:] = bytes(len(buffer))


def _check(data, entropy, what: str) -> None:
    if not isinstance(data, (bytes, bytearray)):
        raise TypeError(f"{what} must be bytes or bytearray")
    if len(data) == 0:
        raise ValueError(f"{what} must not be empty")
    if not isinstance(entropy, (bytes, bytearray)):
        raise TypeError("entropy must be bytes or bytearray")


def protect(data, entropy=b"") -> bytes:
    _check(data, entropy, "data")
    return _windows_protect(data, entropy)


def unprotect(blob, entropy=b"") -> bytearray:
    _check(blob, entropy, "blob")
    return _windows_unprotect(blob, entropy)


def _api():  # pragma: no cover - exercised only on Windows
    if sys.platform != "win32":
        raise DpapiUnavailableError("Windows DPAPI is only available on Windows")
    from ctypes import wintypes

    class DATA_BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

    crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    blob_p = ctypes.POINTER(DATA_BLOB)
    crypt32.CryptProtectData.argtypes = [
        blob_p, wintypes.LPCWSTR, blob_p, ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, blob_p]
    crypt32.CryptProtectData.restype = wintypes.BOOL
    crypt32.CryptUnprotectData.argtypes = [
        blob_p, ctypes.c_void_p, blob_p, ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, blob_p]
    crypt32.CryptUnprotectData.restype = wintypes.BOOL
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    return crypt32, kernel32, DATA_BLOB


def _blob_for(DATA_BLOB, data, copy: bool):  # pragma: no cover - exercised only on Windows
    """Return (blob, array). A bytearray is referenced without copying; the caller wipes its own buffer."""
    n = len(data)
    if copy or not isinstance(data, bytearray):
        array = (ctypes.c_char * n).from_buffer_copy(data)
    else:
        array = (ctypes.c_char * n).from_buffer(data)
    return DATA_BLOB(n, ctypes.cast(array, ctypes.POINTER(ctypes.c_char))), array


def _windows_protect(data, entropy) -> bytes:  # pragma: no cover - exercised only on Windows
    crypt32, kernel32, DATA_BLOB = _api()
    plain_blob, plain_array = _blob_for(DATA_BLOB, data, copy=False)
    plain_is_copy = not isinstance(data, bytearray)  # our private copy of immutable bytes: wipe it afterwards
    entropy_blob = entropy_array = None
    if len(entropy):
        entropy_blob, entropy_array = _blob_for(DATA_BLOB, entropy, copy=True)
    out = DATA_BLOB()
    try:
        ok = crypt32.CryptProtectData(
            ctypes.byref(plain_blob), DESCRIPTION,
            ctypes.byref(entropy_blob) if entropy_blob is not None else None,
            None, None, _UI_FORBIDDEN, ctypes.byref(out))
        if not ok:
            raise DpapiError("protect", ctypes.get_last_error())
        try:
            return ctypes.string_at(out.pbData, out.cbData)  # the encrypted blob is not secret
        finally:
            kernel32.LocalFree(ctypes.cast(out.pbData, ctypes.c_void_p))
    finally:
        if plain_is_copy:
            ctypes.memset(plain_array, 0, len(data))


def _windows_unprotect(blob, entropy) -> bytearray:  # pragma: no cover - exercised only on Windows
    crypt32, kernel32, DATA_BLOB = _api()
    in_blob, in_array = _blob_for(DATA_BLOB, blob, copy=True)
    entropy_blob = entropy_array = None
    if len(entropy):
        entropy_blob, entropy_array = _blob_for(DATA_BLOB, entropy, copy=True)
    out = DATA_BLOB()
    ok = crypt32.CryptUnprotectData(
        ctypes.byref(in_blob), None,
        ctypes.byref(entropy_blob) if entropy_blob is not None else None,
        None, None, _UI_FORBIDDEN, ctypes.byref(out))
    if not ok:
        raise DpapiError("unprotect", ctypes.get_last_error())
    try:
        n = out.cbData
        result = bytearray(n)
        if n:
            ctypes.memmove((ctypes.c_char * n).from_buffer(result), out.pbData, n)  # no intermediate bytes copy
        return result
    finally:
        if out.pbData:
            ctypes.memset(out.pbData, 0, out.cbData)  # zero the native plaintext before freeing it
            kernel32.LocalFree(ctypes.cast(out.pbData, ctypes.c_void_p))