"""The Windows account running the application, read from the process token.

The SID is the authoritative identity. The account name is only a label.
Nothing is read from environment variables such as USERNAME.
"""
from __future__ import annotations

import ctypes
import sys
from dataclasses import dataclass


class IdentityError(RuntimeError):
    """The current Windows identity could not be determined."""


@dataclass(frozen=True)
class WinIdentity:
    sid: str      # e.g. S-1-5-21-...-1001 (authoritative)
    account: str  # account name without domain (label only)
    domain: str   # domain or computer name ("" if unknown)

    @property
    def qualified_name(self) -> str:
        return f"{self.domain}\\{self.account}" if self.domain else self.account


def current_identity() -> WinIdentity:
    if sys.platform != "win32":
        raise IdentityError("Windows account identity is only available on Windows")
    return _windows_identity()


def _windows_identity() -> WinIdentity:  # pragma: no cover - exercised only on Windows
    from ctypes import wintypes

    TOKEN_QUERY = 0x0008
    TOKEN_USER_CLASS = 1  # TokenUser
    ERROR_INSUFFICIENT_BUFFER = 122

    class SID_AND_ATTRIBUTES(ctypes.Structure):
        _fields_ = [("Sid", ctypes.c_void_p), ("Attributes", wintypes.DWORD)]

    class TOKEN_USER(ctypes.Structure):
        _fields_ = [("User", SID_AND_ATTRIBUTES)]

    advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    kernel32.GetCurrentProcess.argtypes = []
    kernel32.GetCurrentProcess.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    advapi32.OpenProcessToken.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE)]
    advapi32.OpenProcessToken.restype = wintypes.BOOL
    advapi32.GetTokenInformation.argtypes = [
        wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
    advapi32.GetTokenInformation.restype = wintypes.BOOL
    advapi32.ConvertSidToStringSidW.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
    advapi32.ConvertSidToStringSidW.restype = wintypes.BOOL
    advapi32.LookupAccountSidW.argtypes = [
        wintypes.LPCWSTR, ctypes.c_void_p, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD),
        wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD), ctypes.POINTER(ctypes.c_int)]
    advapi32.LookupAccountSidW.restype = wintypes.BOOL

    token = wintypes.HANDLE()
    if not advapi32.OpenProcessToken(kernel32.GetCurrentProcess(), TOKEN_QUERY, ctypes.byref(token)):
        raise IdentityError(f"OpenProcessToken failed (Win32 error {ctypes.get_last_error()})")
    try:
        needed = wintypes.DWORD(0)
        advapi32.GetTokenInformation(token, TOKEN_USER_CLASS, None, 0, ctypes.byref(needed))
        if ctypes.get_last_error() != ERROR_INSUFFICIENT_BUFFER or needed.value == 0:
            raise IdentityError(f"GetTokenInformation (size) failed (Win32 error {ctypes.get_last_error()})")
        buf = ctypes.create_string_buffer(needed.value)  # must stay alive while sid_ptr is used
        if not advapi32.GetTokenInformation(token, TOKEN_USER_CLASS, buf, needed, ctypes.byref(needed)):
            raise IdentityError(f"GetTokenInformation failed (Win32 error {ctypes.get_last_error()})")
        sid_ptr = TOKEN_USER.from_buffer(buf).User.Sid
        if not sid_ptr:
            raise IdentityError("the process token contains no user SID")

        sid_text_ptr = ctypes.c_void_p()
        if not advapi32.ConvertSidToStringSidW(sid_ptr, ctypes.byref(sid_text_ptr)):
            raise IdentityError(f"ConvertSidToStringSidW failed (Win32 error {ctypes.get_last_error()})")
        try:
            sid = ctypes.wstring_at(sid_text_ptr.value)
        finally:
            kernel32.LocalFree(sid_text_ptr)

        account, domain = sid, ""  # fallback label if the name cannot be resolved
        name_len, dom_len, use = wintypes.DWORD(0), wintypes.DWORD(0), ctypes.c_int(0)
        advapi32.LookupAccountSidW(None, sid_ptr, None, ctypes.byref(name_len), None, ctypes.byref(dom_len),
                                   ctypes.byref(use))
        if ctypes.get_last_error() == ERROR_INSUFFICIENT_BUFFER and name_len.value:
            name_buf = ctypes.create_unicode_buffer(name_len.value)
            dom_buf = ctypes.create_unicode_buffer(max(dom_len.value, 1))
            if advapi32.LookupAccountSidW(None, sid_ptr, name_buf, ctypes.byref(name_len), dom_buf,
                                          ctypes.byref(dom_len), ctypes.byref(use)):
                account, domain = name_buf.value, dom_buf.value
        return WinIdentity(sid=sid, account=account, domain=domain)
    finally:
        kernel32.CloseHandle(token)