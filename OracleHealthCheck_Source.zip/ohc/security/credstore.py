r"""Per-database encrypted credentials: credentials\<database-id>.dat (Windows DPAPI, CurrentUser).

File layout:  b"OHCC" + version byte + DPAPI blob
Payload:      version byte | u16 username length | username | u16 password length | password
The DPAPI entropy binds each blob to its database id. Username and password are both encrypted.
Errors never contain credential values; a damaged or unreadable file is never modified by load().
"""
from __future__ import annotations

import hmac
import os
import re
import secrets
import time
from pathlib import Path

from ohc.security import dpapi
from ohc.security.dpapi import DpapiError

MAGIC = b"OHCC"
FORMAT_VERSION = 1
HEADER = MAGIC + bytes([FORMAT_VERSION])
ENTROPY_PREFIX = b"OracleHealthCheck.credentials.v1|"
ID_RE = re.compile(r"^[0-9a-f]{16,32}$")
MAX_FIELD = 1024
MAX_FILE = 64 * 1024


class CredentialError(RuntimeError):
    def __init__(self, message: str, category: str):
        super().__init__(message)
        self.category = category


class CredentialNotFoundError(CredentialError):
    def __init__(self, db_id: str):
        super().__init__(f"No credentials are stored for database '{db_id}'", "missing")


class CredentialUnreadableError(CredentialError):
    """category 'format' (damaged file) or 'decrypt' (another Windows account, reset profile, ...)."""


class Credentials:
    """Decrypted username and password held as bytearrays. Call wipe() or use 'with'."""
    __slots__ = ("username", "password")

    def __init__(self, username: bytearray, password: bytearray):
        self.username = username
        self.password = password

    def wipe(self) -> None:
        dpapi.wipe(self.username)
        dpapi.wipe(self.password)

    def __enter__(self):
        return self

    def __exit__(self, *exc_info) -> None:
        self.wipe()

    def __repr__(self) -> str:
        return "Credentials(<hidden>)"

    __str__ = __repr__

    def __reduce__(self):
        raise TypeError("Credentials cannot be pickled")


def new_database_id() -> str:
    return secrets.token_hex(8)


def _check_id(db_id) -> str:
    if not isinstance(db_id, str) or not ID_RE.match(db_id):
        raise ValueError("invalid database id")
    return db_id


def _path(credentials_dir, db_id) -> Path:
    return Path(credentials_dir) / f"{_check_id(db_id)}.dat"


def _entropy(db_id: str) -> bytes:
    return ENTROPY_PREFIX + db_id.encode("ascii")


def _field(value, what: str) -> bytearray:
    if isinstance(value, str):
        raw = bytearray(value.encode("utf-8"))
    elif isinstance(value, (bytes, bytearray)):
        raw = bytearray(value)
    else:
        raise TypeError(f"{what} must be str, bytes or bytearray")
    if not 1 <= len(raw) <= MAX_FIELD:
        dpapi.wipe(raw)
        raise ValueError(f"{what} must be 1 to {MAX_FIELD} bytes")
    return raw


def _pack(username: bytearray, password: bytearray) -> bytearray:
    payload = bytearray(5 + len(username) + len(password))  # preallocated: no reallocation copies
    payload[0] = FORMAT_VERSION
    payload[1:3] = len(username).to_bytes(2, "big")
    payload[3:3 + len(username)] = username
    at = 3 + len(username)
    payload[at:at + 2] = len(password).to_bytes(2, "big")
    payload[at + 2:] = password
    return payload


def _unpack(payload: bytearray) -> Credentials:
    if len(payload) < 5 or payload[0] != FORMAT_VERSION:
        raise ValueError("bad payload")
    ulen = int.from_bytes(payload[1:3], "big")
    at = 3 + ulen
    if not 1 <= ulen <= MAX_FIELD or len(payload) < at + 2:
        raise ValueError("bad payload")
    plen = int.from_bytes(payload[at:at + 2], "big")
    if not 1 <= plen <= MAX_FIELD or len(payload) != at + 2 + plen:
        raise ValueError("bad payload")
    return Credentials(bytearray(payload[3:3 + ulen]), bytearray(payload[at + 2:]))


def _damaged(db_id: str) -> CredentialUnreadableError:
    return CredentialUnreadableError(
        f"The credential file for database '{db_id}' is damaged (format). It was left unchanged; re-enter the credentials.",
        "format")


def _read_credentials(path: Path, db_id: str, backend) -> Credentials:
    try:
        raw = path.read_bytes()  # the encrypted file is not secret
    except FileNotFoundError:
        raise CredentialNotFoundError(db_id) from None
    except OSError as exc:
        raise CredentialError(f"Cannot read the credential file for database '{db_id}': {exc.strerror or type(exc).__name__}", "io") from None
    if len(raw) > MAX_FILE or len(raw) <= len(HEADER) or not raw.startswith(HEADER):
        raise _damaged(db_id)
    try:
        payload = backend.unprotect(raw[len(HEADER):], _entropy(db_id))
    except DpapiError as exc:
        raise CredentialUnreadableError(
            f"The credentials for database '{db_id}' cannot be decrypted (Win32 error {exc.code}). They may belong to another "
            "Windows account, or the profile was reset. The file was left unchanged; re-enter the credentials.",
            "decrypt") from None
    try:
        return _unpack(payload)
    except ValueError:
        raise _damaged(db_id) from None
    finally:
        dpapi.wipe(payload)


def _quarantine_if_unreadable(target: Path, db_id: str, backend) -> None:
    """Keep an unreadable existing file as <id>.dat.corrupt-<time>; never delete it."""
    if not target.exists():
        return
    try:
        _read_credentials(target, db_id, backend).wipe()
    except CredentialUnreadableError:
        stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
        dest, n = target.with_name(f"{target.name}.corrupt-{stamp}"), 2
        while dest.exists():
            dest = target.with_name(f"{target.name}.corrupt-{stamp}-{n}")
            n += 1
        os.replace(target, dest)


def save_credentials(credentials_dir, db_id: str, username, password, *, backend=dpapi) -> None:
    target = _path(credentials_dir, db_id)
    user_bytes = _field(username, "username")
    try:
        pass_bytes = _field(password, "password")
        try:
            payload = _pack(user_bytes, pass_bytes)
        finally:
            dpapi.wipe(pass_bytes)
    finally:
        dpapi.wipe(user_bytes)
    tmp = target.with_name(f"{target.name}.tmp{os.getpid()}")
    try:
        try:
            blob = backend.protect(payload, _entropy(db_id))
        except DpapiError as exc:
            raise CredentialError(f"Encryption failed (Win32 error {exc.code}); nothing was saved.", "encrypt") from None
        data = HEADER + blob
        target.parent.mkdir(parents=True, exist_ok=True)
        tmp.unlink(missing_ok=True)
        with open(tmp, "xb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        try:
            check = backend.unprotect(blob, _entropy(db_id))  # round-trip verification before replacing anything
        except DpapiError as exc:
            raise CredentialError(
                f"The encrypted credentials could not be verified (Win32 error {exc.code}); nothing was saved.", "verify") from None
        try:
            same = hmac.compare_digest(check, payload)
        finally:
            dpapi.wipe(check)
        if not same:
            raise CredentialError("The encrypted credentials failed verification; nothing was saved.", "verify")
        _quarantine_if_unreadable(target, db_id, backend)
        os.replace(tmp, target)
    finally:
        dpapi.wipe(payload)
        tmp.unlink(missing_ok=True)


def load_credentials(credentials_dir, db_id: str, *, backend=dpapi) -> Credentials:
    return _read_credentials(_path(credentials_dir, db_id), db_id, backend)


def has_credentials(credentials_dir, db_id: str) -> bool:
    return _path(credentials_dir, db_id).is_file()


def delete_credentials(credentials_dir, db_id: str) -> bool:
    try:
        _path(credentials_dir, db_id).unlink()
        return True
    except FileNotFoundError:
        return False