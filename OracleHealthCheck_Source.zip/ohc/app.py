"""Application entry logic: the GUI by default, plus small switches used to verify a build.

    OracleHealthCheck.exe                          start the GUI
    OracleHealthCheck.exe --selftest [--out FILE]    environment + Qt + SQL bundle check
    OracleHealthCheck.exe --verify-sql [--out FILE]  SQL bundle integrity only
Exit code 0 = OK, 1 = a check failed, 2 = bad arguments.
--out writes the same text to FILE (the packaged EXE has no console window).
"""
from __future__ import annotations

import platform
import sys
from pathlib import Path

from ohc import __version__, paths

USAGE = ("usage: OracleHealthCheck [--selftest | --verify-sql] [--out FILE]\n"
         "       OracleHealthCheck --run 1|2|3 --db NAME [--root DIR]      (1 Oracle, 2 Sync, 3 All)\n"
         "       OracleHealthCheck --test-connection --db NAME [--root DIR]")


def _sql_status():
    from ohc.resources import sql_access

    problems = sql_access.verify()
    if problems:
        return False, ["SQL bundle INTEGRITY FAILURE:"] + [f"  - {p}" for p in problems]
    return True, [f"SQL bundle OK: {len(sql_access.list_sql())} scripts, sha256 {sql_access.bundle_sha256()}"]


def _qt_status():
    from PySide6 import __version__ as pyside_version
    from PySide6.QtCore import qVersion
    from PySide6.QtWidgets import QApplication

    qapp = QApplication.instance() or QApplication([sys.argv[0]])
    return True, [f"Qt {qVersion()} (PySide6 {pyside_version}), platform plugin: {qapp.platformName()}"]


def _identity_status():
    if sys.platform != "win32":
        return True, ["Windows account: n/a (not Windows)"]
    from ohc import userstore
    from ohc.security.identity import current_identity

    who = current_identity()
    folder, exists = userstore.locate_user_dir(paths.app_root(), who)
    state = "exists" if exists else "not created yet"
    return True, [
        f"Windows account: {who.qualified_name}",
        f"Account SID: {who.sid}",
        f"User folder: {folder} [{state}]",
    ]
    

def _dpapi_status():
    if sys.platform != "win32":
        return True, ["DPAPI: n/a (not Windows)"]
    import os

    from ohc.security import credstore, dpapi

    probe = bytearray(os.urandom(32))  # dummy data: no real credentials, nothing is written to disk
    entropy = b"OracleHealthCheck.selftest"
    blob = dpapi.protect(probe, entropy)
    restored = dpapi.unprotect(blob, entropy)
    try:
        ok = bytes(restored) == bytes(probe)
    finally:
        dpapi.wipe(restored)
        dpapi.wipe(probe)
    if not ok:
        return False, ["DPAPI: round trip MISMATCH"]
    credstore.new_database_id()  # also proves the credential store module is bundled
    return True, [f"DPAPI: CurrentUser round trip OK ({len(blob)}-byte blob); credential store module loaded"]


def _config_status():
    from ohc.config import environment, thresholds
    from ohc.config.jsonio import ConfigFileError

    config = paths.app_root() / "config"
    lines, ok = [], True
    for name, load, missing in (("thresholds.json", thresholds.load_thresholds, thresholds.ThresholdsMissingError),
                                ("environment.json", environment.load_environment, environment.EnvConfigMissingError)):
        try:
            lines.append(f"Config {name}: OK (sha256 {load(config / name).sha256[:12]})")
        except missing:
            lines.append(f"Config {name}: not found (copy the config folder next to the EXE)")
        except (thresholds.ThresholdsError, ConfigFileError) as exc:
            ok = False
            lines.append(f"Config {name}: INVALID - {str(exc).splitlines()[0]}")
    return ok, lines


def selftest(check_qt: bool = True, sql_only: bool = False):
    """Return (ok, lines). Never raises: a failing check is reported as text."""
    lines, ok = [], True
    if not sql_only:
        lines += [
            f"OracleHealthCheck {__version__}",
            f"frozen: {paths.is_frozen()}",
            f"python: {platform.python_version()} ({platform.architecture()[0]})",
            f"app root: {paths.app_root()}",
        ]
    if sql_only:
        checks = [_sql_status]
    else:
        checks = ([_qt_status] if check_qt else []) + [_identity_status, _dpapi_status, _config_status, _sql_status]
    for check in checks:
        try:
            good, out = check()
        except Exception as exc:  
            good, out = False, [
                f"{check.__name__} FAILED: {type(exc).__name__}: {exc}"
            ]
        ok = ok and good
        lines += out
    lines.append("RESULT: OK" if ok else "RESULT: FAILED")
    return ok, lines


def run_gui() -> int:
    from PySide6.QtWidgets import QApplication, QMessageBox

    from ohc.gui.context import AppContext
    from ohc.gui.main_window import MainWindow

    qapp = QApplication(sys.argv[:1])
    qapp.setApplicationName("Oracle Health Check")
    try:
        context = AppContext.for_current_user()
    except Exception as exc:  # identity or per-user folder problem: explain and stop
        QMessageBox.critical(None, "Oracle Health Check", f"The per-user data folder cannot be used:\n\n{exc}")
        return 1
    window = MainWindow(context)
    window.show()
    for problem in context.problems:
        QMessageBox.warning(window, "Oracle Health Check", problem)
    return qapp.exec()


def main(argv: list) -> int:
    args = list(argv)
    out = None
    if "--out" in args:
        i = args.index("--out")
        if i + 1 >= len(args):
            print(USAGE)
            return 2
        out = args[i + 1]
        del args[i:i + 2]
    if args == []:
        if out is not None:
            print(USAGE)
            return 2
        return run_gui()
    if args in (["--selftest"], ["--verify-sql"]):
        ok, lines = selftest(sql_only=(args == ["--verify-sql"]))
        text = "\n".join(lines)
        print(text)  # silently does nothing in the windowed EXE (no console)
        if out:
            Path(out).write_text(text + "\n", encoding="utf-8", newline="\n")
        return 0 if ok else 1
    if args and args[0] in ("--run", "--test-connection"):
        from ohc.checks.launcher import cli
        return cli(args)
    print(USAGE)
    return 2
