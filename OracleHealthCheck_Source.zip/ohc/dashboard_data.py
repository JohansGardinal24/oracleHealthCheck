"""Dashboard data (no Qt): everything comes from files the application itself writes - the run logs (per-check summary lines) and
the shared reports folder (health, AWR, ASH and ADDM reports). Nothing here contacts a database."""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from ohc import addm, ash, awr
from ohc.gui import report_index as ri

SUMMARY_RE = re.compile(r"^\[(?P<n>\d+)\] (?P<name>.+?) : (?P<status>[A-Z]+)\s+-\s+(?P<msg>.*)$")
SEVERITY = {"CRITICAL": 0, "WARNING": 1, "CANCELLED": 2}
MAX_RECENT_CHECKS, MAX_RECENT_REPORTS = 8, 3


@dataclass(frozen=True)
class CheckRow:
    check_id: str          # "CHK_01"
    name: str
    status: str            # OK / WARNING / CRITICAL / INFO / SKIPPED ...
    message: str


@dataclass
class RunSummary:
    db: str = ""
    when: datetime | None = None
    simulated: bool = False
    rows: list = field(default_factory=list)      # every check of the latest run, in run order
    overall: str = ""
    log: Path | None = None

    def count(self, *statuses) -> int:
        return sum(1 for r in self.rows if r.status in statuses)

    @property
    def total(self) -> int:
        return len(self.rows)

    @property
    def healthy(self) -> int:
        return self.count("OK", "INFO")          # informational results are not problems

    @property
    def warnings(self) -> int:
        return self.count("WARNING")

    @property
    def critical(self) -> int:
        return self.count("CRITICAL")

    @property
    def other(self) -> int:
        return self.total - self.healthy - self.warnings - self.critical

    @property
    def db_reachable(self):
        """True/False from check 1 (database status) of the latest run; None when there is no run yet."""
        first = next((r for r in self.rows if r.check_id == "CHK_01"), None)
        return None if first is None else first.status in ("OK", "WARNING", "INFO")

    def recent(self, limit: int = MAX_RECENT_CHECKS) -> list:
        """Problems first (critical, warning), then run order - at most `limit` rows."""
        order = {id(r): i for i, r in enumerate(self.rows)}
        return sorted(self.rows, key=lambda r: (SEVERITY.get(r.status, 3), order[id(r)]))[:limit]


@dataclass(frozen=True)
class ReportRow:
    kind: str              # Health / AWR / ASH / ADDM
    name: str
    when: datetime
    path: Path
    simulated: bool = False


def latest_run(log_dir: Path, db: str) -> RunSummary:
    """The newest run log of `db` (ohc_<db>_<yyyymmdd>_<HHMMSS>.log) -> its per-check summary. Empty summary when there is none.
    Only file names are scanned; one log is read."""
    summary = RunSummary(db=db)
    best = None
    try:
        for e in os.scandir(log_dir):
            m = ri.LOG_RE.match(e.name) if e.is_file() else None
            when = ri._when(m) if m else None
            if when is not None and m.group("db").lower() == db.lower() and (best is None or (when, e.name) > (best[0], best[1].name)):
                best = (when, Path(e.path))
    except OSError:
        return summary
    if best is None:
        return summary
    summary.when, summary.log = best
    try:
        status, _completed, _total, summary.simulated = ri.parse_log(best[1])
        summary.overall = status
        seen = {}
        with open(best[1], "r", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                m = SUMMARY_RE.match(line.rstrip("\r\n"))
                if m:
                    seen[int(m["n"])] = CheckRow(f"CHK_{int(m['n']):02d}", m["name"].strip(), m["status"], m["msg"].strip())
    except OSError:
        return summary
    summary.rows = [seen[k] for k in sorted(seen)]
    return summary


def _recent_health(report_base: Path, limit: int) -> list:
    found = []
    try:
        for top in os.scandir(report_base):
            if top.is_dir():
                for e in os.scandir(top.path):
                    m = ri.REPORT_RE.match(e.name) if e.is_file() else None
                    when = ri._when(m) if m else None
                    if when is not None:
                        found.append((when, Path(e.path)))
    except OSError:
        pass
    found.sort(key=lambda c: (c[0], c[1].name), reverse=True)
    rows = []
    for when, path in found[:limit]:
        try:
            simulated = ri.parse_report(path)[2]
        except OSError:
            simulated = False
        rows.append(ReportRow("Health", path.name, when, path, simulated))
    return rows


def recent_reports(report_base: Path, log_dir: Path = None, limit: int = MAX_RECENT_REPORTS, index_dir=None) -> list:
    """Newest health, AWR, ASH and ADDM reports of the shared reports folder, newest first (names and file sizes only are scanned)."""
    base = Path(report_base)
    if not base.is_dir():
        return []
    rows = _recent_health(base, limit)
    for kind, scan in (("AWR", awr.scan_history(base, index_dir=index_dir)), ("ASH", ash.scan_history(base, index_dir=index_dir)),
                       ("ADDM", addm.scan_history(base, index_dir=index_dir))):
        for e in scan.entries[:limit]:
            rows.append(ReportRow(kind, e.name, e.when, e.path, e.simulated))
    rows.sort(key=lambda r: (r.when, r.name), reverse=True)
    return rows[:limit]
