"""Per-Windows-user folder: user\\<label>\\ under the install root.

The SID stored in owner.json is the authoritative owner; the folder name is only a label.
A folder owned by another SID is never used or modified, and a corrupt owner.json is never
overwritten or deleted.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from ohc import __version__
from ohc.security.identity import WinIdentity, current_identity

SCHEMA_VERSION = 1
OWNER_FILE = "owner.json"
SID_RE = re.compile(r"^S-1-\d+(?:-\d+)+$", re.IGNORECASE)
MAX_LABEL = 64
RESERVED = {"CON", "PRN", "AUX", "NUL"} | {f"COM{i}" for i in range(1, 10)} | {f"LPT{i}" for i in range(1, 10)}


class UserStoreError(RuntimeError):
    """Base class for user-folder problems."""


class OwnershipError(UserStoreError):
    """The folder belongs to a different Windows account (SID mismatch)."""


class CorruptOwnerFileError(UserStoreError):
    """owner.json is unreadable or invalid. The file is left untouched."""


@dataclass(frozen=True)
class UserDir:
    folder: Path
    owner_file: Path
    credentials: Path
    files: Path
    work: Path
    created: bool

    @property
    def label(self) -> str:
        return self.folder.name


def folder_label(account: str, sid: str) -> str:
    """A safe folder name for an account name (a label only; the SID decides ownership)."""
    label = "".join(ch if (ch.isalnum() or ch in "._- ") else "_" for ch in account)
    label = label.strip(" .")[:MAX_LABEL].strip(" .")
    if not label:
        label = "".join(ch if (ch.isalnum() or ch == "-") else "_" for ch in sid)[:MAX_LABEL]
    if label.split(".")[0].strip().upper() in RESERVED:
        label = "_" + label
    return label


def read_owner(path: Path) -> dict:
    """Read and validate owner.json. Error messages never include the file content."""
    try:
        raw = path.read_bytes()
    except OSError as exc:
        raise UserStoreError(f"cannot read {OWNER_FILE} in '{path.parent.name}': {exc.strerror or type(exc).__name__}") from None
    try:
        doc = json.loads(raw.decode("utf-8-sig"))
    except (UnicodeDecodeError, ValueError, RecursionError):
        raise CorruptOwnerFileError(
            f"{OWNER_FILE} in '{path.parent.name}' is not valid JSON; the file was left unchanged") from None
    version = doc.get("schema_version") if isinstance(doc, dict) else None
    sid = doc.get("sid") if isinstance(doc, dict) else None
    if isinstance(version, bool) or not isinstance(version, int) or not isinstance(sid, str) or not SID_RE.match(sid):
        raise CorruptOwnerFileError(
            f"{OWNER_FILE} in '{path.parent.name}' has missing or invalid fields; the file was left unchanged")
    if version > SCHEMA_VERSION:
        raise UserStoreError(f"{OWNER_FILE} in '{path.parent.name}' was written by a newer version of the application")
    return doc


def _is_plain_dir(entry: os.DirEntry) -> bool:
    return entry.is_dir(follow_symlinks=False) and not entry.is_symlink() and not entry.is_junction()


def _folders_owned_by(base: Path, sid: str) -> list:
    """Existing user folders whose owner.json carries this SID (other folders' problems are ignored)."""
    found = []
    try:
        with os.scandir(base) as it:
            entries = sorted(it, key=lambda e: e.name)
    except OSError as exc:
        raise UserStoreError(f"cannot list the user directory: {exc.strerror or type(exc).__name__}") from None
    for entry in entries:
        owner = Path(entry.path) / OWNER_FILE
        if not _is_plain_dir(entry) or not owner.is_file():
            continue
        try:
            doc = read_owner(owner)
        except UserStoreError:
            continue
        if doc["sid"].upper() == sid.upper():
            found.append(Path(entry.path))
    return found


def locate_user_dir(install_root: Path, identity: WinIdentity) -> tuple:
    """Read-only. Return (folder, exists). exists=False means 'would be created at folder'."""
    if not SID_RE.match(identity.sid):
        raise UserStoreError("the Windows identity has an invalid SID")
    base = Path(install_root) / "user"
    label = folder_label(identity.account, identity.sid)
    candidate = base / label
    if not base.is_dir():
        return candidate, False
    owned = _folders_owned_by(base, identity.sid)
    if len(owned) > 1:
        raise UserStoreError("more than one user folder claims this Windows account: "
                             + ", ".join(f"'{p.name}'" for p in owned) + "; an administrator must remove the extra folder")
    if owned:
        return owned[0], True
    if not candidate.exists():
        return candidate, False
    if not candidate.is_dir():
        raise UserStoreError(f"'{label}' exists in the user directory but is not a folder")
    owner = candidate / OWNER_FILE
    if owner.exists():
        read_owner(owner)  # raises CorruptOwnerFileError / UserStoreError when unusable
        raise OwnershipError(
            f"User folder '{label}' belongs to a different Windows account (SID mismatch) and was not used; "
            "an administrator must rename or remove it")
    if any(candidate.iterdir()):
        raise UserStoreError(f"user folder '{label}' exists without {OWNER_FILE} and is not empty; it was not claimed")
    return candidate, False  # empty folder: safe to claim


def ensure_user_dir(install_root: Path, identity: WinIdentity | None = None) -> UserDir:
    """Find or create this Windows account's folder (credentials\\, files\\work\\) and owner.json."""
    identity = identity or current_identity()
    folder, exists = locate_user_dir(install_root, identity)
    owner_file = folder / OWNER_FILE
    if not exists:
        base = Path(install_root) / "user"
        base.mkdir(parents=True, exist_ok=True)
        if folder.resolve().parent != base.resolve():
            raise UserStoreError("the derived user folder is outside the user directory")
        folder.mkdir(exist_ok=True)
        doc = {
            "schema_version": SCHEMA_VERSION,
            "sid": identity.sid,
            "account": identity.account,
            "domain": identity.domain,
            "created_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "app_version": __version__,
        }
        tmp = folder / f"{OWNER_FILE}.tmp{os.getpid()}"
        tmp.write_text(json.dumps(doc, indent=2) + "\n", encoding="utf-8", newline="\n")
        os.replace(tmp, owner_file)
        if read_owner(owner_file)["sid"].upper() != identity.sid.upper():  # lost a race with another account
            raise OwnershipError(f"User folder '{folder.name}' was claimed by a different Windows account at the same time")
    credentials, files = folder / "credentials", folder / "files"
    work = files / "work"
    for p in (credentials, files, work):
        p.mkdir(parents=True, exist_ok=True)
    return UserDir(folder, owner_file, credentials, files, work, created=not exists)