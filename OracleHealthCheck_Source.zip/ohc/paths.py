"""Where the application lives. Phase 1 will extend this with the shared/user folders."""
from __future__ import annotations

import os
import sys
from pathlib import Path


def is_frozen() -> bool:
    """True when running from the packaged EXE."""
    return bool(getattr(sys, "frozen", False))


def app_root() -> Path:
    """Install root: the folder that contains OracleHealthCheck.exe.

    Packaged: derived from the EXE location (the OHC_DEV_HOME override is ignored).
    Development: <project>\\dev_home, or the folder named by OHC_DEV_HOME.
    """
    if is_frozen():
        return Path(sys.executable).resolve().parent
    override = os.environ.get("OHC_DEV_HOME")
    if override:
        return Path(override).resolve()
    return Path(__file__).resolve().parent.parent / "dev_home"