"""ASH report logic without Qt: time-window rules, report history, text/file checks (shared helpers come from ohc.awr).

Window semantics (the same as the legacy ASH_Report.sql):
  relative  - begin = now - N, end = now; "now" is the DATABASE's SYSDATE when the report starts; the duration is ignored.
  absolute  - begin as given, end = begin + duration.
The report itself is made by DBMS_WORKLOAD_REPOSITORY.ASH_REPORT_HTML/_TEXT (single instance) or ASH_GLOBAL_REPORT_HTML/_TEXT (RAC),
see ohc.checks.session.ash_variant_sql. The original ASH_Report.sql is not changed and not used.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path

from ohc import awr
from ohc.awr import AwrError

UNITS = {"minutes": 1, "hours": 60, "days": 1440}          # minutes per unit
REL_MAX_MIN = 7 * 1440                                      # relative window: at most 7 days back
DUR_MIN, DUR_MAX = 1, 1440                                  # duration: 1 minute .. 24 hours
ABS_MAX_AGE_DAYS = 30                                       # specific begin time: at most 30 days back (Oracle may keep less)
INDEX_NAME = "ash_index.json"
MARKER = "ASH REPORT"                                       # text of every ASH report header (HTML title and text banner)
DEFAULT_NAME = "ASH_Report_" + awr.NAME_TOKEN
REPORT_RE = re.compile(r"^ASH_Report_(?P<d>\d{8})_(?P<t>\d{6})\.(?P<x>html|txt)$", re.I)
MAX_ENTRIES = 1000
TS = "%Y-%m-%d %H:%M:%S"
SHOW = "%d-%b-%Y %H:%M:%S"


class AshError(AwrError):
    """Invalid ASH input or a failed ASH run (a readable message)."""


@dataclass(frozen=True)
class Window:
    mode: str                         # "relative" | "absolute"
    minutes_back: int = 0             # relative: N minutes before now
    begin: datetime | None = None     # absolute
    duration: int = 0                 # absolute minutes

    def span(self, now: datetime | None = None) -> tuple:
        """(begin, end). Relative windows use `now` (the real run uses the database's SYSDATE)."""
        if self.mode == "relative":
            now = (now or datetime.now()).replace(microsecond=0)
            return now - timedelta(minutes=self.minutes_back), now
        return self.begin, self.begin + timedelta(minutes=self.duration)

    @property
    def minutes(self) -> int:
        return self.minutes_back if self.mode == "relative" else self.duration

    def describe(self, now: datetime | None = None) -> str:
        if self.mode == "relative":
            return f"last {format_minutes(self.minutes_back)}: now - {format_minutes(self.minutes_back)} to now (now = database time when the report starts)"
        b, e = self.span()
        return f"{b.strftime(SHOW).upper()} to {e.strftime(SHOW).upper()} ({format_minutes(self.duration)})"


def format_minutes(m: int) -> str:
    m = int(m)
    if m % 1440 == 0 and m >= 1440:
        d = m // 1440
        return f"{d} day{'s' if d != 1 else ''}"
    if m % 60 == 0 and m >= 120:
        return f"{m // 60} hours"
    return f"{m} min" if m == 1 else f"{m} mins"


def relative_window(value, unit: str = "minutes") -> Window:
    """value: -15 means 15 units before now. Must be a negative whole number; at most 7 days."""
    if unit not in UNITS:
        raise AshError("Unknown time unit.")
    text = str(value).strip()
    if not re.fullmatch(r"-?\d{1,6}", text):
        raise AshError("The relative time must be a whole number such as -15.")
    n = int(text)
    if n >= 0:
        raise AshError("The relative time must be negative (for example -15 = 15 minutes before now).")
    minutes = -n * UNITS[unit]
    if minutes > REL_MAX_MIN:
        raise AshError("The relative time is limited to 7 days (10080 minutes) before now.")
    return Window("relative", minutes_back=minutes)


def validate_duration(value) -> int:
    text = str(value).strip()
    if not re.fullmatch(r"\d{1,6}", text):
        raise AshError(f"Duration must be a whole number of minutes from {DUR_MIN} to {DUR_MAX}.")
    n = int(text)
    if not DUR_MIN <= n <= DUR_MAX:
        raise AshError(f"Duration must be from {DUR_MIN} to {DUR_MAX} minutes (24 hours).")
    return n


def absolute_window(year, month, day, hour, minute, second, duration, now: datetime | None = None) -> Window:
    """Specific begin time + duration. Rejects impossible dates, a begin in the future, one older than 30 days, and an end in the future."""
    now = (now or datetime.now()).replace(microsecond=0)
    n = validate_duration(duration)
    try:
        begin = datetime(int(year), int(month), int(day), int(hour), int(minute), int(second))
    except (ValueError, TypeError):
        raise AshError(f"{month}/{day}/{year} {hour}:{int(minute):02d}:{int(second):02d} is not a valid date and time.") from None
    if begin > now:
        raise AshError("The begin time is in the future.")
    if begin < now - timedelta(days=ABS_MAX_AGE_DAYS):
        raise AshError(f"The begin time is more than {ABS_MAX_AGE_DAYS} days ago; ASH data that old is normally not available.")
    end = begin + timedelta(minutes=n)
    if end > now:
        raise AshError(f"Begin time + {n} minutes ends in the future ({end.strftime(SHOW).upper()}); shorten the duration or start earlier.")
    return Window("absolute", begin=begin, duration=n)


# ------------------------------------------------------------------ history
@dataclass(frozen=True)
class AshEntry:
    path: Path
    name: str
    db: str
    when: datetime
    begin: datetime | None
    end: datetime | None
    size: int
    simulated: bool
    rac: bool = False

    @property
    def date_key(self) -> str:
        return self.when.strftime("%Y-%m-%d")

    @property
    def range_text(self) -> str:                  # used by the shared search filter
        return f"{self.begin.strftime(TS) if self.begin else ''} {self.end.strftime(TS) if self.end else ''}".strip()

    @property
    def duration_text(self) -> str:
        return awr.format_duration((self.end - self.begin).total_seconds() / 60) if self.begin and self.end else "-"


@dataclass
class HistoryScan:
    entries: list = field(default_factory=list)
    exists: bool = True
    note: str = ""


def record_report(base: Path, path: Path, db: str, simulated: bool, begin: datetime, end: datetime, rac: bool = False, when=None, index_dir=None) -> str:
    """Remember the real window and database of a report we generated. Returns '' or a problem text (never raises)."""
    base = Path(base)
    try:
        reports = awr.load_index(base, INDEX_NAME, index_dir)
        meta = {"db": db, "simulated": bool(simulated), "rac": bool(rac), "begin": begin.strftime(TS), "end": end.strftime(TS)}
        if when is not None:
            meta["when"] = when.strftime(TS)
        reports[awr._key(base, Path(path))] = meta
        awr._write_index(base, INDEX_NAME, reports, index_dir)
        return ""
    except OSError as exc:
        return f"The report was created, but its details could not be saved: {exc}"


def _ts(value):
    try:
        return datetime.strptime(value, TS)
    except (TypeError, ValueError):
        return None


def scan_history(report_base: Path, index_dir=None) -> HistoryScan:
    """ASH reports under reports\\<any folder>\\: legacy-named ASH_Report_<yyyymmdd>_<HHMMSS>.html/.txt and reports we generated
    under a custom name (listed in ash_index.json). AWR, ADDM, health and other files are never listed."""
    base = Path(report_base)
    scan = HistoryScan(exists=base.is_dir())
    if not scan.exists:
        return scan
    index = awr.load_index(base, INDEX_NAME, index_dir)
    files = []
    try:
        for top in os.scandir(base):
            if top.is_dir():
                try:
                    files += [Path(e.path) for e in os.scandir(top.path) if e.is_file()]
                except OSError:
                    scan.note = "Some report folders could not be read."
            elif top.is_file():
                files.append(Path(top.path))
    except OSError as exc:
        scan.note = f"The reports folder cannot be read: {exc}"
    found = []
    for path in files:
        meta = index.get(awr._key(base, path), {})
        m = REPORT_RE.match(path.name)
        when = None
        if m:
            try:
                when = datetime.strptime(m["d"] + m["t"], "%Y%m%d%H%M%S")
            except ValueError:
                continue
        elif meta and path.suffix.lower() in (".html", ".txt") and _ts(meta.get("begin")) and _ts(meta.get("end")):
            when = _ts(meta.get("when"))
            if when is None:
                try:
                    when = datetime.fromtimestamp(path.stat().st_mtime)
                except OSError:
                    continue
        if when is not None:
            found.append((when, path, meta))
    found.sort(key=lambda c: (c[0], c[1].name), reverse=True)
    for when, path, meta in found[:MAX_ENTRIES]:
        try:
            size = path.stat().st_size
        except OSError:
            continue
        scan.entries.append(AshEntry(path, path.name, str(meta.get("db") or "-"), when, _ts(meta.get("begin")), _ts(meta.get("end")),
                                     size, bool(meta.get("simulated")), bool(meta.get("rac"))))
    return scan


def period_from_output(output: str):
    """(begin, end) from the script's 'ASH_PERIOD|<begin>|<end>' line (the window Oracle was really asked for), else None."""
    m = re.search(r"^ASH_PERIOD\|(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)\|(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)\s*$", output or "", re.M)
    return (_ts(m[1]), _ts(m[2])) if m else None
